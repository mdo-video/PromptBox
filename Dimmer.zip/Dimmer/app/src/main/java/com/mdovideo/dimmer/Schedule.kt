package com.mdovideo.dimmer

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import androidx.core.content.ContextCompat
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

/** Programmazione: si accende da solo all'ora (o al tramonto) e si spegne all'ora di fine. */
object Schedule {
    const val ACTION = "com.mdovideo.dimmer.SCHEDULE"
    const val EXTRA_ON = "on"
    private const val REQUEST = 100

    /** Vero se [now] cade nella finestra [start]–[end]; vale anche se la finestra passa la mezzanotte. */
    fun isInside(now: LocalTime, start: LocalTime, end: LocalTime): Boolean =
        if (start < end) now >= start && now < end else now >= start || now < end

    fun hasLocationPermission(c: Context) =
        ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Salva l'ultima posizione nota del telefono (serve solo per calcolare il tramonto). */
    fun refreshLocation(c: Context) {
        if (!hasLocationPermission(c)) return
        runCatching {
            val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val best = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER, LocationManager.GPS_PROVIDER)
                .mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
                .maxByOrNull { it.time }
            if (best != null) Prefs.setLocation(c, best.latitude, best.longitude)
        }
    }

    /** Ora di inizio per [date]: il tramonto, se scelto e calcolabile, altrimenti l'orario fisso. */
    fun startTime(c: Context, date: LocalDate): LocalTime {
        if (Prefs.scheduleSunset(c) && Prefs.hasLocation(c)) {
            Sun.sunset(date, Prefs.lat(c), Prefs.lon(c))?.let { return it }
        }
        val m = Prefs.scheduleStart(c)
        return LocalTime.of(m / 60, m % 60)
    }

    fun endTime(c: Context): LocalTime {
        val m = Prefs.scheduleEnd(c)
        return LocalTime.of(m / 60, m % 60)
    }

    fun inWindow(c: Context, now: ZonedDateTime = ZonedDateTime.now()): Boolean =
        isInside(now.toLocalTime(), startTime(c, now.toLocalDate()), endTime(c))

    /** Tramonto di oggi, per mostrarlo nella schermata. */
    fun todaySunset(c: Context): LocalTime? =
        if (Prefs.hasLocation(c)) Sun.sunset(LocalDate.now(), Prefs.lat(c), Prefs.lon(c)) else null

    private fun pending(c: Context, on: Boolean): PendingIntent =
        PendingIntent.getBroadcast(
            c, REQUEST,
            Intent(c, ScheduleReceiver::class.java).setAction(ACTION).putExtra(EXTRA_ON, on),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    /** Imposta la sveglia del prossimo accendi/spegni (o la toglie se la programmazione è spenta). */
    fun arm(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (!Prefs.scheduleEnabled(c)) {
            am.cancel(pending(c, true))
            return
        }
        val zone = ZoneId.systemDefault()
        val now = ZonedDateTime.now(zone)
        val candidates = ArrayList<Pair<ZonedDateTime, Boolean>>()
        for (offset in 0L..2L) {
            val day = now.toLocalDate().plusDays(offset)
            candidates += day.atTime(startTime(c, day)).atZone(zone) to true
            candidates += day.atTime(endTime(c)).atZone(zone) to false
        }
        val next = candidates.filter { it.first.isAfter(now) }.minByOrNull { it.first } ?: return
        val at = next.first.toInstant().toEpochMilli()
        val pi = pending(c, next.second)
        val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        runCatching {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }.onFailure { runCatching { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) } }
    }

    /** Dopo una modifica: rimette la sveglia e, se adesso si è dentro la finestra, accende subito. */
    fun sync(c: Context) {
        refreshLocation(c)
        arm(c)
        if (Prefs.scheduleEnabled(c) && inWindow(c) && !Prefs.enabled(c)) DimmerService.start(c)
    }

    fun onAlarm(c: Context, on: Boolean) {
        if (on) DimmerService.start(c) else DimmerService.stop(c)
        arm(c)
    }
}
