package com.mdovideo.dimmer

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.BrightnessLow
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Schedule as ScheduleIcon
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WbTwilight
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.time.LocalTime
import kotlin.math.roundToInt

internal val CardShape = RoundedCornerShape(28.dp)

private fun hhmm(minutes: Int) = "%02d:%02d".format(minutes / 60, minutes % 60)
private fun hhmm(t: LocalTime) = "%02d:%02d".format(t.hour, t.minute)

@Composable
internal fun PermissionCard() {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    Card(
        shape = CardShape,
        colors = CardDefaults.cardColors(containerColor = cs.tertiaryContainer, contentColor = cs.onTertiaryContainer),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Warning, null)
                Spacer(Modifier.width(12.dp))
                Text("Serve un permesso", style = MaterialTheme.typography.titleMedium)
            }
            Text("Per oscurare lo schermo serve \"Mostra sopra altre app\".", style = MaterialTheme.typography.bodyMedium)
            Button(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            }) { Text("Apri impostazioni") }
        }
    }
}

/** Interruttore principale: un tocco su tutta la card accende o spegne. */
@Composable
internal fun MainToggleCard(enabled: Boolean, onToggle: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        shape = CardShape,
        colors = CardDefaults.cardColors(
            containerColor = if (enabled) cs.primaryContainer else cs.surfaceContainerHigh,
            contentColor = if (enabled) cs.onPrimaryContainer else cs.onSurface,
        ),
        modifier = Modifier.clip(CardShape).clickable { onToggle(!enabled) },
    ) {
        Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(
                shape = CircleShape,
                color = if (enabled) cs.primary else cs.surfaceContainerHighest,
                contentColor = if (enabled) cs.onPrimary else cs.onSurfaceVariant,
            ) {
                Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) { Icon(Icons.Filled.NightsStay, null) }
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text("Oscuramento", style = MaterialTheme.typography.titleLarge)
                Text(if (enabled) "Attivo" else "Spento", style = MaterialTheme.typography.bodyMedium)
            }
            Switch(
                checked = enabled,
                onCheckedChange = null,
                thumbContent = if (enabled) ({ Icon(Icons.Filled.Check, null, Modifier.size(16.dp)) }) else null,
            )
        }
    }
}

@Composable
internal fun PresetsRow(level: Float, warm: Float, onPick: (Preset) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Presets.all.forEach { p ->
            FilterChip(
                selected = p.matches(level, warm),
                onClick = { onPick(p) },
                label = { Text(p.name) },
                leadingIcon = { Icon(p.icon, null, Modifier.size(18.dp)) },
            )
        }
    }
}

@Composable
internal fun LevelCard(level: Float, maxLevel: Float, trusted: Boolean, onChange: (Float) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(shape = CardShape, colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.BrightnessLow, null, tint = cs.primary)
                Spacer(Modifier.width(12.dp))
                Text("Intensità", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                Text("${(level * 100).roundToInt()}%", style = MaterialTheme.typography.headlineMedium, color = cs.primary)
            }
            Slider(value = level.coerceAtMost(maxLevel), onValueChange = onChange, valueRange = Prefs.MIN_LEVEL..maxLevel)
            Text(
                if (trusted) "Fino al 95% grazie al servizio di accessibilità."
                else "Massimo 80%: oltre, Android 12+ non fa più passare i tocchi. Con il servizio di accessibilità si arriva al 95%.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
        }
    }
}

@Composable
internal fun WarmCard(warm: Float, onChange: (Float) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(shape = CardShape, colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.WbTwilight, null, tint = cs.primary)
                Spacer(Modifier.width(12.dp))
                Text("Filtro caldo", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                Text("${(warm * 100).roundToInt()}%", style = MaterialTheme.typography.titleLarge, color = cs.primary)
            }
            Slider(value = warm, onValueChange = onChange, valueRange = 0f..1f)
            Text("Tinta ambra: meno luce blu la sera.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
    }
}

@Composable
internal fun SwitchCard(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        shape = CardShape,
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh),
        modifier = Modifier.clip(CardShape).clickable { onChecked(!checked) },
    ) {
        Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            Spacer(Modifier.width(12.dp))
            Switch(
                checked = checked,
                onCheckedChange = null,
                thumbContent = if (checked) ({ Icon(Icons.Filled.Check, null, Modifier.size(16.dp)) }) else null,
            )
        }
    }
}

/** Servizio di accessibilità: copre anche barra di stato e notifiche, sblocca il 95% e le app escluse. */
@Composable
internal fun AccessibilityCard(tick: Int, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val on = remember(tick) { DimmerAccessibilityService.isEnabled(ctx) }
    var cover by remember(tick) { mutableStateOf(Prefs.coverSystemUi(ctx)) }
    Card(
        shape = CardShape,
        colors = CardDefaults.cardColors(containerColor = if (on) cs.surfaceContainerHigh else cs.secondaryContainer,
            contentColor = if (on) cs.onSurface else cs.onSecondaryContainer),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Accessibility, null, tint = if (on) cs.primary else cs.onSecondaryContainer)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Servizio di accessibilità", style = MaterialTheme.typography.titleMedium)
                    Text(if (on) "Attivo" else "Spento", style = MaterialTheme.typography.bodySmall)
                }
            }
            Text(
                "Serve per oscurare anche barra di stato e notifiche, arrivare al 95% e fermarsi nelle app escluse. Non legge il contenuto dello schermo.",
                style = MaterialTheme.typography.bodySmall,
            )
            if (!on) {
                FilledTonalButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) {
                    Text("Apri impostazioni accessibilità")
                }
                Text(
                    "Se la voce è grigia: Impostazioni › App › Dimmer › ⋮ › Consenti impostazioni con restrizioni, poi riprova.",
                    style = MaterialTheme.typography.bodySmall,
                )
            } else {
                Row(Modifier.fillMaxWidth().clickable {
                    cover = !cover; Prefs.setCoverSystemUi(ctx, cover); DimmerService.refresh(ctx); onChanged()
                }, verticalAlignment = Alignment.CenterVertically) {
                    Text("Copri anche barra notifiche", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = cover, onCheckedChange = null)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TimeDialog(title: String, initial: Int, onDismiss: () -> Unit, onConfirm: (Int) -> Unit) {
    val state = rememberTimePickerState(initialHour = initial / 60, initialMinute = initial % 60, is24Hour = true)
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = MaterialTheme.shapes.extraLarge,
            tonalElevation = 6.dp,
            modifier = Modifier.width(IntrinsicSize.Min).height(IntrinsicSize.Min),
        ) {
            Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(title, Modifier.fillMaxWidth().padding(bottom = 20.dp), style = MaterialTheme.typography.labelMedium)
                TimePicker(state = state)
                Row(Modifier.height(40.dp).fillMaxWidth()) {
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = onDismiss) { Text("Annulla") }
                    TextButton(onClick = { onConfirm(state.hour * 60 + state.minute) }) { Text("OK") }
                }
            }
        }
    }
}

/** Programmazione: accensione a un'ora fissa o al tramonto, spegnimento all'ora scelta. */
@Composable
internal fun ScheduleCard(tick: Int, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var on by remember(tick) { mutableStateOf(Prefs.scheduleEnabled(ctx)) }
    var start by remember(tick) { mutableIntStateOf(Prefs.scheduleStart(ctx)) }
    var end by remember(tick) { mutableIntStateOf(Prefs.scheduleEnd(ctx)) }
    var sunset by remember(tick) { mutableStateOf(Prefs.scheduleSunset(ctx)) }
    var dialog by remember { mutableIntStateOf(0) } // 1 = inizio, 2 = fine

    val locLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            Schedule.sync(ctx)
        } else {
            sunset = false
            Prefs.setScheduleSunset(ctx, false)
            Schedule.arm(ctx)
        }
        onChanged()
    }

    Card(shape = CardShape, colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth().clickable {
                on = !on; Prefs.setScheduleEnabled(ctx, on); Schedule.sync(ctx); onChanged()
            }, verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.ScheduleIcon, null, tint = cs.primary)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Programmazione", style = MaterialTheme.typography.titleMedium)
                    Text("Si accende e si spegne da solo", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
                Switch(checked = on, onCheckedChange = null)
            }
            if (on) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !sunset, onClick = {
                        sunset = false; Prefs.setScheduleSunset(ctx, false); Schedule.sync(ctx); onChanged()
                    }, label = { Text("Orario fisso") })
                    FilterChip(selected = sunset, onClick = {
                        sunset = true; Prefs.setScheduleSunset(ctx, true)
                        if (Schedule.hasLocationPermission(ctx)) { Schedule.sync(ctx); onChanged() }
                        else locLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                    }, label = { Text("Al tramonto") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (sunset) {
                        val t = Schedule.todaySunset(ctx)
                        Text(
                            if (t != null) "Inizio: al tramonto (oggi alle ${hhmm(t)})" else "Inizio: al tramonto (cerco la posizione…)",
                            Modifier.weight(1f).align(Alignment.CenterVertically),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    } else {
                        OutlinedButton(onClick = { dialog = 1 }) { Text("Inizio ${hhmm(start)}") }
                    }
                    OutlinedButton(onClick = { dialog = 2 }) { Text("Fine ${hhmm(end)}") }
                }
            }
        }
    }

    if (dialog == 1) TimeDialog("Inizio", start, { dialog = 0 }) {
        start = it; Prefs.setScheduleStart(ctx, it); dialog = 0; Schedule.sync(ctx); onChanged()
    }
    if (dialog == 2) TimeDialog("Fine", end, { dialog = 0 }) {
        end = it; Prefs.setScheduleEnd(ctx, it); dialog = 0; Schedule.sync(ctx); onChanged()
    }
}

@Composable
internal fun ExclusionsCard(tick: Int, a11yOn: Boolean, onOpen: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val count = remember(tick) { Prefs.excluded(ctx).size }
    Card(shape = CardShape, colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh)) {
        Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Apps, null, tint = cs.primary)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("App escluse", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (!a11yOn) "Serve il servizio di accessibilità"
                    else if (count == 0) "In nessuna app: l'oscuramento resta sempre acceso"
                    else "$count app: lì l'oscuramento si ferma",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
            }
            Spacer(Modifier.width(12.dp))
            FilledTonalButton(onClick = onOpen, enabled = a11yOn) { Text("Scegli") }
        }
    }
}

@Composable
internal fun UpdateCard(
    info: Updater.Info?,
    currentName: String,
    checking: Boolean,
    progress: Float?,
    message: String?,
    onCheck: () -> Unit,
    onInstall: (Updater.Info) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Card(
        shape = CardShape,
        colors = CardDefaults.cardColors(
            containerColor = if (info != null) cs.secondaryContainer else cs.surfaceContainerHigh,
            contentColor = if (info != null) cs.onSecondaryContainer else cs.onSurface,
        ),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.SystemUpdate, null, tint = if (info != null) cs.onSecondaryContainer else cs.primary)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Aggiornamenti", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (info != null) "Nuova versione disponibile (${info.tag})" else "Versione $currentName",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
            if (progress != null) {
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                Text("Scarico l'aggiornamento… ${(progress * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
            } else if (info != null) {
                Button(onClick = { onInstall(info) }) { Text("Scarica e installa") }
            } else {
                OutlinedButton(onClick = onCheck, enabled = !checking) {
                    if (checking) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                    }
                    Text("Controlla aggiornamenti")
                }
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}
