package com.mdovideo.dimmer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

/**
 * Pannello leggero che si apre sopra l'app in uso toccando la notifica: un cursore grande per regolare
 * l'intensità con un solo trascinamento. Un tocco fuori lo chiude.
 */
class LevelPanelActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DimmerTheme {
                PanelContent(onClose = { finish() }, onOpenApp = {
                    startActivity(android.content.Intent(this, MainActivity::class.java))
                    finish()
                })
            }
        }
    }
}

@Composable
private fun PanelContent(onClose: () -> Unit, onOpenApp: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val maxLevel = remember { Prefs.maxLevel(ctx) }
    var level by remember { mutableStateOf(Prefs.effectiveLevel(ctx)) }
    var warm by remember { mutableStateOf(Prefs.warm(ctx)) }
    val none = remember { MutableInteractionSource() }

    fun apply(preset: Preset) {
        level = preset.level.coerceAtMost(maxLevel)
        warm = preset.warm
        Prefs.setLevel(ctx, level)
        Prefs.setWarm(ctx, warm)
        Prefs.setMinBrightness(ctx, preset.minBrightness)
        DimmerService.start(ctx)
    }

    Box(
        Modifier.fillMaxSize().background(Color(0x66000000)).clickable(interactionSource = none, indication = null, onClick = onClose),
        contentAlignment = Alignment.BottomCenter,
    ) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = cs.surfaceContainerHigh,
            modifier = Modifier
                .navigationBarsPadding()
                .padding(16.dp)
                .fillMaxWidth()
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
        ) {
            Column(Modifier.padding(horizontal = 24.dp, vertical = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Intensità", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                    Text("${(level * 100).roundToInt()}%", style = MaterialTheme.typography.displaySmall, color = cs.primary)
                }
                Slider(
                    value = level.coerceAtMost(maxLevel),
                    onValueChange = {
                        level = it
                        Prefs.setLevel(ctx, it)
                        DimmerService.start(ctx)
                    },
                    valueRange = Prefs.MIN_LEVEL..maxLevel,
                )
                PresetsRow(level = level, warm = warm, onPick = { apply(it) })
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = { DimmerService.stop(ctx); onClose() }) { Text("Spegni") }
                    TextButton(onClick = onOpenApp) { Text("Apri Dimmer") }
                }
            }
        }
    }
}
