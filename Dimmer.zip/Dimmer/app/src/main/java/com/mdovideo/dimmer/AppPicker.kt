package com.mdovideo.dimmer

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private data class AppItem(val pkg: String, val label: String)

private fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
        .distinctBy { it.pkg }
        .filter { it.pkg != ctx.packageName }
        .sortedBy { it.label.lowercase() }
}

/** Elenco delle app installate: spunta quelle in cui l'oscuramento deve fermarsi. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun AppPickerSheet(onDismiss: () -> Unit, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    var selected by remember { mutableStateOf(Prefs.excluded(ctx)) }
    var query by remember { mutableStateOf("") }
    val apps by produceState(initialValue = emptyList<AppItem>()) {
        value = withContext(Dispatchers.IO) { loadApps(ctx) }
    }
    val shown = apps.filter { query.isBlank() || it.label.contains(query, ignoreCase = true) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.fillMaxWidth().fillMaxHeight(0.9f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("App escluse", Modifier.padding(horizontal = 24.dp), style = MaterialTheme.typography.titleLarge)
            Text(
                "In queste app l'oscuramento si ferma da solo e riparte quando ne esci.",
                Modifier.padding(horizontal = 24.dp),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Cerca") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
            )
            LazyColumn(Modifier.fillMaxWidth()) {
                items(shown, key = { it.pkg }) { app ->
                    val icon = remember(app.pkg) {
                        runCatching { ctx.packageManager.getApplicationIcon(app.pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull()
                    }
                    val checked = app.pkg in selected
                    ListItem(
                        headlineContent = { Text(app.label) },
                        leadingContent = {
                            if (icon != null) Image(bitmap = icon, contentDescription = null, modifier = Modifier.size(40.dp))
                        },
                        trailingContent = { Checkbox(checked = checked, onCheckedChange = null) },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        modifier = Modifier.clickable {
                            selected = if (checked) selected - app.pkg else selected + app.pkg
                            Prefs.setExcluded(ctx, selected)
                            DimmerService.refresh(ctx)
                            onChanged()
                        },
                    )
                }
            }
        }
    }
}
