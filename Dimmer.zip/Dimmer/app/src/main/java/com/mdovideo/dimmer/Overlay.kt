package com.mdovideo.dimmer

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.view.View
import android.view.WindowManager

/**
 * Le finestre dell'oscuramento su un WindowManager: una nera (intensità) e, se serve, una ambra (filtro caldo).
 * [type] è TYPE_APPLICATION_OVERLAY per il servizio normale, TYPE_ACCESSIBILITY_OVERLAY per quello di accessibilità.
 * L'intensità è l'alpha della finestra: così resta sotto lo 0,8 che Android 12+ accetta per far passare i tocchi.
 */
class OverlayLayer(private val context: Context, private val type: Int) {

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val views = HashMap<String, View>()
    private val leaving = HashSet<View>()
    private val anims = HashMap<View, Animator>()

    private fun layoutParams(a: Float, brightness: Float): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            this.alpha = a
            this.screenBrightness = brightness
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

    /** Mostra o aggiorna l'oscuramento. [fade] vale solo per le finestre che compaiono ora. */
    fun show(level: Float, warm: Float, minBrightness: Boolean, fade: Boolean) {
        val none = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        if (warm > 0.01f) put("warm", WARM_COLOR, warm * WARM_MAX_ALPHA, none, fade) else drop("warm", fade)
        put("dim", Color.BLACK, level, if (minBrightness) 0f else none, fade)
    }

    /** Toglie tutto, con dissolvenza se [fade]. */
    fun hide(fade: Boolean) {
        views.keys.toList().forEach { drop(it, fade) }
    }

    /** Toglie subito ogni finestra, comprese quelle che stavano sfumando. */
    fun release() {
        anims.values.toList().forEach { it.cancel() }
        anims.clear()
        (views.values + leaving).toList().forEach { runCatching { wm.removeView(it) } }
        views.clear()
        leaving.clear()
    }

    private fun put(key: String, color: Int, a: Float, brightness: Float, fade: Boolean) {
        val lp = layoutParams(a, brightness)
        val existing = views[key]
        if (existing == null) {
            val v = View(context).apply { setBackgroundColor(color) }
            if (fade) lp.alpha = 0f
            runCatching { wm.addView(v, lp) }.onFailure { return }
            views[key] = v
            if (fade) animateAlpha(v, 0f, a, null)
        } else {
            anims.remove(existing)?.cancel()
            runCatching { wm.updateViewLayout(existing, lp) }
        }
    }

    private fun drop(key: String, fade: Boolean) {
        val v = views.remove(key) ?: return
        val lp = v.layoutParams as? WindowManager.LayoutParams
        if (fade && lp != null) {
            leaving.add(v)
            animateAlpha(v, lp.alpha, 0f) {
                leaving.remove(v)
                runCatching { wm.removeView(v) }
            }
        } else {
            anims.remove(v)?.cancel()
            leaving.remove(v)
            runCatching { wm.removeView(v) }
        }
    }

    private fun animateAlpha(v: View, from: Float, to: Float, onEnd: (() -> Unit)?) {
        anims.remove(v)?.cancel()
        val animator = ValueAnimator.ofFloat(from, to)
        animator.duration = FADE_MS
        animator.addUpdateListener { va ->
            val lp = v.layoutParams as? WindowManager.LayoutParams ?: return@addUpdateListener
            lp.alpha = va.animatedValue as Float
            runCatching { wm.updateViewLayout(v, lp) }
        }
        var cancelled = false
        animator.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (anims[v] === animation) anims.remove(v)
                if (!cancelled) onEnd?.invoke()
            }
        })
        anims[v] = animator
        animator.start()
    }

    companion object {
        const val FADE_MS = 280L
        private val WARM_COLOR = Color.rgb(255, 140, 0)
        private const val WARM_MAX_ALPHA = 0.45f
    }
}
