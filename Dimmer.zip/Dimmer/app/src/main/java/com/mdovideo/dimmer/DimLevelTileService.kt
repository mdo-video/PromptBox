package com.mdovideo.dimmer

import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import kotlin.math.roundToInt

/** Secondo tile: a ogni tocco passa al livello successivo (30, 50, 70%, poi il massimo) e riparte da capo. */
class DimLevelTileService : TileService() {

    override fun onStartListening() = refresh()

    override fun onClick() {
        if (!Settings.canDrawOverlays(this)) return
        if (Prefs.enabled(this)) {
            val steps = listOf(0.30f, 0.50f, 0.70f, if (Prefs.trusted(this)) 0.90f else Prefs.MAX_LEVEL)
            val current = Prefs.effectiveLevel(this)
            val next = steps.firstOrNull { it > current + 0.01f } ?: steps.first()
            Prefs.setLevel(this, next)
        }
        DimmerService.start(this)
        refresh()
    }

    private fun refresh() {
        val tile = qsTile ?: return
        tile.state = if (Prefs.enabled(this)) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = "Dimmer ${(Prefs.effectiveLevel(this) * 100).roundToInt()}%"
        tile.updateTile()
    }
}
