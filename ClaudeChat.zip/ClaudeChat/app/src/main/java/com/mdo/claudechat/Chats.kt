package com.mdo.claudechat

data class Msg(val role: String, val text: String)

data class Chat(
    val id: String,
    val title: String,
    val messages: List<Msg>,
    val updated: Long,
)
