package com.mdo.claudechat

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/** Scheda "Nuova versione disponibile" con download e installazione. */
@Composable
fun UpdateCard(info: Updater.Info, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var progress by remember { mutableStateOf<Float?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = cs.tertiaryContainer, contentColor = cs.onTertiaryContainer),
        shape = RoundedCornerShape(24.dp),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.SystemUpdate, null)
                Spacer(Modifier.width(12.dp))
                Text(
                    "Nuova versione disponibile (${info.versionCode})",
                    style = MaterialTheme.typography.titleMedium,
                )
            }
            Spacer(Modifier.height(12.dp))
            Button(
                enabled = progress == null,
                onClick = {
                    message = null
                    progress = 0f
                    scope.launch {
                        Updater.download(context, info) { progress = it }
                            .onSuccess { file ->
                                progress = null
                                message = when (Updater.install(context, file)) {
                                    Updater.InstallResult.NEEDS_PERMISSION ->
                                        "Consenti a Claude Chat di installare app, poi torna qui e premi di nuovo Aggiorna."
                                    Updater.InstallResult.STARTED -> "Conferma l'installazione nella schermata di Android."
                                }
                            }
                            .onFailure {
                                progress = null
                                message = it.message ?: "Download non riuscito."
                            }
                    }
                },
            ) { Text("Aggiorna ora") }

            progress?.let {
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(progress = { it }, modifier = Modifier.fillMaxWidth())
            }
            message?.let {
                Spacer(Modifier.height(10.dp))
                Text(it, fontSize = 13.sp)
            }
        }
    }
}

/** Sezione per le Impostazioni: versione attuale e controllo manuale. */
@Composable
fun UpdateSection() {
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var checking by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var found by remember { mutableStateOf<Updater.Info?>(null) }

    Column {
        Text("Versione installata: ${BuildConfig.VERSION_NAME}", fontSize = 14.sp, color = cs.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            enabled = !checking,
            modifier = Modifier.fillMaxWidth().height(48.dp),
            onClick = {
                checking = true
                status = null
                found = null
                scope.launch {
                    Updater.latest()
                        .onSuccess {
                            if (it.versionCode > BuildConfig.VERSION_CODE) found = it
                            else status = "Sei già all'ultima versione."
                        }
                        .onFailure { status = it.message ?: "Controllo non riuscito." }
                    checking = false
                }
            },
        ) { Text(if (checking) "Controllo..." else "Controlla aggiornamenti") }

        status?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, fontSize = 13.sp)
        }
        found?.let {
            Spacer(Modifier.height(8.dp))
            UpdateCard(it)
        }
    }
}
