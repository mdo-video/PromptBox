package com.mdo.claudechat

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant

/** Limiti residui letti dalle intestazioni di ogni risposta dell'API (tempi in millisecondi epoch). */
data class Limits(
    val reqLimit: Int? = null,
    val reqRemaining: Int? = null,
    val reqReset: Long? = null,
    val tokLimit: Int? = null,
    val tokRemaining: Int? = null,
    val tokReset: Long? = null,
) {
    fun toJson(): String = JSONObject().apply {
        reqLimit?.let { put("rl", it) }
        reqRemaining?.let { put("rr", it) }
        reqReset?.let { put("rt", it) }
        tokLimit?.let { put("tl", it) }
        tokRemaining?.let { put("tr", it) }
        tokReset?.let { put("tt", it) }
    }.toString()

    companion object {
        fun fromJson(raw: String?): Limits? = runCatching {
            if (raw.isNullOrBlank()) return null
            val o = JSONObject(raw)
            fun i(k: String) = if (o.has(k)) o.getInt(k) else null
            fun l(k: String) = if (o.has(k)) o.getLong(k) else null
            Limits(i("rl"), i("rr"), l("rt"), i("tl"), i("tr"), l("tt"))
        }.getOrNull()
    }
}

object ClaudeClient {

    data class Usage(val input: Int, val output: Int)
    data class Reply(val text: String, val usage: Usage, val limits: Limits)

    /** Errore temporaneo (limite raggiunto o server sovraccarico): l'app aspetta e riprova da sola. */
    class Retryable(val waitSeconds: Int, val limits: Limits?, message: String) : RuntimeException(message)

    suspend fun ask(apiKey: String, model: String, history: List<Msg>): Result<Reply> =
        withContext(Dispatchers.IO) {
            runCatching {
                require(apiKey.isNotBlank()) { "Manca la chiave API. Inseriscila nelle Impostazioni." }

                val messages = JSONArray()
                history.forEach { messages.put(JSONObject().put("role", it.role).put("content", it.text)) }
                val body = JSONObject()
                    .put("model", model)
                    .put("max_tokens", 4096)
                    .put("messages", messages)

                val conn = (URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20_000
                    readTimeout = 120_000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("x-api-key", apiKey.trim())
                    setRequestProperty("anthropic-version", "2023-06-01")
                }
                try {
                    conn.outputStream.use { it.write(body.toString().toByteArray()) }
                    val code = conn.responseCode
                    val limits = readLimits(conn)
                    val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                        ?.bufferedReader()?.use { it.readText() }.orEmpty()
                    if (code !in 200..299) {
                        val wait = conn.getHeaderField("retry-after")?.toDoubleOrNull()?.toInt()
                        when (code) {
                            429 -> throw Retryable(
                                (wait ?: 20).coerceIn(1, 120), limits,
                                "Limite raggiunto. Riprovo da solo appena si libera.",
                            )
                            500, 502, 503, 529 -> throw Retryable(
                                (wait ?: 8).coerceIn(1, 60), limits,
                                "Il server Anthropic è sovraccarico. Riprovo da solo.",
                            )
                        }
                        throw RuntimeException(friendlyError(code, text))
                    }
                    parse(text, limits)
                } finally {
                    conn.disconnect()
                }
            }
        }

    private fun parse(json: String, limits: Limits): Reply {
        val root = JSONObject(json)
        val content = root.optJSONArray("content") ?: JSONArray()
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val block = content.getJSONObject(i)
            if (block.optString("type") == "text") sb.append(block.optString("text"))
        }
        val u = root.optJSONObject("usage")
        val usage = Usage(u?.optInt("input_tokens") ?: 0, u?.optInt("output_tokens") ?: 0)
        val text = sb.toString().ifBlank { throw RuntimeException("Risposta vuota. Riprova.") }
        return Reply(text, usage, limits)
    }

    private fun readLimits(conn: HttpURLConnection): Limits {
        fun int(name: String) = conn.getHeaderField(name)?.toIntOrNull()
        fun time(name: String) = conn.getHeaderField(name)?.let { runCatching { Instant.parse(it).toEpochMilli() }.getOrNull() }
        return Limits(
            reqLimit = int("anthropic-ratelimit-requests-limit"),
            reqRemaining = int("anthropic-ratelimit-requests-remaining"),
            reqReset = time("anthropic-ratelimit-requests-reset"),
            tokLimit = int("anthropic-ratelimit-tokens-limit"),
            tokRemaining = int("anthropic-ratelimit-tokens-remaining"),
            tokReset = time("anthropic-ratelimit-tokens-reset"),
        )
    }

    private fun friendlyError(code: Int, body: String): String {
        val apiMsg = runCatching { JSONObject(body).getJSONObject("error").getString("message") }.getOrNull()
        return when (code) {
            400 -> "Richiesta non valida. ${apiMsg.orEmpty()}".trim()
            401 -> "Chiave API non valida. Controllala nelle Impostazioni."
            402 -> "Credito API esaurito. Ricaricalo su console.anthropic.com."
            403 -> "Chiave non autorizzata per questo modello. ${apiMsg.orEmpty()}".trim()
            404 -> "Modello non trovato. Cambia il nome del modello nelle Impostazioni."
            413 -> "La conversazione è troppo lunga. Aprine una nuova."
            else -> "Errore $code. ${apiMsg.orEmpty()}".trim()
        }
    }
}
