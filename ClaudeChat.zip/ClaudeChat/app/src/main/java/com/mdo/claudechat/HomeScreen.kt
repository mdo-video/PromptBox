package com.mdo.claudechat

import android.net.Uri
import androidx.browser.customtabs.CustomTabColorSchemeParams
import androidx.browser.customtabs.CustomTabsIntent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    session: Session,
    hasKey: Boolean,
    update: Updater.Info?,
    onOpen: (Chat) -> Unit,
    onNew: () -> Unit,
    onSettings: () -> Unit,
    onOpenSite: (String) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    // Browser integrato (Chrome Custom Tabs): Google consente l'accesso all'account, a differenza di una WebView.
    val openSite = onOpenSite

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = {},
                actions = {
                    IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, "Impostazioni") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onNew,
                icon = { Icon(Icons.Filled.Add, null) },
                text = { Text("Nuova chat") },
                containerColor = cs.primaryContainer,
                contentColor = cs.onPrimaryContainer,
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 0.dp, 16.dp, 110.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                Column(Modifier.padding(bottom = 6.dp)) {
                    Text("Claude Chat", style = MaterialTheme.typography.displaySmall)
                    Text(
                        "Una sola chat, sempre con te",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                    )
                }
            }
            if (update != null) item { UpdateCard(update) }
            if (!hasKey) {
                item {
                    Card(
                        onClick = onSettings,
                        colors = CardDefaults.cardColors(
                            containerColor = cs.errorContainer,
                            contentColor = cs.onErrorContainer,
                        ),
                        shape = RoundedCornerShape(24.dp),
                    ) {
                        Text(
                            "Per iniziare inserisci la chiave API nelle Impostazioni. Tocca qui.",
                            modifier = Modifier.padding(18.dp),
                        )
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SiteCard("Claude", Modifier.weight(1f)) { openSite("https://claude.ai") }
                    SiteCard("Gemini", Modifier.weight(1f)) { openSite("https://gemini.google.com/app") }
                    SiteCard("Grok", Modifier.weight(1f)) { openSite("https://grok.com") }
                }
            }
            item { UsageCard(session.limits, session.todayIn, session.todayOut) }

            items(session.chats, key = { it.id }) { chat ->
                Card(
                    onClick = { onOpen(chat) },
                    colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                chat.title,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                chat.messages.lastOrNull()?.text?.replace("\n", " ") ?: "Vuota",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        IconButton(onClick = { session.delete(chat.id) }) {
                            Icon(Icons.Filled.Delete, "Elimina", Modifier.size(20.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SiteCard(title: String, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        onClick = onClick,
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = cs.tertiaryContainer,
            contentColor = cs.onTertiaryContainer,
        ),
        shape = RoundedCornerShape(24.dp),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Filled.AutoAwesome, null)
            Text(title, fontWeight = FontWeight.Bold)
        }
    }
}
