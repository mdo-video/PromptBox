package com.mdo.claudechat

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Aggiornamento OTA: cerca l'ultima release su GitHub, scarica l'APK e avvia l'installazione.
 * La release deve avere come tag "v<numero>" (es. v12), dove il numero è il versionCode.
 * Il repository deve essere pubblico, altrimenti l'API risponde 404.
 */
object Updater {

    const val REPO = "mdo-video/ClaudeChat"

    data class Info(val versionCode: Int, val tag: String, val apkUrl: String)

    suspend fun latest(): Result<Info> = withContext(Dispatchers.IO) {
        runCatching {
            val conn = open("https://api.github.com/repos/$REPO/releases/latest")
            try {
                val code = conn.responseCode
                if (code == 404) throw RuntimeException("Nessuna release trovata. Il repository è pubblico e ha una release?")
                if (code == 403 || code == 429) throw RuntimeException("GitHub ha limitato le richieste. Riprova tra un po'.")
                if (code !in 200..299) throw RuntimeException("Errore GitHub $code.")
                val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                val tag = json.getString("tag_name")
                val number = tag.filter { it.isDigit() }.toIntOrNull()
                    ?: throw RuntimeException("Tag release non valido: $tag")
                val assets = json.getJSONArray("assets")
                var apk: String? = null
                for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.getString("name").endsWith(".apk")) {
                        apk = a.getString("browser_download_url")
                        break
                    }
                }
                Info(number, tag, apk ?: throw RuntimeException("La release non contiene un APK."))
            } finally {
                conn.disconnect()
            }
        }
    }

    suspend fun download(context: Context, info: Info, onProgress: (Float) -> Unit): Result<File> =
        withContext(Dispatchers.IO) {
            runCatching {
                val dir = File(context.cacheDir, "updates").apply { mkdirs() }
                dir.listFiles()?.forEach { it.delete() }
                val file = File(dir, "ClaudeChat-${info.versionCode}.apk")

                val conn = open(info.apkUrl)
                try {
                    if (conn.responseCode !in 200..299) throw RuntimeException("Download non riuscito (${conn.responseCode}).")
                    val total = conn.contentLengthLong
                    var done = 0L
                    conn.inputStream.use { input ->
                        file.outputStream().use { output ->
                            val buf = ByteArray(32 * 1024)
                            while (true) {
                                val n = input.read(buf)
                                if (n < 0) break
                                output.write(buf, 0, n)
                                done += n
                                if (total > 0) onProgress(done.toFloat() / total)
                            }
                        }
                    }
                } finally {
                    conn.disconnect()
                }
                file
            }
        }

    /** Apre l'installer di Android. Se manca il permesso, apre la schermata per concederlo. */
    fun install(context: Context, apk: File): InstallResult {
        if (!context.packageManager.canRequestPackageInstalls()) {
            val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            return InstallResult.NEEDS_PERMISSION
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", apk)
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return InstallResult.STARTED
    }

    enum class InstallResult { STARTED, NEEDS_PERMISSION }

    private fun open(url: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 60_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "ClaudeChat")
            setRequestProperty("Accept", "application/vnd.github+json")
        }
}
