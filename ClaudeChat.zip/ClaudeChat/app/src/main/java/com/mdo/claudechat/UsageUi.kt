package com.mdo.claudechat

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.NumberFormat
import java.util.Locale

private fun fmt(n: Int): String = NumberFormat.getIntegerInstance(Locale.ITALY).format(n)

/**
 * Resoconto d'uso in tempo reale: limiti residui letti dall'API a ogni risposta
 * più i token consumati oggi. [compact] lo riduce a due righe per la schermata di chat.
 */
@Composable
fun UsageCard(limits: Limits?, todayIn: Int, todayOut: Int, compact: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            now = System.currentTimeMillis()
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer),
        shape = RoundedCornerShape(if (compact) 16.dp else 24.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            Modifier.padding(if (compact) 12.dp else 16.dp),
            verticalArrangement = Arrangement.spacedBy(if (compact) 6.dp else 10.dp),
        ) {
            if (limits == null || (limits.reqLimit == null && limits.tokLimit == null)) {
                Text(
                    "Invia un messaggio per vedere i limiti dell'account.",
                    fontSize = 13.sp,
                    color = cs.onSurfaceVariant,
                )
            } else {
                Meter("Richieste", limits.reqRemaining, limits.reqLimit, limits.reqReset, now)
                Meter("Token", limits.tokRemaining, limits.tokLimit, limits.tokReset, now)
            }
            if (!compact) {
                Text(
                    "Oggi: ${fmt(todayIn)} token in ingresso · ${fmt(todayOut)} in uscita",
                    fontSize = 13.sp,
                    color = cs.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun Meter(label: String, remaining: Int?, limit: Int?, reset: Long?, now: Long) {
    if (remaining == null || limit == null || limit <= 0) return
    val cs = MaterialTheme.colorScheme
    val restored = reset != null && now >= reset
    val left = if (restored) limit else remaining
    val fraction = (left.toFloat() / limit).coerceIn(0f, 1f)
    val low = fraction < 0.2f
    val tail = when {
        restored -> "ripristinato"
        reset != null -> "reset tra ${((reset - now) / 1000).coerceAtLeast(0)}s"
        else -> ""
    }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                if (low) "$label · in esaurimento" else label,
                fontSize = 13.sp,
                color = if (low) cs.error else cs.onSurface,
            )
            Text("${fmt(left)} / ${fmt(limit)}  $tail".trim(), fontSize = 12.sp, color = cs.onSurfaceVariant)
        }
        LinearProgressIndicator(
            progress = { fraction },
            modifier = Modifier.fillMaxWidth(),
            color = if (low) cs.error else cs.primary,
            trackColor = cs.surfaceContainerHighest,
        )
    }
}
