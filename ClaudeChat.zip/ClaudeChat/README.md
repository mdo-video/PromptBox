# Claude Chat (cartella e zip: ClaudeChat)

App Android (Kotlin + Jetpack Compose) con una sola interfaccia di chat verso Claude, tramite la tua chiave API Anthropic.
Il nome mostrato è "Claude Chat"; l'ID tecnico `com.mdo.claudechat` e il nome dello zip servono agli aggiornamenti automatici.

## Cosa fa

- Chat salvate in locale: la conversazione non si perde mai, anche se chiudi l'app o esci mentre Claude risponde.
- Resoconto d'uso in tempo reale in Home e in cima a ogni chat: richieste e token rimasti, reset, avviso "in esaurimento" sotto il 20%, token consumati oggi. I valori arrivano dalle intestazioni `anthropic-ratelimit-*` di ogni risposta.
- Se il limite viene raggiunto (429) o il server è sovraccarico, l'app aspetta il tempo indicato da Anthropic e riprova da sola, con il conto alla rovescia nella chat.

- Schede "Claude", "Gemini" e "Grok" in Home: aprono claude.ai, gemini.google.com e grok.com in un browser dentro l'app (WebView, `BrowserScreen.kt`) con sessione salvata, allegati e tasto indietro tra le pagine. Per aggiungere un altro sito basta una riga con `SiteCard` in `HomeScreen.kt`. Nota: Google blocca l'accesso con "Continua con Google" nei browser integrati; sui siti si usa l'accesso con email.

## Chiave API

Si crea qui: https://console.anthropic.com/settings/keys e si inserisce nelle Impostazioni dell'app (resta cifrata sul dispositivo).
Modello predefinito: `claude-sonnet-5-5`, modificabile in Impostazioni.

## Compilazione e aggiornamenti OTA (GitHub)

La repo contiene `ClaudeChat.zip` e il workflow `.github/workflows/build.yml`.
Ad ogni push il workflow scompatta lo zip, compila l'APK firmato e crea una release `v<numero>`.
L'app controlla l'ultima release all'avvio (e da Impostazioni > Controlla aggiornamenti), scarica l'APK e avvia l'installazione.

Requisiti:
- la repo `mdo-video/ClaudeChat` deve essere **pubblica** (l'app legge le release senza login);
- la firma è sempre la stessa (`app/promptbox.jks`), altrimenti Android rifiuta l'aggiornamento;
- la prima installazione si fa a mano dall'APK della release, consentendo "installa app sconosciute".

## Codice

- `ClaudeClient.kt` chiamata REST a `api.anthropic.com/v1/messages`, lettura dei limiti, errori in italiano.
- `Session.kt`      chat, limiti, consumi e invio con retry automatico (vive quanto l'app).
- `Store.kt`        chiave cifrata, modello, chat su file JSON, consumi di oggi.
- `UsageUi.kt`      barre di utilizzo in tempo reale.
- `HomeScreen.kt`, `ChatScreen.kt`, `SettingsScreen.kt`, `MainActivity.kt` schermate.
- `Updater.kt`, `UpdateUi.kt` aggiornamento OTA da GitHub Releases.
