package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.YearMonth

class LearningTest {
    private fun at(y: Int, m: Int, d: Int) =
        ZonedDateTime.of(y, m, d, 12, 0, 0, 0, ZoneId.systemDefault()).toInstant().toEpochMilli()

    @Test fun chiaveDelNome() {
        assertEquals("latte ps", Learning.normalize("Latte PS 1L"))
        assertEquals("caffe lavazza", Learning.normalize("CAFFÈ  Lavazza 250g"))
        assertEquals("pasta", Learning.normalize("Pasta 500 g"))
        assertEquals("", Learning.normalize("  1 L "))
    }

    @Test fun trovaConNomiSimili() {
        val memo = ProductMemo("latte ps", "Latte parzialmente scremato", "frigo", "Latticini", 0, 1, 1L)
        assertEquals(memo, Learning.find(listOf(memo), "LATTE PS 1L"))
        assertNull(Learning.find(listOf(memo), "Latte intero"))
        assertNull(Learning.find(listOf(memo), "  "))
    }

    @Test fun applicaCioCheHaImparato() {
        val guess = StockPlan("LATTE PS 1L", "frigo", "Latticini", 10, price = 1.5)
        val memo = ProductMemo("latte ps", "Latte parzialmente scremato", "frigo", "Sportello", 0, 2, 1L)
        val out = Learning.applyMemo(guess, memo)
        assertEquals("Latte parzialmente scremato", out.name)
        assertEquals("Sportello", out.shelf)
        assertEquals(10, out.days) // nessuna durata imparata → resta la proposta
        assertEquals(1.5, out.price!!, 0.001) // il prezzo resta
    }

    @Test fun unaVecchiaConfermaSbagliataNonMettePulizieInDispensa() {
        // In rev. 88 l'anticalcare era stato confermato in Dispensa: la memoria non deve più vincere.
        val memo = ProductMemo("anticalcare maury s", "Anticalcare Maury's 500ml", "dispensa", "Pasta e cereali", 7, 1, 1L)
        val out = Learning.applyMemo(StockPlan("Anticalcare Maury's 500ml", "casa", "Pulizie", 0), memo)
        assertEquals("casa", out.place)
        assertEquals("Pulizie", out.shelf)
        // Anche se la proposta di partenza era sbagliata, il nome da casalinghi la riporta in Casa.
        val out2 = Learning.applyMemo(StockPlan("Portaposate", "dispensa", "Conserve", 7), ProductMemo("portaposate", "Portaposate", "dispensa", "Conserve", 0, 1, 1L))
        assertEquals("casa", out2.place)
        assertEquals("Altro", out2.shelf)
    }

    @Test fun ricordaAncheCheNonVaInFrigo() {
        val memo = ProductMemo("piselli", "Piselli", "", "", 0, 1, 1L)
        val out = Learning.applyMemo(StockPlan("Piselli", "frigo", "Latticini", 5), memo)
        assertEquals("", out.place)
    }

    @Test fun imparaSoloLeDurateCambiate() {
        val first = Learning.learn(
            emptyList(),
            listOf(Triple("LATTE PS 1L", StockPlan("Latte PS", "frigo", "Latticini", 10), 10)),
            now = 100L,
        )
        assertEquals(0, first.single().days) // durata non cambiata → non imparata
        assertEquals("Latte PS", first.single().name)

        val second = Learning.learn(
            first,
            listOf(Triple("LATTE PS 1L", StockPlan("Latte PS", "frigo", "Latticini", 7), 10)),
            now = 200L,
        )
        assertEquals(7, second.single().days)
        assertEquals(2, second.single().uses)

        val third = Learning.learn(
            second,
            listOf(Triple("LATTE PS 1L", StockPlan("Latte PS", "frigo", "Latticini", 7), 7)),
            now = 300L,
        )
        assertEquals(7, third.single().days) // non cambiata ma già imparata → resta
    }

    @Test fun nonTieneTroppeVoci() {
        val many = (1..520).map { Triple("Prodotto x$it", StockPlan("P$it", "frigo", "Latticini", 5), 5) }
        val out = Learning.learn(emptyList(), many, now = 1L)
        assertEquals(500, out.size)
    }

    @Test fun salvaERilegge() {
        val memos = listOf(ProductMemo("latte ps", "Latte", "frigo", "Latticini", 7, 3, 99L))
        assertEquals(memos, Learning.memosFromJson(Learning.memosToJson(memos)))
        val waste = listOf(WasteEntry("a", "Yogurt", 1.2, 5L), WasteEntry("b", "Pane", null, 6L))
        assertEquals(waste, Learning.wasteFromJson(Learning.wasteToJson(waste)))
    }

    @Test fun contaUnaVoltaSola() {
        val item = PantryItem("x1", "Yogurt", "frigo", "Latticini", "", 10L, 1L, price = 1.2)
        val once = Learning.addWaste(emptyList(), listOf(item), 50L)
        val twice = Learning.addWaste(once, listOf(item), 60L)
        assertEquals(1, twice.size)
        assertEquals(1.2, twice.single().price!!, 0.001)
    }

    @Test fun spesaPerMese() {
        val list = listOf(
            WasteEntry("a", "Yogurt", 1.5, at(2026, 11, 3)),
            WasteEntry("b", "Pane", null, at(2026, 11, 9)),
            WasteEntry("c", "Burro", 2.0, at(2026, 10, 20)),
        )
        val (euro, count, noPrice) = Learning.wasteMonth(list, YearMonth.of(2026, 11))
        assertEquals(1.5, euro, 0.001)
        assertEquals(2, count)
        assertEquals(1, noPrice)
        assertTrue(Learning.wasteMonth(list, YearMonth.of(2026, 9)).second == 0)
    }

    @Test fun ilPrezzoSiPortaDietro() {
        val plan = Stock.guess(StockCandidate("Yogurt", "Latticini e uova", 1.2))
        assertEquals(1.2, plan.price!!, 0.001)
        val item = Stock.toItems(listOf(plan), now = 1L, today = 10L).single()
        assertEquals(1.2, item.price!!, 0.001)
        val old = PantryItem("o", "yogurt", "frigo", "Latticini", "", 12L, 0L, price = 0.9)
        val merged = Stock.merge(listOf(old), listOf(item.copy(name = "Yogurt")))
        assertEquals(1.2, merged.last().price!!, 0.001) // ricomprato: prezzo nuovo
        val keep = Stock.merge(listOf(old), listOf(item.copy(name = "Yogurt", price = null)))
        assertEquals(0.9, keep.first().price!!, 0.001)
        assertNull(keep.last().price)
    }
}
