package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class StockTest {
    @Test fun propostaPerReparto() {
        assertEquals("frigo", Stock.guess(StockCandidate("Yogurt", "Latticini e uova")).place)
        assertEquals(21, Stock.guess(StockCandidate("Uova", "Latticini e uova")).days)
        assertEquals("Cassetto verdure", Stock.guess(StockCandidate("Spinaci", "Frutta e verdura")).shelf)
        assertEquals(3, Stock.guess(StockCandidate("Pane casereccio", "Pane e cereali")).days)
        assertEquals(270, Stock.guess(StockCandidate("Riso", "Pane e cereali")).days)
        assertEquals("", Stock.guess(StockCandidate("Piselli", "Surgelati")).place)
        assertEquals("casa", Stock.guess(StockCandidate("Detersivo", "Casa e igiene")).place)
    }

    @Test fun scontrinoDiUnNegozioDiCasalinghi() {
        // Righe di Maury's: l'AI le aveva messe in reparti di cibo, finivano in Dispensa.
        val anticalcare = Stock.guess(StockCandidate("Anticalcare Maury's 500ml", "Dispensa"))
        assertEquals("casa", anticalcare.place)
        assertEquals("Pulizie", anticalcare.shelf)
        assertEquals("Altro", Stock.guess(StockCandidate("Portaposate", "Dispensa")).shelf)
        assertEquals("casa", Stock.guess(StockCandidate("Cuffie copripiatti 60 pezzi", "Pane e cereali")).place)
        assertEquals("Bagno e igiene", Stock.guess(StockCandidate("Dentifricio Oral B 3D White", "Altro")).shelf)
        assertEquals("Bagno e igiene", Stock.guess(StockCandidate("Deo roll-on Lycia", "Altro")).shelf)
        // Il cibo resta dov'è.
        assertEquals("dispensa", Stock.guess(StockCandidate("Pasta Barilla", "Dispensa")).place)
        assertTrue(!Stock.looksHome("Pasta fresca") && !Stock.looksHome("Piatti pronti"))
    }

    @Test fun scalaDeiGiorni() {
        assertEquals(7, Stock.step(5, up = true))
        assertEquals(3, Stock.step(5, up = false))
        assertEquals(1, Stock.step(1, up = false))
        assertEquals(730, Stock.step(730, up = true))
        assertEquals(14, Stock.step(10, up = true))
    }

    @Test fun creaSoloIProdottiConUnPosto() {
        val plans = listOf(
            StockPlan("Latte", "frigo", "Latticini", 5),
            StockPlan("Piselli", "", "", 0),
            StockPlan("Pasta", "dispensa", "Ripiano inventato", 300),
        )
        val items = Stock.toItems(plans, now = 1000L, today = 100L)
        assertEquals(listOf("Latte", "Pasta"), items.map { it.name })
        assertEquals(105L, items[0].expiry)
        assertEquals(Pantry.PANTRY.first(), items[1].shelf) // ripiano non valido → il primo
    }

    @Test fun conservaLottiSeparati() {
        val old = PantryItem("a", "Latte", "frigo", "Latticini", "1 L", 10L, 1L)
        val added = PantryItem("b", " latte ", "frigo", "Latticini", "", 20L, 2L)
        val other = PantryItem("c", "Burro", "frigo", "Latticini", "", 30L, 3L)
        val merged = Stock.merge(listOf(old), listOf(added, other))
        assertEquals(3, merged.size)
        assertEquals(10L, merged[0].expiry)
        assertEquals("1 L", merged[0].qty)
        assertEquals(20L, merged[1].expiry)
        assertEquals("Burro", merged[2].name)
        assertEquals(merged, Stock.merge(merged, listOf(added)))
    }

    @Test fun leggeLaRispostaDellAi() {
        val cands = listOf(StockCandidate("Yogurt", "Latticini e uova"), StockCandidate("Piselli", "Surgelati"), StockCandidate("Pane", "Pane e cereali"))
        val raw = "```json\n[{\"nome\":\"yogurt\",\"luogo\":\"frigo\",\"ripiano\":\"Latticini\",\"giorni\":18}," +
            "{\"nome\":\"Piselli\",\"luogo\":\"nessuno\",\"ripiano\":\"\",\"giorni\":0}]\n```"
        val out = Stock.parseAi(raw, cands)
        assertEquals(StockPlan("Yogurt", "frigo", "Latticini", 18), out[0])
        assertEquals("", out[1].place)
        assertEquals(3, out[2].days) // non risposto dall'AI → stima per reparto
    }

    @Test fun iProdottiNuoviHannoScadenzaStimata() {
        val items = Stock.toItems(listOf(StockPlan("Latte", "frigo", "Latticini", 5)), now = 1000L, today = 100L)
        assertTrue(items[0].estimated)
    }

    @Test fun nomeVuotoNonVieneAggiunto() {
        val items = Stock.toItems(listOf(StockPlan("  ", "frigo", "Latticini", 5), StockPlan("Burro", "frigo", "Latticini", 20)), now = 1000L, today = 100L)
        assertEquals(listOf("Burro"), items.map { it.name })
    }

    @Test fun rinnovareTieneLaStimaDelNuovo() {
        val old = PantryItem("a", "Latte", "frigo", "Latticini", "", 10L, 1L, estimated = false)
        val added = PantryItem("b", "Latte", "frigo", "Latticini", "", 20L, 2L, estimated = true)
        assertFalse(Stock.merge(listOf(old), listOf(added))[0].estimated)
        assertTrue(Stock.merge(listOf(old), listOf(added))[1].estimated)
    }
    @Test fun rispostaAiNonAssociataPerPosizione() {
        val c = listOf(StockCandidate("Latte", "Latticini e uova"))
        val raw = """[{"nome":"Altro prodotto","luogo":"dispensa","giorni":99}]"""
        assertEquals(Stock.guess(c.single()), Stock.parseAi(raw, c).single())
    }
    @Test fun idUniciAncheNelloStessoMillisecondo() {
        val p = listOf(StockPlan("Latte", "frigo", "Latticini", 5))
        assertNotEquals(Stock.toItems(p, 1L, 1L).single().id, Stock.toItems(p, 1L, 1L).single().id)
    }
}
