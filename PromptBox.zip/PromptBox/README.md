# Prisma (cartella e zip: PromptBox)

Il nome mostrato nell'app è "Prisma" (`res/values/strings.xml`). L'ID tecnico `com.promptbox`
e il nome dello zip restano uguali: servono agli aggiornamenti automatici.

Grafica: Material 3 scuro, tema in `Theme.kt`, colori dinamici opzionali (Android 12+) da Impostazioni.
Icona: `res/drawable/ic_launcher_foreground.xml` (adattiva, con versione monocromatica per le icone a tema).

App Android (Kotlin + Jetpack Compose) che raccoglie prompt già pronti, ognuno con la sua AI.
Ogni sezione è un prompt di sistema: tu aggiungi solo foto e/o testo.

Sezioni incluse: SPESA, ETICHETTA, FRIGO, LIBERO. Dall'app puoi crearne altre (pulsante "Nuova sezione"):
l'icona la scegli tu: in creazione e in modifica "Proponi icone" ne mostra fino a 5 (scelte dall'AI leggendo titolo e istruzioni) e tocchi quella che vuoi (📌 di partenza).
I link nelle risposte (anche scritti per esteso) sono toccabili.
Ogni sezione si può fissare in alto con la puntina; tenendo premuta una sezione escono Modifica ed Elimina (vale anche per quelle di partenza).
Dopo la prima risposta puoi continuare la conversazione con domande di approfondimento (anche con nuove foto):
la chat di ogni sezione resta salvata (solo testo) e si riprende quando vuoi; "Nuova chat" in alto la azzera; l'interruttore "Chat" la attiva o la spegne, sezione per sezione (da spenta ogni messaggio riparte da zero).
Le risposte sono formattate: titoletti colorati, elenchi con rientro, grassetto, corsivo, codice, citazioni.
Nella creazione di una sezione scrivi cosa vuoi, "Crea prompt con AI" genera il prompt (modificabile prima di salvare).

## Novità recenti

- **Novità** (icona in Home e pulsante in Impostazioni): changelog nell'app, con pallino quando c'è qualcosa di nuovo.
  Si aggiorna in `Changelog.kt`: nuova voce in cima alla lista, con `id` più alto.
- **Su di me** (Impostazioni): testo aggiunto a ogni richiesta (obiettivi, allergie, preferenze). Cifrato, solo sul telefono.
- **Condividi verso Prisma**: da Galleria, Chrome, WhatsApp... scegli Prisma, poi la sezione (`ShareUi.kt`).
- **Scanner codice a barre** (menu + nella sezione): ML Kit + Open Food Facts, testo pronto nel campo (`BarcodeTools.kt`).

- **Lista della spesa** (carrello in Home): checklist, sincronizzata con l'account Google (per prodotto vince la modifica più recente, le eliminazioni si propagano); "Alla lista" sotto ogni risposta estrae i prodotti dagli elenchi (`ShoppingUi.kt`).
- **Suggerimenti rapidi** sotto il campo di testo, per sezione (`quickChips` in `Sections.kt`); "Confronta i prodotti" dopo due scansioni.
- **Lunghezza risposte** (Breve / Normale / Dettagliata) e **cambio modello automatico** (404, 429, 5xx) in Impostazioni > Risposte.
- **Contatore** delle richieste fatte oggi (solo informativo: il limite gratuito lo decide Google).

## Compilazione e aggiornamenti OTA (GitHub)

La repo contiene `PromptBox.zip` e il workflow `.github/workflows/build.yml`.
Ad ogni push il workflow scompatta lo zip, compila l'APK firmato e crea una release `v<numero>`.
L'app controlla l'ultima release all'avvio (e da Impostazioni > Controlla aggiornamenti),
scarica l'APK e avvia l'installazione.

Per pubblicare una nuova versione: sostituisci `PromptBox.zip` nella repo con quello nuovo e fai commit.

Requisiti:
- la repo `mdo-video/PromptBox` deve essere **pubblica** (l'app legge le release senza login);
- la firma è sempre la stessa (`app/promptbox.jks`), altrimenti Android rifiuta l'aggiornamento;
- il numero della versione è il numero dell'esecuzione del workflow, quindi cresce da solo;
- la prima installazione si fa a mano dall'APK della release, consentendo "installa app sconosciute".

## Come funziona il codice

- `Sync.kt`        accesso con Google e sincronizzazione delle sezioni nella cartella nascosta di Drive.
- `Markdown.kt`    divide la risposta in blocchi e li disegna (MarkdownText).
- `Sections.kt`    sezioni di partenza: vengono copiate nello Store alla prima apertura, poi sono tutte modificabili.
- `GeminiClient.kt` chiamata REST all'API Gemini (testo + immagine, conversazione a più turni, stile Markdown aggiunto a ogni prompt), con messaggi d'errore in italiano.
- `Store.kt`       chiave API cifrata (EncryptedSharedPreferences), modello, sezioni e chat salvate.
- `ImageUtils.kt`  carica la foto, la ruota e la riduce a 1280 px prima dell'invio.
- `Updater.kt`, `UpdateUi.kt` aggiornamento OTA da GitHub Releases.
- `Changelog.kt`   voci e schermata Novità.
- `ShareUi.kt`     ricezione dal menu Condividi e scelta della sezione.
- `BarcodeTools.kt` scanner e ricerca prodotto.
- `ShoppingUi.kt`  lista della spesa e finestra "Alla lista".
- `MainActivity.kt` schermate: Home, Sezione, Impostazioni.

## Note

- Modello predefinito: `gemini-3.1-flash-lite`. Se Google lo cambia, modificalo in Impostazioni.
- Chiave API gratuita: https://aistudio.google.com/apikey (si inserisce nelle Impostazioni dell'app).
- Nel free tier Google può usare i dati inviati per migliorare i suoi prodotti: niente dati sensibili.
- Il keystore è nella repo con password semplice: va bene per un'app personale, ma chiunque
  veda la repo potrebbe firmare un APK con la stessa firma.


## Account Google e sincronizzazione

In Impostazioni → Account Google. Servono il progetto Google Cloud con Drive API attiva e un client OAuth Android
(pacchetto `com.promptbox`, impronta SHA-1 di `app/promptbox.jks`). Si sincronizzano sezioni (nome, icona, prompt), lista della spesa
e le eliminazioni; la chiave API e le chat restano sul telefono. Parte all'apertura e dopo ogni modifica; per ogni sezione
vince la versione modificata più di recente.
