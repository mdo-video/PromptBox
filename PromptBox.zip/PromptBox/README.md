# Prisma (cartella e zip: PromptBox)

Il nome mostrato nell'app è "Prisma" (`res/values/strings.xml`). L'ID tecnico `com.promptbox`
e il nome dello zip restano uguali: servono agli aggiornamenti automatici.

Grafica: Material 3 scuro, tema in `Theme.kt`, colori dinamici opzionali (Android 12+) da Impostazioni.
Icona: `res/drawable/ic_launcher_foreground.xml` (adattiva, con versione monocromatica per le icone a tema).

App Android (Kotlin + Jetpack Compose) che raccoglie prompt già pronti, ognuno con la sua AI.
Ogni sezione è un prompt di sistema: tu aggiungi solo foto e/o testo.

Sezioni incluse: SPESA, ETICHETTA, FRIGO, LIBERO. Dall'app puoi crearne altre (pulsante "Nuova sezione"):
l'icona la scegli tu: in creazione e in modifica "Proponi icone" ne mostra fino a 5 (scelte dall'AI leggendo titolo e istruzioni) e tocchi quella che vuoi (📌 di partenza).
I link nelle risposte (anche scritti per esteso) sono toccabili.
Ogni sezione si può fissare in alto con la puntina; tenendo premuta una sezione escono Modifica ed Elimina (vale anche per quelle di partenza).
Dopo la prima risposta puoi continuare la conversazione con domande di approfondimento (anche con nuove foto):
la chat di ogni sezione resta salvata (solo testo) e si riprende quando vuoi; "Nuova chat" in alto la azzera; l'interruttore "Chat" la attiva o la spegne, sezione per sezione (da spenta ogni messaggio riparte da zero).
Le risposte sono formattate: titoletti colorati, elenchi con rientro, grassetto, corsivo, codice, citazioni.
Nella creazione di una sezione scrivi cosa vuoi, "Crea prompt con AI" genera il prompt (modificabile prima di salvare).

## Da fare nella prossima versione (decisione dell'autore, 18 nov 2026)

**Tutto ciò che si può sincronizzare deve sincronizzarsi con l'accesso con l'account, ed essere incluso nel backup.**
Oggi questi dati restano solo sul telefono (nelle `SharedPreferences` di `Store.kt`) e vanno aggiunti sia a `Sync.kt` sia a `BackupTools.kt`:

- Frigo e dispensa: `Store.pantryItems()` / `savePantry()` (`PantryItem` in `Pantry.kt`).
- Campi guidati delle sezioni e ultime scelte: `Store.guidedFields()` / `guidedValues()` (chiavi `gf_<id>` e `gv_<id>`), più le loro funzioni di salvataggio.
- Scontrini e statistiche: `Store.receipts()` / `saveReceipts()` (`Receipt` in `Receipts.kt`).
- Routine programmate e avviso di scadenza: `Store.routines()` / `saveRoutines()` / `expiryNotify` (`Routine` in `Reminders.kt`). Dopo una sincronizzazione o un ripristino, chiamare `Reminders.rescheduleAll()`.
- Ogni nuovo dato futuro: decidere subito se è sincronizzabile e, se sì, aggiungerlo a sincronizzazione e backup nello stesso giro in cui nasce.

Da tenere presente: usare un `updatedAt` per elemento (come per le sezioni) per risolvere i conflitti tra dispositivi, e dare ai prodotti/scontrini id stabili (già così: `PantryItem.id`, `Receipt.id`). 

## Novità recenti

- **Ottimizzazioni**: R8/shrink attivi in release (`app/proguard-rules.pro`; se l'app crasha all'avvio, provare `isMinifyEnabled = false` in `app/build.gradle.kts`); risposte in streaming (`GeminiClient.postStream`, `onPartial` → `streamText` in `SectionScreen`); `Store.inBackground` per salvare frigo, scontrini e routine fuori dal thread principale (le chat restano sincrone di proposito); `Store.secure` pigro; `ImageUtils.load(maxSide)` con 2000 px per gli scontrini; file lunghi divisi in `SectionParts.kt`, `HomeParts.kt`, `ShoppingParts.kt` (le funzioni spostate sono `internal`); test in `app/src/test` (`gradle test`).
- **Giro 3** (`Reminders.kt`, `RoutinesUi.kt`): routine programmate (allarmi inesatti `setAndAllowWhileIdle`, nessun permesso speciale) e avviso di scadenza alle 8; `AlarmReceiver` gestisce allarmi e riavvio; la notifica apre l'app (e la richiesta parte da sola: `Shared.autoSend` → `autoSendPending` in `SectionScreen`) con l'extra `action` = `routine:<id>` o `place:<frigo|dispensa>` (gestito in `MainActivity`). Lettura ad alta voce con `TextToSpeech` in `SectionScreen`. Cronologia e Routine si aprono dalle Impostazioni.
- **Campi guidati** (`Guided.kt`, `GuidedUi.kt`): per ogni sezione un modulo a chip / testo sopra il composer; salvati per sezione in `Store.guidedFields` / `guidedValues`; le scelte diventano righe "Campo: valore" prima del testo in `SectionScreen.send()`; `GeminiClient.suggestFields` li propone.
- **Scontrini e statistiche** (`Receipts.kt`, `ReceiptsUi.kt`): foto dello scontrino letta da `ReceiptTools.read` (JSON con negozio, data, totale, articoli per reparto), salvata in `Store.receipts`; schermata `receipts` raggiunta dall'icona nella Spesa. Non ancora in backup/sincronizzazione.
- **Frigo e dispensa** (`Pantry.kt`, `PantryUi.kt`; due voci "Frigo" e "Dispensa" in `NavBar.kt`, schermate `frigo` / `dispensa`): prodotti su ripiani con scadenza (`PantryItem`, salvati in `Store.pantryItems`), vista Disegno/Elenco, stati scaduto / da usare presto (`Pantry.freshness`), scanner con `BarcodeTools.productName`, "Cosa ci cucino?" verso FRIGO (`Pantry.cookPrompt`). Non ancora in backup/sincronizzazione; notifiche di scadenza rimandate.
- **Manda a… e timer**: sotto ogni risposta "Manda a…" (`sendTargets` / `onSendTo` in `SectionScreen.kt`, collegato in `MainActivity.kt`) porta la risposta nel campo di un'altra sezione; i tempi nel testo ("12 min", "1 ora", `Timers.kt`) sono link toccabili in `Markdown.kt` e avviano un timer nell'Orologio (`AlarmClock.ACTION_SET_TIMER`, permesso `SET_ALARM` nel manifest). `SectionScreen` è avvolta in `key(section.id)`.
- **Archivio schede** (menu "+" > Archivio schede): per sezione, interruttore "Archivia i file che allego"; il blocco `DATI SCHEDA` (JSON con `esercizi`) di un PDF/testo è estratto (`DocArchive` in `DocUtils.kt`, `GeminiClient.extractData`), salvato in `Store.docItems` e aggiunto al prompt di sistema a ogni richiesta (`DocArchive.context`).
- **Allega documenti**: voce "Da file" nel "+" (`DocUtils.kt`, `ChatDoc` in `GeminiClient.kt`): PDF fino a 15 MB (inviato come `inline_data`) e file di testo (inviati come testo).
- **Revisione dai mockup (appunti "DA CAMBIARE")**: scheda vuota con suggerimenti a schede grandi, risposta a card per proposta con barra azioni fissa (`AiResponse`, `ResponseActions` in `SectionScreen.kt`; pillola tempo `[15 min]` nel titolo, `Passaggi` richiudibili in `Markdown.kt`), lista della spesa con reparti a icona, swipe per cambiare reparto, lista Bring accanto al reparto (`Store.bringListNames`) e conferma "Apri Bring" (`<queries>` nel manifest), Impostazioni in gruppi, Cronologia con filtri/date/swipe (`Store.restoreArchived`), Nuova sezione a schede grandi con "Crea con AI" a un campo e libreria con anteprima.
- **Nuova Home (mockup "Prisma – mockup e revisione")**: barra di navigazione in basso (`NavBar.kt`: Home, Spesa, Cronologia, Impostazioni, nascosta con la tastiera aperta), testata compatta con logo, titolo, Novità e vista griglia/lista (`HomeHeader` in `HomeScreen.kt`), ricerca sempre visibile, schede in griglia con solo icona e titolo, pulsante "+" al posto di "Nuova sezione".
- **Home**: ricerca (lente), colore per categoria (`categoryPalette`, indice salvato in `Store.categoryColors`), menu scheda con Condividi (`CardShare.kt`, codice `PRISMA1:` importabile da Condividi verso Prisma o da "Incolla scheda") e Aggiungi alla Home (`SectionShortcut.kt`, extra `open_section`); Elimina con "Annulla" (`DeletedSection` in `MainActivity.kt`).
- **Categorie e riordino**: ogni scheda può avere una categoria (campo in creazione/modifica); in Home le schede sono raggruppate sotto il titolo della categoria (si chiude con un tocco; menu a tre puntini: rinomina, sposta su/giù, togli). Tenendo premuta una scheda e trascinando la si riordina (dentro la sua categoria e tra pinnate / non pinnate); `Section.category`, salvata in `Store`, `Sync` e backup.
- **Novità** (icona in Home e pulsante in Impostazioni): changelog nell'app, con pallino quando c'è qualcosa di nuovo.
  Si aggiorna in `Changelog.kt`: nuova voce in cima alla lista, con `id` più alto.
- **Su di me** (Impostazioni): testo aggiunto a ogni richiesta (obiettivi, allergie, preferenze). Cifrato, solo sul telefono.
- **Condividi verso Prisma**: da Galleria, Chrome, WhatsApp... scegli Prisma, poi la sezione (`ShareUi.kt`).
- **Scanner codice a barre** (menu + nella sezione): ML Kit + Open Food Facts, testo pronto nel campo (`BarcodeTools.kt`).

- **Lista della spesa** (carrello in Home): checklist, sincronizzata con l'account Google (per prodotto vince la modifica più recente, le eliminazioni si propagano); con la lista aperta si risincronizza ogni 20 s, "tira giù" forza la sincronizzazione, e si sincronizza anche a ogni ritorno nell'app; "Alla lista" compare solo quando l'AI riconosce prodotti concreti da comprare: chiude la risposta con una riga nascosta `[[LISTA: a | b]]` (istruzione in `GeminiClient.STYLE`, lettura in `splitShoppingMarker`, `ShoppingUi.kt`); per meteo, calcoli, pacchi ecc. il tasto non c'è.
- **Suggerimenti rapidi** sotto il campo di testo, per sezione (`quickChips` in `Sections.kt`); "Confronta i prodotti" dopo due scansioni.
- **Lunghezza risposte** (Breve / Normale / Dettagliata) e **cambio modello automatico** (404, 429, 5xx) in Impostazioni > Risposte.
- **Contatore** delle richieste fatte oggi (solo informativo: il limite gratuito lo decide Google).

- **Lista per reparti**: l'AI aggiunge `#Reparto` ai prodotti nella riga `[[LISTA: ...]]`; modifica del prodotto al tocco, condividi, "Cosa ci cucino?" (manda a FRIGO), suggerimenti "ricomprare" (storico sincronizzato), evidenziazione dei prodotti nuovi da sync.
- **Sincronizzazione**: sezioni, lista della spesa, storico e, se attivato, "Su di me" (`LocalSync` / `DriveSync` in `Sync.kt`).
- **Cronologia** (`HistoryUi.kt`): "Nuova chat" archivia la chat (`Store.archiveChat`); ricerca nel testo; riapri una chat archiviata.
- **Libreria sezioni** (`Library.kt`) e sezioni extra (`DefaultSections.extra`, aggiunte una volta anche a chi aveva già l'app).
- **Backup** (`BackupTools.kt`): file JSON, senza chiave API né chat; il ripristino unisce ai dati presenti.
- **Widget** (`ShoppingWidget.kt`, `res/xml/shopping_widget_info.xml`) e **scorciatoie** (`res/xml/shortcuts.xml`, extra `action`: `shopping`, `spesa_photo`, `spesa_scan`).
- **Tema** chiaro / scuro / automatico (`Theme.kt`, `Store.theme`).

## Compilazione e aggiornamenti OTA (GitHub)

La repo contiene `PromptBox.zip` e il workflow `.github/workflows/build.yml`.
Ad ogni push il workflow scompatta lo zip, compila l'APK firmato e crea una release `v<numero>`.
L'app controlla l'ultima release all'avvio (e da Impostazioni > Controlla aggiornamenti),
scarica l'APK e avvia l'installazione.

Per pubblicare una nuova versione: sostituisci `PromptBox.zip` nella repo con quello nuovo e fai commit.

Requisiti:
- la repo `mdo-video/PromptBox` deve essere **pubblica** (l'app legge le release senza login);
- la firma è sempre la stessa (`app/promptbox.jks`), altrimenti Android rifiuta l'aggiornamento;
- il numero della versione è il numero dell'esecuzione del workflow, quindi cresce da solo;
- la prima installazione si fa a mano dall'APK della release, consentendo "installa app sconosciute".

## Come funziona il codice

- `Sync.kt`        accesso con Google e sincronizzazione delle sezioni nella cartella nascosta di Drive.
- `Markdown.kt`    divide la risposta in blocchi e li disegna (MarkdownText).
- `Sections.kt`    sezioni di partenza: vengono copiate nello Store alla prima apertura, poi sono tutte modificabili.
- `GeminiClient.kt` chiamata REST all'API Gemini (testo + immagine, conversazione a più turni, stile Markdown aggiunto a ogni prompt), con messaggi d'errore in italiano.
- `Store.kt`       chiave API cifrata (EncryptedSharedPreferences), modello, sezioni e chat salvate.
- `ImageUtils.kt`  carica la foto, la ruota e la riduce a 1280 px prima dell'invio.
- `Updater.kt`, `UpdateUi.kt` aggiornamento OTA da GitHub Releases.
- `Changelog.kt`   voci e schermata Novità.
- `ShareUi.kt`     ricezione dal menu Condividi e scelta della sezione.
- `BarcodeTools.kt` scanner e ricerca prodotto.
- `ShoppingUi.kt`  lista della spesa e finestra "Alla lista".
- `HistoryUi.kt`, `Library.kt`, `BackupTools.kt`, `ShoppingWidget.kt` vedi sopra.
- `MainActivity.kt` schermate: Home, Sezione, Impostazioni.

## Note

- Modello predefinito: `gemini-3.1-flash-lite`. Se Google lo cambia, modificalo in Impostazioni.
- Chiave API gratuita: https://aistudio.google.com/apikey (si inserisce nelle Impostazioni dell'app).
- Nel free tier Google può usare i dati inviati per migliorare i suoi prodotti: niente dati sensibili.
- Il keystore è nella repo con password semplice: va bene per un'app personale, ma chiunque
  veda la repo potrebbe firmare un APK con la stessa firma.


## Account Google e sincronizzazione

In Impostazioni → Account Google. Servono il progetto Google Cloud con Drive API attiva e un client OAuth Android
(pacchetto `com.promptbox`, impronta SHA-1 di `app/promptbox.jks`). Si sincronizzano sezioni (nome, icona, prompt), lista della spesa
e le eliminazioni; la chiave API e le chat restano sul telefono. Parte all'apertura e dopo ogni modifica; per ogni sezione
vince la versione modificata più di recente.
