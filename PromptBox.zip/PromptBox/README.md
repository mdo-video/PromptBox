# Prisma (cartella e zip: PromptBox)

**Revisione del codice: 66 (22 nov 2026).** È l'`id` della voce più in alto di `Changelog.kt` (letta da `AppInfo.kt`, mostrata in Impostazioni → Aggiornamenti).
Ad ogni nuova versione: nuova voce in `Changelog.kt` con l'id successivo e aggiornare questa riga. Il numero `1.N` dell'APK invece lo decide la CI (numero dell'esecuzione del workflow).

Il nome mostrato nell'app è "Prisma" (`res/values/strings.xml`). L'ID tecnico `com.promptbox`
e il nome dello zip restano uguali: servono agli aggiornamenti automatici.

Grafica: Material 3 scuro, tema in `Theme.kt`, colori dinamici opzionali (Android 12+) da Impostazioni.
Icona: `res/drawable/ic_launcher_foreground.xml` (adattiva, con versione monocromatica per le icone a tema).

App Android (Kotlin + Jetpack Compose) che raccoglie prompt già pronti, ognuno con la sua AI.
Ogni sezione è un prompt di sistema: tu aggiungi solo foto e/o testo.

Sezioni incluse: SPESA, ETICHETTA, FRIGO, LIBERO. Dall'app puoi crearne altre (pulsante "Nuova sezione"):
l'icona la scegli tu: in creazione e in modifica "Proponi icone" ne mostra fino a 5 (scelte dall'AI leggendo titolo e istruzioni) e tocchi quella che vuoi (📌 di partenza).
I link nelle risposte (anche scritti per esteso) sono toccabili.
Ogni sezione si può fissare in alto con la puntina; tenendo premuta una sezione escono Modifica ed Elimina (vale anche per quelle di partenza).
Dopo la prima risposta puoi continuare la conversazione con domande di approfondimento (anche con nuove foto):
la chat di ogni sezione resta salvata (solo testo) e si riprende quando vuoi; "Nuova chat" in alto la azzera; l'interruttore "Chat" la attiva o la spegne, sezione per sezione (da spenta ogni messaggio riparte da zero).
Le risposte sono formattate: titoletti colorati, elenchi con rientro, grassetto, corsivo, codice, citazioni.
Nella creazione di una sezione scrivi cosa vuoi, "Crea prompt con AI" genera il prompt (modificabile prima di salvare).

## Sincronizzazione e backup (fatto nella revisione 34)

**Regola dell'autore: tutto ciò che si può sincronizzare si sincronizza con l'account Google ed entra nel backup.**
Frigo e dispensa, scontrini, routine con avviso di scadenza e campi guidati (con le ultime scelte) viaggiano come **blocchi**
(`SyncBlock` in `Sync.kt`: `pantry`, `receipts`, `routines`, `guided`), ognuno con la sua data di ultima modifica
(`Store.blockAt`, chiave `blk_<nome>_at`, aggiornata dalle funzioni `save*`). Per ogni blocco vince il più recente (`DriveSync.mergeBlocks`);
un blocco con dati ma mai sincronizzato (data 0) si **unisce per id** a quello su Drive invece di sostituirlo.
Dopo l'arrivo di un blocco `MainActivity` ricarica frigo/scontrini e, per le routine, chiama `Reminders.rescheduleAll()`.
Il backup (`BackupTools`) contiene gli stessi blocchi.

**Revisione 51, sincronizzazione completa.** Due blocchi nuovi:
- `chats`: `{"cur": {idSezione: array turni}, "arch": array archivio}`, letti dalla memoria cifrata (`Store.chatsBlockJson`); unione dei dati mai sincronizzati: per sezione la chat con più messaggi, archivio unito per `id` (max 60).
- `docs`: `{"items": {idSezione: array schede}, "on": {...}, "chat": {...}}` con archivio documenti, interruttori Archivio e Chat per sezione; i PDF viaggiano in base64 dentro le schede se pesano al massimo 1 MB (`MAX_SYNC_PDF`), altrimenti restano sul dispositivo dove sono stati salvati e altrove la scheda si apre dai dati.
Le chat si uniscono a tre vie (`DriveSync.mergeChats`): `Store.chatsBase` (cifrato, azzerato quando si spegne la sincronizzazione) è lo stato dell'ultima sincronizzazione; una chat o un archivio che c'era nella base e manca da un lato è stato cancellato e resta cancellato, se una chat cambia su entrambi i lati i messaggi si uniscono per ora (`ts`, aggiunto da `saveChat`). Senza base (primo avvio dopo l'aggiornamento) vale ancora l'ultimo che modifica.\nChat e archivio documenti non si applicano mentre è aperta una scheda (`MainActivity.doSync`): arrivano alla sincronizzazione successiva, che parte anche all'uscita dalla scheda.
Il backup su file non contiene `chats` (finirebbero in chiaro); quello su Drive sì. Vista Home (lista/griglia), categorie chiuse e "già chiesto avviso scadenze" viaggiano con le impostazioni.
Non si sincronizza di proposito: contatori richieste, blocco del PIN dopo errori, ultima versione del changelog vista, ultime schede aperte.

**Revisione 54, scontrini più veloci.** `GeminiClient.askJson` imposta `thinkingConfig.thinkingLevel = "low"` e non cambia la temperatura (per Gemini 3 si lascia a 1); `ReceiptTools.askFastest` lancia una seconda richiesta con un altro modello dopo `HEDGE_MS` (7 s) e tiene la prima risposta riuscita; foto a 2400 px; `onStage` mostra la fase in corso.

**Revisione 53, scontrini.** `ReceiptTools.readChecked`: `GeminiClient.askJson` (JSON forzato, fino a 16384 token, modelli `gemini-3.7-flash` → `gemini-3.5-flash` → quello scelto nelle Impostazioni); un secondo tentativo se la lettura fallisce; se la somma delle righe si discosta dal totale (`gap` > `tolerance`: 2%, minimo 0,10 €) una rilettura di verifica con la prima risposta e la foto, tenendo quella più vicina al totale; altrimenti un avviso (Toast). Le foto si caricano a 2400 px; in `PantryReceipt.kt` e `ReceiptsUi.kt` l'ultima foto resta in `lastUri` per "Riprova a leggere la stessa foto".

**Revisione 52, PDF grandi.** I PDF oltre `Store.MAX_SYNC_PDF` (1 MB) e fino a 15 MB non stanno nel blocco `docs`: `DriveSync.syncPdfs` li carica come file separati `prisma-pdf-<nome>` (base64) nella cartella nascosta di Drive, scarica quelli che le schede citano e che mancano qui, toglie da Drive quelli che nessuna scheda cita. Parte dopo ogni sincronizzazione riuscita (`MainActivity.doSync`); un errore non fa fallire la sincronizzazione. `SyncResult.uploadedBytes`, `Store.syncDetail` e `SyncUi.detail` alimentano la riga di dettaglio in Impostazioni.

Per ogni nuovo dato futuro: decidere subito se è sincronizzabile e, se sì, aggiungerlo come blocco (`Store.blockData` / `applyBlock`,
elenco in `BackupTools.BLOCKS`) nello stesso giro in cui nasce.
Limite noto: la regola è "vince il blocco intero", non il singolo elemento: se due dispositivi cambiano il frigo prima di sincronizzare, vince l'ultimo.

Sicurezza: le chat e la cronologia stanno in `EncryptedSharedPreferences` (migrate una volta da quelle in chiaro, `Store.migrateChatsToSecure`);
la password di Bring è solo nel file di sincronizzazione su Drive (cartella privata dell'app), non nel backup salvato su file (`settingsJson(includeSecrets)`).
Prima di scrivere su Drive si controlla che la versione del file non sia cambiata (`DriveSync.syncBlocking`, fino a 3 giri).
Test: `app/src/test/.../SyncMergeTest.kt` (`./gradlew testDebugUnitTest`).

## Novità recenti

- **Foto prodotto (rev. 66)**: `PantryPhoto.kt` (`fromPhoto`, `fromBarcode`, `parse`, `validEan`, `qtyFromOff`): una foto della confezione → JSON dell'AI (`askJson`, `gemini-3.7-flash` → `gemini-3.5-flash` → modello scelto) con nome, ripiano tra quelli del posto, pezzi per confezione, peso, scadenza se visibile, codice a barre (valido solo con cifra di controllo giusta, poi quantità da Open Food Facts) e giorni medi di durata (scadenza stimata, `estimated = true`). In `PantryUi.kt`: voce "Foto prodotto" nel menu Aggiungi, `readProduct` con "Riprova" senza rifare la foto, `draftFrom`; la finestra del prodotto non ha più le scorciatoie di data (solo foto della data via `ExpiryTools.read`, "Scegli la data…", "Nessuna"); anche `ExpiryWalkthroughDialog` senza scorciatoie. Parte Compose non compilata in sessione. Test: `PantryPhotoTest.kt`.
- **Selezione multipla (rev. 65)**: in `PantryUi.kt` barra in basso (`bottomBar`) con Finiti/Sposta/Elimina, `deleteMany`, `moveMany` (con Annulla), `PantryMoveSheet`; titolo della selezione con "Seleziona tutti". Parte Compose non compilata in sessione.
- **Sync completa e avvisi (rev. 60)**: la chiave API si sincronizza con le impostazioni (solo cartella privata su Drive); avvisi Toast dopo sincronizzazione manuale e "tira giù" (`startSync(interactive, notify)`). Parte Compose non compilata in sessione.
- **Azioni sul prodotto (rev. 59)**: in `PantryUi.kt` il tocco breve apre `PantryActionsSheet` (il lungo la modifica) (Finito, Modifica, Seleziona, Elimina via `deleteItem`); `PantryItemDialog` è un `ModalBottomSheet` senza Finito/Elimina; `notify()` mostra avvisi brevi (salvato, aggiunto, N prodotti dopo lo scontrino). Parte Compose non compilata in sessione.
- **Foglio "Scansiona scontrino" (rev. 58)**: `ReceiptToPantryFlow` (`PantryReceipt.kt`) usa `ModalBottomSheet` con `ReceiptSteps`, stati scelta/lettura/errore; `confirmValueChange = { !busy }` impedisce di chiuderlo durante la lettura. Parte Compose non compilata in sessione.
- **Menù "+" della Home (rev. 57)**: `ModalBottomSheet` "Aggiungi" in `HomeScreen.kt` (tasto pieno "Scansiona scontrino" → `ReceiptToPantryFlow`; righe `ChooserRow` in `HomeParts.kt`). `HomeScreen` riceve `store`, `onReceipt`, `onToStock`; in `MainActivity` il salvataggio dello scontrino è `saveScannedReceipt`, condiviso con `PantryScreen`. Parte Compose non compilata in sessione.
- **Quantità dagli scontrini (rev. 56)**: `ReceiptItem`, `StockCandidate` e `StockPlan` hanno `qty` (default vuoto); il prompt di `Receipts.kt` chiede `quantita`, `cleanQty` la normalizza (1 e 0 → vuoto), salvataggio con chiave `q`; `Stock.toItems` la scrive in `PantryItem.qty`, `Stock.merge` la rinnova se non vuota. Campo Quantità in `StockImportDialog`. Test in `ReceiptToolsTest`.
- **Codice a barre per rifinire il nome (rev. 55)**: `BarcodeTools.product(code)` restituisce nome (in italiano se c'è, con la marca) e quantità da Open Food Facts; `productName` ora lo usa. Pulsante scanner nel campo Nome di `PantryItemDialog` (`PantryUi.kt`) e su ogni riga di `StockImportDialog` (`StockImport.kt`). Unito sopra la rev. 54 installata (tocca solo `BarcodeTools`, `PantryUi`, `StockImport`). Parte Compose non compilata in sessione.

- **Layout per il tablet (rev. 50)**: `Tablet.kt` (`WIDE_MIN_DP` = 600, `SectionPaneLayout`, `TwoPane`) e `PrismaNavRail` in `NavBar.kt`; in `MainActivity` il contenuto è nel lambda `body` e `pantryPane(place)` è condiviso tra Frigo/Dispensa e il pannello destro della Spesa; `HomeScreen` usa 3 colonne (o 2 in elenco) sugli schermi larghi. Prossime: esporta/importa (51), codice a barre (52), widget (53). Parte Compose non compilata in sessione e mai provata su un tablet vero.

- **Stile unico: risposte e Cronologia, pulizia (rev. 49)**: `accentFor` (`SectionParts.kt`) restituisce sempre i colori primari, `ErrorCard` è neutra, in `HistoryUi.kt` icone e titoli dei gruppi neutri. Rimossi `PantryListRow`, il ramo "elenco" di `PantryUi` e `categoryPalette`. Prossime: layout per tablet (rev. 50), esporta/importa (51), codice a barre (52), widget (53). Parte Compose non compilata in sessione.

- **Ripiani senza vuoti (rev. 48)**: in `PantryUi.kt` tolto il selettore Disegno/Elenco (`listView` ora è una costante `false`, `PantryListRow` non è più raggiunta); i ripiani senza prodotti non si disegnano e in fondo c'è la scheda con i `FilterChip` per aggiungere in un ripiano vuoto. Prossima: risposte e Cronologia (rev. 49). Parte Compose non compilata in sessione.

- **Stile unico: Spesa, Frigo e Dispensa (rev. 47)**: in `PantryUi.kt` `freshnessColors` restituisce sempre `surfaceContainerHigh` (rosso/arancio solo su icona e scadenza), `StatusPill` prende solo il colore dell'icona, le schede d'azione sono neutre; in `ShoppingUi.kt` "Cosa ci cucino?" è `primary` pieno, titoli reparto e contatori neutri. Prossima: risposte e Cronologia (rev. 48). Parte Compose non compilata in sessione.

- **PIN con tastierino (rev. 46)**: `PinDialog` in `SettingsScreen.kt` ha sei punti e un tastierino (`PinKey`) al posto del campo di testo; alla sesta cifra conferma da solo (`submit`), il nuovo PIN si digita due volte. Stessi controlli di prima (`checkPin`, `pinLockSeconds`, `setPin`). Parte Compose non compilata in sessione.

- **Stile unico: Home e Impostazioni (rev. 45)**: `SectionCard` e `ChooserCard` (`HomeParts.kt`) usano `surfaceContainer`/`surfaceContainerHigh` e un solo accento; la categoria resta nel pallino di `CategoryHeader` (`categoryPalette` non è più usata per le schede). Avviso "Manca la chiave API" come riga di stato; in `SettingsScreen` titoli delle schede neutri, `SettingsLink` e `StatusLine` con icona tonda. Prossime: Spesa/Frigo/Dispensa (rev. 46), risposte e Cronologia (rev. 47). Parte Compose non compilata in sessione.

- **Scheda Aggiornamenti a pulsante unico (rev. 44)**: in `UpdateSection` (`UpdateUi.kt`) un solo pulsante grande cambia con lo stato (Controlla aggiornamenti / Controllo in corso… / Controlla di nuovo / Riprova / Aggiorna ora); la riga di stato compare solo dopo un controllo; "Cosa c'è di nuovo" è una riga cliccabile con freccia. Parte Compose non compilata in sessione.

- **Avviso aggiornamento in Home ridisegnato (rev. 43)**: `UpdateCard` (in `UpdateUi.kt`) usa `surfaceContainerHigh` e un solo accento, titolo/stato in una riga, "Aggiorna ora" a tutta larghezza, percentuale durante il download, titolo "Manca un permesso"; `onDismiss` (X) nasconde l'avviso con un `rememberSaveable` in `HomeScreen`. Parte Compose non compilata in sessione.

- **Scheda Aggiornamenti ridisegnata (rev. 42)**: `UpdateSection` in `UpdateUi.kt` ha un solo accento, una riga di stato (controllo, aggiornata, disponibile, download con percentuale, errore) e un solo pulsante pieno ("Aggiorna ora"); "Controlla/Riprova" e "Novità" sono `TextButton` affiancati. `UpdateCard` (Home) resta com'era. Parte Compose non compilata in sessione.

- **Spesa a voce e schermo acceso (rev. 41)**: nel campo "Aggiungi" di `ShoppingScreen` il microfono lancia `RecognizerIntent` (come `SectionScreen`, nessun permesso) e `fromSpeech` mette le virgole al posto di "e / più / poi / virgola" così il testo si corregge prima di aggiungere; `splitItems` separa su virgola, punto e virgola o a capo (la virgola tra due cifre non separa: "Pasta 0,5 kg") e `addMany` passa da `withNewItems` come l'aggiunta singola. `keepScreenOn` sulla vista finché ci sono prodotti da comprare (`DisposableEffect` che lo toglie all'uscita). `NetErrors.message` dà frasi di rete chiare anche a sincronizzazione (`syncMessage` in `MainActivity`) e aggiornamenti (`UpdateUi`). Test in `ShoppingAddTest` e `NetErrorsTest`. Logica provata col compilatore Kotlin; la parte Compose non compilata in sessione.
- **Annulla ovunque, ricerca e rete (rev. 40)**: `GeminiClient.generate` ora gira in un `coroutineScope` con un osservatore (`launch(UNDISPATCHED) { awaitCancellation() }`) che alla cancellazione chiude la connessione (`LiveCall.cancel` → `HttpURLConnection.disconnect`); `SectionScreen` tiene il `requestJob` e `stopRequest`/`newChat` lo cancellano (prima l'annullo ignorava solo la risposta). `NetErrors.kt` (senza dipendenze Android) traduce gli errori di rete e decide se riprovare: un solo nuovo tentativo, solo se la richiesta non è partita (`UnknownHost`, `Connect`, timeout di connessione). Spesa: `removeWithUndo` (snackbar "Annulla", i prodotti tornano con `updatedAt` nuovo, così battono `shoppingDeleted` in `DriveSync.mergeShopping`); `addItem` passa da `withNewItems`, che ora rimette da comprare un prodotto già spuntato; l'annulla di `onToShopping` in `MainActivity` ripristina ogni voce che dopo l'aggiunta risulta diversa. `PantryScreen`: campo "Cerca" (`query`, da 8 prodotti) e Annulla sull'eliminazione. Accessibilità: `semantics { contentDescription }` sulle caselle di `ShopRow`. Test: `NetErrorsTest`, `ShoppingAddTest`. Provato in sessione col compilatore Kotlin e un server locale (streaming, fallback 429, annullo, assenza di rete); la parte Compose non è stata compilata: verificare con GitHub Actions.
- **Impara dalle correzioni e spreco** (`Learning.kt`): `ProductMemo` (chiave = nome scontrino normalizzato senza misure; ricorda nome, posto, ripiano, durata solo se cambiata) letta in `StockImportDialog` prima dell'AI (l'AI si chiede solo per i prodotti sconosciuti); `PantryItem.price` (dallo scontrino) → `WasteEntry` quando si usa "butta e rimetti in lista" o si elimina un prodotto scaduto (`PantryScreen.finish(wasted)`, `onWaste`/`onUnwaste` → `MainActivity.addWaste`); card "Buttato perché scaduto" in `StatsContent`. Nuovi blocchi di sincronizzazione/backup `waste` e `memory` (array con campo `i` = id, quindi si uniscono per id).
- **Dalla spesa al frigo** (`StockImport.kt`): `StockImportDialog` propone posto, ripiano e giorni di durata per i prodotti spuntati nella Spesa o per quelli di uno scontrino (`GeminiClient.suggestStock` → `Stock.parseAi`; senza chiave o se l'AI non risponde, `Stock.guess` per reparto). `Stock.merge` rinnova i duplicati (stesso nome e posto) invece di aggiungerli; in `MainActivity` `addToPantry` salva in background e avvia la sincronizzazione.
- **Frigo da scontrino e scadenze vere (rev. 36)**: `PantryScreen` ha il tasto "Aggiungi da scontrino" (`ReceiptToPantryFlow` in `PantryReceipt.kt`: foto → `ReceiptTools.read` → `StockImportDialog`, ora con nome modificabile). Dopo "Aggiungi" il dialogo chiede se mettere le scadenze vere: `ExpiryWalkthroughDialog` (`ExpiryUi.kt`) le chiede un prodotto alla volta con scorciatoie, calendario o foto dell'etichetta (`ExpiryTools.read` → `parseDate`). `PantryItem.estimated` (chiave JSON `g`) segna le scadenze stimate: si vedono come "circa tra 5 gg" e `PantryScreen` mostra "Aggiungi le scadenze" finché ce ne sono. Non compilato in sessione: verificare con GitHub Actions.
- **Un solo "+" e Finito (rev. 37)**: `PantryScreen` ha un solo pulsante "Aggiungi" con menu (Manualmente, Scansiona, Da scontrino). "Finito" (`finish()`) toglie il prodotto e, se si vuole, lo manda alla lista con `Pantry.toShopping` → `onToShopping` (`withNewItems` in `MainActivity`, che restituisce anche l'annulla); snackbar con Annulla, scheda per i scaduti e selezione multipla (pressione lunga). Non compilato in sessione.\n- **Avviso di scadenza automatico (rev. 38)**: `ExpiryNotifyPrompt` (`ExpiryNotifyPrompt.kt`, chiamato da `PantryScreen`) propone una volta l'avviso e chiede `POST_NOTIFICATIONS` (flag locale `Store.expiryAsked`); `Reminders.expiryNote` costruisce il testo (scaduti / in scadenza con `Pantry.soonLimit`, "circa" per le stime) e `postExpiry` aggiunge l'azione "Apri frigo/dispensa". Non compilato in sessione.
- **Ottimizzazioni**: R8/shrink attivi in release (`app/proguard-rules.pro`; se l'app crasha all'avvio, provare `isMinifyEnabled = false` in `app/build.gradle.kts`); risposte in streaming (`GeminiClient.postStream`, `onPartial` → `streamText` in `SectionScreen`); `Store.inBackground` per salvare frigo, scontrini e routine fuori dal thread principale (le chat restano sincrone di proposito); `Store.secure` pigro; `ImageUtils.load(maxSide)` con 2000 px per gli scontrini; file lunghi divisi in `SectionParts.kt`, `HomeParts.kt`, `ShoppingParts.kt` (le funzioni spostate sono `internal`); test in `app/src/test` (`gradle test`).
- **Giro 3** (`Reminders.kt`, `RoutinesUi.kt`): routine programmate (allarmi inesatti `setAndAllowWhileIdle`, nessun permesso speciale) e avviso di scadenza alle 8; `AlarmReceiver` gestisce allarmi e riavvio; la notifica apre l'app (e la richiesta parte da sola: `Shared.autoSend` → `autoSendPending` in `SectionScreen`) con l'extra `action` = `routine:<id>` o `place:<frigo|dispensa>` (gestito in `MainActivity`). Lettura ad alta voce con `TextToSpeech` in `SectionScreen`. Cronologia e Routine si aprono dalle Impostazioni.
- **Campi guidati** (`Guided.kt`, `GuidedUi.kt`): per ogni sezione un modulo a chip / testo sopra il composer; salvati per sezione in `Store.guidedFields` / `guidedValues`; le scelte diventano righe "Campo: valore" prima del testo in `SectionScreen.send()`; `GeminiClient.suggestFields` li propone.
- **Scontrini e statistiche** (`Receipts.kt`, `ReceiptsUi.kt`): foto dello scontrino letta da `ReceiptTools.read` (JSON con negozio, data, totale, articoli per reparto), salvata in `Store.receipts`; schermata `receipts` raggiunta dall'icona nella Spesa. Non ancora in backup/sincronizzazione.
- **Frigo e dispensa** (`Pantry.kt`, `PantryUi.kt`; due voci "Frigo" e "Dispensa" in `NavBar.kt`, schermate `frigo` / `dispensa`): prodotti su ripiani con scadenza (`PantryItem`, salvati in `Store.pantryItems`), vista Disegno/Elenco, stati scaduto / da usare presto (`Pantry.freshness`), scanner con `BarcodeTools.productName`, "Cosa ci cucino?" verso FRIGO (`Pantry.cookPrompt`). Non ancora in backup/sincronizzazione; notifiche di scadenza rimandate.
- **Manda a… e timer**: sotto ogni risposta "Manda a…" (`sendTargets` / `onSendTo` in `SectionScreen.kt`, collegato in `MainActivity.kt`) porta la risposta nel campo di un'altra sezione; i tempi nel testo ("12 min", "1 ora", `Timers.kt`) sono link toccabili in `Markdown.kt` e avviano un timer nell'Orologio (`AlarmClock.ACTION_SET_TIMER`, permesso `SET_ALARM` nel manifest). `SectionScreen` è avvolta in `key(section.id)`.
- **Archivio schede** (menu "+" > Archivio schede): per sezione, interruttore "Archivia i file che allego"; il blocco `DATI SCHEDA` (JSON con `esercizi`) di un PDF/testo è estratto (`DocArchive` in `DocUtils.kt`, `GeminiClient.extractData`), salvato in `Store.docItems` e aggiunto al prompt di sistema a ogni richiesta (`DocArchive.context`).
- **Allega documenti**: voce "Da file" nel "+" (`DocUtils.kt`, `ChatDoc` in `GeminiClient.kt`): PDF fino a 15 MB (inviato come `inline_data`) e file di testo (inviati come testo).
- **Revisione dai mockup (appunti "DA CAMBIARE")**: scheda vuota con suggerimenti a schede grandi, risposta a card per proposta con barra azioni fissa (`AiResponse`, `ResponseActions` in `SectionScreen.kt`; pillola tempo `[15 min]` nel titolo, `Passaggi` richiudibili in `Markdown.kt`), lista della spesa con reparti a icona, swipe per cambiare reparto, lista Bring accanto al reparto (`Store.bringListNames`) e conferma "Apri Bring" (`<queries>` nel manifest), Impostazioni in gruppi, Cronologia con filtri/date/swipe (`Store.restoreArchived`), Nuova sezione a schede grandi con "Crea con AI" a un campo e libreria con anteprima.
- **Nuova Home (mockup "Prisma – mockup e revisione")**: barra di navigazione in basso (`NavBar.kt`: Home, Spesa, Cronologia, Impostazioni, nascosta con la tastiera aperta), testata compatta con logo, titolo, Novità e vista griglia/lista (`HomeHeader` in `HomeScreen.kt`), ricerca sempre visibile, schede in griglia con solo icona e titolo, pulsante "+" al posto di "Nuova sezione".
- **Home**: ricerca (lente), colore per categoria (`categoryPalette`, indice salvato in `Store.categoryColors`), menu scheda con Condividi (`CardShare.kt`, codice `PRISMA1:` importabile da Condividi verso Prisma o da "Incolla scheda") e Aggiungi alla Home (`SectionShortcut.kt`, extra `open_section`); Elimina con "Annulla" (`DeletedSection` in `MainActivity.kt`).
- **Categorie e riordino**: ogni scheda può avere una categoria (campo in creazione/modifica); in Home le schede sono raggruppate sotto il titolo della categoria (si chiude con un tocco; menu a tre puntini: rinomina, sposta su/giù, togli). Tenendo premuta una scheda e trascinando la si riordina (dentro la sua categoria e tra pinnate / non pinnate); `Section.category`, salvata in `Store`, `Sync` e backup.
- **Novità** (icona in Home e pulsante in Impostazioni): changelog nell'app, con pallino quando c'è qualcosa di nuovo.
  Si aggiorna in `Changelog.kt`: nuova voce in cima alla lista, con `id` più alto.
- **Su di me** (Impostazioni): testo aggiunto a ogni richiesta (obiettivi, allergie, preferenze). Cifrato, solo sul telefono.
- **Condividi verso Prisma**: da Galleria, Chrome, WhatsApp... scegli Prisma, poi la sezione (`ShareUi.kt`).
- **Scanner codice a barre** (menu + nella sezione): ML Kit + Open Food Facts, testo pronto nel campo (`BarcodeTools.kt`).

- **Lista della spesa** (carrello in Home): checklist, sincronizzata con l'account Google (per prodotto vince la modifica più recente, le eliminazioni si propagano); con la lista aperta si risincronizza ogni 20 s, "tira giù" forza la sincronizzazione, e si sincronizza anche a ogni ritorno nell'app; "Alla lista" compare solo quando l'AI riconosce prodotti concreti da comprare: chiude la risposta con una riga nascosta `[[LISTA: a | b]]` (istruzione in `GeminiClient.STYLE`, lettura in `splitShoppingMarker`, `ShoppingUi.kt`); per meteo, calcoli, pacchi ecc. il tasto non c'è.
- ~~Suggerimenti rapidi~~ tolti nella revisione 24 (nel codice resta solo `QuickChip`, usato dal campo di testo).
- **Lunghezza risposte** (Breve / Normale / Dettagliata) e **cambio modello automatico** (404, 429, 5xx) in Impostazioni > Risposte.
- **Contatore** delle richieste fatte oggi (solo informativo: il limite gratuito lo decide Google).

- **Lista per reparti**: l'AI aggiunge `#Reparto` ai prodotti nella riga `[[LISTA: ...]]`; modifica del prodotto al tocco, condividi, "Cosa ci cucino?" (manda a FRIGO), suggerimenti "ricomprare" (storico sincronizzato), evidenziazione dei prodotti nuovi da sync.
- **Sincronizzazione**: sezioni, lista della spesa, storico e, se attivato, "Su di me" (`LocalSync` / `DriveSync` in `Sync.kt`).
- **Cronologia** (`HistoryUi.kt`): "Nuova chat" archivia la chat (`Store.archiveChat`); ricerca nel testo; riapri una chat archiviata.
- **Libreria sezioni** (`Library.kt`) e sezioni extra (`DefaultSections.extra`, aggiunte una volta anche a chi aveva già l'app).
- **Backup** (`BackupTools.kt`): file JSON, senza chiave API né chat (chiave e chat ci sono solo nel backup su Drive, cartella privata); il ripristino unisce ai dati presenti.
- **Widget** (`ShoppingWidget.kt`, `res/xml/shopping_widget_info.xml`) e **scorciatoie** (`res/xml/shortcuts.xml`, extra `action`: `shopping`, `spesa_photo`, `spesa_scan`).
- **Tema** chiaro / scuro / automatico (`Theme.kt`, `Store.theme`).

## Compilazione e aggiornamenti OTA (GitHub)

La repo contiene `PromptBox.zip` e il workflow `.github/workflows/build.yml`.
Ad ogni push il workflow scompatta lo zip, compila l'APK firmato e crea una release `v<numero>`.
L'app controlla l'ultima release all'avvio (e da Impostazioni > Controlla aggiornamenti),
scarica l'APK e avvia l'installazione.

Per pubblicare una nuova versione: sostituisci `PromptBox.zip` nella repo con quello nuovo e fai commit.

Requisiti:
- la repo `mdo-video/PromptBox` deve essere **pubblica** (l'app legge le release senza login);
- la firma è sempre la stessa (`app/promptbox.jks`), altrimenti Android rifiuta l'aggiornamento;
- il numero della versione è il numero dell'esecuzione del workflow, quindi cresce da solo;
- la prima installazione si fa a mano dall'APK della release, consentendo "installa app sconosciute".

## Come funziona il codice

- `Sync.kt`        accesso con Google e sincronizzazione delle sezioni nella cartella nascosta di Drive.
- `Markdown.kt`    divide la risposta in blocchi e li disegna (MarkdownText).
- `Sections.kt`    sezioni di partenza: vengono copiate nello Store alla prima apertura, poi sono tutte modificabili.
- `GeminiClient.kt` chiamata REST all'API Gemini (testo + immagine, conversazione a più turni, stile Markdown aggiunto a ogni prompt), con messaggi d'errore in italiano.
- `Store.kt`       chiave API e chat cifrate (EncryptedSharedPreferences), modello, sezioni, blocchi sincronizzati.
- `ImageUtils.kt`  carica la foto, la ruota e la riduce a 1280 px prima dell'invio.
- `Updater.kt`, `UpdateUi.kt` aggiornamento OTA da GitHub Releases.
- `Changelog.kt`   voci e schermata Novità.
- `ShareUi.kt`     ricezione dal menu Condividi e scelta della sezione.
- `BarcodeTools.kt` scanner e ricerca prodotto.
- `ShoppingUi.kt`  lista della spesa e finestra "Alla lista".
- `HistoryUi.kt`, `Library.kt`, `BackupTools.kt`, `ShoppingWidget.kt` vedi sopra.
- `MainActivity.kt` schermate: Home, Sezione, Impostazioni.

## Note

- Modello predefinito: `gemini-3.1-flash-lite`. Se Google lo cambia, modificalo in Impostazioni.
- Chiave API gratuita: https://aistudio.google.com/apikey (si inserisce nelle Impostazioni dell'app).
- Nel free tier Google può usare i dati inviati per migliorare i suoi prodotti: niente dati sensibili.
- Il keystore è nella repo con password semplice: va bene per un'app personale, ma chiunque
  veda la repo potrebbe firmare un APK con la stessa firma.


## Account Google e sincronizzazione

In Impostazioni → Account Google. Servono il progetto Google Cloud con Drive API attiva e un client OAuth Android
(pacchetto `com.promptbox`, impronta SHA-1 di `app/promptbox.jks`). Si sincronizzano sezioni (nome, icona, prompt), lista della spesa
le eliminazioni, frigo e dispensa, scontrini, routine e campi guidati; la chiave API viaggia con le impostazioni (`apiKey` in `Store.settingsJson`, solo verso Drive; `DriveSync.fillSecret` non la perde mai); chat, archivio chat e archivio documenti viaggiano come blocchi `chats` e `docs`. Parte all'apertura e dopo ogni modifica; per ogni sezione
vince la versione modificata più di recente.
