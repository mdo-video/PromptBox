# PromptBox

App Android (Kotlin + Jetpack Compose) che raccoglie prompt già pronti, ognuno con la sua AI.
Ogni sezione è un prompt di sistema: tu aggiungi solo foto e/o testo.

Sezioni incluse: SPESA, ETICHETTA, FRIGO, LIBERO. Dall'app puoi crearne altre (pulsante "Nuova sezione").

## Come aprirla

1. Apri la cartella in Android Studio (Ladybug o più recente). Il wrapper Gradle viene creato da Android Studio al primo sync.
2. Collega il telefono o avvia un emulatore e premi Run. Oppure: Build > Build APK(s).
3. Nell'app vai in Impostazioni e incolla la tua chiave API Gemini
   (gratuita su https://aistudio.google.com/apikey).

## Come funziona

- `Sections.kt`   prompt delle sezioni fisse. Per aggiungerne una basta una voce nella lista.
- `GeminiClient.kt` chiamata REST all'API Gemini (testo + immagine), con messaggi d'errore in italiano.
- `Store.kt`      chiave API cifrata (EncryptedSharedPreferences), modello e sezioni personalizzate.
- `ImageUtils.kt` carica la foto, la ruota e la riduce a 1280 px prima dell'invio.
- `MainActivity.kt` schermate: Home, Sezione, Impostazioni.

## Note

- Modello predefinito: `gemini-2.5-flash`. Se Google lo cambia, modificalo in Impostazioni
  senza ricompilare.
- Free tier: i limiti precisi per modello si vedono in Google AI Studio. Se li superi l'app mostra
  un avviso e basta riprovare più tardi.
- Nel free tier Google può usare i dati inviati per migliorare i suoi prodotti: niente dati sensibili.
