# Prisma (cartella e zip: PromptBox)

Il nome mostrato nell'app è "Prisma" (`res/values/strings.xml`). L'ID tecnico `com.promptbox`
e il nome dello zip restano uguali: servono agli aggiornamenti automatici.

Grafica: Material 3 scuro, tema in `Theme.kt`, colori dinamici opzionali (Android 12+) da Impostazioni.
Icona: `res/drawable/ic_launcher_foreground.xml` (adattiva, con versione monocromatica per le icone a tema).

App Android (Kotlin + Jetpack Compose) che raccoglie prompt già pronti, ognuno con la sua AI.
Ogni sezione è un prompt di sistema: tu aggiungi solo foto e/o testo.

Sezioni incluse: SPESA, ETICHETTA, FRIGO, LIBERO. Dall'app puoi crearne altre (pulsante "Nuova sezione"):
l'emoji la sceglie l'AI leggendo titolo e istruzioni (📌 finché non risponde o se manca la chiave API).
Ogni sezione si può fissare in alto con la puntina.

## Compilazione e aggiornamenti OTA (GitHub)

La repo contiene `PromptBox.zip` e il workflow `.github/workflows/build.yml`.
Ad ogni push il workflow scompatta lo zip, compila l'APK firmato e crea una release `v<numero>`.
L'app controlla l'ultima release all'avvio (e da Impostazioni > Controlla aggiornamenti),
scarica l'APK e avvia l'installazione.

Per pubblicare una nuova versione: sostituisci `PromptBox.zip` nella repo con quello nuovo e fai commit.

Requisiti:
- la repo `mdo-video/PromptBox` deve essere **pubblica** (l'app legge le release senza login);
- la firma è sempre la stessa (`app/promptbox.jks`), altrimenti Android rifiuta l'aggiornamento;
- il numero della versione è il numero dell'esecuzione del workflow, quindi cresce da solo;
- la prima installazione si fa a mano dall'APK della release, consentendo "installa app sconosciute".

## Come funziona il codice

- `Sections.kt`    prompt delle sezioni fisse. Per aggiungerne una basta una voce nella lista.
- `GeminiClient.kt` chiamata REST all'API Gemini (testo + immagine), con messaggi d'errore in italiano.
- `Store.kt`       chiave API cifrata (EncryptedSharedPreferences), modello e sezioni personalizzate.
- `ImageUtils.kt`  carica la foto, la ruota e la riduce a 1280 px prima dell'invio.
- `Updater.kt`, `UpdateUi.kt` aggiornamento OTA da GitHub Releases.
- `MainActivity.kt` schermate: Home, Sezione, Impostazioni.

## Note

- Modello predefinito: `gemini-3.1-flash-lite`. Se Google lo cambia, modificalo in Impostazioni.
- Chiave API gratuita: https://aistudio.google.com/apikey (si inserisce nelle Impostazioni dell'app).
- Nel free tier Google può usare i dati inviati per migliorare i suoi prodotti: niente dati sensibili.
- Il keystore è nella repo con password semplice: va bene per un'app personale, ma chiunque
  veda la repo potrebbe firmare un APK con la stessa firma.
