package com.promptbox

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat

/**
 * Una sola volta, appena in frigo o in dispensa c'è un prodotto con scadenza: propone l'avviso delle 8 del mattino.
 * Android vuole la conferma dell'utente per le notifiche, quindi qui si spiega e si chiede il permesso.
 * Dopo la risposta non richiede più (l'interruttore resta in Impostazioni → Routine).
 */
@Composable
fun ExpiryNotifyPrompt(store: Store, hasExpiry: Boolean) {
    val context = LocalContext.current
    var show by remember { mutableStateOf(false) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(hasExpiry) {
        if (hasExpiry && !store.expiryNotify && !store.expiryAsked) {
            store.expiryAsked = true
            show = true
        }
    }

    if (show) {
        AlertDialog(
            onDismissRequest = { show = false },
            title = { Text("Avviso di scadenza") },
            text = {
                Text(
                    "Ogni mattina alle 8 ti scrivo se in frigo o in dispensa c'è qualcosa di scaduto o che sta per scadere, " +
                        "così non ti accorgi tardi. Posso attivarlo?",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    show = false
                    store.expiryNotify = true
                    if (Build.VERSION.SDK_INT >= 33 &&
                        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    ) {
                        permission.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    Reminders.rescheduleAll(context, store)
                }) { Text("Attiva") }
            },
            dismissButton = { TextButton(onClick = { show = false }) { Text("Non ora") } },
        )
    }
}
