package com.promptbox

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Da questa larghezza (dp) l'app usa il layout per tablet: barra laterale e schermate affiancate. */
const val WIDE_MIN_DP = 600

/**
 * Elenco delle schede a sinistra e la scheda aperta a destra. Su telefono mostra solo [content].
 */
@Composable
fun SectionPaneLayout(
    wide: Boolean,
    sections: List<Section>,
    selectedId: String,
    onSelect: (String) -> Unit,
    content: @Composable () -> Unit,
) {
    if (!wide) {
        content()
        return
    }
    Row(Modifier.fillMaxSize()) {
        SectionListPane(sections, selectedId, onSelect, Modifier.width(300.dp).fillMaxHeight())
        VerticalDivider()
        Box(Modifier.weight(1f).fillMaxHeight()) { content() }
    }
}

@Composable
private fun SectionListPane(sections: List<Section>, selectedId: String, onSelect: (String) -> Unit, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    Column(modifier.windowInsetsPadding(WindowInsets.statusBars)) {
        Text(
            "Schede",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(start = 20.dp, top = 18.dp, end = 20.dp, bottom = 8.dp),
        )
        LazyColumn(
            contentPadding = PaddingValues(12.dp, 4.dp, 12.dp, 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(sections, key = { it.id }) { s ->
                val selected = s.id == selectedId
                val shape = RoundedCornerShape(20.dp)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(shape)
                        .background(if (selected) cs.surfaceContainerHigh else cs.surfaceContainer)
                        .then(if (selected) Modifier.border(BorderStroke(2.dp, cs.primary), shape) else Modifier)
                        .clickable { onSelect(s.id) }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier.size(38.dp).clip(CircleShape).background(cs.primary.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center,
                    ) { Text(s.emoji, fontSize = 18.sp) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(s.title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            s.hint,
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
    }
}

/** Due schermate affiancate su tablet; su telefono solo quella di sinistra ([left]). */
@Composable
fun TwoPane(wide: Boolean, right: @Composable () -> Unit, left: @Composable () -> Unit) {
    if (!wide) {
        left()
        return
    }
    Row(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxHeight()) { left() }
        VerticalDivider()
        Box(Modifier.weight(1f).fillMaxHeight()) { right() }
    }
}
