package com.promptbox

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val EMOJI_CHOICES = listOf(
    "🥛", "🧀", "🥩", "🐟", "🥬", "🍎", "🍞", "🍝", "🥫", "🧂",
    "🍫", "🧃", "🍱", "🥚", "🍕", "🍦", "🧴", "🧽", "🧻", "📦",
)

private fun placeTitle(place: String): String = KitchenTabs.renamed(place) ?: when (place) {
    "frigo" -> "Frigo"
    "dispensa" -> "Dispensa"
    "congelatore" -> "Congelati"
    else -> "Pulizie e igiene"
}

/** Il nome del ripiano è valido? (non vuoto, non troppo lungo, diverso dagli altri). Vuoto = va bene. */
internal fun shelfNameError(name: String, others: List<String>): String {
    val n = name.trim()
    return when {
        n.isEmpty() -> "Scrivi un nome"
        n.length > 24 -> "Al massimo 24 lettere"
        others.any { it.equals(n, ignoreCase = true) } -> "C'è già un ripiano con questo nome"
        else -> ""
    }
}

/** Dove va un prodotto quando il suo ripiano viene eliminato: "Altro" se c'è, altrimenti il primo rimasto. */
internal fun shelfAfterDelete(remaining: List<String>): String = remaining.firstOrNull { it.equals("Altro", ignoreCase = true) } ?: remaining.first()

/**
 * Impostazioni di un posto: scadenze accese o spente, ripiano scelto dall'AI, avvisi, e i ripiani
 * (si aggiungono, si rinominano, si riordinano, si eliminano; ognuno può avere o no la scadenza).
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PlaceSettingsSheet(
    place: String,
    store: Store,
    items: List<PantryItem>,
    onItems: (List<PantryItem>) -> Unit,
    onChanged: () -> Unit,
    onDismiss: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var cfg by remember { mutableStateOf(store.pantryConfig) }
    // Il ripiano in modifica: il suo numero, oppure NEW per uno nuovo; null = nessuno.
    var editing by remember { mutableStateOf<Int?>(null) }
    val pc = cfg.of(place)
    val defs = cfg.shelfDefs(place)
    val isCasa = place == "casa"

    fun save(newPlace: PlaceConfig) {
        val n = cfg.with(place, newPlace)
        cfg = n
        store.pantryConfig = n
        onChanged()
    }

    fun saveShelves(list: List<ShelfDef>) = save(pc.copy(shelves = list))

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = cs.surfaceContainerHigh,
    ) {
        Column(Modifier.navigationBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
            Text("Impostazioni · " + placeTitle(place), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))

            if (!isCasa) {
                SettingSwitch(
                    "Usa le scadenze",
                    "Spento: niente date, stime, \"da usare presto\" né foto della data",
                    pc.expiry,
                ) { save(pc.copy(expiry = it)) }
                if (pc.expiry) {
                    SettingSwitch("Avvisi di scadenza", "Le notifiche della mattina includono questo posto", pc.notify) { save(pc.copy(notify = it)) }
                }
                SettingSwitch("Ripiano scelto dall'AI", "Da foto, scrittura o codice a barre: se spento lo scegli tu", pc.autoShelf) { save(pc.copy(autoShelf = it)) }
                HorizontalDivider(Modifier.padding(vertical = 12.dp), color = cs.outlineVariant.copy(alpha = 0.5f))
            }

            Text("Ripiani", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
            Text("Tocca un ripiano per cambiarlo; le frecce lo spostano.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            Spacer(Modifier.height(6.dp))
            defs.forEachIndexed { i, d ->
                Row(
                    Modifier.fillMaxWidth().clickable { editing = i }.padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(d.emoji, style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(d.name, style = MaterialTheme.typography.bodyLarge)
                        if (!isCasa && pc.expiry && !d.expiry) {
                            Text("Senza scadenza", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        }
                    }
                    IconButton(
                        enabled = i > 0,
                        onClick = { saveShelves(defs.toMutableList().also { val x = it.removeAt(i); it.add(i - 1, x) }) },
                    ) { Icon(Icons.Filled.ExpandLess, contentDescription = "Sposta su") }
                    IconButton(
                        enabled = i < defs.lastIndex,
                        onClick = { saveShelves(defs.toMutableList().also { val x = it.removeAt(i); it.add(i + 1, x) }) },
                    ) { Icon(Icons.Filled.ExpandMore, contentDescription = "Sposta giù") }
                }
            }
            OutlinedButton(onClick = { editing = NEW_SHELF }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Icon(Icons.Filled.Add, null)
                Spacer(Modifier.width(8.dp))
                Text("Aggiungi un ripiano")
            }
            if (pc.shelves != null) {
                TextButton(
                    onClick = {
                        // I prodotti sui ripiani che spariscono vanno nel primo dei predefiniti.
                        val keep = Pantry.defaultShelves(place)
                        onItems(items.map { if (it.place == place && it.shelf !in keep) it.copy(shelf = keep.first()) else it })
                        save(pc.copy(shelves = null))
                    },
                ) { Text("Ripristina i ripiani predefiniti") }
            }
        }
    }

    editing?.let { index ->
        val old = defs.getOrNull(index)
        ShelfEditDialog(
            def = old,
            others = defs.filterIndexed { i, _ -> i != index }.map { it.name },
            showExpiry = !isCasa && pc.expiry,
            canDelete = old != null && defs.size > 1,
            onSave = { d ->
                saveShelves(if (old == null) defs + d else defs.toMutableList().also { it[index] = d })
                if (old != null && old.name != d.name) {
                    onItems(items.map { if (it.place == place && it.shelf == old.name) it.copy(shelf = d.name) else it })
                }
                editing = null
            },
            onDelete = {
                if (old != null) {
                    val rest = defs.filterIndexed { i, _ -> i != index }
                    val target = shelfAfterDelete(rest.map { it.name })
                    saveShelves(rest)
                    onItems(items.map { if (it.place == place && it.shelf == old.name) it.copy(shelf = target) else it })
                }
                editing = null
            },
            onDismiss = { editing = null },
        )
    }
}

private const val NEW_SHELF = -1

@Composable
private fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ShelfEditDialog(
    def: ShelfDef?,
    others: List<String>,
    showExpiry: Boolean,
    canDelete: Boolean,
    onSave: (ShelfDef) -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var name by remember { mutableStateOf(def?.name.orEmpty()) }
    var emoji by remember { mutableStateOf(def?.emoji ?: "📦") }
    var expiry by remember { mutableStateOf(def?.expiry ?: true) }
    val error = shelfNameError(name, others)
    var touched by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (def == null) "Nuovo ripiano" else "Modifica ripiano") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(30); touched = true },
                    label = { Text("Nome") },
                    singleLine = true,
                    isError = touched && error.isNotEmpty(),
                    supportingText = { if (touched && error.isNotEmpty()) Text(error) },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = emoji,
                    onValueChange = { emoji = it.take(4) },
                    label = { Text("Emoji") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    EMOJI_CHOICES.forEach { e ->
                        Text(
                            e,
                            style = MaterialTheme.typography.titleLarge,
                            modifier = Modifier.clickable { emoji = e }.padding(6.dp),
                        )
                    }
                }
                if (showExpiry) {
                    Row(Modifier.fillMaxWidth().clickable { expiry = !expiry }, verticalAlignment = Alignment.CenterVertically) {
                        Text("Con scadenza", modifier = Modifier.weight(1f))
                        Switch(checked = expiry, onCheckedChange = { expiry = it })
                    }
                }
                if (canDelete) {
                    TextButton(onClick = onDelete) { Text("Elimina il ripiano", color = cs.error) }
                    Text(
                        "I prodotti che ci sono passano in \"" + "Altro" + "\" se esiste, altrimenti nel primo ripiano.",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = error.isEmpty(),
                onClick = { onSave(ShelfDef(name.trim(), emoji.trim().ifEmpty { "📦" }, expiry)) },
            ) { Text("Salva") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annulla") } },
    )
}
