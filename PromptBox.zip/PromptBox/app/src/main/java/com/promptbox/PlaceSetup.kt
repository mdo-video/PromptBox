package com.promptbox

import org.json.JSONObject

/**
 * Tutto quello che serve per avviare una scheda nuova: le opzioni (temperatura, sbrinamento, pulizia...) e le
 * impostazioni del posto (ripiani, scadenze, avvisi). Si ricava dal nome: "Frigo 2" si comporta da frigo, "Congelatore 2"
 * da congelatore, "Sottotetto" da ripostiglio (niente scadenze né ricette, ma spazio e piantina).
 */
data class PlaceSetup(val options: PlaceConditions = PlaceConditions(), val config: PlaceConfig = PlaceConfig()) {
    companion object {
        /** Dove non si tiene da mangiare (ripostiglio, pulizie) le scadenze e i loro avvisi non servono. */
        fun configFor(kind: PlaceKind?): PlaceConfig = when (kind) {
            PlaceKind.STORAGE, PlaceKind.CLEANING -> PlaceConfig(expiry = false, notify = false)
            else -> PlaceConfig()
        }

        fun forKind(kind: PlaceKind): PlaceSetup = PlaceSetup(PlaceConditions.forKind(kind), configFor(kind))

        /** Senza rete: dal nome. Un nome che non si riconosce non cambia niente. */
        fun guess(name: String): PlaceSetup {
            val o = PlaceConditions.guess(name)
            return PlaceSetup(o, configFor(o.placeKind()))
        }

        /**
         * Legge la risposta dell'AI (vedi [GeminiClient.suggestPlaceOptions]). I ripiani suggeriti si usano solo nei posti
         * "liberi" (ripostiglio, cantina, altro): frigo, congelatore, dispensa e pulizie tengono i loro ripiani di sempre.
         * Lancia un errore se la risposta non si legge, così chi chiama ripiega su [guess].
         */
        fun parse(raw: String, name: String = ""): PlaceSetup {
            var options = PlaceConditions.parseSuggestion(raw)
            if (options.kind == null) options = options.copy(kind = PlaceKind.guess(name)?.key)
            val kind = options.placeKind()
            val clean = raw.replace("```json", "").replace("```", "").trim()
            val o = JSONObject(clean.substring(clean.indexOf('{'), clean.lastIndexOf('}') + 1))
            fun flag(k: String): Boolean? = o.optJSONObject(k)?.let { if (it.has("attiva")) it.optBoolean("attiva") else null }
            val base = configFor(kind)
            val expiry = flag("scadenze") ?: base.expiry
            val notify = flag("avvisi") ?: base.notify
            val free = kind == null || kind == PlaceKind.STORAGE || kind == PlaceKind.CELLAR || kind == PlaceKind.OTHER
            val shelves = if (!free) null else o.optJSONArray("ripiani")?.let { arr ->
                (0 until arr.length()).mapNotNull { i ->
                    val s = arr.optJSONObject(i) ?: return@mapNotNull null
                    val n = s.optString("nome").trim().take(24)
                    if (n.isEmpty()) null else ShelfDef(n, s.optString("emoji").trim().take(8).ifBlank { "📦" }, s.optBoolean("scadenza", expiry))
                }.distinctBy { it.name.lowercase() }.take(8).takeIf { it.size >= 2 }
            }
            return PlaceSetup(options, PlaceConfig(shelves = shelves, expiry = expiry, autoShelf = base.autoShelf, notify = notify))
        }
    }
}
