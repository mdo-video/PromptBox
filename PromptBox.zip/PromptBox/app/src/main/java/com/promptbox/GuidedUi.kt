package com.promptbox

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/** Il modulo sopra la casella di testo: scelte rapide (chip) o testo breve per ogni campo. */
@Composable
fun GuidedPanel(fields: List<GuidedField>, values: Map<String, String>, onChange: (Map<String, String>) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxWidth().heightIn(max = 210.dp).verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        fields.forEach { f ->
            Column {
                Text(f.label, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                if (f.options.isEmpty()) {
                    OutlinedTextField(
                        value = values[f.label].orEmpty(),
                        onValueChange = { onChange(values + (f.label to it)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        f.options.forEach { o ->
                            val on = values[f.label] == o
                            FilterChip(
                                selected = on,
                                onClick = { onChange(if (on) values - f.label else values + (f.label to o)) },
                                label = { Text(o) },
                            )
                        }
                    }
                }
            }
        }
    }
}

private data class FieldDraft(val label: String, val options: String)

/** Crea, cambia o toglie i campi guidati di una sezione; l'AI può proporne di nuovi. */
@Composable
fun GuidedFieldsDialog(
    initial: List<GuidedField>,
    suggest: suspend () -> Result<List<GuidedField>>,
    onSave: (List<GuidedField>) -> Unit,
    onDismiss: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val drafts = remember {
        mutableStateListOf<FieldDraft>().also { l -> l.addAll(initial.map { FieldDraft(it.label, it.options.joinToString(", ")) }) }
    }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Campi guidati") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Appaiono sopra la casella di testo e compongono la richiesta per te. " +
                        "Se lasci vuote le opzioni, il campo è di testo libero.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
                drafts.forEachIndexed { i, d ->
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = d.label,
                                onValueChange = { drafts[i] = d.copy(label = it) },
                                label = { Text("Nome del campo") },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                            )
                            IconButton(onClick = { drafts.removeAt(i) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Togli il campo")
                            }
                        }
                        OutlinedTextField(
                            value = d.options,
                            onValueChange = { drafts[i] = d.copy(options = it) },
                            label = { Text("Opzioni, separate da virgola") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { if (drafts.size < 6) drafts.add(FieldDraft("", "")) }) { Text("Aggiungi campo") }
                    TextButton(
                        enabled = !busy,
                        onClick = {
                            busy = true
                            err = null
                            scope.launch {
                                suggest()
                                    .onSuccess { list ->
                                        list.forEach { f ->
                                            if (drafts.size < 6 && drafts.none { it.label.trim().equals(f.label, ignoreCase = true) }) {
                                                drafts.add(FieldDraft(f.label, f.options.joinToString(", ")))
                                            }
                                        }
                                    }
                                    .onFailure { err = it.message ?: "Proposta non riuscita." }
                                busy = false
                            }
                        },
                    ) {
                        if (busy) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                        else Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                        Text("  Proponi con AI")
                    }
                }
                err?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    drafts.mapNotNull { d ->
                        val label = d.label.trim()
                        if (label.isEmpty()) null
                        else GuidedField(label, d.options.split(",").map { it.trim() }.filter { it.isNotEmpty() })
                    }.distinctBy { it.label }.take(6),
                )
            }) { Text("Salva") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annulla") } },
    )
}
