package com.promptbox

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat

/** Aggiunge alla Home di Android un'icona che apre direttamente una scheda. */
object SectionShortcut {

    /** false se il launcher non supporta le scorciatoie fissate. */
    fun pin(context: Context, s: Section): Boolean {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(context)) return false
        val intent = Intent(context, MainActivity::class.java)
            .setAction(Intent.ACTION_VIEW)
            .putExtra("open_section", s.id)
        val info = ShortcutInfoCompat.Builder(context, "sec_${s.id}")
            .setShortLabel(s.title.lowercase().replaceFirstChar { it.uppercase() }.take(14))
            .setLongLabel(s.title)
            .setIcon(IconCompat.createWithBitmap(emojiBitmap(s.emoji)))
            .setIntent(intent)
            .build()
        return ShortcutManagerCompat.requestPinShortcut(context, info, null)
    }

    private fun emojiBitmap(emoji: String): Bitmap {
        val size = 192
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF14201B.toInt() }
        canvas.drawCircle(size / 2f, size / 2f, size / 2f, bg)
        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size * 0.5f
            textAlign = Paint.Align.CENTER
        }
        val y = size / 2f - (text.descent() + text.ascent()) / 2f
        canvas.drawText(emoji, size / 2f, y, text)
        return bmp
    }
}
