package com.promptbox

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Kitchen
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Warehouse
import androidx.compose.material.icons.filled.WineBar
import androidx.compose.material.icons.outlined.Warehouse
import androidx.compose.material.icons.outlined.WineBar
import androidx.compose.material3.FilterChip
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.outlined.AcUnit
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material.icons.outlined.CleaningServices
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.Kitchen
import androidx.compose.material.icons.outlined.PieChart
import androidx.compose.material.icons.outlined.Receipt
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.VerticalDivider
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/** I due gruppi della riga: le schede "di lavoro" (spesa, riepilogo, scontrini) e i luoghi dove si tengono le cose. Tra i due gruppi c'è un filetto. */
internal fun tabGroup(id: String): Int = if (id == "shopping" || id == "cucina" || id == "receipts") 0 else 1

/** L'icona di una scheda: piena quando è quella aperta, solo contorno nelle altre (come nella barra in basso di Material 3). */
internal fun tabIcon(id: String, selected: Boolean, kind: PlaceKind? = null): ImageVector = when (id) {
    "shopping" -> if (selected) Icons.Filled.ShoppingCart else Icons.Outlined.ShoppingCart
    "cucina" -> if (selected) Icons.Filled.PieChart else Icons.Outlined.PieChart
    "frigo" -> if (selected) Icons.Filled.Kitchen else Icons.Outlined.Kitchen
    "dispensa" -> if (selected) Icons.Filled.Inventory2 else Icons.Outlined.Inventory2
    "congelatore" -> if (selected) Icons.Filled.AcUnit else Icons.Outlined.AcUnit
    "casa" -> if (selected) Icons.Filled.CleaningServices else Icons.Outlined.CleaningServices
    "receipts" -> if (selected) Icons.Filled.Receipt else Icons.Outlined.Receipt
    else -> kindIcon(kind, selected)
}

/** L'icona di un posto in base al tipo: una scheda "Frigo 2" ha il frigo, "Sottotetto" il magazzino, "Cantina" il calice. */
internal fun kindIcon(kind: PlaceKind?, selected: Boolean): ImageVector = when (kind) {
    PlaceKind.FRIDGE -> if (selected) Icons.Filled.Kitchen else Icons.Outlined.Kitchen
    PlaceKind.FREEZER -> if (selected) Icons.Filled.AcUnit else Icons.Outlined.AcUnit
    PlaceKind.PANTRY -> if (selected) Icons.Filled.Inventory2 else Icons.Outlined.Inventory2
    PlaceKind.CELLAR -> if (selected) Icons.Filled.WineBar else Icons.Outlined.WineBar
    PlaceKind.STORAGE -> if (selected) Icons.Filled.Warehouse else Icons.Outlined.Warehouse
    PlaceKind.CLEANING -> if (selected) Icons.Filled.CleaningServices else Icons.Outlined.CleaningServices
    else -> if (selected) Icons.Filled.Category else Icons.Outlined.Category
}

/**
 * Una scheda della riga in alto in Casa. Si tocca per aprirla e si tiene premuta per il menu: per questo non è un
 * FilterChip (che ha solo il tocco semplice) ma una superficie con [combinedClickable].
 *
 * Gerarchia: la scheda aperta è l'unica "piena" (secondaryContainer, icona piena, testo in neretto); le altre sono solo
 * icona a contorno e testo, senza bordo. Il numero dei prodotti da usare presto è un Badge discreto (primary) e non più rosa.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun TabChip(label: String, icon: ImageVector, selected: Boolean, badge: Int, onClick: () -> Unit, onLongClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val container by animateColorAsState(if (selected) cs.secondaryContainer else Color.Transparent, label = "tabContainer")
    val content = if (selected) cs.onSecondaryContainer else cs.onSurfaceVariant
    Surface(
        shape = CircleShape,
        color = container,
        modifier = Modifier
            .height(40.dp)
            .clip(CircleShape)
            .semantics { this.selected = selected }
            .combinedClickable(onClick = onClick, onLongClick = onLongClick, onLongClickLabel = "Opzioni della scheda", role = Role.Tab),
    ) {
        Row(Modifier.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = content, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                label,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = content,
                maxLines = 1,
                softWrap = false,
            )
            if (badge > 0) {
                Spacer(Modifier.width(8.dp))
                Badge(containerColor = cs.primary, contentColor = cs.onPrimary) { Text(if (badge > 9) "9+" else badge.toString()) }
            }
        }
    }
}

/** Il filetto tra un gruppo di schede e l'altro. */
@Composable
internal fun TabGroupDivider() {
    VerticalDivider(
        modifier = Modifier.height(20.dp).padding(horizontal = 4.dp),
        color = MaterialTheme.colorScheme.outlineVariant,
    )
}

/** Il tasto + in fondo alla riga: nuova scheda o schede nascoste da ripristinare. Senza bordo, per non competere con le schede. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun AddTabChip(hasHidden: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val description = if (hasHidden) "Nuova scheda o schede nascoste" else "Nuova scheda"
    Surface(
        shape = CircleShape,
        color = Color.Transparent,
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .semantics { contentDescription = description }
            .combinedClickable(onClick = onClick, role = Role.Button),
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Add, contentDescription = null, tint = cs.onSurfaceVariant, modifier = Modifier.size(20.dp))
        }
    }
}

/** Rinomina una scheda. Per quelle di base il nome vuoto rimette quello originale ([original]); per le altre serve un nome. */
@Composable
internal fun RenameTabDialog(
    current: String,
    original: String?,
    error: (String) -> String,
    onSave: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf(current) }
    val err = error(name)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rinomina la scheda") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(KitchenTabsConfig.MAX_NAME) },
                    singleLine = true,
                    isError = err.isNotEmpty(),
                    label = { Text("Nome") },
                    supportingText = {
                        if (err.isNotEmpty()) Text(err)
                        else if (original != null) Text("Lascia vuoto per tornare a «$original»")
                    },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = { TextButton(onClick = { onSave(name) }, enabled = err.isEmpty()) { Text("Salva") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annulla") } },
    )
}

/** Conferma prima di eliminare una scheda creata dall'utente: i suoi prodotti vanno via con lei. */
@Composable
internal fun DeleteTabDialog(name: String, count: Int, restorable: Boolean = false, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Eliminare «$name»?") },
        text = {
            Text(
                when (count) {
                    0 -> "La scheda verrà eliminata."
                    1 -> "Verrà eliminato anche il prodotto che contiene. Se vuoi tenerlo, spostalo prima in un'altra scheda, oppure nascondi la scheda invece di eliminarla."
                    else -> "Verranno eliminati anche i $count prodotti che contiene. Se vuoi tenerli, spostali prima in un'altra scheda, oppure nascondi la scheda invece di eliminarla."
                } + if (restorable) " Potrai rimetterla, vuota, dal tasto +." else "",
            )
        },
        confirmButton = { TextButton(onClick = onConfirm) { Text("Elimina", color = cs.error) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annulla") } },
    )
}

/**
 * Il foglio del tasto +: crea una scheda personalizzata. Dal nome capisce che tipo di posto è ("Frigo 2" è un frigo,
 * "Sottotetto" un ripostiglio) e propone le opzioni giuste: si possono cambiare, anche scegliendo un altro tipo.
 * Sotto elenca le schede nascoste e quelle di base eliminate, da ripristinare; quelle nascoste si possono anche eliminare.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
internal fun AddTabSheet(
    tabs: KitchenTabsConfig,
    counts: Map<String, Int>,
    /** Crea la scheda con le opzioni scelte (tipo, temperatura, sbrinamento...) e le impostazioni del posto (ripiani, scadenze). */
    onCreate: (String, PlaceSetup) -> Unit,
    /** Chiede all'AI il tipo e le opzioni giuste per quel nome; null se non c'è la chiave o non risponde (si tengono quelle "da regola"). */
    onSuggest: suspend (String) -> PlaceSetup?,
    onRestore: (String) -> Unit,
    onDelete: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var name by remember { mutableStateOf("") }
    val err = if (name.isBlank()) "" else tabs.nameError(name, null)
    val hidden = tabs.hiddenTabs()
    val removed = tabs.removedTabs()
    var setup by remember { mutableStateOf(PlaceSetup()) }
    // Se l'utente cambia tipo o accende e spegne un'opzione a mano, i suggerimenti smettono di cambiarle.
    var touched by remember { mutableStateOf(false) }
    var thinking by remember { mutableStateOf(false) }
    LaunchedEffect(name) {
        val n = name.trim()
        if (touched) return@LaunchedEffect
        if (n.length < 3) { setup = PlaceSetup(); return@LaunchedEffect }
        // Subito le opzioni "da regola" (funzionano anche senza rete), poi l'AI le affina.
        setup = PlaceSetup.guess(n)
        delay(700)
        if (touched || tabs.nameError(n, null).isNotEmpty()) return@LaunchedEffect
        thinking = true
        try {
            val ai = onSuggest(n)
            if (!touched && ai != null) setup = ai
        } finally {
            thinking = false
        }
    }
    PrismaSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = cs.surfaceContainerHigh,
    ) {
        Column(
            Modifier
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Nuova scheda", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                "Scrivi il nome e l'AI capisce che posto è: Frigo 2 si comporta da frigo, Congelatore 2 da congelatore, Sottotetto da ripostiglio. Poi cambi quello che vuoi.",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
            )
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(KitchenTabsConfig.MAX_NAME) },
                singleLine = true,
                isError = err.isNotEmpty(),
                label = { Text("Nome della scheda") },
                supportingText = { if (err.isNotEmpty()) Text(err) },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth(),
            )
            if (name.trim().length >= 3 && err.isEmpty()) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = cs.primary, modifier = Modifier.size(18.dp))
                    Text(
                        "Suggerite per «" + name.trim() + "»",
                        style = MaterialTheme.typography.labelLarge,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.weight(1f),
                    )
                    if (thinking) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                }
                Text("Tipo di posto", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    PlaceKind.values().forEach { k ->
                        FilterChip(
                            selected = setup.options.placeKind() == k,
                            onClick = { touched = true; setup = PlaceSetup.forKind(k) },
                            label = { Text(k.label) },
                            leadingIcon = { Icon(kindIcon(k, true), contentDescription = null, modifier = Modifier.size(18.dp)) },
                        )
                    }
                }
                setup.config.shelves?.let { list ->
                    Text(
                        "Ripiani proposti: " + list.joinToString(", ") { it.emoji + " " + it.name },
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                }
                if (!setup.config.expiry) {
                    Text(
                        "Senza scadenze né avvisi di scadenza: qui non si tiene da mangiare.",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                }
                PlaceOptionsList(setup.options) { setup = setup.copy(options = it); touched = true }
                Text(
                    "Ripiani, scadenze e avvisi si cambiano anche dopo, tenendo premuta la scheda.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
            }
            Button(
                onClick = { onCreate(name, setup) },
                enabled = name.isNotBlank() && err.isEmpty(),
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) { Text("Crea scheda") }

            if (hidden.isNotEmpty()) {
                HorizontalDivider(color = cs.outlineVariant, modifier = Modifier.padding(top = 8.dp))
                Text("Schede nascoste", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    "Nascondere non cancella niente: i prodotti restano al loro posto e tornano insieme alla scheda.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
                hidden.forEach { id ->
                    val custom = tabs.isCustom(id)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(tabs.label(id), style = MaterialTheme.typography.titleSmall)
                            val n = counts[id] ?: 0
                            Text(
                                if (custom) "Creata da te · " + (if (n == 1) "1 prodotto" else "$n prodotti") else "Scheda di base",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant,
                            )
                        }
                        TextButton(onClick = { onRestore(id) }) { Text("Ripristina") }
                        if (tabs.canDelete(id)) {
                            IconButton(onClick = { onDelete(id) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Elimina «" + tabs.label(id) + "»", tint = cs.error)
                            }
                        }
                    }
                }
            }
            if (removed.isNotEmpty()) {
                HorizontalDivider(color = cs.outlineVariant, modifier = Modifier.padding(top = 8.dp))
                Text("Schede eliminate", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    "Si rimettono vuote, con il nome di una volta.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
                removed.forEach { id ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(KITCHEN_TABS.first { it.first == id }.second, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        TextButton(onClick = { onRestore(id) }) { Text("Rimetti") }
                    }
                }
            }
        }
    }
}
