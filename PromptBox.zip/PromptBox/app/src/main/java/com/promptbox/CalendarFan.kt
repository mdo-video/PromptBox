package com.promptbox

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Event
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.PopupProperties

/** Mette il popup sopra il bottone, allineato a sinistra e sempre dentro lo schermo. */
private object AboveAnchor : PopupPositionProvider {
    override fun calculatePosition(
        anchorBounds: IntRect,
        windowSize: IntSize,
        layoutDirection: LayoutDirection,
        popupContentSize: IntSize,
    ): IntOffset {
        val margin = 24
        val x = anchorBounds.left.coerceIn(margin, (windowSize.width - popupContentSize.width - margin).coerceAtLeast(margin))
        val above = anchorBounds.top - popupContentSize.height - 16
        val y = if (above >= margin) above else anchorBounds.bottom + 16
        return IntOffset(x, y)
    }
}

/**
 * "Aggiungi a Calendar" a ventaglio: al tocco si aprono sopra il bottone le opzioni già compilate
 * (un evento per voce) e, se sono più di uno, "Tutti" per importarli in un colpo solo.
 */
@Composable
internal fun CalendarFanButton(
    events: List<CalEvent>,
    accent: Accent,
    onOne: (CalEvent) -> Unit,
    onAll: () -> Unit,
) {
    var open by remember { mutableStateOf(false) }
    val tonal = ButtonDefaults.filledTonalButtonColors(containerColor = accent.container, contentColor = accent.onContainer)
    Box {
        FilledTonalButton(onClick = { open = !open }, colors = tonal) {
            Icon(Icons.Filled.Event, null, Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Aggiungi a Calendar")
        }
        if (open) {
            Popup(
                popupPositionProvider = AboveAnchor,
                onDismissRequest = { open = false },
                properties = PopupProperties(focusable = true),
            ) {
                CalendarFan(
                    events = events.sortedWith(compareBy({ it.date }, { it.time })),
                    accent = accent,
                    onOne = { open = false; onOne(it) },
                    onAll = { open = false; onAll() },
                )
            }
        }
    }
}

@Composable
private fun CalendarFan(events: List<CalEvent>, accent: Accent, onOne: (CalEvent) -> Unit, onAll: () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val showAll = events.size > 1
    val total = events.size + if (showAll) 1 else 0

    Column(
        modifier = Modifier.widthIn(max = 340.dp).heightIn(max = 440.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        horizontalAlignment = Alignment.Start,
    ) {
        events.forEachIndexed { i, e ->
            FanItem(
                order = total - 1 - i,
                shown = shown,
                title = e.title,
                subtitle = CalendarTools.summary(e),
                container = accent.container,
                content = accent.onContainer,
                icon = Icons.Filled.Event,
                onClick = { onOne(e) },
            )
        }
        if (showAll) {
            FanItem(
                order = 0,
                shown = shown,
                title = "Tutti (${events.size})",
                subtitle = "Li importo in Calendar in un colpo solo",
                container = accent.strong,
                content = accent.onStrong,
                icon = Icons.Filled.DoneAll,
                onClick = onAll,
            )
        }
    }
}

/** Una voce del ventaglio: [order] 0 è la più vicina al bottone e compare per prima. */
@Composable
private fun FanItem(
    order: Int,
    shown: Boolean,
    title: String,
    subtitle: String,
    container: Color,
    content: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
) {
    val p by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = tween(durationMillis = 240, delayMillis = order.coerceAtMost(8) * 45),
        label = "fan",
    )
    val shape = RoundedCornerShape(20.dp)
    Surface(
        modifier = Modifier.graphicsLayer {
            alpha = p
            val s = 0.7f + 0.3f * p
            scaleX = s
            scaleY = s
            translationY = (1f - p) * 40.dp.toPx()
            rotationZ = (1f - p) * -6f
            transformOrigin = TransformOrigin(0f, 1f)
        },
        shape = shape,
        color = container,
        contentColor = content,
        shadowElevation = 6.dp,
    ) {
        Row(
            Modifier.clip(shape).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(icon, null, Modifier.size(20.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}
