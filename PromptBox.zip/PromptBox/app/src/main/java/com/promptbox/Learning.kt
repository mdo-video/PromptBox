package com.promptbox

import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId

/** Un prodotto buttato perché scaduto. [id] è quello del prodotto in frigo (serve per annullare e per la sincronizzazione). */
data class WasteEntry(val id: String, val name: String, val price: Double?, val at: Long)

/**
 * Cosa l'app ha imparato dalle tue correzioni per un nome di prodotto dello scontrino.
 * [days] 0 = nessuna durata imparata (si usa la stima dell'AI o del reparto).
 */
data class ProductMemo(
    val key: String,
    val name: String,
    val place: String,
    val shelf: String,
    val days: Int,
    val uses: Int,
    val at: Long,
)

object Learning {
    private const val MAX_MEMOS = 500
    private val MARKS = Regex("\\p{M}+")
    private val NOT_ALNUM = Regex("[^a-z0-9]+")
    private val SIZE_TOKEN = Regex("^\\d+[a-z]{0,2}$") // 1l, 500g, 6, 2pz
    private val UNIT_TOKEN = Regex("^(g|gr|kg|l|ml|cl|pz)$") // unità rimaste da sole ("500 g")

    /** Il nome ridotto a una chiave: minuscolo, senza accenti, senza segni e senza misure ("Latte PS 1L" → "latte ps"). */
    fun normalize(raw: String): String {
        val plain = Normalizer.normalize(raw.lowercase(), Normalizer.Form.NFD).replace(MARKS, "")
        return plain.replace(NOT_ALNUM, " ").trim().split(' ')
            .filter { it.isNotEmpty() && !SIZE_TOKEN.matches(it) && !UNIT_TOKEN.matches(it) }
            .joinToString(" ")
    }

    fun find(memos: List<ProductMemo>, name: String): ProductMemo? {
        val key = normalize(name)
        return if (key.isEmpty()) null else memos.firstOrNull { it.key == key }
    }

    /** Applica ciò che è stato imparato a una proposta: nome, posto e ripiano; la durata solo se l'hai cambiata tu in passato. */
    fun applyMemo(plan: StockPlan, memo: ProductMemo): StockPlan {
        val name = memo.name.ifBlank { plan.name }
        if (memo.place.isEmpty()) return plan.copy(name = name, place = "", shelf = "", days = 0)
        val days = if (memo.days > 0) memo.days else if (plan.days > 0) plan.days else 7
        return plan.copy(name = name, place = memo.place, shelf = Stock.validShelf(memo.place, memo.shelf), days = days)
    }

    /**
     * Impara da una conferma: per ogni prodotto (nome sullo scontrino, scelta finale, giorni proposti all'inizio).
     * La durata si ricorda solo se è stata cambiata rispetto alla proposta.
     */
    fun learn(memos: List<ProductMemo>, entries: List<Triple<String, StockPlan, Int>>, now: Long): List<ProductMemo> {
        val out = LinkedHashMap<String, ProductMemo>()
        memos.forEach { out[it.key] = it }
        entries.forEach { (original, plan, initialDays) ->
            val key = normalize(original)
            if (key.isEmpty()) return@forEach
            val prev = out[key]
            val days = when {
                plan.place.isEmpty() -> 0
                plan.days != initialDays -> plan.days
                else -> prev?.days ?: 0
            }
            out.remove(key) // così torna in fondo (più recente)
            out[key] = ProductMemo(
                key = key,
                name = plan.name.trim().ifEmpty { original.trim() },
                place = plan.place,
                shelf = if (plan.place.isEmpty()) "" else plan.shelf,
                days = days,
                uses = (prev?.uses ?: 0) + 1,
                at = now,
            )
        }
        return out.values.sortedByDescending { it.at }.take(MAX_MEMOS)
    }

    fun memosToJson(list: List<ProductMemo>): String {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("i", it.key).put("n", it.name).put("p", it.place).put("s", it.shelf)
                    .put("d", it.days).put("u", it.uses).put("a", it.at),
            )
        }
        return arr.toString()
    }

    fun memosFromJson(raw: String?): List<ProductMemo> = runCatching {
        val arr = JSONArray(raw ?: "[]")
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ProductMemo(
                key = o.getString("i"),
                name = o.optString("n", ""),
                place = o.optString("p", ""),
                shelf = o.optString("s", ""),
                days = o.optInt("d", 0),
                uses = o.optInt("u", 1),
                at = o.optLong("a", 0L),
            )
        }
    }.getOrDefault(emptyList())

    fun wasteToJson(list: List<WasteEntry>): String {
        val arr = JSONArray()
        list.forEach {
            val o = JSONObject().put("i", it.id).put("n", it.name).put("a", it.at)
            it.price?.let { p -> o.put("p", p) }
            arr.put(o)
        }
        return arr.toString()
    }

    fun wasteFromJson(raw: String?): List<WasteEntry> = runCatching {
        val arr = JSONArray(raw ?: "[]")
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            WasteEntry(o.getString("i"), o.optString("n", ""), if (o.has("p")) o.getDouble("p") else null, o.optLong("a", 0L))
        }
    }.getOrDefault(emptyList())

    /** Aggiunge i buttati (un prodotto conta una volta sola, per id). */
    fun addWaste(list: List<WasteEntry>, items: List<PantryItem>, now: Long): List<WasteEntry> {
        val ids = list.map { it.id }.toSet()
        return list + items.filter { it.id !in ids }.map { WasteEntry(it.id, it.name, it.price, now) }
    }

    fun monthOf(at: Long): YearMonth = YearMonth.from(Instant.ofEpochMilli(at).atZone(ZoneId.systemDefault()))

    /** Quanto è stato buttato in un mese: somma dei prezzi noti, quanti buttati, quanti senza prezzo. */
    fun wasteMonth(list: List<WasteEntry>, month: YearMonth): Triple<Double, Int, Int> {
        val inMonth = list.filter { monthOf(it.at) == month }
        return Triple(inMonth.sumOf { it.price ?: 0.0 }, inMonth.size, inMonth.count { it.price == null })
    }
}
