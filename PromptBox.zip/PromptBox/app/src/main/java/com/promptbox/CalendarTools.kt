package com.promptbox

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter

/** Un appuntamento deciso dall'AI: [weeks] = quante settimane di fila (1 = una volta sola). */
data class CalEvent(
    val title: String,
    val date: LocalDate,
    val time: LocalTime,
    val minutes: Int,
    val weeks: Int,
    val place: String = "",
    val notes: String = "",
)

/**
 * Quando la risposta contiene appuntamenti con giorno e ora, l'AI chiude con una riga nascosta
 * [[CALENDARIO: titolo # 2026-11-16 # 18:00 # 60 # 4 # luogo # note | titolo # ...]] (luogo e note sono facoltativi). Qui la riga si toglie dal testo
 * e si trasforma in un file .ics che Google Calendar importa in un colpo solo.
 */
object CalendarTools {

    private val MARKER = Regex("""\[\[\s*CALENDARIO\s*:(.*?)\]\]""", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
    private val OPEN = Regex("""\[\[\s*CALENDARIO\s*:[^\]]*$""", RegexOption.IGNORE_CASE)

    fun strip(raw: String): String = raw.replace(MARKER, "").replace(OPEN, "").trim()

    /** La riga [[CALENDARIO: ...]] completa, se c'è. */
    fun markerOf(raw: String): String? = MARKER.find(raw)?.value

    fun parse(raw: String): List<CalEvent> {
        val body = MARKER.find(raw)?.groupValues?.get(1) ?: return emptyList()
        return body.split('|').mapNotNull { piece ->
            val p = piece.split('#').map { it.trim() }
            if (p.size < 3) return@mapNotNull null
            runCatching {
                val title = p[0].trim('-', '•', '*', ' ').ifBlank { return@mapNotNull null }
                val date = LocalDate.parse(p[1])
                val time = LocalTime.parse(p[2].padStart(5, '0'))
                val minutes = p.getOrNull(3)?.filter { it.isDigit() }?.toIntOrNull()?.coerceIn(5, 600) ?: 60
                val weeks = p.getOrNull(4)?.filter { it.isDigit() }?.toIntOrNull()?.coerceIn(1, 52) ?: 1
                val place = p.getOrNull(5).orEmpty()
                val notes = p.getOrNull(6).orEmpty()
                CalEvent(title, date, time, minutes, weeks, place, notes)
            }.getOrNull()
        }.take(40)
    }

    /** Riga da aggiungere al prompt di sistema, con la data di oggi (l'AI non la conosce da sola). */
    fun promptRule(): String {
        val today = LocalDate.now()
        val day = today.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, java.util.Locale.ITALIAN)
        return "\n\nOggi è $day ${today.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))}. Usa SEMPRE questa data per calcolare " +
            "i giorni (\"lunedì prossimo\", \"da domani\"): mai date nel passato o di altri mesi inventati." +
            "\n\nCalendario: SOLO se la risposta propone appuntamenti, allenamenti o impegni con un giorno e un'ora precisi " +
            "da mettere in agenda, chiudi con una riga finale esatta " +
            "[[CALENDARIO: Titolo # AAAA-MM-GG # HH:MM # durata in minuti # settimane # luogo # note | Titolo # AAAA-MM-GG # HH:MM # durata in minuti # settimane # luogo # note]]. " +
            "LUOGO: se nelle informazioni c'è un posto in QUALSIASI forma (nome del locale come \"Jambo\", indirizzo, città, sala, link della call) " +
            "copialo qui, esattamente come è scritto: anche solo il nome del locale va bene, senza inventare l'indirizzo. Lascialo vuoto solo se non c'è davvero nessun posto. " +
            "NOTE: scrivi qui in breve tutto il resto che serve (prezzo, cosa è incluso, cosa portare, dress code, contatti, telefono o WhatsApp, link, scadenze), separato da \" – \". " +
            "Dentro luogo e note non usare mai i simboli # e |. Se la durata non è scritta, stimala (cena 180 minuti, riunione 60). " +
            "Se c'è una scadenza (\"conferma entro\", \"prenota entro\", \"iscrizioni entro\"), aggiungi una voce in più \"Conferma: Titolo\" a quella data alle 09:00, durata 15, 1 settimana, con il contatto nelle note. " +
            "Esempio: [[CALENDARIO: Cena aziendale # 2026-12-15 # 20:00 # 180 # 1 # Ristorante Da Mario # 40 € a persona – bevande incluse – posti limitati | Conferma: Cena aziendale # 2026-11-30 # 09:00 # 15 # 1 # # Confermare su WhatsApp 333 0000000]]. " +
            "AAAA-MM-GG è la PRIMA data; \"settimane\" è per quante settimane di fila si ripete ogni settimana lo stesso giorno (1 = una volta sola). " +
            "Una voce per ogni giorno della settimana diverso. Non aggiungere la riga se mancano giorno e ora, " +
            "e non parlare mai di questa riga."
    }

    private fun esc(s: String) = s.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")

    fun toIcs(events: List<CalEvent>): String {
        val f = DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss")
        val stamp = LocalDateTime.now().format(f)
        val sb = StringBuilder()
        sb.append("BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//Prisma//IT\r\nCALSCALE:GREGORIAN\r\n")
        events.forEachIndexed { i, e ->
            val start = LocalDateTime.of(e.date, e.time)
            val end = start.plusMinutes(e.minutes.toLong())
            sb.append("BEGIN:VEVENT\r\n")
            sb.append("UID:prisma-${System.currentTimeMillis()}-$i@prisma\r\n")
            sb.append("DTSTAMP:${stamp}\r\n")
            sb.append("DTSTART:${start.format(f)}\r\n")
            sb.append("DTEND:${end.format(f)}\r\n")
            if (e.weeks > 1) sb.append("RRULE:FREQ=WEEKLY;COUNT=${e.weeks}\r\n")
            sb.append("SUMMARY:${esc(e.title)}\r\n")
            if (e.place.isNotBlank()) sb.append("LOCATION:${esc(e.place)}\r\n")
            if (e.notes.isNotBlank()) sb.append("DESCRIPTION:${esc(e.notes)}\r\n")
            sb.append("END:VEVENT\r\n")
        }
        sb.append("END:VCALENDAR\r\n")
        return sb.toString()
    }

    private val DAY_FMT = DateTimeFormatter.ofPattern("EEE d MMM", java.util.Locale.ITALIAN)

    /** Riga di riepilogo per il ventaglio: "lun 16 nov · 18:00–19:00 · ogni settimana ×4 · Palestra". */
    fun summary(e: CalEvent): String {
        val end = e.time.plusMinutes(e.minutes.toLong())
        val parts = mutableListOf(
            e.date.format(DAY_FMT).replace(".", ""),
            "${e.time.format(DateTimeFormatter.ofPattern("HH:mm"))}–${end.format(DateTimeFormatter.ofPattern("HH:mm"))}",
        )
        if (e.weeks > 1) parts += "ogni settimana ×${e.weeks}"
        if (e.place.isNotBlank()) parts += e.place
        return parts.joinToString(" · ")
    }

    /** Apre Google Calendar con UN evento già compilato (titolo, orario, luogo, note, ripetizione): resta solo da salvare. */
    fun openOne(context: Context, e: CalEvent): String? {
        return runCatching {
            val zone = java.time.ZoneId.systemDefault()
            val start = LocalDateTime.of(e.date, e.time).atZone(zone).toInstant().toEpochMilli()
            val end = start + e.minutes * 60_000L
            val intent = Intent(Intent.ACTION_INSERT).apply {
                data = android.provider.CalendarContract.Events.CONTENT_URI
                putExtra(android.provider.CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
                putExtra(android.provider.CalendarContract.EXTRA_EVENT_END_TIME, end)
                putExtra(android.provider.CalendarContract.Events.TITLE, e.title)
                if (e.place.isNotBlank()) putExtra(android.provider.CalendarContract.Events.EVENT_LOCATION, e.place)
                if (e.notes.isNotBlank()) putExtra(android.provider.CalendarContract.Events.DESCRIPTION, e.notes)
                if (e.weeks > 1) putExtra(android.provider.CalendarContract.Events.RRULE, "FREQ=WEEKLY;COUNT=${e.weeks}")
            }
            context.startActivity(intent)
            null
        }.getOrElse { "Non riesco ad aprire il calendario." }
    }

    /** Scrive il file .ics e lo apre: Android propone Google Calendar. Restituisce un messaggio se qualcosa non va. */
    fun open(context: Context, events: List<CalEvent>): String? {
        return runCatching {
            val dir = File(context.cacheDir, "calendar").apply { mkdirs() }
            val file = File(dir, "prisma-calendario.ics")
            file.writeText(toIcs(events))
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val view = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "text/calendar")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                setPackage("com.google.android.calendar")
            }
            try {
                context.startActivity(view)
            } catch (_: Exception) {
                val any = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "text/calendar")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(any, null))
            }
            null
        }.getOrElse { "Non riesco ad aprire il calendario." }
    }
}
