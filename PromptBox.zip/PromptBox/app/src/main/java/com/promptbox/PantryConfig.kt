package com.promptbox

import org.json.JSONArray
import org.json.JSONObject

/** Un ripiano scelto dall'utente: nome, emoji e se i suoi prodotti hanno la scadenza. */
data class ShelfDef(val name: String, val emoji: String, val expiry: Boolean = true)

/**
 * Impostazioni di un posto (frigo, dispensa, congelatore, casa).
 * [shelves] null = i ripiani predefiniti. [expiry] spento = niente date, stime, "da usare presto" né avvisi.
 * [autoShelf] spento = l'AI non sceglie il ripiano. [notify] spento = niente avvisi di scadenza per questo posto.
 */
data class PlaceConfig(
    val shelves: List<ShelfDef>? = null,
    val expiry: Boolean = true,
    val autoShelf: Boolean = true,
    val notify: Boolean = true,
)

/** Le impostazioni dei posti. Un posto senza modifiche non compare e vale tutto com'era (ripiani predefiniti, scadenze accese). */
class PantryConfig(val places: Map<String, PlaceConfig> = emptyMap()) {
    fun of(place: String): PlaceConfig = places[place] ?: PlaceConfig()

    /** I ripiani del posto: quelli scelti dall'utente, o i predefiniti con la loro emoji. */
    fun shelfDefs(place: String): List<ShelfDef> =
        of(place).shelves?.takeIf { it.isNotEmpty() }
            ?: Pantry.defaultShelves(place).map { ShelfDef(it, Pantry.builtinEmoji(it)) }

    /** I prodotti di questo ripiano hanno la scadenza? I prodotti della casa (detersivi...) mai. */
    fun expiryOn(place: String, shelf: String): Boolean {
        if (place == "casa") return false
        if (!of(place).expiry) return false
        return shelfDefs(place).firstOrNull { it.name.equals(shelf, ignoreCase = true) }?.expiry ?: true
    }

    fun with(place: String, config: PlaceConfig): PantryConfig {
        val m = places.toMutableMap()
        if (config == PlaceConfig()) m.remove(place) else m[place] = config
        return PantryConfig(m)
    }

    fun toJson(): String {
        val root = JSONObject()
        places.forEach { (place, c) ->
            val o = JSONObject()
            c.shelves?.let { list ->
                val arr = JSONArray()
                list.forEach { arr.put(JSONObject().put("n", it.name).put("e", it.emoji).put("x", it.expiry)) }
                o.put("s", arr)
            }
            if (!c.expiry) o.put("x", false)
            if (!c.autoShelf) o.put("a", false)
            if (!c.notify) o.put("v", false)
            root.put(place, o)
        }
        return if (places.isEmpty()) "" else root.toString()
    }

    companion object {
        /** Legge le impostazioni salvate; se il testo è rovinato o vuoto restano quelle predefinite. */
        fun parse(json: String): PantryConfig {
            if (json.isBlank()) return PantryConfig()
            return try {
                val root = JSONObject(json)
                val m = mutableMapOf<String, PlaceConfig>()
                root.keys().forEach { place ->
                    val o = root.optJSONObject(place) ?: return@forEach
                    val shelves = o.optJSONArray("s")?.let { arr ->
                        (0 until arr.length()).mapNotNull { i ->
                            val s = arr.optJSONObject(i) ?: return@mapNotNull null
                            val name = s.optString("n").trim()
                            if (name.isEmpty()) null else ShelfDef(name, s.optString("e").ifBlank { "📦" }, s.optBoolean("x", true))
                        }.takeIf { it.isNotEmpty() }
                    }
                    m[place] = PlaceConfig(shelves, o.optBoolean("x", true), o.optBoolean("a", true), o.optBoolean("v", true))
                }
                PantryConfig(m)
            } catch (e: Exception) {
                PantryConfig()
            }
        }
    }
}
