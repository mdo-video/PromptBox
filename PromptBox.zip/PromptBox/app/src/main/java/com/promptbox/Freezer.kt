package com.promptbox

import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Congelatore: quanto si conserva un alimento. La durata di riferimento è quella a -18 °C (in giorni, [PantryItem.lifeDays]);
 * con un freezer più caldo o più freddo si accorcia o si allunga ([factor]). È una stima di qualità, non una data di sicurezza.
 */
object Freezer {
    const val DEFAULT_TEMP = -18
    const val MIN_TEMP = -30
    const val MAX_TEMP = -10

    fun clampTemp(t: Int): Int = t.coerceIn(MIN_TEMP, MAX_TEMP)

    /** Rispetto a -18 °C: la durata raddoppia ogni 10 °C di freddo in più (a -12 °C è circa due terzi, a -24 °C circa una volta e mezza). */
    fun factor(temp: Int): Double = 2.0.pow((-clampTemp(temp) - 18) / 10.0).coerceIn(0.25, 2.5)

    /** Durata tipica a -18 °C in mesi, quando l'AI non la dà: per ripiano. */
    fun defaultMonths(shelf: String): Double = when (shelf) {
        "Carne" -> 6.0
        "Pesce" -> 4.0
        "Verdure e frutta" -> 10.0
        "Pronti e sughi" -> 3.0
        "Pane e dolci" -> 3.0
        else -> 6.0
    }

    fun lifeDays(months: Double): Int = (months * 30.4).roundToInt().coerceIn(7, 1460)

    /** Ultimo giorno consigliato: giorno del congelamento + durata a -18 °C scalata sulla temperatura. */
    fun expiry(frozenAt: Long, lifeDays: Int, temp: Int): Long = frozenAt + (lifeDays * factor(temp)).roundToInt()

    /** "3 mesi", "1 mese", "6 sett." */
    fun durationText(days: Int): String = when {
        days < 60 -> (days / 7).coerceAtLeast(1).toString() + " sett."
        else -> {
            val m = (days / 30.4).roundToInt()
            if (m == 1) "1 mese" else "$m mesi"
        }
    }

    /** Ricalcola scadenza dei prodotti del congelatore con la temperatura data (gli altri restano com'erano). */
    fun rescale(items: List<PantryItem>, temp: Int): List<PantryItem> = items.map {
        val f = it.frozenAt
        val d = it.lifeDays
        if (Pantry.isFreezer(it.place) && f != null && d != null) it.copy(expiry = expiry(f, d, temp), estimated = false) else it
    }

    /** Durate di riferimento a -18 °C, date all'AI perché dia numeri coerenti. */
    const val GUIDE =
        "Durate di riferimento a -18 °C, in mesi, per un alimento fresco congelato bene: " +
            "manzo in pezzi/bistecche/arrosti 10, vitello 8, maiale in pezzi 6, agnello 8, carne macinata 3, hamburger e salsicce 3, " +
            "pollo o tacchino intero 12, pollo a pezzi 9, fegato e frattaglie 3, selvaggina 8, " +
            "pesce magro (merluzzo, nasello, orata, branzino) 6, pesce grasso (salmone, sgombro, tonno) 3, gamberi e crostacei 6, molluschi e calamari 3, " +
            "verdure sbollentate 10, verdure non sbollentate 3, frutta 10, pane 3, pasta fresca e gnocchi 3, dolci e torte 3, " +
            "sughi, ragù, zuppe e piatti cucinati 3, formaggi 3, burro 6, uova sgusciate 8. " +
            "Se il prodotto era già stato congelato e scongelato o è un surgelato comprato, usa la durata scritta sulla confezione se si legge."
}
