package com.promptbox

import android.content.Context
import android.content.Intent
import android.util.Base64
import org.json.JSONObject

/** Una scheda in forma portatile: titolo, icona, prompt e categoria. */
data class CardData(val title: String, val emoji: String, val prompt: String, val category: String)

/**
 * Condivisione di una scheda come testo (WhatsApp, Telegram, email...).
 * Il messaggio contiene una riga di codice "PRISMA1:..." che Prisma riconosce:
 * condividendo il messaggio verso Prisma, oppure copiandolo e usando "Incolla scheda", la scheda si importa.
 */
object CardShare {
    private const val TAG = "PRISMA1:"
    private val FLAGS = Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
    private val REGEX = Regex("PRISMA1:([A-Za-z0-9_\\-]+)")

    fun encode(s: Section): String {
        val json = JSONObject()
            .put("t", s.title).put("e", s.emoji).put("p", s.systemPrompt).put("c", s.category)
            .toString()
        val code = Base64.encodeToString(json.toByteArray(Charsets.UTF_8), FLAGS)
        return "${s.emoji} ${s.title} - scheda per Prisma\n" +
            "Per importarla: condividi questo messaggio verso Prisma, oppure copialo e usa Nuova sezione > Incolla scheda.\n\n" +
            TAG + code
    }

    fun decode(text: String): CardData? {
        val code = REGEX.find(text)?.groupValues?.get(1) ?: return null
        return runCatching {
            val o = JSONObject(String(Base64.decode(code, FLAGS), Charsets.UTF_8))
            val title = o.getString("t").trim()
            val prompt = o.getString("p").trim()
            if (title.isEmpty() || prompt.isEmpty()) return null
            CardData(title, o.optString("e", "📌").ifBlank { "📌" }, prompt, o.optString("c", "").trim())
        }.getOrNull()
    }

    fun share(context: Context, s: Section) {
        val send = Intent(Intent.ACTION_SEND)
            .setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, encode(s))
        val chooser = Intent.createChooser(send, "Condividi scheda").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }
}
