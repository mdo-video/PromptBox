package com.promptbox

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

private fun featureIcon(f: PlaceFeature): ImageVector = when (f) {
    PlaceFeature.TEMP -> Icons.Filled.Thermostat
    PlaceFeature.HUMIDITY -> Icons.Filled.WaterDrop
    PlaceFeature.SPACE -> Icons.Filled.Straighten
}

/** La riga sotto il nome di un'opzione: i limiti di avviso se ci sono, altrimenti a cosa serve. */
private fun featureHint(f: PlaceFeature, c: PlaceConditions): String = when (f) {
    PlaceFeature.TEMP -> when {
        c.tempMin != null && c.tempMax != null -> "Avviso fuori da ${PlaceConditions.num(c.tempMin)}–${PlaceConditions.num(c.tempMax)} °C"
        c.tempMin != null -> "Avviso sotto ${PlaceConditions.num(c.tempMin)} °C"
        c.tempMax != null -> "Avviso sopra ${PlaceConditions.num(c.tempMax)} °C"
        else -> "La scrivi tu, l'app avvisa se esce dai limiti"
    }
    PlaceFeature.HUMIDITY -> if (c.humidityMax != null) "Avviso sopra il ${c.humidityMax}%" else "La scrivi tu, l'app avvisa se è troppa"
    PlaceFeature.SPACE -> "Quanto è pieno, in percentuale"
}

/** Le tre opzioni con un interruttore ciascuna. Si usa sia nel foglio "Nuova scheda" (preimpostate dall'AI) sia per cambiarle dopo. */
@Composable
internal fun PlaceOptionsList(options: PlaceConditions, onChange: (PlaceConditions) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column {
        PlaceFeature.values().forEach { f ->
            val on = options.has(f)
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { onChange(options.with(f, !on)) }
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(featureIcon(f), contentDescription = null, tint = cs.onSurfaceVariant, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(f.label, style = MaterialTheme.typography.titleSmall)
                    Text(featureHint(f, options), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
                Switch(checked = on, onCheckedChange = { onChange(options.with(f, it)) })
            }
        }
    }
}

/** Le letture in una riga sola. Se qualcosa è fuori dai limiti diventa rossa (errorContainer) e dice cosa non va. */
private fun summary(c: PlaceConditions): String {
    val parts = ArrayList<String>()
    if (c.has(PlaceFeature.TEMP) && c.temp != null) parts += "Temperatura ${PlaceConditions.num(c.temp)} °C"
    if (c.has(PlaceFeature.HUMIDITY) && c.humidity != null) parts += "Umidità ${c.humidity}%"
    if (c.has(PlaceFeature.SPACE) && c.spacePct != null) {
        parts += "Spazio ${c.spacePct}%" + (c.spaceM2?.let { " di ${PlaceConditions.num(it)} m²" } ?: "")
    }
    return if (parts.isEmpty()) "Tocca per inserire le letture" else parts.joinToString(" · ")
}

/** La striscia sopra la scheda: legge i valori e avvisa se escono dai limiti. Si tocca per aggiornarli. */
@Composable
internal fun PlaceConditionsBar(c: PlaceConditions, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val alerts = c.alerts()
    val bad = alerts.isNotEmpty()
    val shape = RoundedCornerShape(16.dp)
    Surface(
        shape = shape,
        color = if (bad) cs.errorContainer else cs.surfaceContainerHigh,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(shape)
            .clickable(onClickLabel = "Aggiorna temperatura, umidità e spazio", onClick = onClick),
    ) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                if (bad) {
                    Text(alerts.joinToString(" · "), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = cs.onErrorContainer)
                    Text(summary(c), style = MaterialTheme.typography.bodySmall, color = cs.onErrorContainer)
                } else {
                    Text(summary(c), style = MaterialTheme.typography.labelLarge, color = cs.onSurface)
                }
            }
            Spacer(Modifier.width(12.dp))
            Icon(
                Icons.Filled.Edit,
                contentDescription = null,
                tint = if (bad) cs.onErrorContainer else cs.onSurfaceVariant,
                modifier = Modifier.size(18.dp),
            )
        }
    }
}

private fun badNumber(s: String): Boolean = s.isNotBlank() && PlaceConditions.readNumber(s) == null

@Composable
private fun NumberField(label: String, value: String, suffix: String, onValue: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = { onValue(it.take(6)) },
        singleLine = true,
        isError = badNumber(value),
        label = { Text(label) },
        suffix = { Text(suffix) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier,
    )
}

/**
 * Il foglio per cambiare le opzioni di una scheda (accendere o spegnere temperatura, umidità, spazio) e per scrivere le
 * letture di adesso e i limiti oltre i quali l'app avvisa.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun PlaceConditionsSheet(name: String, current: PlaceConditions, onSave: (PlaceConditions) -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var c by remember { mutableStateOf(current) }
    var temp by remember { mutableStateOf(current.temp?.let { PlaceConditions.num(it) } ?: "") }
    var tempMin by remember { mutableStateOf(current.tempMin?.let { PlaceConditions.num(it) } ?: "") }
    var tempMax by remember { mutableStateOf(current.tempMax?.let { PlaceConditions.num(it) } ?: "") }
    var hum by remember { mutableStateOf(current.humidity?.toString() ?: "") }
    var humMax by remember { mutableStateOf(current.humidityMax?.toString() ?: "") }
    var m2 by remember { mutableStateOf(current.spaceM2?.let { PlaceConditions.num(it) } ?: "") }
    var pct by remember { mutableStateOf(current.spacePct?.toFloat()) }
    val invalid = listOf(temp, tempMin, tempMax, hum, humMax, m2).any { badNumber(it) }

    PrismaSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = cs.surfaceContainerHigh,
    ) {
        Column(
            Modifier
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                "Scegli cosa seguire in questo posto. Temperatura e umidità le scrivi tu: l'app ti avvisa quando escono dai limiti.",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
            )
            PlaceOptionsList(c) { c = it }

            if (c.has(PlaceFeature.TEMP)) {
                Text("Temperatura", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumberField("Adesso", temp, "°C", { temp = it }, Modifier.weight(1f))
                    NumberField("Minima", tempMin, "°C", { tempMin = it }, Modifier.weight(1f))
                    NumberField("Massima", tempMax, "°C", { tempMax = it }, Modifier.weight(1f))
                }
            }
            if (c.has(PlaceFeature.HUMIDITY)) {
                Text("Umidità", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumberField("Adesso", hum, "%", { hum = it }, Modifier.weight(1f))
                    NumberField("Massima", humMax, "%", { humMax = it }, Modifier.weight(1f))
                }
            }
            if (c.has(PlaceFeature.SPACE)) {
                Text("Spazio occupato", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    pct?.let { "${it.roundToInt()}% pieno" } ?: "Non impostato",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant,
                )
                Slider(value = pct ?: 0f, onValueChange = { pct = it }, valueRange = 0f..100f)
                NumberField("Superficie (facoltativa)", m2, "m²", { m2 = it }, Modifier.fillMaxWidth())
            }

            Button(
                onClick = {
                    val t1 = PlaceConditions.readNumber(tempMin)
                    val t2 = PlaceConditions.readNumber(tempMax)
                    // Minima e massima scambiate per sbaglio: si rimettono in ordine.
                    val lo = if (t1 != null && t2 != null) minOf(t1, t2) else t1
                    val hi = if (t1 != null && t2 != null) maxOf(t1, t2) else t2
                    onSave(
                        c.copy(
                            temp = PlaceConditions.readNumber(temp),
                            tempMin = lo,
                            tempMax = hi,
                            humidity = PlaceConditions.readNumber(hum)?.roundToInt()?.coerceIn(0, 100),
                            humidityMax = PlaceConditions.readNumber(humMax)?.roundToInt()?.coerceIn(0, 100),
                            spacePct = if (c.has(PlaceFeature.SPACE)) pct?.roundToInt() else null,
                            spaceM2 = PlaceConditions.readNumber(m2)?.takeIf { it > 0 },
                        ),
                    )
                },
                enabled = !invalid,
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) { Text("Salva") }
        }
    }
}
