package com.promptbox

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import org.json.JSONArray

/** Widget della Home di Android: i prodotti ancora da comprare. Toccandolo si apre la lista. */
class ShoppingWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { manager.updateAppWidget(it, build(context)) }
    }

    companion object {
        private const val MAX_LINES = 12

        /** Da chiamare quando la lista cambia (anche per una sincronizzazione). */
        fun refresh(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, ShoppingWidget::class.java))
            ids.forEach { manager.updateAppWidget(it, build(context)) }
        }

        private fun build(context: Context): RemoteViews {
            // Legge la lista direttamente dalle preferenze, senza aprire l'archivio cifrato.
            val raw = context.getSharedPreferences("promptbox_plain", Context.MODE_PRIVATE)
                .getString("shopping", "[]") ?: "[]"
            val open = runCatching {
                val arr = JSONArray(raw)
                (0 until arr.length()).map { arr.getJSONObject(it) }
                    .filter { !it.optBoolean("d", false) }
                    .sortedBy { Depts.rank(it.optString("p", "").ifBlank { "Altro" }) }
                    .map { it.getString("t") }
            }.getOrDefault(emptyList())

            val text = when {
                open.isEmpty() -> "Lista vuota"
                else -> {
                    val shown = open.take(MAX_LINES).joinToString("\n") { "• $it" }
                    if (open.size > MAX_LINES) shown + "\n+ altri ${open.size - MAX_LINES}" else shown
                }
            }

            val views = RemoteViews(context.packageName, R.layout.widget_shopping)
            views.setTextViewText(R.id.widget_items, text)
            val open_ = Intent(context, MainActivity::class.java)
                .putExtra("action", "shopping")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            val pi = PendingIntent.getActivity(
                context, 0, open_, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            views.setOnClickPendingIntent(R.id.widget_root, pi)
            return views
        }
    }
}
