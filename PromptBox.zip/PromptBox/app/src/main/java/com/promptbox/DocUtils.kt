package com.promptbox

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONObject

object DocUtils {

    /** Tipi che il picker mostra: PDF e file di testo (txt, csv, md, html, json...). */
    val PICKER_TYPES = arrayOf("application/pdf", "text/*", "application/json")

    private const val MAX_PDF = 15 * 1024 * 1024
    private const val MAX_TEXT = 400 * 1024

    /** Legge il file scelto. Errore con messaggio leggibile se il tipo non è supportato o è troppo grande. */
    fun load(context: Context, uri: Uri): Result<ChatDoc> = runCatching {
        val resolver = context.contentResolver
        var name = "documento"
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0)?.let { name = it }
        }
        val raw = resolver.getType(uri).orEmpty()
        val lower = name.lowercase()
        val mime = when {
            raw == "application/pdf" || lower.endsWith(".pdf") -> "application/pdf"
            raw.startsWith("text/") -> raw
            raw == "application/json" || lower.endsWith(".json") -> "text/plain"
            lower.endsWith(".md") || lower.endsWith(".csv") || lower.endsWith(".txt") -> "text/plain"
            else -> error("Per ora accetto PDF e file di testo (txt, csv, md, json). Word ed Excel vanno prima salvati come PDF.")
        }
        val limit = if (mime == "application/pdf") MAX_PDF else MAX_TEXT
        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Non riesco a leggere il file.")
        if (bytes.size > limit) {
            error(if (mime == "application/pdf") "Il PDF è troppo grande (massimo 15 MB)." else "Il file di testo è troppo lungo.")
        }
        ChatDoc(name, mime, bytes)
    }
}

/** Una scheda salvata nell'archivio di una sezione. [json] è il blocco DATI SCHEDA. */
class DocItem(val id: Long, val name: String, val json: String)

object DocArchive {

    /** Testo da aggiungere al prompt di sistema: le schede salvate, così l'AI risponde da quelle. */
    fun context(items: List<DocItem>): String {
        if (items.isEmpty()) return ""
        return "\n\nARCHIVIO SALVATO: ogni riga è una scheda che l'utente ha archiviato (dati in JSON). " +
            "Rispondi usando esclusivamente queste schede; se l'informazione non c'è, dillo.\n" +
            items.joinToString("\n") { "- ${it.name}: ${it.json}" }
    }

    /** Cerca il JSON nel testo e lo controlla. Restituisce (nome, json compatto). */
    fun parse(raw: String): Result<Pair<String, String>> = runCatching {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        require(start in 0 until end) { "Non trovo i DATI SCHEDA in questo file." }
        val o = JSONObject(raw.substring(start, end + 1))
        val ex = o.optJSONArray("esercizi")
        require(ex != null && ex.length() > 0) { "I DATI SCHEDA non hanno l'elenco degli esercizi." }
        o.optString("nome").ifBlank { "Scheda" } to o.toString()
    }

    /** File di testo: legge il JSON direttamente. PDF: lo fa copiare all'AI (una richiesta). */
    suspend fun extract(doc: ChatDoc, apiKey: String, model: String, fallback: Boolean): Result<Pair<String, String>> {
        if (doc.isText) {
            val local = parse(String(doc.bytes, Charsets.UTF_8))
            if (local.isSuccess) return local
        }
        val raw = GeminiClient.extractData(apiKey, model, doc, fallback).getOrElse { return Result.failure(it) }
        return parse(raw)
    }
}
