package com.promptbox

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns

object DocUtils {

    /** Tipi che il picker mostra: PDF e file di testo (txt, csv, md, html, json...). */
    val PICKER_TYPES = arrayOf("application/pdf", "text/*", "application/json")

    private const val MAX_PDF = 15 * 1024 * 1024
    private const val MAX_TEXT = 400 * 1024

    /** Legge il file scelto. Errore con messaggio leggibile se il tipo non è supportato o è troppo grande. */
    fun load(context: Context, uri: Uri): Result<ChatDoc> = runCatching {
        val resolver = context.contentResolver
        var name = "documento"
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0)?.let { name = it }
        }
        val raw = resolver.getType(uri).orEmpty()
        val lower = name.lowercase()
        val mime = when {
            raw == "application/pdf" || lower.endsWith(".pdf") -> "application/pdf"
            raw.startsWith("text/") -> raw
            raw == "application/json" || lower.endsWith(".json") -> "text/plain"
            lower.endsWith(".md") || lower.endsWith(".csv") || lower.endsWith(".txt") -> "text/plain"
            else -> error("Per ora accetto PDF e file di testo (txt, csv, md, json). Word ed Excel vanno prima salvati come PDF.")
        }
        val limit = if (mime == "application/pdf") MAX_PDF else MAX_TEXT
        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Non riesco a leggere il file.")
        if (bytes.size > limit) {
            error(if (mime == "application/pdf") "Il PDF è troppo grande (massimo 15 MB)." else "Il file di testo è troppo lungo.")
        }
        ChatDoc(name, mime, bytes)
    }
}
