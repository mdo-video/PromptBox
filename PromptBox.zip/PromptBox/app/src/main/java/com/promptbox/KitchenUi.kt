package com.promptbox

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Kitchen
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

private class KitchenPlace(val place: String, val title: String, val icon: ImageVector, val openLabel: String)

private val KITCHEN_PLACES = listOf(
    KitchenPlace("frigo", "Frigo", Icons.Filled.Kitchen, "Apri il frigo"),
    KitchenPlace("dispensa", "Dispensa", Icons.Filled.Inventory2, "Apri la dispensa"),
    KitchenPlace("congelatore", "Congelati", Icons.Filled.AcUnit, "Apri i congelati"),
)

/** Quanti prodotti mostra una sezione chiusa-aperta prima di "Mostra tutti". */
private const val PREVIEW = 3

/**
 * Cucina: frigo, dispensa e congelati in una schermata sola. Una ricerca e un "da usare presto" per tutti e tre i posti;
 * ogni sezione si apre per vedere i primi prodotti in scadenza, e "Mostra tutti" porta alla schermata completa del posto.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun KitchenScreen(
    items: List<PantryItem>,
    tabs: KitchenTabsConfig,
    canCook: Boolean,
    onOpen: (String) -> Unit,
    onCook: (String) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var query by remember { mutableStateOf("") }
    var open by remember { mutableStateOf(setOf("frigo")) }
    var soonSheet by remember { mutableStateOf(false) }
    // I posti nell'ordine delle schede, con i nomi scelti e le schede create dall'utente; quelle nascoste non compaiono.
    val places = remember(tabs) {
        val base = KITCHEN_PLACES.map { kp ->
            if (tabs.renamed(kp.place) != null) KitchenPlace(kp.place, tabs.label(kp.place), kp.icon, "Apri " + tabs.label(kp.place)) else kp
        }
        val mine = tabs.custom.map { KitchenPlace(it.id, it.name, Icons.Filled.Inventory2, "Apri " + it.name) }
        (base + mine).filter { it.place !in tabs.hidden }.sortedBy { tabs.all().indexOf(it.place) }
    }

    val q = query.trim().lowercase()
    val searching = q.isNotEmpty()
    val late = remember(items) { items.count { Pantry.freshness(it) == Freshness.LATE } }
    val soonAll = remember(items) { Pantry.sorted(items.filter { Pantry.freshness(it) == Freshness.SOON }) }
    // "Usa prima…": i più urgenti tra frigo e dispensa (i congelati non hanno fretta).
    val urgentNames = remember(items) {
        Pantry.sorted(items.filter { it.place != "congelatore" && it.expiry != null && Pantry.freshness(it) != Freshness.OK })
            .take(2).joinToString(", ") { it.name }
    }
    fun matches(it: PantryItem) = it.name.lowercase().contains(q) || it.shelf.lowercase().contains(q)

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text("Frigo e dispensa") },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = cs.background),
            )
        },
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text("Cerca in frigo, dispensa e congelati") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, contentDescription = "Cancella la ricerca") }
                },
                shape = RoundedCornerShape(50),
                modifier = Modifier.fillMaxWidth(),
            )

            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val foodCount = items.count { it.place != "casa" }
                StatusPill(foodCount.toString() + if (foodCount == 1) " prodotto" else " prodotti", cs.onSurfaceVariant, Icons.Filled.Kitchen)
                if (late > 0) StatusPill(late.toString() + if (late == 1) " scaduto" else " scaduti", cs.error, Icons.Filled.ErrorOutline)
                if (soonAll.isNotEmpty()) {
                    StatusPill(soonAll.size.toString() + " da usare presto", cs.tertiary, Icons.Filled.Schedule) { soonSheet = true }
                }
            }

            if (!searching) {
                // Cosa ci cucino con tutto: niente prodotti dai posti dove non si tiene da mangiare (es. Garage).
                val cookable = items.filter { it.place != "casa" && tabs.cooks(it.place) }
                val enabled = canCook && cookable.isNotEmpty()
                Card(
                    onClick = { onCook(Pantry.cookPrompt(cookable, "tutto")) },
                    enabled = enabled,
                    colors = CardDefaults.cardColors(
                        containerColor = cs.surfaceContainerHigh,
                        contentColor = cs.onSurface,
                        disabledContainerColor = cs.surfaceContainerHigh,
                        disabledContentColor = cs.onSurfaceVariant,
                    ),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Restaurant, contentDescription = null, tint = if (enabled) cs.primary else cs.onSurfaceVariant)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Cosa ci cucino?", style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (urgentNames.isNotEmpty()) "Usa prima $urgentNames" else "Idee con quello che hai",
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                }
            }

            val anyShown = !searching || places.any { kp -> items.any { it.place == kp.place && matches(it) } }
            Surface(shape = RoundedCornerShape(24.dp), color = cs.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
                Column {
                    places.forEachIndexed { index, kp ->
                        val all = items.filter { it.place == kp.place }
                        val shown = Pantry.sorted(if (searching) all.filter { matches(it) } else all)
                        if (searching && shown.isEmpty()) return@forEachIndexed
                        val expanded = searching || kp.place in open
                        if (index > 0) HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                        Row(
                            Modifier.fillMaxWidth().clickable(enabled = !searching) {
                                open = if (kp.place in open) open - kp.place else open + kp.place
                            }.padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(kp.icon, contentDescription = null, tint = cs.onSurfaceVariant)
                            Spacer(Modifier.width(12.dp))
                            Text(kp.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                            Text(shown.size.toString(), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                            if (!searching) {
                                Spacer(Modifier.width(8.dp))
                                Icon(
                                    if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                                    contentDescription = if (expanded) "Chiudi" else "Apri",
                                    tint = cs.onSurfaceVariant,
                                )
                            }
                        }
                        if (expanded) {
                            val rows = if (searching) shown else shown.take(PREVIEW)
                            Column(Modifier.padding(horizontal = 16.dp)) {
                                if (shown.isEmpty()) {
                                    Text("Ancora niente qui.", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, modifier = Modifier.padding(bottom = 8.dp))
                                }
                                rows.forEachIndexed { i, item ->
                                    if (i > 0) HorizontalDivider(color = cs.outlineVariant.copy(alpha = 0.5f))
                                    KitchenRow(item) { onOpen(kp.place) }
                                }
                                TextButton(onClick = { onOpen(kp.place) }) {
                                    Text(if (!searching && shown.size > PREVIEW) "Mostra tutti e " + shown.size else kp.openLabel)
                                }
                            }
                        }
                    }
                }
            }
            if (searching && !anyShown) {
                Text("Nessun prodotto con «" + query.trim() + "».", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, modifier = Modifier.padding(4.dp))
            }
            Spacer(Modifier.height(16.dp))
        }
    }

    if (soonSheet && soonAll.isNotEmpty()) {
        PantrySoonSheet(
            items = soonAll,
            canCook = canCook,
            onPick = { soonSheet = false; onOpen(it.place) },
            onDone = null,
            onCook = { soonSheet = false; onCook(Pantry.cookPrompt(soonAll, "tutto")) },
            onDismiss = { soonSheet = false },
        )
    }
}

@Composable
private fun KitchenRow(item: PantryItem, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val days = (item.expiry ?: Long.MAX_VALUE) - Pantry.today()
    val (bg, fg) = when {
        item.expiry == null -> cs.surfaceVariant to cs.onSurfaceVariant
        days <= 0L -> cs.errorContainer to cs.onErrorContainer
        Pantry.freshness(item) == Freshness.SOON -> cs.tertiaryContainer to cs.onTertiaryContainer
        else -> cs.surfaceVariant to cs.onSurfaceVariant
    }
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(item.name, style = MaterialTheme.typography.bodyLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(
                (if (item.qty.isBlank()) "" else item.qty + " · ") + item.shelf,
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(
            Pantry.labelOf(item),
            style = MaterialTheme.typography.labelMedium,
            color = fg,
            modifier = Modifier.clip(RoundedCornerShape(50)).background(bg).padding(horizontal = 10.dp, vertical = 5.dp),
        )
    }
}
