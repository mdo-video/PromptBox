package com.promptbox

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * "Da scontrino" dentro Frigo e Dispensa: foto → l'AI legge i prodotti → controllo e correzioni
 * ([StockImportDialog], nome compreso) → "vuoi aggiungere le scadenze?". Lo scontrino finisce anche in Scontrini e spese.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReceiptToPantryFlow(
    store: Store,
    onReceipt: (Receipt) -> Unit,
    onToStock: (List<PantryItem>) -> Unit,
    onDismiss: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var receipt by remember { mutableStateOf<Receipt?>(null) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var pendingUri by remember { mutableStateOf<Uri?>(null) }
    // L'ultima foto resta: se la lettura fallisce basta "Riprova", senza rifare la foto.
    var lastUri by remember { mutableStateOf<Uri?>(null) }
    var stage by remember { mutableStateOf("Leggo lo scontrino…") }

    fun process(uri: Uri) {
        lastUri = uri
        stage = "Leggo lo scontrino…"
        scope.launch {
            busy = true
            error = null
            val bmp = withContext(Dispatchers.IO) { ImageUtils.load(context, uri, maxSide = 2400) }
            if (bmp == null) {
                error = "Non riesco ad aprire la foto."
            } else {
                ReceiptTools.readChecked(store.apiKey, store.model, bmp) { stage = it }
                    .onSuccess { c ->
                        repeat(c.calls) { store.countRequest() }
                        c.warning?.let { Toast.makeText(context, it, Toast.LENGTH_LONG).show() }
                        onReceipt(c.receipt)
                        receipt = c.receipt
                    }
                    .onFailure { error = it.message ?: "Errore sconosciuto" }
            }
            busy = false
        }
    }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) process(uri)
    }
    val take = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) pendingUri?.let { process(it) }
    }

    fun camera() {
        val dir = File(context.cacheDir, "photos").apply { mkdirs() }
        val file = File.createTempFile("scontrino", ".jpg", dir)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        pendingUri = uri
        take.launch(uri)
    }

    val r = receipt
    if (r != null) {
        StockImportDialog(
            candidates = r.items.map { StockCandidate(it.name, it.dept, it.price.takeIf { p -> p > 0.0 }, it.qty) },
            store = store,
            onConfirm = { items ->
                onToStock(items)
                onDismiss()
            },
            onDismiss = onDismiss,
        )
    } else {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true, confirmValueChange = { !busy })
        ModalBottomSheet(
            onDismissRequest = { if (!busy) onDismiss() },
            sheetState = sheetState,
            containerColor = cs.surfaceContainerHigh,
        ) {
            val failed = error != null && !busy
            Column(Modifier.navigationBarsPadding().padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
                Text(
                    when {
                        busy -> "Leggo lo scontrino…"
                        failed -> "Non sono riuscito a leggerlo"
                        else -> "Scansiona scontrino"
                    },
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 4.dp),
                )
                if (!failed) {
                    Text(
                        if (busy) "Di solito servono pochi secondi." else "L'AI legge i prodotti e li smista in frigo e dispensa. Prima di aggiungerli puoi correggere tutto.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.padding(start = 4.dp, top = 4.dp),
                    )
                }
                ReceiptSteps(current = if (busy) 2 else 1)

                if (busy) {
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(cs.surfaceContainer).padding(18.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(44.dp).clip(CircleShape).background(cs.primary.copy(alpha = 0.16f)),
                                contentAlignment = Alignment.Center,
                            ) { Icon(Icons.Filled.Receipt, null, tint = cs.primary) }
                            Spacer(Modifier.width(12.dp))
                            Text(stage, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        }
                        Spacer(Modifier.height(16.dp))
                        LinearProgressIndicator(Modifier.fillMaxWidth().clip(RoundedCornerShape(3.dp)))
                    }
                } else if (failed) {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(cs.surfaceContainer).padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            Modifier.size(44.dp).clip(CircleShape).background(cs.error.copy(alpha = 0.16f)),
                            contentAlignment = Alignment.Center,
                        ) { Icon(Icons.Filled.ErrorOutline, null, tint = cs.error) }
                        Spacer(Modifier.width(14.dp))
                        Text(error.orEmpty(), style = MaterialTheme.typography.bodyMedium)
                    }
                    Spacer(Modifier.height(12.dp))
                    lastUri?.let { u ->
                        Button(onClick = { process(u) }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Riprova con la stessa foto") }
                    }
                    ChooserRow(icon = Icons.Filled.CameraAlt, title = "Rifai la foto", subtitle = "Più vicina e senza ombre", divider = false, onClick = { camera() })
                    ChooserRow(
                        icon = Icons.Filled.PhotoLibrary,
                        title = "Scegli un'altra foto",
                        subtitle = "Dalla galleria",
                        onClick = { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    )
                } else {
                    // L'unico tasto pieno: la foto. La galleria è una riga.
                    Card(
                        onClick = { camera() },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = cs.primary, contentColor = cs.onPrimary),
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(48.dp).clip(CircleShape).background(cs.onPrimary.copy(alpha = 0.14f)),
                                contentAlignment = Alignment.Center,
                            ) { Icon(Icons.Filled.CameraAlt, null) }
                            Spacer(Modifier.width(14.dp))
                            Column {
                                Text("Fotografa lo scontrino", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text("Appoggialo su un piano, ben illuminato", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    ChooserRow(
                        icon = Icons.Filled.PhotoLibrary,
                        title = "Scegli dalla galleria",
                        subtitle = "Una foto già fatta",
                        divider = false,
                        onClick = { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    )
                }
                TextButton(enabled = !busy, onClick = onDismiss, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 6.dp)) { Text("Annulla") }
            }
        }
    }
}

/** I tre passi della scansione: foto, lettura, controllo. Quello attuale è pieno. */
@Composable
private fun ReceiptSteps(current: Int) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("Foto", "L'AI legge", "Controlli e aggiungi").forEachIndexed { i, label ->
            val on = i + 1 == current
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(
                    Modifier.size(26.dp).clip(CircleShape).background(if (on) cs.primary else cs.surfaceContainerHighest),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("${i + 1}", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = if (on) cs.onPrimary else cs.onSurfaceVariant)
                }
                Text(label, style = MaterialTheme.typography.labelSmall, color = if (on) cs.onSurface else cs.onSurfaceVariant, textAlign = TextAlign.Center)
            }
        }
    }
}
