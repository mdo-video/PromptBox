package com.promptbox

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * "Da scontrino" dentro Frigo e Dispensa: foto → l'AI legge i prodotti → controllo e correzioni
 * ([StockImportDialog], nome compreso) → "vuoi aggiungere le scadenze?". Lo scontrino finisce anche in Scontrini e spese.
 */
@Composable
fun ReceiptToPantryFlow(
    store: Store,
    onReceipt: (Receipt) -> Unit,
    onToStock: (List<PantryItem>) -> Unit,
    onDismiss: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var receipt by remember { mutableStateOf<Receipt?>(null) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var pendingUri by remember { mutableStateOf<Uri?>(null) }
    // L'ultima foto resta: se la lettura fallisce basta "Riprova", senza rifare la foto.
    var lastUri by remember { mutableStateOf<Uri?>(null) }
    var stage by remember { mutableStateOf("Leggo lo scontrino…") }

    fun process(uri: Uri) {
        lastUri = uri
        stage = "Leggo lo scontrino…"
        scope.launch {
            busy = true
            error = null
            val bmp = withContext(Dispatchers.IO) { ImageUtils.load(context, uri, maxSide = 2400) }
            if (bmp == null) {
                error = "Non riesco ad aprire la foto."
            } else {
                ReceiptTools.readChecked(store.apiKey, store.model, bmp) { stage = it }
                    .onSuccess { c ->
                        repeat(c.calls) { store.countRequest() }
                        c.warning?.let { Toast.makeText(context, it, Toast.LENGTH_LONG).show() }
                        onReceipt(c.receipt)
                        receipt = c.receipt
                    }
                    .onFailure { error = it.message ?: "Errore sconosciuto" }
            }
            busy = false
        }
    }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) process(uri)
    }
    val take = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) pendingUri?.let { process(it) }
    }

    fun camera() {
        val dir = File(context.cacheDir, "photos").apply { mkdirs() }
        val file = File.createTempFile("scontrino", ".jpg", dir)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        pendingUri = uri
        take.launch(uri)
    }

    val r = receipt
    if (r != null) {
        StockImportDialog(
            candidates = r.items.map { StockCandidate(it.name, it.dept, it.price.takeIf { p -> p > 0.0 }, it.qty) },
            store = store,
            onConfirm = { items ->
                onToStock(items)
                onDismiss()
            },
            onDismiss = onDismiss,
        )
    } else {
        AlertDialog(
            onDismissRequest = { if (!busy) onDismiss() },
            title = { Text("Da scontrino") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "Fotografa lo scontrino: l'AI legge i prodotti e li smista in frigo e dispensa. Prima di aggiungerli puoi correggere tutto.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Button(onClick = { camera() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.CameraAlt, null, Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Fotografa")
                    }
                    FilledTonalButton(
                        onClick = { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.Filled.PhotoLibrary, null, Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Galleria")
                    }
                    if (busy) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(stage, color = cs.onSurfaceVariant)
                        }
                    }
                    error?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodyMedium) }
                    if (error != null && !busy) {
                        lastUri?.let { u ->
                            FilledTonalButton(onClick = { process(u) }, modifier = Modifier.fillMaxWidth()) { Text("Riprova a leggere la stessa foto") }
                        }
                    }
                }
            },
            confirmButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("Annulla") } },
        )
    }
}
