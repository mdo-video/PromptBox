package com.promptbox

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Una voce del changelog. [id] cresce a ogni voce nuova: serve a mostrare il pallino "novità" in Home. */
data class ChangeEntry(val id: Int, val date: String, val title: String, val items: List<String>)

/**
 * Il changelog vive nel codice, così si legge anche offline.
 * Per aggiungere una novità: nuova voce IN CIMA alla lista, con [id] più alto di tutti.
 */
object Changelog {
    val entries = listOf(
        ChangeEntry(
            id = 4,
            date = "13 nov 2026",
            title = "Lista della spesa, suggerimenti rapidi, modelli di riserva",
            items = listOf(
                "Lista della spesa (icona carrello in Home): spunti i prodotti, li togli, ne scrivi di nuovi.",
                "Sotto ogni risposta c'è \"Alla lista\": scegli quali prodotti dell'elenco aggiungere.",
                "Suggerimenti rapidi sotto il campo di testo (Più proteine, Meno zuccheri, Solo 15 minuti...): tocchi e si scrive da solo.",
                "Confronta i prodotti: scansiona due codici a barre di fila e tocca il suggerimento.",
                "Lunghezza delle risposte (Breve, Normale, Dettagliata) nelle Impostazioni.",
                "Cambia modello da solo: se quello scelto non risponde o ha finito le richieste, Prisma ne prova un altro gratuito.",
                "Contatore delle richieste fatte oggi, nelle Impostazioni.",
            ),
        ),
        ChangeEntry(
            id = 3,
            date = "13 nov 2026",
            title = "Su di me, condivisione e codice a barre",
            items = listOf(
                "Pulsante Novità (questa pagina), con il pallino quando c'è qualcosa di nuovo.",
                "Su di me (Impostazioni): obiettivi, allergie e preferenze vengono aggiunti a ogni richiesta, così le risposte sono su misura.",
                "Prisma compare nel menu Condividi di Android: dalla Galleria, da Chrome o da WhatsApp mandi foto o testo e scegli la sezione.",
                "Scanner codice a barre (menu +): inquadri il prodotto e Prisma carica nome, ingredienti e valori nutrizionali da Open Food Facts, pronti da analizzare.",
            ),
        ),
        ChangeEntry(
            id = 2,
            date = "",
            title = "Prisma",
            items = listOf(
                "Nuovo nome, logo e grafica Material 3 scura, con colori dinamici opzionali.",
                "Sezioni modificabili, eliminabili e fissabili in alto; icona proposta dall'AI.",
                "Chat di approfondimento salvata per ogni sezione, risposte formattate, link toccabili.",
                "Dettatura vocale, copia e condivisione delle risposte.",
                "Accesso con Google e sincronizzazione delle sezioni.",
            ),
        ),
        ChangeEntry(
            id = 1,
            date = "11 nov 2026",
            title = "Prima versione",
            items = listOf(
                "Sezioni SPESA, ETICHETTA, FRIGO e LIBERO con prompt già pronti.",
                "Intelligenza artificiale Gemini con chiave gratuita inserita nelle Impostazioni.",
                "Aggiornamenti automatici dalle release di GitHub.",
            ),
        ),
    )

    val latestId: Int get() = entries.first().id
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChangelogScreen(onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text("Novità", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 8.dp, 16.dp, 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Text(
                    "Versione installata: ${BuildConfig.VERSION_NAME}",
                    fontSize = 13.sp,
                    color = cs.onSurfaceVariant,
                )
            }
            itemsIndexed(Changelog.entries) { index, e ->
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (index == 0) cs.primaryContainer else cs.surfaceContainer,
                        contentColor = if (index == 0) cs.onPrimaryContainer else cs.onSurface,
                    ),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(e.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        if (e.date.isNotBlank()) {
                            Text(e.date, fontSize = 12.sp, color = cs.onSurfaceVariant)
                        }
                        Spacer(Modifier.height(2.dp))
                        e.items.forEach { line ->
                            Row {
                                Text("•", modifier = Modifier.width(18.dp))
                                Text(line, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }
    }
}
