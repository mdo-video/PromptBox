package com.promptbox

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Una voce del changelog. [id] cresce a ogni voce nuova: serve a mostrare il pallino "novità" in Home. */
data class ChangeEntry(val id: Int, val date: String, val title: String, val items: List<String>)

/**
 * Il changelog vive nel codice, così si legge anche offline.
 * Per aggiungere una novità: nuova voce IN CIMA alla lista, con [id] più alto di tutti.
 */
object Changelog {
    val entries = listOf(
        ChangeEntry(
            id = 73,
            date = "22 nov 2026",
            title = "Il pallino ti dice dove guardare",
            items = listOf(
                "Il numero sul tasto Cucina compare anche sulle schede Frigo, Dispensa e Congelati: vedi subito in quale posto ci sono prodotti scaduti o da usare presto.",
            ),
        ),
        ChangeEntry(
            id = 72,
            date = "22 nov 2026",
            title = "Cucina: meno ripetizioni",
            items = listOf(
                "In Home è sparita la tessera Cucina: c'è già il tasto in basso, e il nome compariva tre volte nella stessa schermata.",
                "Sul tasto Cucina nella barra compare un pallino col numero dei prodotti scaduti o da usare presto.",
                "In Spesa e Scontrini non c'è più la freccia indietro né l'icona Scontrini: sono schede, si cambia dalla riga in alto.",
                "Il Riepilogo ora si intitola \"Cosa c'è in casa\", così non ripete il nome dell'area.",
            ),
        ),
        ChangeEntry(
            id = 71,
            date = "22 nov 2026",
            title = "Prisma torna il box dei prompt: la cucina è un'area sola",
            items = listOf(
                "La barra in basso ha tre voci: Home, Cucina e Impostazioni. Il tasto Spesa non c'è più nella barra.",
                "Dentro Cucina una riga di schede in alto: Spesa, Riepilogo, Frigo, Dispensa, Congelati e Scontrini. Toccando Cucina si riparte dall'ultima scheda aperta.",
                "In Home, sopra le sezioni, c'è una tessera Cucina con quanti prodotti sono da comprare e quanti da usare presto; le sezioni di prompt restano tutte alla pari.",
                "Il tasto indietro dalle schede di Cucina torna alla Home. Widget, scorciatoie e notifiche aprono la scheda giusta come prima.",
            ),
        ),
        ChangeEntry(
            id = 70,
            date = "22 nov 2026",
            title = "Cucina: frigo, dispensa e congelati in una schermata",
            items = listOf(
                "Nella barra in basso Frigo, Dispensa e Congelati diventano una voce sola, \"Cucina\": ora sono quattro voci e \"Impostazioni\" torna per intero.",
                "Una ricerca per tutti e tre i posti, un solo \"da usare presto\" che li unisce e \"Cosa ci cucino?\" con tutto quello che hai.",
                "Tre sezioni che si aprono e si chiudono: mostrano i 3 prodotti più urgenti, e \"Mostra tutti\" apre la schermata completa del posto, con aggiungi, ripiani, selezione e il resto.",
                "Dalle schermate di frigo, dispensa e congelati il tasto indietro torna a Cucina; le notifiche aprono ancora il posto giusto.",
            ),
        ),
        ChangeEntry(
            id = 69,
            date = "22 nov 2026",
            title = "Congelati: scongela, più prodotti insieme, surgelati dallo scontrino",
            items = listOf(
                "Scongela: nelle azioni di un prodotto del congelatore. Passa nel frigo con una scadenza nuova (carne e pesce 2 giorni, il resto 3) e puoi annullare.",
                "Una foto o una frase con più prodotti (\"4 hamburger e 2 petti di pollo\") ne crea uno per ciascuno, fino a 8: li controlli uno alla volta con \"Salva e vai al prossimo\". Vale anche in Frigo e Dispensa.",
                "Nel foglio \"Da usare presto\" c'è il tasto spunta per segnare un prodotto finito senza aprirlo.",
                "Dallo scontrino, i prodotti del reparto Surgelati vanno nel congelatore, con il ripiano scelto dal nome e la durata a -18 °C; puoi cambiarli come gli altri.",
                "L'avviso di scadenza includeva già i Congelati (30 giorni prima della fine della durata consigliata); ora è coperto da un test.",
            ),
        ),
        ChangeEntry(
            id = 68,
            date = "22 nov 2026",
            title = "Da usare presto: un foglio con i prodotti",
            items = listOf(
                "Tocca \"da usare presto\" in Frigo, Dispensa o Congelati: si apre un foglio con i prodotti in scadenza, i più urgenti per primi.",
                "Ogni riga ha ripiano, quantità e quanto manca (rosso oggi, giallo domani, grigio dopo). Un tocco apre le azioni del prodotto: Finito, Modifica, Elimina.",
                "In fondo \"Cosa ci cucino con questi\" propone ricette usando solo quei prodotti.",
            ),
        ),
        ChangeEntry(
            id = 67,
            date = "22 nov 2026",
            title = "Nuova sezione Congelati",
            items = listOf(
                "Una voce \"Congelati\" nella barra in basso (ora sei voci: Impostazioni nella barra si chiama \"Opzioni\" per stare tutto), con gli stessi riquadri e ripiani di Frigo e Dispensa: Carne, Pesce, Verdure e frutta, Pronti e sughi, Pane e dolci, Altro.",
                "Aggiungi con una foto di cosa congeli, scrivendolo (\"800 g di macinato di manzo\") o a mano: l'AI sceglie il ripiano, la quantità e quanti mesi si conserva a -18 °C.",
                "Se sulla busta c'è una data, quella è il giorno in cui hai congelato; senza data vale oggi. La scadenza è: giorno del congelamento + durata dell'alimento.",
                "Temperatura del congelatore impostabile (tocca \"-18 °C\" in alto): più caldo accorcia le durate, più freddo le allunga, e le scadenze si ricalcolano. Si sincronizza con l'account.",
                "Nella finestra del prodotto puoi cambiare giorno di congelamento e durata (± 1 mese). Sono stime di qualità, non date di sicurezza.",
                "Sposta: un prodotto che entra nel congelatore parte da oggi con la durata del ripiano; uno che esce perde la scadenza del congelamento.",
            ),
        ),
        ChangeEntry(
            id = 66,
            date = "22 nov 2026",
            title = "Frigo e Dispensa: una foto e il prodotto si compila da solo",
            items = listOf(
                "Nuovo \"Foto prodotto\" in Aggiungi: scatti la confezione e l'AI compila nome, ripiano, quantità e, se si vede nella foto, anche la scadenza.",
                "La quantità è quella della confezione: se leggi o riconosci il prodotto sai già che, per esempio, le mozzarelle si vendono a tre (\"3 × 100 g\"). Il codice a barre, se inquadrato, conferma la confezione su Open Food Facts.",
                "Anche \"Scansiona codice\" ora sceglie il ripiano, mette la quantità e propone una scadenza stimata.",
                "Tolte le scorciatoie di data (Domani, 3 giorni, 1 settimana…): restano \"Fotografa la data sull'etichetta\", \"Scegli la data…\" e \"Nessuna\". Vale anche per \"Aggiungi le scadenze\".",
                "Se la lettura della foto fallisce c'è \"Riprova\" senza rifare la foto. Resta libero solo ciò che non si riesce a capire; tutto si corregge a mano.",
            ),
        ),
        ChangeEntry(
            id = 65,
            date = "22 nov 2026",
            title = "Selezione multipla: Finiti, Sposta, Elimina",
            items = listOf(
                "Da \"Seleziona più prodotti\" ogni riquadro ha la sua spunta; in alto \"N selezionati\", la X per uscire e \"Seleziona tutti\".",
                "Barra in basso con tre azioni in blocco: Finiti (li rimette nella lista della spesa), Sposta ed Elimina; Finiti ed Elimina hanno l'Annulla.",
                "Sposta: foglio con i ripiani di questo posto e quelli dell'altro, così si cambia ripiano o anche frigo/dispensa; la scadenza resta com'è, con Annulla.",
            ),
        ),
        ChangeEntry(
            id = 64,
            date = "22 nov 2026",
            title = "Frigo e Dispensa: tocco e tocco lungo invertiti",
            items = listOf(
                "Un tocco su un prodotto apre il foglio con le azioni (Finito, Modifica, Seleziona più prodotti, Elimina).",
                "Tenendo premuto si apre direttamente la modifica.",
            ),
        ),
        ChangeEntry(
            id = 63,
            date = "22 nov 2026",
            title = "Fogli aperti a tutta altezza",
            items = listOf(
                "Aggiungi e le azioni del prodotto si aprono subito a tutta altezza: prima restavano a metà e l'ultima riga (Elimina) si vedeva solo trascinando il foglio in alto.",
            ),
        ),
        ChangeEntry(
            id = 62,
            date = "22 nov 2026",
            title = "Fogli più in alto",
            items = listOf(
                "I fogli dal basso (Aggiungi, Scansiona scontrino, azioni e modifica del prodotto) hanno più spazio in fondo e scorrono se lo schermo è piccolo: l'ultima riga non finisce più sotto la barra dei gesti.",
            ),
        ),
        ChangeEntry(
            id = 61,
            date = "22 nov 2026",
            title = "I fogli si alzano sopra la barra di Android",
            items = listOf(
                "I fogli dal basso (Aggiungi, Scansiona scontrino, azioni e modifica del prodotto) lasciano lo spazio della barra dei gesti: l'ultima riga, per esempio Elimina, non finisce più sotto.",
            ),
        ),
        ChangeEntry(
            id = 60,
            date = "22 nov 2026",
            title = "Sincronizzazione completa e avvisi",
            items = listOf(
                "La chiave API ora si sincronizza con il tuo account Google, nella cartella privata di Prisma su Drive come la password di Bring: su un nuovo telefono basta accedere a Google. Non finisce mai nel file di backup che salvi tu.",
                "Verificato che tutto il resto viaggia già: schede, categorie, Spesa, Frigo e Dispensa, scontrini, spreco, routine, campi guidati, chat, documenti e impostazioni. Restano solo locali i contatori delle richieste, il blocco del PIN dopo errori e le ultime schede aperte.",
                "Avvisi: \"Sincronizzato con Google\" (o l'errore) dopo \"Sincronizza ora\" e dopo \"tira giù\" nella Spesa; il backup su Drive conferma cosa ha salvato.",
            ),
        ),
        ChangeEntry(
            id = 59,
            date = "22 nov 2026",
            title = "Frigo e Dispensa: azioni rapide, modifica nuova, avvisi",
            items = listOf(
                "Tenendo premuto un prodotto si apre un foglio con le azioni: Finito (con \"Rimetti nella lista della spesa\"), Modifica, Seleziona più prodotti ed Elimina (senza rosso; con Annulla).",
                "Il tocco breve apre solo la modifica, ridisegnata come foglio: nome con scanner, quantità, ripiano e scadenza (scorciatoie su due righe che scorrono). Salva è l'unico tasto pieno; Finito ed Elimina non sono più lì.",
                "Avvisi in basso quando confermi: \"Modifiche salvate\", \"«prodotto» aggiunto\", \"N prodotti aggiunti\" dopo lo scontrino (anche dal \"+\" della Home), oltre a Finito ed Elimina che avevano già l'Annulla.",
            ),
        ),
        ChangeEntry(
            id = 58,
            date = "21 nov 2026",
            title = "Scansiona scontrino: nuovo foglio",
            items = listOf(
                "La finestra \"Da scontrino\" diventa un foglio dal basso, come il menù Aggiungi: tre passi in alto (Foto, L'AI legge, Controlli e aggiungi), \"Fotografa lo scontrino\" come unico tasto pieno e la galleria come riga.",
                "Durante la lettura il foglio non si chiude e mostra lo stato con una barra di avanzamento.",
                "Se la lettura fallisce: messaggio con il cerchio rosso, \"Riprova con la stessa foto\" come tasto pieno, poi \"Rifai la foto\" e \"Scegli un'altra foto\".",
                "Vale sia dal \"+\" della Home sia da Frigo e Dispensa.",
            ),
        ),
        ChangeEntry(
            id = 57,
            date = "21 nov 2026",
            title = "Il \"+\" della Home: Scansiona scontrino e menù nuovo",
            items = listOf(
                "Il \"+\" della Home apre il foglio \"Aggiungi\": in cima Scansiona scontrino (foto → l'AI legge i prodotti → li controlli, con quantità e codice a barre → entrano in frigo e dispensa; lo scontrino finisce anche in Scontrini e spese).",
                "Sotto restano Crea con AI, Dalla libreria e Incolla scheda copiata, ridisegnate come righe con cerchio tonale e divisori, nello stile unico dell'app.",
            ),
        ),
        ChangeEntry(
            id = 56,
            date = "21 nov 2026",
            title = "Le quantità dello scontrino arrivano in Frigo e Dispensa",
            items = listOf(
                "Lo scontrino ora riporta anche la quantità: una riga \"2 x 1,190 BIRRA DREHER\" entra in Frigo o Dispensa con quantità 2 (per i prodotti a peso, il peso).",
                "In \"Metti in frigo e dispensa\" ogni riga ha il campo Quantità, già compilato e correggibile prima di confermare.",
                "Se il prodotto c'è già, rinnovandolo la quantità nuova sostituisce la vecchia; se lo scontrino non ne indica una, resta quella di prima.",
                "Gli scontrini già salvati non hanno la quantità: vale per quelli letti da adesso.",
            ),
        ),
        ChangeEntry(
            id = 55,
            date = "21 nov 2026",
            title = "Il codice a barre per rifinire il nome del prodotto",
            items = listOf(
                "Frigo e Dispensa, \"Modifica prodotto\": accanto al nome c'è l'icona del codice a barre. Scansionalo e il nome diventa quello preciso del prodotto (ad esempio \"Limonata zero zuccheri aggiunti San Benedetto\" al posto della sigla dello scontrino); se la quantità è vuota si compila anche quella (ad esempio \"75 cl\").",
                "\"Metti in frigo e dispensa\" (dopo scontrino o spesa): la stessa icona è su ogni riga, così correggi il nome di un prodotto letto male senza uscire dalla finestra.",
                "Se il prodotto non è su Open Food Facts lo dice e il nome resta com'era: lo scrivi tu.",
            ),
        ),
        ChangeEntry(
            id = 54,
            date = "21 nov 2026",
            title = "Scontrini più veloci",
            items = listOf(
                "La lettura ragiona meno (livello basso) e la foto è un po' più piccola: l'attesa è più breve.",
                "Se un modello è lento, dopo 7 secondi parte in parallelo un secondo modello e vale la prima risposta riuscita. Succede solo quando serve, per non consumare la quota gratuita.",
                "Mentre aspetti vedi cosa sta facendo: lettura, nuovo tentativo o controllo dei conti.",
            ),
        ),
        ChangeEntry(
            id = 53,
            date = "21 nov 2026",
            title = "Scontrini letti meglio",
            items = listOf(
                "Se la lettura di uno scontrino non riesce, la foto resta: premi \"Riprova a leggere la stessa foto\" invece di rifarla. L'app riprova anche da sola una volta.",
                "Lettura più precisa: foto a risoluzione più alta, risposta in formato JSON, regole per quantità, pesi e sconti, e un modello più forte (con quello scelto nelle Impostazioni come ultima scelta).",
                "Controllo dei conti: se la somma dei prodotti non coincide con il totale dello scontrino, l'app rilegge guardando di nuovo la foto e, se ancora non torna, ti avvisa.",
            ),
        ),
        ChangeEntry(
            id = 52,
            date = "21 nov 2026",
            title = "PDF grandi e stato della sincronizzazione",
            items = listOf(
                "I PDF dell'archivio documenti oltre 1 MB (fino a 15 MB) ora si sincronizzano come file separati nella cartella nascosta di Drive: compaiono sugli altri dispositivi alla sincronizzazione successiva.",
                "In Impostazioni, sotto Ultima sincronizzazione, vedi la dimensione del file su Drive e quanti PDF grandi sono stati caricati, scaricati o sono in attesa.",
            ),
        ),
        ChangeEntry(
            id = 51,
            date = "21 nov 2026",
            title = "Sincronizzazione completa",
            items = listOf(
                "Con l'account Google ora si sincronizzano anche le chat e l'archivio chat, l'archivio documenti di ogni scheda (con i PDF fino a 1 MB), l'interruttore Chat e Archivio di ogni scheda, la vista a lista o griglia della Home e le categorie chiuse.",
                "Se chatti nella stessa scheda su due dispositivi, i messaggi di entrambi si uniscono in ordine di ora: non si perde più niente. Una chat cancellata resta cancellata.",
                "Restano solo sul dispositivo la chiave API e i dati tecnici (contatori, blocco del PIN).",
                "Tutto va nella cartella nascosta di Prisma su Drive. Il backup su file non include le chat, quello su Drive sì.",
            ),
        ),
        ChangeEntry(
            id = 50,
            date = "21 nov 2026",
            title = "Layout per il tablet",
            items = listOf(
                "Sugli schermi larghi (tablet, da circa 600 dp) la barra in basso diventa una barra laterale a sinistra. Sul telefono non cambia niente.",
                "Home a tre colonne: le schede si dispongono in griglia invece di lasciare spazio vuoto ai lati.",
                "Schede e risposta affiancate: aprendo una scheda vedi l'elenco delle schede a sinistra e la chat a destra, e passi da una all'altra con un tocco.",
                "Spesa e Frigo affiancati: mentre fai la lista vedi cosa hai già in frigo. Le due schermate funzionano come prima, si vedono solo insieme.",
            ),
        ),
        ChangeEntry(
            id = 49,
            date = "20 nov 2026",
            title = "Uno stile solo: risposte e Cronologia, e un po' di pulizia",
            items = listOf(
                "Risposte: ogni sezione usa lo stesso viola dell'app (prima cambiava tra viola, azzurro e marrone secondo la scheda). L'avviso di errore ha fondo neutro e l'icona rossa.",
                "Cronologia: titoli dei gruppi (Oggi, Ieri...) in grigio e icone delle chat tutte dello stesso colore tenue.",
                "Pulizia: tolti dal codice la vecchia vista a elenco della Dispensa e la tavolozza dei colori delle schede, che non servivano più. Nessun cambiamento visibile.",
            ),
        ),
        ChangeEntry(
            id = 48,
            date = "20 nov 2026",
            title = "Frigo e Dispensa: solo i ripiani con prodotti",
            items = listOf(
                "Frigo e Dispensa: tolto il selettore Disegno/Elenco, resta la vista a ripiani.",
                "Compaiono solo i ripiani che contengono prodotti. I ripiani vuoti non occupano più spazio: in fondo c'è la scheda \"Aggiungi in un altro ripiano\" con un pulsante per ciascuno (o \"Aggiungi in un ripiano\" se è tutto vuoto).",
            ),
        ),
        ChangeEntry(
            id = 47,
            date = "20 nov 2026",
            title = "Uno stile solo: Spesa, Frigo e Dispensa",
            items = listOf(
                "Frigo e Dispensa: le schede dei prodotti sono tutte dello stesso grigio. Il rosso (scaduto) e l'arancio (da usare presto) restano solo sull'icona e sulla scadenza, non più come sfondo dell'intera scheda.",
                "Frigo e Dispensa: le etichette in alto (prodotti, scaduti, da usare presto, tutto sotto controllo) e le schede \"scaduti: butta e rimetti in lista\", \"Aggiungi le scadenze\" e \"Cosa ci cucino?\" hanno fondo neutro e l'icona colorata.",
                "Spesa: \"Cosa ci cucino?\" è il tasto pieno in viola, \"Metti in frigo e dispensa\" ha fondo neutro, i nomi dei reparti non sono più in viola e il contatore del reparto è grigio.",
            ),
        ),
        ChangeEntry(
            id = 46,
            date = "20 nov 2026",
            title = "Il PIN con il tastierino",
            items = listOf(
                "Il PIN si digita su un tastierino a schermo, con sei punti che si riempiono. Alla sesta cifra si conferma da solo: niente più campo di testo e tasto \"Sblocca\".",
                "Scegliendo un nuovo PIN lo digiti due volte (\"Scegli un PIN\", poi \"Ripeti il PIN\"); se non coincidono ricominci. Se sbagli il PIN, i punti si svuotano e compare \"PIN sbagliato\".",
            ),
        ),
        ChangeEntry(
            id = 45,
            date = "20 nov 2026",
            title = "Uno stile solo: Home e Impostazioni",
            items = listOf(
                "Home: le schede non sono più verdi, viola o marroni a rotazione ma tutte dello stesso grigio, con l'icona su fondo tenue. La categoria si riconosce dal pallino colorato accanto al nome, come prima. Il pin è viola solo quando la scheda è fissata.",
                "Home: l'avviso \"Manca la chiave API\" non è più un riquadro rosso ma una riga con icona, titolo e spiegazione, uguale agli altri avvisi.",
                "Impostazioni: titoli delle schede in bianco invece che in viola, le righe che portano ad altre schermate (Cronologia, Routine e avvisi) hanno l'icona in un cerchio tenue, e lo stato della chiave API usa la stessa icona tonda dell'aggiornamento (spunta o punto esclamativo).",
            ),
        ),
        ChangeEntry(
            id = 44,
            date = "20 nov 2026",
            title = "Aggiornamenti: un solo pulsante che si capisce",
            items = listOf(
                "Impostazioni → Aggiornamenti: il controllo è dentro un unico pulsante grande. All'apertura dice \"Controlla aggiornamenti\"; mentre cerca mostra \"Controllo in corso…\"; poi diventa \"Controlla di nuovo\", \"Riprova\" (se c'è stato un errore) o \"Aggiorna ora\" (se c'è una nuova versione).",
                "Tolta la riga \"Cerca nuove versioni / Premi Controlla\" con l'icona di download, che confondeva: la riga di stato compare solo dopo un controllo.",
                "\"Cosa c'è di nuovo\" è ora una riga da toccare in fondo alla scheda, con la freccia.",
            ),
        ),
        ChangeEntry(
            id = 43,
            date = "20 nov 2026",
            title = "L'avviso di aggiornamento in Home, senza rosso",
            items = listOf(
                "Home: l'avviso \"Nuova versione disponibile\" non è più un riquadro rosso-marrone ma una scheda neutra, con lo stesso viola d'accento della scheda in Impostazioni e il pulsante \"Aggiorna ora\" a tutta larghezza.",
                "Durante il download vedi percentuale e barra sottile. Se manca il permesso di installazione compare \"Manca un permesso\" con cosa fare, invece di una riga di testo piccola.",
                "Nuova X per nascondere l'avviso fino alla prossima apertura dell'app.",
            ),
        ),
        ChangeEntry(
            id = 42,
            date = "20 nov 2026",
            title = "La scheda Aggiornamenti, più calma",
            items = listOf(
                "Impostazioni → Aggiornamenti ridisegnata: un solo colore d'accento, una riga di stato chiara (\"Sei all'ultima versione\", \"Nuova versione disponibile\", \"Nessuna connessione\") e basta riquadri colorati uno dentro l'altro.",
                "\"Aggiorna ora\" è l'unico pulsante pieno e compare solo quando c'è davvero una nuova versione; \"Controlla\" (o \"Riprova\" dopo un errore) e \"Novità\" sono due azioni discrete in fondo.",
                "Durante il download vedi la percentuale e una barra sottile; il chip con la versione è sparito perché la versione è già nel sottotitolo.",
            ),
        ),
        ChangeEntry(
            id = 41,
            date = "20 nov 2026",
            title = "La spesa a voce, e lo schermo resta acceso",
            items = listOf(
                "Spesa: tocca il microfono nel campo \"Aggiungi\" e detta i prodotti. \"Latte uova e pane\" diventa \"latte, uova, pane\" nel campo: lo correggi e poi aggiungi. Nessun permesso da concedere.",
                "Spesa: puoi aggiungere più prodotti insieme scrivendoli separati da virgola (o uno per riga, se li incolli). Le quantità con la virgola, come \"Pasta 0,5 kg\", restano intere. Vale la stessa regola dei singoli: niente doppioni, quantità sommate, presi rimessi da comprare.",
                "Spesa: lo schermo non si spegne finché c'è qualcosa da comprare, così al supermercato non devi sbloccare il telefono ogni volta.",
                "Sincronizzazione e aggiornamenti: senza internet compare \"Nessuna connessione a internet\" (o \"La connessione è troppo lenta\") invece del messaggio tecnico.",
            ),
        ),
        ChangeEntry(
            id = 40,
            date = "19 nov 2026",
            title = "Annulla ovunque, ricerca nel frigo e rete più chiara",
            items = listOf(
                "Spesa: se tocchi il cestino su un prodotto o \"Togli spuntati\" compare \"Annulla\". I prodotti tornano come prima, anche sugli altri dispositivi.",
                "Spesa: scrivendo un prodotto a mano valgono le stesse regole dell'AI. Se c'è già lo dice (\"Latte è già in lista\" invece di non fare niente), le quantità si sommano (Uova 6 + Uova 12 = Uova 18) e un prodotto già spuntato come preso torna da comprare. Vale anche per \"Alla lista\" e per \"Finito\".",
                "Frigo e Dispensa: con 8 o più prodotti compare \"Cerca\". Filtra il disegno e l'elenco e nasconde i ripiani vuoti.",
                "Frigo e Dispensa: anche \"Elimina\" dalla scheda di un prodotto ha l'Annulla. Se era scaduto, torna anche fuori dal conteggio dello spreco.",
                "\"Annulla\" mentre l'AI sta rispondendo ferma davvero la richiesta: la connessione si chiude subito e non resta una richiesta fantasma che consuma quelle gratuite.",
                "Se manca internet compare \"Nessuna connessione a internet\" al posto del messaggio tecnico. Se la rete non c'è proprio, l'app riprova una volta da sola dopo un secondo e mezzo.",
                "Il lettore dello schermo ora dice il nome del prodotto sulle caselle della lista (\"Latte\", non solo \"casella\") e \"Elimina Latte\" sul cestino. Una vibrazione leggera conferma spunta e aggiunta.",
                "Tirando giù la lista senza account Google collegato, l'app spiega perché non succede niente.",
            ),
        ),
        ChangeEntry(
            id = 39,
            date = "19 nov 2026",
            title = "L'app impara dalle tue correzioni, e conta lo spreco",
            items = listOf(
                "Quando correggi un prodotto dello scontrino (nome, posto, ripiano o durata), l'app se lo ricorda: la volta dopo lo stesso prodotto si smista da solo, con il nome corretto. Se tutti i prodotti sono già conosciuti non serve nemmeno chiedere all'AI, ed è più veloce.",
                "Ricorda anche cosa non va in frigo (come i surgelati): resta su Salta.",
                "I prodotti da scontrino si portano dietro il prezzo. Quando usi \"butta e rimetti in lista\" (o elimini un prodotto già scaduto) il prezzo finisce nello spreco.",
                "In Scontrini e spese → Statistiche compare \"Buttato perché scaduto\": quanto questo mese, quanti prodotti, i più costosi e il confronto col mese scorso. I prodotti senza prezzo si contano ma non si sommano.",
                "Sulla scheda rossa dei scaduti c'è già una stima: \"circa 4,20 € buttati\".",
                "Tutto si sincronizza e va nel backup come il resto.",
            ),
        ),
        ChangeEntry(
            id = 38,
            date = "19 nov 2026",
            title = "Avviso di scadenza automatico",
            items = listOf(
                "La prima volta che in Frigo o in Dispensa c'è un prodotto con scadenza, l'app propone l'avviso delle 8 del mattino e chiede il permesso notifiche di Android. Se rispondi \"Non ora\" non te lo richiede: l'interruttore resta in Impostazioni → Routine.",
                "La notifica ora separa i scaduti (\"Scaduti: Yogurt (scaduto ieri)\") da quelli in scadenza, e scrive \"circa\" per le scadenze solo stimate.",
                "La soglia \"in scadenza\" è la stessa della schermata: 3 giorni in frigo, 14 in dispensa.",
                "Dalla notifica c'è il tasto \"Apri frigo e rimetti in lista\" (o \"Apri dispensa…\"): porta alla scheda dove, con la scheda rossa dei scaduti, li sposti nella lista della spesa con un tocco.",
            ),
        ),
        ChangeEntry(
            id = 37,
            date = "19 nov 2026",
            title = "Un solo \"+\" e il tasto Finito",
            items = listOf(
                "In Frigo e Dispensa c'è un solo pulsante \"Aggiungi\": toccandolo si aprono Manualmente, Scansiona codice e Da scontrino, con lo sfondo scurito. Sparisce la pila di tasti.",
                "Nella scheda di ogni prodotto c'è \"Finito\": il prodotto esce da frigo o dispensa e, con l'interruttore \"Rimetti nella lista della spesa\" (acceso di default), va nella lista, nel reparto giusto e senza doppioni.",
                "Dopo ogni \"Finito\" compare un messaggio con \"Annulla\": ripristina il prodotto e toglie dalla lista quello appena aggiunto. Non cambi schermata.",
                "I prodotti scaduti hanno una scheda in alto: \"N scaduti: butta e rimetti in lista\" li sposta tutti con un tocco (sempre con Annulla).",
                "Tenendo premuto un prodotto ne scegli più d'uno: \"Finiti → in lista\" li sposta tutti insieme. Poi mandi la lista a Bring in blocco, come prima.",
            ),
        ),
        ChangeEntry(
            id = 36,
            date = "19 nov 2026",
            title = "Frigo da scontrino, con le scadenze",
            items = listOf(
                "In Frigo e in Dispensa c'è il nuovo tasto \"Aggiungi da scontrino\": fotografi (o scegli dalla galleria) lo scontrino e l'AI smista i prodotti tra frigo e dispensa. L'inserimento a mano resta come prima.",
                "Prima di aggiungere controlli tutto: puoi correggere il nome, cambiare posto e ripiano, o scegliere Salta per ciò che non va in frigo. Vale anche dalla Spesa.",
                "Lo scontrino letto viene salvato anche in Scontrini e spese.",
                "Dopo la conferma l'app chiede \"Vuoi aggiungere le scadenze?\". Se dici sì, passi i prodotti uno alla volta: scorciatoie, calendario oppure foto della data sull'etichetta (l'AI la legge, tu controlli). Salta tiene la stima.",
                "Se dici \"Più tardi\", le scadenze restano stimate e si vedono come \"circa tra 5 gg\". In Frigo e Dispensa compare \"Aggiungi le scadenze\" finché ce n'è qualcuna da confermare.",
                "Se cambi a mano la scadenza di un prodotto, smette di essere una stima.",
            ),
        ),
        ChangeEntry(
            id = 35,
            date = "19 nov 2026",
            title = "Dalla spesa al frigo",
            items = listOf(
                "Nella Spesa, quando spunti dei prodotti compare \"Metti in frigo e dispensa\": l'app (con l'AI, se c'è la chiave) propone per ognuno dove va, su che ripiano e quanto dura.",
                "In ogni riga scegli Frigo, Dispensa o Salta, cambi il ripiano con un tocco e la scadenza con + e −. Surgelati e prodotti per la casa restano fuori.",
                "Se un prodotto c'è già nello stesso posto, non si duplica: si rinnova con la scadenza nuova.",
                "Anche dallo scontrino: aprendo uno scontrino letto dall'AI c'è \"In frigo e dispensa\".",
                "Confermando, i prodotti messi via escono dalla lista della spesa.",
            ),
        ),
        ChangeEntry(
            id = 34,
            date = "18 nov 2026",
            title = "Tutto sincronizzato, più sicuro",
            items = listOf(
                "Frigo e dispensa, scontrini, routine con avviso di scadenza e campi guidati ora si sincronizzano tra telefono e tablet e finiscono anche nel backup.",
                "La prima volta che sincronizzi, i dati che avevi già su ogni dispositivo si uniscono invece di sostituirsi: non se ne perde nessuno.",
                "Se telefono e tablet sincronizzano nello stesso momento, l'app ricontrolla il file su Drive prima di scrivere e rifà l'unione: le modifiche non si cancellano più a vicenda.",
                "Le chat e la cronologia sono ora salvate cifrate sul dispositivo, come la chiave API.",
                "La password di Bring non è più nel file di backup che salvi: viaggia solo nella sincronizzazione privata di Drive. Dopo un ripristino da file la reinserisci.",
                "Ruotando lo schermo non si perdono più la foto allegata e la risposta in arrivo.",
                "Mentre l'AI sta rispondendo c'è il tasto Annulla.",
                "Nella lista della spesa un prodotto già presente non si duplica: se ha la stessa unità le quantità si sommano (Uova 6 + Uova 12 = Uova 18).",
                "In Impostazioni → Aggiornamenti compare la revisione del codice (es. \"Revisione 34\"), e nella schermata Novità \"v1.N · revisione 34\": serve a sapere da quale versione dei sorgenti nasce l'app installata.",
            ),
        ),
        ChangeEntry(
            id = 33,
            date = "18 nov 2026",
            title = "Routine automatiche",
            items = listOf(
                "Toccando la notifica di una routine la sezione si apre e la richiesta parte da sola: non serve più premere invio.",
            ),
        ),
        ChangeEntry(
            id = 32,
            date = "18 nov 2026",
            title = "Più veloce e più leggera",
            items = listOf(
                "Le risposte compaiono man mano mentre l'AI le scrive, invece di aspettare la fine.",
                "L'app occupa meno spazio (l'APK è più piccolo) e parte un po' più in fretta.",
                "Frigo, dispensa, scontrini e routine si salvano in background: niente scatti con tanti dati.",
                "Allarmi e notifiche partono più veloci e consumano meno.",
                "Le foto degli scontrini sono più nitide, così i prezzi si leggono meglio.",
                "Il codice è stato riordinato (file più corti) e ci sono i primi test automatici su scadenze, timer, scontrini, routine e campi guidati.",
            ),
        ),
        ChangeEntry(
            id = 31,
            date = "18 nov 2026",
            title = "Frigo e Dispensa separati, routine, avvisi e voce",
            items = listOf(
                "Frigo e Dispensa ora sono due voci separate nella barra in basso, così la Dispensa si trova subito. La Cronologia si apre dalle Impostazioni.",
                "Nuovo aspetto Material 3 per frigo e dispensa: ripiani come schede, prodotti con colori di stato (scaduto, da usare presto) e icone, riepilogo con etichette, interruttore Disegno / Elenco, pulsanti Aggiungi e scanner in basso.",
                "Routine programmate (Impostazioni → Routine e avvisi): scegli sezione, ora e giorni, e cosa chiedere. All'ora giusta arriva una notifica: la tocchi e la sezione si apre con la richiesta già inviata, anche con i prodotti che hai in frigo.",
                "Avvisi di scadenza: ogni mattina alle 8 una notifica con i prodotti scaduti o che scadono entro 3 giorni, in frigo e in dispensa. Tocchi la notifica e si apre il frigo o la dispensa.",
                "Voce: sotto ogni risposta il tasto \"Leggi\" la legge ad alta voce (\"Ferma\" per interrompere). La dettatura con il microfono c'era già.",
                "Per ora routine e avvisi restano solo su questo telefono (non sono nel backup né nella sincronizzazione).",
            ),
        ),
        ChangeEntry(
            id = 30,
            date = "18 nov 2026",
            title = "Campi guidati, scontrini e statistiche",
            items = listOf(
                "Campi guidati: in ogni sezione, l'icona con i cursori (in alto) apre i campi del modulo. Appaiono sopra la casella di testo come scelte rapide (es. Persone: 2, Tempo: 30 min) o testo breve, e compongono la richiesta per te. \"Proponi con AI\" suggerisce i campi giusti per la sezione.",
                "Le ultime scelte si ricordano. Con la chat attiva il modulo compare solo all'inizio della conversazione.",
                "Scontrini: dall'icona scontrino nella Spesa fotografi (o scegli dalla galleria) uno scontrino e l'AI legge negozio, data, prodotti e prezzi, divisi per reparto.",
                "Statistiche: quanto spendi questo mese e rispetto al mese scorso, grafico degli ultimi 6 mesi, dove spendi di più per reparto e cosa compri più spesso.",
                "Per ora campi guidati e scontrini restano solo su questo telefono (non sono nel backup né nella sincronizzazione).",
            ),
        ),
        ChangeEntry(
            id = 29,
            date = "18 nov 2026",
            title = "Barra e Aggiornamenti più curate",
            items = listOf(
                "La barra in basso ora mostra tutte le etichette su una riga, anche \"Impostazioni\".",
                "La scheda Aggiornamenti ha un nuovo aspetto: icona, versione in evidenza, esito del controllo ben visibile (verde se sei aggiornato, rosso se c'è un problema) e \"Cosa c'è di nuovo\" a portata di mano.",
            ),
        ),
        ChangeEntry(
            id = 28,
            date = "18 nov 2026",
            title = "Frigo e dispensa",
            items = listOf(
                "Nuova voce \"Frigo\" nella barra in basso: il frigo (ripiani, cassetto verdure, sportello) e la dispensa disegnati, con ogni prodotto su un ripiano. In alto scegli Frigo o Dispensa e la vista Disegno o Elenco.",
                "Ogni prodotto ha la scadenza: bordo pieno = scaduto, tratteggiato = da usare presto (3 giorni per il frigo, 2 settimane per la dispensa). Si legge anche senza i colori.",
                "Tocca un prodotto per modificarlo, spostarlo di ripiano, cambiare la scadenza (scelte rapide o calendario) o eliminarlo. Il + su ogni ripiano aggiunge un prodotto lì.",
                "Il tasto scanner legge il codice a barre e propone il nome da Open Food Facts; \"Salva e altro\" passa subito al prodotto successivo, per riempire il frigo dopo la spesa.",
                "\"Cosa ci cucino?\" manda a FRIGO i prodotti in ordine di scadenza, così le ricette usano prima quelli che scadono.",
                "Per ora frigo e dispensa restano solo su questo telefono (non sono nel backup né nella sincronizzazione).",
            ),
        ),
        ChangeEntry(
            id = 27,
            date = "18 nov 2026",
            title = "Manda a… e timer nelle risposte",
            items = listOf(
                "Sotto ogni risposta c'è \"Manda a…\": scegli un'altra sezione e la risposta arriva nel suo campo di testo, pronta per la tua richiesta (es. da ETICHETTA a FRIGO, o da FRIGO a SPESA).",
                "I tempi scritti nelle risposte (\"12 min\", \"1 ora\", \"10-12 minuti\") sono toccabili: parte un timer nell'app Orologio del telefono.",
                "Se la risposta ha più tempi, il tasto \"Timer\" sotto la risposta ti fa scegliere quale avviare.",
                "Cambiando sezione, il campo di testo e lo stato della sezione di partenza non si portano più dietro.",
            ),
        ),
        ChangeEntry(
            id = 26,
            date = "14 nov 2026",
            title = "Categorie chiuse ricordate",
            items = listOf(
                "Le categorie che chiudi in Home restano chiuse anche dopo aver cambiato schermata o chiuso l'app.",
            ),
        ),
        ChangeEntry(
            id = 25,
            date = "14 nov 2026",
            title = "Mostra e copia la chiave API con il PIN",
            items = listOf(
                "Nelle Impostazioni puoi vedere e copiare la chiave API dopo aver inserito un PIN di 6 cifre. Il PIN si specchia sugli altri dispositivi.",
                "PIN dimenticato: lo sblocco del telefono (impronta, schema o codice) ti fa scegliere un PIN nuovo.",
            ),
        ),
        ChangeEntry(
            id = 24,
            date = "14 nov 2026",
            title = "Sync completa, backup su Drive, risposte modificabili",
            items = listOf(
                "Tieni premuta una risposta per modificarla a mano. Salvando, \"Alla lista\" e \"Aggiungi a Calendar\" si aggiornano dal testo nuovo.",
                "\"Alla lista\" ora porta anche le quantità (e per i menù somma gli ingredienti di tutta la settimana).",
                "Tolti i tasti rapidi (Più breve, Spiega meglio, Dammi un esempio...) dalla chat.",
                "Con l'accesso a Google si specchiano su tutti i dispositivi anche categorie e colori, \"Su di me\", account Bring con le liste per reparto, tema, modello e sezioni fissate.",
                "Il backup ora include tutto questo. Nuovi tasti \"Backup su Drive\" e \"Ripristina da Drive\" nelle Impostazioni.",
            ),
        ),
        ChangeEntry(
            id = 23,
            date = "14 nov 2026",
            title = "Cambia lista Bring dal reparto",
            items = listOf(
                "Nella lista della spesa, tocca il nome della lista a destra di ogni reparto (es. \"→ Todis\") per scegliere un'altra lista di Bring. Resta salvato per i prossimi invii.",
            ),
        ),
        ChangeEntry(
            id = 22,
            date = "14 nov 2026",
            title = "Aggiungi a Calendar",
            items = listOf(
                "Se una risposta propone appuntamenti o allenamenti con giorno e ora, sotto compare \"Aggiungi a Calendar\": si apre Google Calendar con tutti gli eventi (anche settimanali) da importare in un colpo solo.",
                "L'AI ora conosce la data di oggi, così non sbaglia più mese o giorno.",
            ),
        ),
        ChangeEntry(
            id = 21,
            date = "14 nov 2026",
            title = "PDF dal menu Condividi",
            items = listOf(
                "Prisma ora compare nel menu Condividi anche per i PDF: dal file manager, da Drive o da WhatsApp scegli Prisma, poi la sezione, e il PDF resta allegato come con \"Da file\".",
            ),
        ),
        ChangeEntry(
            id = 20,
            date = "14 nov 2026",
            title = "Archivio schede",
            items = listOf(
                "Nel \"+\" c'è \"Archivio schede\": con l'interruttore acceso, un PDF con i DATI SCHEDA in fondo viene salvato sul telefono (una richiesta per scheda) e l'AI risponde usando solo le schede salvate.",
                "In alto, accanto a Chat, compare l'icona cartella: apre l'archivio. Toccando una scheda si apre il PDF salvato, con le immagini (o \"Apri con…\" per un'altra app).",
                "Il PDF originale resta salvato sul telefono. L'archivio è per sezione e resta solo su questo telefono.",
            ),
        ),
        ChangeEntry(
            id = 19,
            date = "14 nov 2026",
            title = "Allega documenti",
            items = listOf(
                "Nel \"+\" c'è la nuova voce \"Da file\": puoi allegare un PDF (fino a 15 MB) o un file di testo (txt, csv, md, json) e chiedere all'AI di leggerlo, riassumerlo o spiegartelo.",
                "Il file resta in memoria solo finché l'app è aperta; nella chat salvata rimane il nome. Word ed Excel vanno prima salvati come PDF.",
            ),
        ),
        ChangeEntry(
            id = 18,
            date = "14 nov 2026",
            title = "Schede, spesa, Bring e impostazioni rinnovate",
            items = listOf(
                "Scheda vuota: descrizione e suggerimenti rapidi come schede grandi sopra il campo; i suggerimenti dopo la risposta vanno su due righe. Foto, scanner e voce restano nel \"+\".",
                "Risposta: ogni proposta ha la sua scheda (oltre 5, carosello), con tempo in pillola, \"Ingredienti\" e \"Manca\" a colori e \"Passaggi\" richiudibili. Alla lista, Cosa ci cucino?, Copia e Condividi stanno in una barra fissa sotto la risposta.",
                "Lista della spesa: reparti con icona e contatore, lista Bring di destinazione accanto al reparto, swipe a destra/sinistra per cambiare reparto, \"Presi\" richiudibile; Bring è un tasto con icona accanto a Cosa ci cucino?.",
                "Manda a Bring: \"Tutto a…\" per mandare ogni reparto alla stessa lista, anteprima prodotti su 2 righe e, dopo l'invio, una conferma con \"Apri Bring\".",
                "Impostazioni in 5 gruppi (AI, Sincronizzazione, Bring, Aspetto, Altro) con lo stato della chiave API e le liste Bring per reparto.",
                "Cronologia: emoji e colore della scheda, filtri per scheda, chat raggruppate per data, swipe per eliminare con Annulla.",
                "Nuova sezione: tre schede grandi (Crea con AI, Libreria, Incolla); \"Crea con AI\" parte da un solo campo e la libreria mostra l'anteprima prima di aggiungere.",
            ),
        ),
        ChangeEntry(
            id = 17,
            date = "14 nov 2026",
            title = "Nuova Home con barra in basso",
            items = listOf(
                "In basso c'è la barra con Home, Spesa, Cronologia e Impostazioni: non servono più le icone in alto.",
                "La testata è più compatta (logo, titolo, Novità e vista griglia/lista) e la ricerca è sempre visibile sotto il titolo.",
                "Le schede in griglia mostrano solo icona e titolo; il pulsante per creare una sezione è un semplice \"+\".",
            ),
        ),
        ChangeEntry(
            id = 16,
            date = "14 nov 2026",
            title = "Bring: scegli la lista",
            items = listOf(
                "Il tasto \"Bring\" ora mostra le tue liste di Bring e, per ogni reparto della spesa (es. Carne e pesce, Casa e igiene), ti fa scegliere la lista di destinazione (es. Macelleria, Eurospin, Maury's) oppure \"Non mandare\". Le scelte restano salvate per la volta dopo.",
                "Reparto automatico: i prodotti che scrivi a mano nella lista della spesa (es. \"Tagliata manzo\") vengono assegnati al reparto giusto dall'AI, così vanno alla lista Bring giusta. Puoi sempre cambiarlo toccando il prodotto.",
            ),
        ),
        ChangeEntry(
            id = 15,
            date = "14 nov 2026",
            title = "Recenti più ordinate",
            items = listOf(
                "Le schede recenti in Home sono più compatte e sfumano sul bordo destro invece di essere tagliate; il tasto griglia/lista è più piccolo.",
            ),
        ),
        ChangeEntry(
            id = 14,
            date = "14 nov 2026",
            title = "Colore della categoria a scelta",
            items = listOf(
                "\"Cambia colore\" nel menu di una categoria ora mostra 8 colori tra cui scegliere, invece di farli girare uno alla volta.",
            ),
        ),
        ChangeEntry(
            id = 13,
            date = "14 nov 2026",
            title = "Lista della spesa verso Bring!",
            items = listOf(
                "Nella lista della spesa, tasto \"Bring\": manda in un tocco i prodotti ancora da comprare alla lista predefinita di Bring!. La prima volta chiede email e password di Bring (se entri con Google o Apple, creala da Profilo > Altre impostazioni > Cambia password).",
            ),
        ),
        ChangeEntry(
            id = 12,
            date = "14 nov 2026",
            title = "Vista lista, Recenti e ritocchi grafici",
            items = listOf(
                "In Home, in alto a destra sotto il titolo: tasto per passare da griglia a lista compatta (si ricorda la scelta).",
                "Riga \"Recenti\" con le ultime 3 schede aperte, per riaprirle in un tocco.",
                "Nella scheda il titolo non va più a capo né viene tagliato: sta su una riga e si adatta alla larghezza.",
                "\"Nuova chat\" ora è un'icona, così resta più spazio per il titolo.",
                "Le risposte lunghe sfumano in fondo invece di essere tagliate di netto.",
            ),
        ),
        ChangeEntry(
            id = 11,
            date = "13 nov 2026",
            title = "Home più comoda: ricerca, colori, condivisione",
            items = listOf(
                "Cerca in Home (lente in alto): filtra le schede per nome, categoria o prompt mentre scrivi.",
                "Ogni categoria ha il suo colore (si cambia dai tre puntini del titolo).",
                "Tenendo premuta una scheda: Condividi (manda la scheda a un altro telefono; chi la riceve la condivide verso Prisma o la copia e usa Nuova sezione > Incolla scheda) e Aggiungi alla Home (icona sulla schermata di Android che apre subito la scheda).",
                "Elimina non chiede più conferma: compare \"Annulla\" per qualche secondo e la scheda torna com'era, con la sua chat.",
            ),
        ),
        ChangeEntry(
            id = 10,
            date = "13 nov 2026",
            title = "Categorie per le schede",
            items = listOf(
                "Crea o modifica una scheda e scrivi (o scegli) una categoria: in Home le schede si raggruppano sotto il suo titolo.",
                "Tocca il titolo di una categoria per chiuderla o aprirla; con i tre puntini la rinomini, la sposti su o giù, o la togli (le schede restano).",
                "Il riordino con tenuta + trascinamento funziona dentro ogni categoria; per cambiare categoria usa Modifica.",
                "Le categorie si sincronizzano e rientrano nel backup.",
            ),
        ),
        ChangeEntry(
            id = 9,
            date = "13 nov 2026",
            title = "Ordina le schede come vuoi",
            items = listOf(
                "Tieni premuta una scheda in Home e trascinala dove vuoi: l'ordine resta salvato e si sincronizza.",
                "Le schede fissate (pin) restano in cima: si riordinano tra loro.",
                "Se tieni premuto e rilasci senza muoverti, esce ancora il menu Modifica / Elimina.",
            ),
        ),
        ChangeEntry(
            id = 8,
            date = "13 nov 2026",
            title = "Lista più completa, cronologia, widget e tema chiaro",
            items = listOf(
                "Lista della spesa per reparti: l'AI assegna il reparto ai prodotti (e la quantità, se la indica). Tocca un prodotto per cambiare nome, quantità o reparto.",
                "Condividi la lista (icona in alto) e \"Cosa ci cucino?\": manda i prodotti a FRIGO per avere ricette.",
                "Ricomprare: i prodotti che prendi più spesso compaiono come suggerimenti da aggiungere con un tocco.",
                "I prodotti arrivati da un altro dispositivo restano evidenziati per qualche secondo.",
                "Se la sincronizzazione non riesce compare un'icona in Home: toccala per riprovare.",
                "\"Su di me\" si può sincronizzare con l'account Google (opzione spenta di default, Impostazioni).",
                "Sezioni nuove: DOCUMENTI, VIAGGIO e VIDEO. Libreria di sezioni pronte (Traduttore, Scrivere, Studio, Allenamento, Piante, Foto, Contratti) dal pulsante Nuova sezione.",
                "Cronologia (icona in Home): le chat messe da parte con \"Nuova chat\", con ricerca in tutto il testo e possibilità di riaprirle.",
                "Backup e ripristino in un file (Impostazioni > Backup).",
                "Widget con la lista della spesa per la Home di Android e scorciatoie tenendo premuta l'icona (Lista, Spesa con foto, Scansiona codice).",
                "Tema chiaro, scuro o automatico (Impostazioni > Aspetto).",
            ),
        ),
        ChangeEntry(
            id = 7,
            date = "13 nov 2026",
            title = "\"Alla lista\" solo quando serve",
            items = listOf(
                "Il tasto \"Alla lista\" compare solo se l'AI riconosce prodotti concreti da comprare: non per meteo, calcoli, pacchi in arrivo o cose già acquistate.",
                "I nomi arrivano già puliti dall'AI (es. \"Yogurt greco\"), senza spiegazioni attaccate.",
                "Le chat salvate prima di questa versione non mostrano il tasto: vale per le risposte nuove.",
            ),
        ),
        ChangeEntry(
            id = 6,
            date = "13 nov 2026",
            title = "Sincronizzazione automatica",
            items = listOf(
                "Con la lista della spesa aperta, i prodotti nuovi aggiunti sugli altri dispositivi arrivano da soli (controllo ogni 20 secondi).",
                "Tirando giù la lista si forza subito la sincronizzazione.",
                "Quando riapri l'app si sincronizza in automatico.",
            ),
        ),
        ChangeEntry(
            id = 5,
            date = "13 nov 2026",
            title = "Lista della spesa sincronizzata",
            items = listOf(
                "La lista della spesa ora si sincronizza con l'account Google, come le sezioni: telefono e tablet vedono gli stessi prodotti.",
                "Spunte ed eliminazioni arrivano sugli altri dispositivi; se modifichi lo stesso prodotto in due posti vince l'ultima modifica.",
                "Aprendo la lista si scaricano subito le novità. Serve la versione nuova su tutti i dispositivi.",
            ),
        ),
        ChangeEntry(
            id = 4,
            date = "13 nov 2026",
            title = "Lista della spesa, suggerimenti rapidi, modelli di riserva",
            items = listOf(
                "Lista della spesa (icona carrello in Home): spunti i prodotti, li togli, ne scrivi di nuovi.",
                "Sotto ogni risposta c'è \"Alla lista\": scegli quali prodotti dell'elenco aggiungere.",
                "Suggerimenti rapidi sotto il campo di testo (Più proteine, Meno zuccheri, Solo 15 minuti...): tocchi e si scrive da solo.",
                "Confronta i prodotti: scansiona due codici a barre di fila e tocca il suggerimento.",
                "Lunghezza delle risposte (Breve, Normale, Dettagliata) nelle Impostazioni.",
                "Cambia modello da solo: se quello scelto non risponde o ha finito le richieste, Prisma ne prova un altro gratuito.",
                "Contatore delle richieste fatte oggi, nelle Impostazioni.",
            ),
        ),
        ChangeEntry(
            id = 3,
            date = "13 nov 2026",
            title = "Su di me, condivisione e codice a barre",
            items = listOf(
                "Pulsante Novità (questa pagina), con il pallino quando c'è qualcosa di nuovo.",
                "Su di me (Impostazioni): obiettivi, allergie e preferenze vengono aggiunti a ogni richiesta, così le risposte sono su misura.",
                "Prisma compare nel menu Condividi di Android: dalla Galleria, da Chrome o da WhatsApp mandi foto o testo e scegli la sezione.",
                "Scanner codice a barre (menu +): inquadri il prodotto e Prisma carica nome, ingredienti e valori nutrizionali da Open Food Facts, pronti da analizzare.",
            ),
        ),
        ChangeEntry(
            id = 2,
            date = "",
            title = "Prisma",
            items = listOf(
                "Nuovo nome, logo e grafica Material 3 scura, con colori dinamici opzionali.",
                "Sezioni modificabili, eliminabili e fissabili in alto; icona proposta dall'AI.",
                "Chat di approfondimento salvata per ogni sezione, risposte formattate, link toccabili.",
                "Dettatura vocale, copia e condivisione delle risposte.",
                "Accesso con Google e sincronizzazione delle sezioni.",
            ),
        ),
        ChangeEntry(
            id = 1,
            date = "11 nov 2026",
            title = "Prima versione",
            items = listOf(
                "Sezioni SPESA, ETICHETTA, FRIGO e LIBERO con prompt già pronti.",
                "Intelligenza artificiale Gemini con chiave gratuita inserita nelle Impostazioni.",
                "Aggiornamenti automatici dalle release di GitHub.",
            ),
        ),
    )

    val latestId: Int get() = entries.first().id
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChangelogScreen(onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text("Novità", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 8.dp, 16.dp, 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Text(
                    "Versione installata: ${AppInfo.full}",
                    fontSize = 13.sp,
                    color = cs.onSurfaceVariant,
                )
            }
            itemsIndexed(Changelog.entries) { index, e ->
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (index == 0) cs.primaryContainer else cs.surfaceContainer,
                        contentColor = if (index == 0) cs.onPrimaryContainer else cs.onSurface,
                    ),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(e.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        if (e.date.isNotBlank()) {
                            Text(e.date, fontSize = 12.sp, color = cs.onSurfaceVariant)
                        }
                        Spacer(Modifier.height(2.dp))
                        e.items.forEach { line ->
                            Row {
                                Text("•", modifier = Modifier.width(18.dp))
                                Text(line, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }
    }
}
