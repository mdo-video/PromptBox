package com.promptbox

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Una voce del changelog. [id] cresce a ogni voce nuova: serve a mostrare il pallino "novità" in Home. */
data class ChangeEntry(val id: Int, val date: String, val title: String, val items: List<String>)

/**
 * Il changelog vive nel codice, così si legge anche offline.
 * Per aggiungere una novità: nuova voce IN CIMA alla lista, con [id] più alto di tutti.
 */
object Changelog {
    val entries = listOf(
        ChangeEntry(
            id = 16,
            date = "14 nov 2026",
            title = "Bring: scegli la lista",
            items = listOf(
                "Il tasto \"Bring\" ora mostra le tue liste di Bring e, per ogni reparto della spesa (es. Carne e pesce, Casa e igiene), ti fa scegliere la lista di destinazione (es. Macelleria, Eurospin, Maury's) oppure \"Non mandare\". Le scelte restano salvate per la volta dopo.",
            ),
        ),
        ChangeEntry(
            id = 15,
            date = "14 nov 2026",
            title = "Recenti più ordinate",
            items = listOf(
                "Le schede recenti in Home sono più compatte e sfumano sul bordo destro invece di essere tagliate; il tasto griglia/lista è più piccolo.",
            ),
        ),
        ChangeEntry(
            id = 14,
            date = "14 nov 2026",
            title = "Colore della categoria a scelta",
            items = listOf(
                "\"Cambia colore\" nel menu di una categoria ora mostra 8 colori tra cui scegliere, invece di farli girare uno alla volta.",
            ),
        ),
        ChangeEntry(
            id = 13,
            date = "14 nov 2026",
            title = "Lista della spesa verso Bring!",
            items = listOf(
                "Nella lista della spesa, tasto \"Bring\": manda in un tocco i prodotti ancora da comprare alla lista predefinita di Bring!. La prima volta chiede email e password di Bring (se entri con Google o Apple, creala da Profilo > Altre impostazioni > Cambia password).",
            ),
        ),
        ChangeEntry(
            id = 12,
            date = "14 nov 2026",
            title = "Vista lista, Recenti e ritocchi grafici",
            items = listOf(
                "In Home, in alto a destra sotto il titolo: tasto per passare da griglia a lista compatta (si ricorda la scelta).",
                "Riga \"Recenti\" con le ultime 3 schede aperte, per riaprirle in un tocco.",
                "Nella scheda il titolo non va più a capo né viene tagliato: sta su una riga e si adatta alla larghezza.",
                "\"Nuova chat\" ora è un'icona, così resta più spazio per il titolo.",
                "Le risposte lunghe sfumano in fondo invece di essere tagliate di netto.",
            ),
        ),
        ChangeEntry(
            id = 11,
            date = "13 nov 2026",
            title = "Home più comoda: ricerca, colori, condivisione",
            items = listOf(
                "Cerca in Home (lente in alto): filtra le schede per nome, categoria o prompt mentre scrivi.",
                "Ogni categoria ha il suo colore (si cambia dai tre puntini del titolo).",
                "Tenendo premuta una scheda: Condividi (manda la scheda a un altro telefono; chi la riceve la condivide verso Prisma o la copia e usa Nuova sezione > Incolla scheda) e Aggiungi alla Home (icona sulla schermata di Android che apre subito la scheda).",
                "Elimina non chiede più conferma: compare \"Annulla\" per qualche secondo e la scheda torna com'era, con la sua chat.",
            ),
        ),
        ChangeEntry(
            id = 10,
            date = "13 nov 2026",
            title = "Categorie per le schede",
            items = listOf(
                "Crea o modifica una scheda e scrivi (o scegli) una categoria: in Home le schede si raggruppano sotto il suo titolo.",
                "Tocca il titolo di una categoria per chiuderla o aprirla; con i tre puntini la rinomini, la sposti su o giù, o la togli (le schede restano).",
                "Il riordino con tenuta + trascinamento funziona dentro ogni categoria; per cambiare categoria usa Modifica.",
                "Le categorie si sincronizzano e rientrano nel backup.",
            ),
        ),
        ChangeEntry(
            id = 9,
            date = "13 nov 2026",
            title = "Ordina le schede come vuoi",
            items = listOf(
                "Tieni premuta una scheda in Home e trascinala dove vuoi: l'ordine resta salvato e si sincronizza.",
                "Le schede fissate (pin) restano in cima: si riordinano tra loro.",
                "Se tieni premuto e rilasci senza muoverti, esce ancora il menu Modifica / Elimina.",
            ),
        ),
        ChangeEntry(
            id = 8,
            date = "13 nov 2026",
            title = "Lista più completa, cronologia, widget e tema chiaro",
            items = listOf(
                "Lista della spesa per reparti: l'AI assegna il reparto ai prodotti (e la quantità, se la indica). Tocca un prodotto per cambiare nome, quantità o reparto.",
                "Condividi la lista (icona in alto) e \"Cosa ci cucino?\": manda i prodotti a FRIGO per avere ricette.",
                "Ricomprare: i prodotti che prendi più spesso compaiono come suggerimenti da aggiungere con un tocco.",
                "I prodotti arrivati da un altro dispositivo restano evidenziati per qualche secondo.",
                "Se la sincronizzazione non riesce compare un'icona in Home: toccala per riprovare.",
                "\"Su di me\" si può sincronizzare con l'account Google (opzione spenta di default, Impostazioni).",
                "Sezioni nuove: DOCUMENTI, VIAGGIO e VIDEO. Libreria di sezioni pronte (Traduttore, Scrivere, Studio, Allenamento, Piante, Foto, Contratti) dal pulsante Nuova sezione.",
                "Cronologia (icona in Home): le chat messe da parte con \"Nuova chat\", con ricerca in tutto il testo e possibilità di riaprirle.",
                "Backup e ripristino in un file (Impostazioni > Backup).",
                "Widget con la lista della spesa per la Home di Android e scorciatoie tenendo premuta l'icona (Lista, Spesa con foto, Scansiona codice).",
                "Tema chiaro, scuro o automatico (Impostazioni > Aspetto).",
            ),
        ),
        ChangeEntry(
            id = 7,
            date = "13 nov 2026",
            title = "\"Alla lista\" solo quando serve",
            items = listOf(
                "Il tasto \"Alla lista\" compare solo se l'AI riconosce prodotti concreti da comprare: non per meteo, calcoli, pacchi in arrivo o cose già acquistate.",
                "I nomi arrivano già puliti dall'AI (es. \"Yogurt greco\"), senza spiegazioni attaccate.",
                "Le chat salvate prima di questa versione non mostrano il tasto: vale per le risposte nuove.",
            ),
        ),
        ChangeEntry(
            id = 6,
            date = "13 nov 2026",
            title = "Sincronizzazione automatica",
            items = listOf(
                "Con la lista della spesa aperta, i prodotti nuovi aggiunti sugli altri dispositivi arrivano da soli (controllo ogni 20 secondi).",
                "Tirando giù la lista si forza subito la sincronizzazione.",
                "Quando riapri l'app si sincronizza in automatico.",
            ),
        ),
        ChangeEntry(
            id = 5,
            date = "13 nov 2026",
            title = "Lista della spesa sincronizzata",
            items = listOf(
                "La lista della spesa ora si sincronizza con l'account Google, come le sezioni: telefono e tablet vedono gli stessi prodotti.",
                "Spunte ed eliminazioni arrivano sugli altri dispositivi; se modifichi lo stesso prodotto in due posti vince l'ultima modifica.",
                "Aprendo la lista si scaricano subito le novità. Serve la versione nuova su tutti i dispositivi.",
            ),
        ),
        ChangeEntry(
            id = 4,
            date = "13 nov 2026",
            title = "Lista della spesa, suggerimenti rapidi, modelli di riserva",
            items = listOf(
                "Lista della spesa (icona carrello in Home): spunti i prodotti, li togli, ne scrivi di nuovi.",
                "Sotto ogni risposta c'è \"Alla lista\": scegli quali prodotti dell'elenco aggiungere.",
                "Suggerimenti rapidi sotto il campo di testo (Più proteine, Meno zuccheri, Solo 15 minuti...): tocchi e si scrive da solo.",
                "Confronta i prodotti: scansiona due codici a barre di fila e tocca il suggerimento.",
                "Lunghezza delle risposte (Breve, Normale, Dettagliata) nelle Impostazioni.",
                "Cambia modello da solo: se quello scelto non risponde o ha finito le richieste, Prisma ne prova un altro gratuito.",
                "Contatore delle richieste fatte oggi, nelle Impostazioni.",
            ),
        ),
        ChangeEntry(
            id = 3,
            date = "13 nov 2026",
            title = "Su di me, condivisione e codice a barre",
            items = listOf(
                "Pulsante Novità (questa pagina), con il pallino quando c'è qualcosa di nuovo.",
                "Su di me (Impostazioni): obiettivi, allergie e preferenze vengono aggiunti a ogni richiesta, così le risposte sono su misura.",
                "Prisma compare nel menu Condividi di Android: dalla Galleria, da Chrome o da WhatsApp mandi foto o testo e scegli la sezione.",
                "Scanner codice a barre (menu +): inquadri il prodotto e Prisma carica nome, ingredienti e valori nutrizionali da Open Food Facts, pronti da analizzare.",
            ),
        ),
        ChangeEntry(
            id = 2,
            date = "",
            title = "Prisma",
            items = listOf(
                "Nuovo nome, logo e grafica Material 3 scura, con colori dinamici opzionali.",
                "Sezioni modificabili, eliminabili e fissabili in alto; icona proposta dall'AI.",
                "Chat di approfondimento salvata per ogni sezione, risposte formattate, link toccabili.",
                "Dettatura vocale, copia e condivisione delle risposte.",
                "Accesso con Google e sincronizzazione delle sezioni.",
            ),
        ),
        ChangeEntry(
            id = 1,
            date = "11 nov 2026",
            title = "Prima versione",
            items = listOf(
                "Sezioni SPESA, ETICHETTA, FRIGO e LIBERO con prompt già pronti.",
                "Intelligenza artificiale Gemini con chiave gratuita inserita nelle Impostazioni.",
                "Aggiornamenti automatici dalle release di GitHub.",
            ),
        ),
    )

    val latestId: Int get() = entries.first().id
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChangelogScreen(onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text("Novità", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 8.dp, 16.dp, 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Text(
                    "Versione installata: ${BuildConfig.VERSION_NAME}",
                    fontSize = 13.sp,
                    color = cs.onSurfaceVariant,
                )
            }
            itemsIndexed(Changelog.entries) { index, e ->
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (index == 0) cs.primaryContainer else cs.surfaceContainer,
                        contentColor = if (index == 0) cs.onPrimaryContainer else cs.onSurface,
                    ),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(e.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        if (e.date.isNotBlank()) {
                            Text(e.date, fontSize = 12.sp, color = cs.onSurfaceVariant)
                        }
                        Spacer(Modifier.height(2.dp))
                        e.items.forEach { line ->
                            Row {
                                Text("•", modifier = Modifier.width(18.dp))
                                Text(line, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }
    }
}
