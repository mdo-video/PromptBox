package com.promptbox

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/** Aria lasciata tra il bordo alto del foglio e la barra di stato (o il foro della fotocamera). */
private val SHEET_TOP_GAP = 16.dp

/** La maniglia in cima al foglio (22 dp sopra e sotto una barretta di 4 dp). */
private val SHEET_HANDLE = 48.dp

/**
 * Il foglio dal basso di Prisma: come [ModalBottomSheet], ma con un'altezza massima fissa, cioè lo schermo meno la barra di stato
 * e un po' d'aria. Così un foglio lungo (es. "Nuovo prodotto") non sale mai fin sotto la barra di stato, dove la maniglia finiva
 * in mezzo alla fotocamera; il contenuto che non ci sta scorre (le schede dei fogli hanno già `verticalScroll`).
 *
 * La barra di stato si legge dalla finestra dell'app e non da quella del foglio: lì, a tutto schermo, risulta 0.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrismaSheet(
    onDismissRequest: () -> Unit,
    sheetState: SheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    containerColor: Color = MaterialTheme.colorScheme.surfaceContainerHigh,
    content: @Composable ColumnScope.() -> Unit,
) {
    val view = LocalView.current
    val density = LocalDensity.current
    val topPx = ViewCompat.getRootWindowInsets(view)
        ?.getInsets(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.displayCutout())?.top ?: 0
    val windowPx = view.rootView.height
    val maxContent = with(density) { (windowPx - topPx).toDp() } - SHEET_TOP_GAP - SHEET_HANDLE
    ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        sheetState = sheetState,
        containerColor = containerColor,
    ) {
        Column(Modifier.heightIn(max = maxContent.coerceAtLeast(240.dp))) { content() }
    }
}
