package com.promptbox

import org.json.JSONObject

/** Un ripiano proposto dall'AI nel riordino, con i prodotti (id) che ci andrebbero. [isNew] = il ripiano non esiste ancora. */
data class ReorderGroup(val shelf: String, val emoji: String, val isNew: Boolean, val ids: List<String>)

/**
 * "Riordina con AI" per le schede create dall'utente: l'AI guarda tutti i prodotti del posto e li distribuisce nei ripiani,
 * creandone di nuovi (es. "Decorazioni natalizie") dove serve. Prima di applicare si controlla e si corregge.
 */
object PantryReorder {
    private const val PRIMARY_MODEL = "gemini-3.7-flash"
    private const val SECOND_MODEL = "gemini-3.5-flash"
    private const val MAX_ITEMS = 80
    private const val MAX_NEW_SHELVES = 8

    internal fun system(place: String): String {
        val shelves = Pantry.shelves(place).joinToString(", ")
        val where = if (KitchenTabs.isCustom(place)) KitchenTabs.label(place).lowercase() else place
        return "Ti arriva l'elenco numerato dei prodotti che l'utente tiene in: $where. " +
            "Distribuiscili in ripiani per categoria. Ripiani che ci sono già: $shelves. " +
            "Se un prodotto non entra in nessuno, inventa un ripiano nuovo: nome corto (al massimo 3 parole, per esempio \"Decorazioni natalizie\") " +
            "con una sola emoji adatta. Usa \"Altro\" e \"Generale\" solo per ciò che non ha una categoria chiara. " +
            "Non fare più di $MAX_NEW_SHELVES ripiani nuovi e non fare ripiani da un prodotto solo se esiste già un ripiano adatto. " +
            "Rispondi SOLO con un oggetto JSON: {\"ripiani\":[{\"nome\":\"Decorazioni natalizie\",\"emoji\":\"🎄\",\"prodotti\":[1,4]}]}. " +
            "\"prodotti\" = i numeri dell'elenco. Ogni numero in un solo ripiano. Non inventare prodotti."
    }

    internal fun userText(items: List<PantryItem>): String =
        items.take(MAX_ITEMS).mapIndexed { i, it -> "${i + 1}. ${it.name}" }.joinToString("\n")

    private fun jsonObject(raw: String): JSONObject {
        val clean = raw.replace("```json", "").replace("```", "").trim()
        val a = clean.indexOf('{')
        val b = clean.lastIndexOf('}')
        require(a >= 0 && b > a) { "Non riesco a leggere la risposta dell'AI. Riprova." }
        return JSONObject(clean.substring(a, b + 1))
    }

    /** Dalla risposta dell'AI ai soli spostamenti: i prodotti che sono già nel ripiano giusto non compaiono. */
    internal fun parse(raw: String, items: List<PantryItem>, shelves: List<String>): List<ReorderGroup> {
        val list = items.take(MAX_ITEMS)
        val arr = jsonObject(raw).optJSONArray("ripiani") ?: throw IllegalArgumentException("Non riesco a leggere la risposta dell'AI. Riprova.")
        val used = mutableSetOf<Int>()
        val newNames = mutableListOf<String>()
        val out = mutableListOf<ReorderGroup>()
        for (g in 0 until arr.length()) {
            val o = arr.optJSONObject(g) ?: continue
            val raw0 = if (o.isNull("nome")) "" else o.optString("nome")
            val name = raw0.trim().replace(Regex("\\s+"), " ")
            if (name.isEmpty() || name.length > 30 || name.split(' ').size > 4) continue
            val existing = shelves.firstOrNull { it.equals(name, ignoreCase = true) }
            val shelf = existing ?: name.replaceFirstChar { it.uppercase() }
            if (existing == null && newNames.none { it.equals(shelf, ignoreCase = true) }) {
                if (newNames.size >= MAX_NEW_SHELVES) continue
                newNames += shelf
            }
            val emoji = (if (o.isNull("emoji")) "" else o.optString("emoji")).trim().takeIf { it.isNotEmpty() && it.length <= 8 } ?: "📦"
            val nums = o.optJSONArray("prodotti") ?: continue
            val ids = (0 until nums.length())
                .map { nums.optInt(it, -1) - 1 }
                .filter { it in list.indices && used.add(it) }
                .map { list[it] }
                .filter { !it.shelf.equals(shelf, ignoreCase = true) }
                .map { it.id }
            if (ids.isEmpty()) continue
            out += ReorderGroup(shelf, emoji, existing == null, ids)
        }
        // Lo stesso ripiano nuovo ripetuto dall'AI si unisce in uno solo.
        return out.groupBy { it.shelf.lowercase() }.values.map { g ->
            ReorderGroup(g.first().shelf, g.first().emoji, g.first().isNew, g.flatMap { it.ids })
        }
    }

    /** I prodotti con il nuovo ripiano (solo quelli non esclusi dall'utente). */
    fun apply(items: List<PantryItem>, groups: List<ReorderGroup>, skipped: Set<String> = emptySet()): List<PantryItem> {
        val target = mutableMapOf<String, String>()
        groups.forEach { g -> g.ids.filter { it !in skipped }.forEach { target[it] = g.shelf } }
        return items.map { i -> target[i.id]?.let { i.copy(shelf = it) } ?: i }
    }

    suspend fun propose(store: Store, place: String, items: List<PantryItem>): Result<List<ReorderGroup>> {
        if (store.apiKey.isBlank()) return Result.failure(RuntimeException("Per riordinare serve la chiave API nelle Impostazioni."))
        val models = listOf(PRIMARY_MODEL, SECOND_MODEL, store.model).distinct()
        val shelves = Pantry.shelves(place)
        return GeminiClient.askJson(store.apiKey, models, system(place), userText(items), null, maxTokens = 3072)
            .mapCatching { parse(it, items, shelves) }
            .onSuccess { store.countRequest() }
    }
}
