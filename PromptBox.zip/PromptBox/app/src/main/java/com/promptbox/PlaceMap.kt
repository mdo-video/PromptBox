package com.promptbox

import org.json.JSONArray
import org.json.JSONObject

/**
 * Il riquadro di un ripiano nella piantina di un posto. Le misure sono frazioni della piantina (da 0 a 1): così
 * la stessa piantina si vede uguale su qualsiasi schermo e non dipende dai pixel.
 */
data class PlanBox(val shelf: String, val x: Float, val y: Float, val w: Float, val h: Float) {
    fun toJson(): JSONObject = JSONObject().put("n", shelf).put("x", x.toDouble()).put("y", y.toDouble()).put("w", w.toDouble()).put("h", h.toDouble())

    companion object {
        fun parse(o: JSONObject): PlanBox? {
            val n = o.optString("n").trim()
            if (n.isEmpty() || !o.has("x") || !o.has("y") || !o.has("w") || !o.has("h")) return null
            val b = PlanBox(n, o.optDouble("x").toFloat(), o.optDouble("y").toFloat(), o.optDouble("w").toFloat(), o.optDouble("h").toFloat())
            if (listOf(b.x, b.y, b.w, b.h).any { it.isNaN() || it.isInfinite() }) return null
            return PlaceMap.clamp(b)
        }

        fun parseAll(a: JSONArray?): List<PlanBox> =
            if (a == null) emptyList() else (0 until a.length()).mapNotNull { a.optJSONObject(it)?.let(::parse) }.distinctBy { it.shelf }
    }
}

/** Un ripiano di un posto, con quanti prodotti ci sono: serve a decidere cosa disegnare. */
data class PlanShelf(val name: String, val emoji: String, val count: Int)

/** Un riquadro pronto da disegnare. */
data class PlanZone(val box: PlanBox, val emoji: String, val count: Int)

/**
 * La piantina di un posto (es. un Garage): ogni ripiano con dei prodotti è un riquadro, e compare da solo man mano che
 * si aggiungono cose. I riquadri nuovi si mettono nel primo spazio libero; l'utente li sposta e li ingrandisce a mano.
 */
object PlaceMap {
    const val DEF_W = 0.44f
    const val DEF_H = 0.24f
    const val MIN_W = 0.2f
    const val MIN_H = 0.14f
    private const val GAP = 0.02f
    private const val STEP = 0.02f

    /** Tiene il riquadro dentro la piantina e non più piccolo del minimo. */
    fun clamp(b: PlanBox): PlanBox {
        val w = b.w.coerceIn(MIN_W, 1f)
        val h = b.h.coerceIn(MIN_H, 1f)
        return b.copy(w = w, h = h, x = b.x.coerceIn(0f, 1f - w), y = b.y.coerceIn(0f, 1f - h))
    }

    fun move(b: PlanBox, dx: Float, dy: Float): PlanBox = clamp(b.copy(x = b.x + dx, y = b.y + dy))

    /** Ingrandisce o rimpicciolisce dall'angolo in basso a destra, senza uscire dalla piantina. */
    fun resize(b: PlanBox, dw: Float, dh: Float): PlanBox {
        val maxW = maxOf(MIN_W, 1f - b.x)
        val maxH = maxOf(MIN_H, 1f - b.y)
        return clamp(b.copy(w = (b.w + dw).coerceIn(MIN_W, maxW), h = (b.h + dh).coerceIn(MIN_H, maxH)))
    }

    private fun overlaps(a: PlanBox, b: PlanBox, gap: Float): Boolean =
        a.x < b.x + b.w + gap && b.x < a.x + a.w + gap && a.y < b.y + b.h + gap && b.y < a.y + a.h + gap

    /** Il primo posto libero, da sinistra a destra e dall'alto in basso. Se la piantina è piena va in alto a sinistra, sopra gli altri. */
    private fun firstFree(shelf: String, others: List<PlanBox>): PlanBox {
        var y = 0f
        while (y <= 1f - DEF_H + 0.0001f) {
            var x = 0f
            while (x <= 1f - DEF_W + 0.0001f) {
                val c = PlanBox(shelf, x, y, DEF_W, DEF_H)
                if (others.none { overlaps(c, it, GAP) }) return c
                x += STEP
            }
            y += STEP
        }
        return PlanBox(shelf, 0f, 0f, DEF_W, DEF_H)
    }

    /** Un riquadro per ogni ripiano di [shelves], nello stesso ordine: quelli già salvati restano dove sono, gli altri trovano posto. */
    fun layout(shelves: List<String>, saved: List<PlanBox>): List<PlanBox> {
        val placed = ArrayList<PlanBox>()
        saved.filter { it.shelf in shelves }.distinctBy { it.shelf }.forEach { placed += clamp(it) }
        shelves.filter { s -> placed.none { it.shelf == s } }.forEach { s -> placed += firstFree(s, placed) }
        return shelves.map { s -> placed.first { it.shelf == s } }
    }

    /** I riquadri da disegnare: i ripiani con prodotti, più quelli che l'utente ha già posizionato anche se ora sono vuoti. */
    fun zones(shelves: List<PlanShelf>, saved: List<PlanBox>): List<PlanZone> {
        val visible = shelves.filter { s -> s.count > 0 || saved.any { it.shelf == s.name } }
        val boxes = layout(visible.map { it.name }, saved)
        return visible.mapIndexed { i, s -> PlanZone(boxes[i], s.emoji, s.count) }
    }

    /**
     * La piantina da salvare dopo che l'utente ha mosso [moved]: si salvano tutti i riquadri di adesso (così gli altri non
     * si spostano da soli quando ne arrivano di nuovi) e si tengono quelli salvati di ripiani ora nascosti.
     */
    fun commit(saved: List<PlanBox>, current: List<PlanBox>, moved: PlanBox): List<PlanBox> {
        val now = current.map { if (it.shelf == moved.shelf) clamp(moved) else it }
        return now + saved.filter { s -> now.none { it.shelf == s.shelf } }
    }
}
