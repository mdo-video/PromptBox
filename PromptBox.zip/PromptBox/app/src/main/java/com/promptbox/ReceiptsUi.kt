package com.promptbox

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.TextStyle
import java.util.Locale

private fun monthOf(at: Long): YearMonth = YearMonth.from(Instant.ofEpochMilli(at).atZone(ZoneId.systemDefault()))

private data class TopItem(val name: String, val count: Int, val sum: Double)

/** Scontrini fotografati e statistiche di spesa. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReceiptsScreen(
    store: Store,
    receipts: List<Receipt>,
    onChange: (List<Receipt>) -> Unit,
    onBack: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by rememberSaveable { mutableStateOf("stats") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var detail by remember { mutableStateOf<Receipt?>(null) }
    var pendingUri by remember { mutableStateOf<Uri?>(null) }

    fun process(uri: Uri) {
        scope.launch {
            busy = true
            error = null
            val bmp = withContext(Dispatchers.IO) { ImageUtils.load(context, uri, maxSide = 2000) }
            if (bmp == null) {
                error = "Non riesco ad aprire la foto."
            } else {
                ReceiptTools.read(store.apiKey, store.model, bmp)
                    .onSuccess { r ->
                        store.countRequest()
                        onChange(listOf(r) + receipts)
                        detail = r
                    }
                    .onFailure { error = it.message ?: "Errore sconosciuto" }
            }
            busy = false
        }
    }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) process(uri)
    }
    val take = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) pendingUri?.let { process(it) }
    }

    fun camera() {
        val dir = File(context.cacheDir, "photos").apply { mkdirs() }
        val file = File.createTempFile("scontrino", ".jpg", dir)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        pendingUri = uri
        take.launch(uri)
    }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text("Scontrini e spese") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { camera() }, enabled = !busy, modifier = Modifier.weight(1f).height(52.dp)) {
                    Icon(Icons.Filled.CameraAlt, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Fotografa")
                }
                FilledTonalButton(
                    onClick = { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    enabled = !busy,
                    modifier = Modifier.weight(1f).height(52.dp),
                ) {
                    Icon(Icons.Filled.PhotoLibrary, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Galleria")
                }
            }
            if (busy) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Leggo lo scontrino…", color = cs.onSurfaceVariant)
                }
            }
            error?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodyMedium) }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = tab == "stats", onClick = { tab = "stats" }, label = { Text("Statistiche") })
                FilterChip(selected = tab == "list", onClick = { tab = "list" }, label = { Text("Scontrini (${receipts.size})") })
            }

            if (receipts.isEmpty()) {
                Text(
                    "Fotografa uno scontrino: l'AI legge prodotti e prezzi, e qui compaiono quanto spendi, dove e cosa compri più spesso.",
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 12.dp),
                )
            } else if (tab == "stats") {
                StatsContent(receipts)
            } else {
                receipts.sortedByDescending { it.at }.forEach { r ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surfaceContainerHigh)
                            .clickable { detail = r }.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                r.shop.ifBlank { "Scontrino" },
                                style = MaterialTheme.typography.bodyLarge,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                ReceiptTools.dateText(r.at) + " · " + r.items.size + " articoli",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant,
                            )
                        }
                        Text(ReceiptTools.euro(r.total), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }

    detail?.let { r ->
        AlertDialog(
            onDismissRequest = { detail = null },
            title = { Text(r.shop.ifBlank { "Scontrino" } + " · " + ReceiptTools.dateText(r.at)) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    r.items.forEach { it2 ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(Depts.icon(it2.dept) + "  " + it2.name, Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.width(8.dp))
                            Text(ReceiptTools.euro(it2.price), color = cs.onSurfaceVariant)
                        }
                    }
                    Text(
                        "Totale " + ReceiptTools.euro(r.total),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
            },
            confirmButton = { TextButton(onClick = { detail = null }) { Text("Chiudi") } },
            dismissButton = {
                TextButton(onClick = {
                    onChange(receipts.filter { it.id != r.id })
                    detail = null
                }) { Text("Elimina", color = cs.error) }
            },
        )
    }
}

@Composable
private fun StatsContent(receipts: List<Receipt>) {
    val cs = MaterialTheme.colorScheme
    val now = YearMonth.now()
    val months = (5 downTo 0).map { now.minusMonths(it.toLong()) }
    val perMonth = months.map { m -> receipts.filter { monthOf(it.at) == m }.sumOf { it.total } }
    val thisMonth = perMonth.last()
    val prevMonth = perMonth[perMonth.size - 2]
    val monthReceipts = receipts.filter { monthOf(it.at) == now }
    val byDept = monthReceipts.flatMap { it.items }
        .groupBy { it.dept }
        .map { (dept, list) -> dept to list.sumOf { it.price } }
        .sortedByDescending { it.second }
    val top = receipts.flatMap { it.items }
        .groupBy { it.name.lowercase().trim() }
        .map { (_, list) -> TopItem(list.first().name, list.size, list.sumOf { it.price }) }
        .sortedWith(compareByDescending<TopItem> { it.count }.thenByDescending { it.sum })
        .take(5)

    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(cs.surfaceContainer).padding(16.dp)) {
        Text("Questo mese", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
        Text(ReceiptTools.euro(thisMonth), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = cs.primary)
        val sub = buildString {
            append(monthReceipts.size).append(if (monthReceipts.size == 1) " scontrino" else " scontrini")
            if (prevMonth > 0.0) {
                val diff = thisMonth - prevMonth
                append(" · ").append(if (diff >= 0) "+" else "−").append(ReceiptTools.euro(kotlin.math.abs(diff))).append(" sul mese scorso")
            }
        }
        Text(sub, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)

        Spacer(Modifier.height(16.dp))
        val maxV = (perMonth.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
        Row(Modifier.fillMaxWidth().height(160.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
            months.forEachIndexed { i, m ->
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                    Text(
                        if (perMonth[i] > 0.0) String.format(Locale.ITALY, "%.0f", perMonth[i]) else "",
                        style = MaterialTheme.typography.labelSmall,
                        color = cs.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(4.dp))
                    Box(
                        Modifier.fillMaxWidth(0.6f)
                            .height((100f * (perMonth[i] / maxV).toFloat()).coerceAtLeast(3f).dp)
                            .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp, bottomStart = 2.dp, bottomEnd = 2.dp))
                            .background(if (i == months.lastIndex) cs.primary else cs.primaryContainer),
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        m.month.getDisplayName(TextStyle.SHORT, Locale.ITALY).replace(".", ""),
                        style = MaterialTheme.typography.labelSmall,
                        color = cs.onSurfaceVariant,
                    )
                }
            }
        }
    }

    if (byDept.isNotEmpty()) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(cs.surfaceContainer).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Dove spendi di più (questo mese)", style = MaterialTheme.typography.titleSmall, color = cs.primary)
            val maxD = byDept.first().second.coerceAtLeast(0.01)
            byDept.forEach { (dept, sum) ->
                Column {
                    Row(Modifier.fillMaxWidth()) {
                        Text(Depts.icon(dept) + "  " + dept, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Text(ReceiptTools.euro(sum), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                    }
                    Spacer(Modifier.height(4.dp))
                    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(cs.surfaceContainerHighest)) {
                        Box(Modifier.fillMaxWidth((sum / maxD).toFloat().coerceIn(0.02f, 1f)).fillMaxHeight().background(cs.primary))
                    }
                }
            }
        }
    }

    if (top.isNotEmpty()) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(cs.surfaceContainer).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Cosa compri più spesso", style = MaterialTheme.typography.titleSmall, color = cs.primary)
            top.forEach { t ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(t.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        t.count.toString() + "× · " + ReceiptTools.euro(t.sum),
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
