package com.promptbox

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.TextButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.NewReleases
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/** Scheda "Nuova versione disponibile" con download e installazione. */
@Composable
fun UpdateCard(info: Updater.Info, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var progress by remember { mutableStateOf<Float?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = cs.tertiaryContainer, contentColor = cs.onTertiaryContainer),
        shape = RoundedCornerShape(24.dp),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.SystemUpdate, null)
                Spacer(Modifier.width(12.dp))
                Text(
                    "Nuova versione disponibile (${info.versionCode})",
                    style = MaterialTheme.typography.titleMedium,
                )
            }
            Spacer(Modifier.height(12.dp))
            Button(
                enabled = progress == null,
                onClick = {
                    message = null
                    progress = 0f
                    scope.launch {
                        Updater.download(context, info) { progress = it }
                            .onSuccess { file ->
                                progress = null
                                message = when (Updater.install(context, file)) {
                                    Updater.InstallResult.NEEDS_PERMISSION ->
                                        "Consenti a Prisma di installare app, poi torna qui e premi di nuovo Aggiorna."
                                    Updater.InstallResult.STARTED -> "Conferma l'installazione nella schermata di Android."
                                }
                            }
                            .onFailure {
                                progress = null
                                message = it.message ?: "Download non riuscito."
                            }
                    }
                },
            ) { Text("Aggiorna ora") }

            progress?.let {
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(progress = { it }, modifier = Modifier.fillMaxWidth())
            }
            message?.let {
                Spacer(Modifier.height(10.dp))
                Text(it, fontSize = 13.sp)
            }
        }
    }
}

/** Scheda per le Impostazioni: versione attuale, controllo manuale e novità. */
@Composable
fun UpdateSection(onChangelog: () -> Unit) {
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var checking by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var upToDate by remember { mutableStateOf(false) }
    var found by remember { mutableStateOf<Updater.Info?>(null) }

    Card(
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(cs.primaryContainer),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.SystemUpdate, contentDescription = null, tint = cs.onPrimaryContainer)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Aggiornamenti", style = MaterialTheme.typography.titleMedium, color = cs.primary)
                    Text(
                        "Da GitHub, in automatico",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                }
                Box(
                    Modifier.clip(RoundedCornerShape(50)).background(cs.secondaryContainer)
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                ) {
                    Text(
                        "v" + BuildConfig.VERSION_NAME,
                        style = MaterialTheme.typography.labelLarge,
                        color = cs.onSecondaryContainer,
                    )
                }
            }

            val newer = found
            if (newer != null) {
                UpdateCard(newer)
            } else if (upToDate) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.primaryContainer.copy(alpha = 0.45f))
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = cs.primary)
                    Spacer(Modifier.width(10.dp))
                    Text("Sei già all'ultima versione.", style = MaterialTheme.typography.bodyMedium)
                }
            } else if (error != null) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.errorContainer)
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = cs.onErrorContainer)
                    Spacer(Modifier.width(10.dp))
                    Text(error.orEmpty(), style = MaterialTheme.typography.bodyMedium, color = cs.onErrorContainer)
                }
            }

            FilledTonalButton(
                enabled = !checking,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                onClick = {
                    checking = true
                    error = null
                    upToDate = false
                    found = null
                    scope.launch {
                        Updater.latest()
                            .onSuccess {
                                if (it.versionCode > BuildConfig.VERSION_CODE) found = it else upToDate = true
                            }
                            .onFailure { error = it.message ?: "Controllo non riuscito." }
                        checking = false
                    }
                },
            ) {
                if (checking) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                } else {
                    Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(8.dp))
                Text(if (checking) "Controllo..." else "Controlla aggiornamenti")
            }

            TextButton(onClick = onChangelog, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                Icon(Icons.Filled.NewReleases, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("Cosa c'è di nuovo")
            }
        }
    }
}
