package com.promptbox

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.material3.TextButton
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/** Avviso "Nuova versione disponibile" per la Home: scheda neutra, un solo pulsante, download con percentuale. */
@Composable
fun UpdateCard(info: Updater.Info, modifier: Modifier = Modifier, onDismiss: (() -> Unit)? = null) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var progress by remember { mutableStateOf<Float?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var needsPermission by remember { mutableStateOf(false) }
    val downloading = progress != null

    fun start() {
        message = null
        needsPermission = false
        progress = 0f
        scope.launch {
            Updater.download(context, info) { progress = it }
                .onSuccess { file ->
                    progress = null
                    when (Updater.install(context, file)) {
                        Updater.InstallResult.NEEDS_PERMISSION -> {
                            needsPermission = true
                            message = "Consenti a Prisma di installare app, poi torna qui e premi di nuovo Aggiorna."
                        }
                        Updater.InstallResult.STARTED -> message = "Conferma l'installazione nella schermata di Android."
                    }
                }
                .onFailure {
                    progress = null
                    message = NetErrors.message(it, "Download non riuscito.")
                }
        }
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh, contentColor = cs.onSurface),
        shape = RoundedCornerShape(20.dp),
    ) {
        Column(Modifier.padding(start = 16.dp, top = 14.dp, end = 14.dp, bottom = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(cs.primary.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.Download, contentDescription = null, tint = cs.primary)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        when {
                            downloading -> "Download in corso…"
                            needsPermission -> "Manca un permesso"
                            else -> "Nuova versione disponibile"
                        },
                        style = MaterialTheme.typography.titleSmall,
                    )
                    Text(
                        if (needsPermission) message.orEmpty() else "Versione ${AppInfo.versionName(info.versionCode)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                }
                val pct = progress
                if (pct != null) {
                    Text(
                        "${(pct * 100).toInt()}%",
                        style = MaterialTheme.typography.titleSmall,
                        color = cs.primary,
                        modifier = Modifier.padding(end = 6.dp),
                    )
                } else if (onDismiss != null) {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "Più tardi", tint = cs.onSurfaceVariant)
                    }
                }
            }

            progress?.let {
                LinearProgressIndicator(progress = { it }, modifier = Modifier.fillMaxWidth())
            }
            if (!needsPermission) {
                message?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            }
            if (!downloading) {
                Button(onClick = { start() }, modifier = Modifier.fillMaxWidth().height(44.dp)) {
                    if (!needsPermission) {
                        Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                    }
                    Text("Aggiorna ora")
                }
            }
        }
    }
}

/**
 * Aggiornamenti. Un solo pulsante grande che cambia con lo stato:
 * Controlla -> (Controllo in corso) -> Controlla di nuovo / Aggiorna ora / Riprova.
 *
 * Con [embedded] = true (come nella sezione Informazioni delle Impostazioni, dove titolo e versione stanno già nella riga)
 * si disegnano solo stato e pulsante, senza scheda, titolo né la riga "Cosa c'è di nuovo" (che lì è una riga a parte).
 */
@Composable
fun UpdateSection(onChangelog: () -> Unit, embedded: Boolean = false) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var checking by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var upToDate by remember { mutableStateOf(false) }
    var found by remember { mutableStateOf<Updater.Info?>(null) }
    var progress by remember { mutableStateOf<Float?>(null) }
    var hint by remember { mutableStateOf<String?>(null) }

    fun check() {
        checking = true
        error = null
        upToDate = false
        found = null
        hint = null
        scope.launch {
            Updater.latest()
                .onSuccess {
                    if (it.versionCode > BuildConfig.VERSION_CODE) found = it else upToDate = true
                }
                .onFailure { error = NetErrors.message(it, "Controllo non riuscito.") }
            checking = false
        }
    }

    fun install(info: Updater.Info) {
        hint = null
        progress = 0f
        scope.launch {
            Updater.download(context, info) { progress = it }
                .onSuccess { file ->
                    progress = null
                    hint = when (Updater.install(context, file)) {
                        Updater.InstallResult.NEEDS_PERMISSION ->
                            "Consenti a Prisma di installare app, poi torna qui e premi di nuovo Aggiorna."
                        Updater.InstallResult.STARTED -> "Conferma l'installazione nella schermata di Android."
                    }
                }
                .onFailure {
                    progress = null
                    hint = NetErrors.message(it, "Download non riuscito.")
                }
        }
    }

    val newer = found
    val downloading = progress != null
    val failed = error != null && !checking

    val body: @Composable ColumnScope.() -> Unit = {
            // Riga di stato: compare solo dopo un controllo, così all'apertura non c'è nulla da interpretare.
            val title: String? = when {
                downloading -> "Download in corso…"
                newer != null -> "Versione ${AppInfo.versionName(newer.versionCode)} disponibile"
                upToDate -> "Sei all'ultima versione"
                failed -> "Controllo non riuscito"
                else -> null
            }
            if (title != null) {
                val sub = when {
                    downloading -> "Versione ${newer?.let { AppInfo.versionName(it.versionCode) } ?: ""}"
                    newer != null -> "Pronta da installare"
                    upToDate -> "Controllato poco fa"
                    else -> error.orEmpty()
                }
                val tint = if (failed && !downloading && newer == null) cs.error else cs.primary
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(tint.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        val icon = when {
                            downloading || newer != null -> Icons.Filled.Download
                            upToDate -> Icons.Filled.CheckCircle
                            else -> Icons.Filled.ErrorOutline
                        }
                        Icon(icon, contentDescription = null, tint = tint)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(title, style = MaterialTheme.typography.titleMedium)
                        Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                    progress?.let {
                        Text(
                            "${(it * 100).toInt()}%",
                            style = MaterialTheme.typography.titleMedium,
                            color = cs.primary,
                        )
                    }
                }
            }
            progress?.let { LinearProgressIndicator(progress = { it }, modifier = Modifier.fillMaxWidth()) }
            if (downloading && hint == null) {
                Text(
                    "Al termine Android ti chiede di confermare l'installazione.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
            }
            hint?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }

            // Il pulsante unico: l'azione giusta per lo stato in cui siamo.
            if (newer != null && !downloading) {
                Button(onClick = { install(newer) }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("Aggiorna ora")
                }
            } else if (!downloading) {
                FilledTonalButton(
                    onClick = { check() },
                    enabled = !checking,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                ) {
                    if (checking) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.5.dp)
                    } else {
                        Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(20.dp))
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        when {
                            checking -> "Controllo in corso…"
                            failed -> "Riprova"
                            upToDate -> "Controlla di nuovo"
                            else -> "Controlla aggiornamenti"
                        },
                    )
                }
            }

    }

    if (embedded) {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) { body() }
        return
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer),
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            Modifier.padding(start = 22.dp, top = 22.dp, end = 22.dp, bottom = 10.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Column {
                Text("Aggiornamenti", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(3.dp))
                Text(
                    "Versione ${BuildConfig.VERSION_NAME} · revisione ${AppInfo.revision}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant,
                )
            }

            body()

            // "Cosa c'è di nuovo": una riga da toccare, con la freccia.
            Column {
                HorizontalDivider(color = cs.outlineVariant)
                Row(
                    Modifier.fillMaxWidth().height(48.dp).clickable(onClick = onChangelog).padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = cs.primary, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(12.dp))
                    Text("Cosa c'è di nuovo", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = cs.onSurfaceVariant)
                }
            }
        }
    }
}
