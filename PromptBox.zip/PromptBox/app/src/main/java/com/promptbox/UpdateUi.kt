package com.promptbox

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.TextButton
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/** Avviso "Nuova versione disponibile" per la Home: scheda neutra, un solo pulsante, download con percentuale. */
@Composable
fun UpdateCard(info: Updater.Info, modifier: Modifier = Modifier, onDismiss: (() -> Unit)? = null) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var progress by remember { mutableStateOf<Float?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var needsPermission by remember { mutableStateOf(false) }
    val downloading = progress != null

    fun start() {
        message = null
        needsPermission = false
        progress = 0f
        scope.launch {
            Updater.download(context, info) { progress = it }
                .onSuccess { file ->
                    progress = null
                    when (Updater.install(context, file)) {
                        Updater.InstallResult.NEEDS_PERMISSION -> {
                            needsPermission = true
                            message = "Consenti a Prisma di installare app, poi torna qui e premi di nuovo Aggiorna."
                        }
                        Updater.InstallResult.STARTED -> message = "Conferma l'installazione nella schermata di Android."
                    }
                }
                .onFailure {
                    progress = null
                    message = NetErrors.message(it, "Download non riuscito.")
                }
        }
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh, contentColor = cs.onSurface),
        shape = RoundedCornerShape(20.dp),
    ) {
        Column(Modifier.padding(start = 16.dp, top = 14.dp, end = 14.dp, bottom = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(cs.primary.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.Download, contentDescription = null, tint = cs.primary)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        when {
                            downloading -> "Download in corso…"
                            needsPermission -> "Manca un permesso"
                            else -> "Nuova versione disponibile"
                        },
                        style = MaterialTheme.typography.titleSmall,
                    )
                    Text(
                        if (needsPermission) message.orEmpty() else "Versione ${info.versionCode}",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                }
                val pct = progress
                if (pct != null) {
                    Text(
                        "${(pct * 100).toInt()}%",
                        style = MaterialTheme.typography.titleSmall,
                        color = cs.primary,
                        modifier = Modifier.padding(end = 6.dp),
                    )
                } else if (onDismiss != null) {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "Più tardi", tint = cs.onSurfaceVariant)
                    }
                }
            }

            progress?.let {
                LinearProgressIndicator(progress = { it }, modifier = Modifier.fillMaxWidth())
            }
            if (!needsPermission) {
                message?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            }
            if (!downloading) {
                Button(onClick = { start() }, modifier = Modifier.fillMaxWidth().height(44.dp)) {
                    if (!needsPermission) {
                        Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                    }
                    Text("Aggiorna ora")
                }
            }
        }
    }
}

/** Scheda per le Impostazioni: versione attuale, stato dell'aggiornamento e due azioni discrete. */
@Composable
fun UpdateSection(onChangelog: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var checking by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var upToDate by remember { mutableStateOf(false) }
    var found by remember { mutableStateOf<Updater.Info?>(null) }
    var progress by remember { mutableStateOf<Float?>(null) }
    var hint by remember { mutableStateOf<String?>(null) }

    fun check() {
        checking = true
        error = null
        upToDate = false
        found = null
        hint = null
        scope.launch {
            Updater.latest()
                .onSuccess {
                    if (it.versionCode > BuildConfig.VERSION_CODE) found = it else upToDate = true
                }
                .onFailure { error = NetErrors.message(it, "Controllo non riuscito.") }
            checking = false
        }
    }

    fun install(info: Updater.Info) {
        hint = null
        progress = 0f
        scope.launch {
            Updater.download(context, info) { progress = it }
                .onSuccess { file ->
                    progress = null
                    hint = when (Updater.install(context, file)) {
                        Updater.InstallResult.NEEDS_PERMISSION ->
                            "Consenti a Prisma di installare app, poi torna qui e premi di nuovo Aggiorna."
                        Updater.InstallResult.STARTED -> "Conferma l'installazione nella schermata di Android."
                    }
                }
                .onFailure {
                    progress = null
                    hint = NetErrors.message(it, "Download non riuscito.")
                }
        }
    }

    val newer = found
    val downloading = progress != null
    val isError = error != null && !checking && !downloading

    Card(
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer),
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
            Column {
                Text("Aggiornamenti", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Versione ${BuildConfig.VERSION_NAME} · revisione ${AppInfo.revision}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant,
                )
            }
            HorizontalDivider(color = cs.outlineVariant)

            // Stato: una sola riga, niente riquadri colorati.
            val iconTint = if (isError) cs.error else cs.primary
            val iconBg = (if (isError) cs.error else cs.primary).copy(alpha = 0.16f)
            val title: String
            val subtitle: String
            when {
                downloading -> { title = "Download in corso…"; subtitle = "Versione ${newer?.versionCode ?: ""}" }
                checking -> { title = "Controllo in corso…"; subtitle = "Un attimo" }
                newer != null -> { title = "Nuova versione disponibile"; subtitle = "Versione ${newer.versionCode} · pronta da installare" }
                upToDate -> { title = "Sei all'ultima versione"; subtitle = "Controllato poco fa" }
                isError -> { title = "Controllo non riuscito"; subtitle = error.orEmpty() }
                else -> { title = "Cerca nuove versioni"; subtitle = "Premi Controlla" }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(iconBg),
                    contentAlignment = Alignment.Center,
                ) {
                    when {
                        checking -> CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                        isError -> Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = iconTint)
                        upToDate && newer == null && !downloading ->
                            Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = iconTint)
                        else -> Icon(Icons.Filled.Download, contentDescription = null, tint = iconTint)
                    }
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleMedium)
                    Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                }
                progress?.let {
                    Text(
                        "${(it * 100).toInt()}%",
                        style = MaterialTheme.typography.titleMedium,
                        color = cs.primary,
                    )
                }
            }

            progress?.let {
                LinearProgressIndicator(progress = { it }, modifier = Modifier.fillMaxWidth())
            }
            hint?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            if (downloading && hint == null) {
                Text(
                    "Al termine Android ti chiede di confermare l'installazione.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
            }

            // Unico pulsante pieno: solo quando c'è davvero qualcosa da installare.
            if (newer != null && !downloading) {
                Button(
                    onClick = { install(newer) },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                ) {
                    Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Aggiorna ora")
                }
            }

            HorizontalDivider(color = cs.outlineVariant)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(
                    onClick = { check() },
                    enabled = !checking && !downloading,
                    modifier = Modifier.weight(1f).height(48.dp),
                ) {
                    Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (isError) "Riprova" else "Controlla")
                }
                TextButton(onClick = onChangelog, modifier = Modifier.weight(1f).height(48.dp)) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Novità")
                }
            }
        }
    }
}
