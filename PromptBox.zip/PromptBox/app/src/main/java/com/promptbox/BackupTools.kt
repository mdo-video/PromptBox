package com.promptbox

import org.json.JSONArray
import org.json.JSONObject

/**
 * Backup in un file: sezioni, lista della spesa, storico, "Su di me", colori delle categorie, account Bring
 * e impostazioni (le stesse che si specchiano tra i dispositivi). Non include la chiave API né le chat. Ripristinando, i dati si uniscono a quelli presenti
 * (per ogni elemento vince la versione più recente), quindi non si perde nulla.
 */
object BackupTools {

    fun export(store: Store): String {
        val base = JSONObject(
            DriveSync.serialize(
                store.loadSections(), store.deletedSections(),
                store.shoppingList(), store.shoppingDeleted(),
                store.shoppingHistory(), store.profile, store.profileAt,
                store.settingsJson().toString(), store.settingsAt,
            ),
        )
        return base.put("app", "Prisma").toString(2)
    }

    /** Restituisce un riepilogo di ciò che è stato ripristinato. */
    fun import(store: Store, raw: String): Result<String> = runCatching {
        val o = JSONObject(raw)
        require(o.optString("app") == "Prisma" && o.has("sections")) { "Questo file non sembra un backup di Prisma." }
        val remote = DriveSync.parse(raw)

        val sections = DriveSync.merge(store.loadSections(), store.deletedSections(), remote.sections, remote.deleted)
        store.saveSections(sections.first)
        store.setDeletedSections(sections.second)

        val shop = DriveSync.mergeShopping(store.shoppingList(), store.shoppingDeleted(), remote.shopping, remote.shoppingDeleted)
        store.saveShopping(shop.first)
        store.setShoppingDeleted(shop.second)

        store.setShoppingHistory(DriveSync.mergeHistory(store.shoppingHistory(), remote.history))

        if (remote.profile.isNotBlank() && remote.profileAt > store.profileAt) {
            store.applyRemoteProfile(remote.profile, remote.profileAt)
        }

        // Backup nuovo: tutte le impostazioni. Ripristinare è una scelta esplicita, quindi si applicano sempre
        // (e con la data di adesso, così arrivano anche agli altri dispositivi).
        if (remote.settings.isNotBlank()) {
            store.applySettings(JSONObject(remote.settings), System.currentTimeMillis())
        }
        // Backup vecchio: solo poche impostazioni.
        o.optJSONObject("settings")?.let { s ->
            if (s.has("model")) store.model = s.getString("model")
            if (s.has("length")) store.length = s.getInt("length")
            if (s.has("fallback")) store.fallback = s.getBoolean("fallback")
            if (s.has("theme")) store.theme = s.getInt("theme")
            s.optJSONArray("pinned")?.let { a ->
                store.pinned = store.pinned + (0 until a.length()).map { a.getString(it) }
            }
        }
        "Ripristinati ${sections.first.size} sezioni e ${shop.first.size} prodotti."
    }
}
