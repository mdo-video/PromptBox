package com.promptbox

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock

/** Un tempo trovato nel testo di una risposta, es. "12 min" → 720 secondi. */
data class TimerHit(val seconds: Int, val label: String)

/**
 * Timer dall'app Orologio del telefono (nessun permesso da concedere: SET_ALARM si dichiara solo nel manifest).
 * I tempi si riconoscono nel testo: "12 min", "10-12 minuti", "1 ora", "30 sec".
 */
object Timers {
    /** Numero (anche intervallo "10-12") + unità. Con un intervallo vale il numero più alto. */
    val regex = Regex(
        """(?<![\w.,:])(\d{1,3})(?:\s?[-–]\s?(\d{1,3}))?\s?(minuti|minuto|min|ore|ora|h|secondi|sec)\b""",
        RegexOption.IGNORE_CASE,
    )

    fun seconds(first: String, second: String?, unit: String): Int {
        val n = (second ?: first).toInt()
        return when (unit.lowercase()) {
            "ore", "ora", "h" -> n * 3600
            "secondi", "sec" -> n
            else -> n * 60
        }
    }

    /** Il tempo scritto in modo breve: 90 → "1 min 30 s", 3600 → "1 h". */
    fun pretty(seconds: Int): String {
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return listOfNotNull(
            if (h > 0) "$h h" else null,
            if (m > 0) "$m min" else null,
            if (s > 0) "$s s" else null,
        ).joinToString(" ").ifEmpty { "0 s" }
    }

    /** Tutti i tempi diversi del testo (al massimo 8), nell'ordine in cui compaiono. */
    fun parse(text: String): List<TimerHit> {
        val seen = LinkedHashMap<Int, TimerHit>()
        for (m in regex.findAll(text)) {
            val sec = seconds(m.groupValues[1], m.groupValues[2].ifEmpty { null }, m.groupValues[3])
            if (sec in 5..86_400 && sec !in seen) seen[sec] = TimerHit(sec, pretty(sec))
            if (seen.size >= 8) break
        }
        return seen.values.toList()
    }

    /** Avvia il timer nell'Orologio. Ritorna un messaggio d'errore, oppure null se è partito. */
    fun start(context: Context, seconds: Int): String? {
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            putExtra(AlarmClock.EXTRA_MESSAGE, "Prisma · " + pretty(seconds))
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            null
        } catch (e: Exception) {
            "Non riesco ad avviare il timer: manca l'app Orologio."
        }
    }
}
