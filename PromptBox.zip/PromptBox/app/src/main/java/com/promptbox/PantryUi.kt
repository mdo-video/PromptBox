package com.promptbox

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/** Prodotto in modifica (o nuovo) nella finestra. [fromScan]: arriva dallo scanner, c'è "Salva e scansiona un altro". */
private class PantryDraft(val item: PantryItem, val isNew: Boolean, val fromScan: Boolean)

private val SoonColor = Color(0xFFFFC857)

/** Frigo e dispensa: disegno a ripiani o elenco, scadenze, scanner codice a barre. */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PantryScreen(
    items: List<PantryItem>,
    canCook: Boolean,
    onChange: (List<PantryItem>) -> Unit,
    onCook: (String) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var place by rememberSaveable { mutableStateOf("frigo") }
    var listView by rememberSaveable { mutableStateOf(false) }
    var draft by remember { mutableStateOf<PantryDraft?>(null) }
    var scanning by remember { mutableStateOf(false) }

    val shelves = Pantry.shelves(place)
    val placeItems = items.filter { it.place == place }
    val late = placeItems.count { Pantry.freshness(it) == Freshness.LATE }
    val soon = placeItems.count { Pantry.freshness(it) == Freshness.SOON }
    val subtitle = buildString {
        append(placeItems.size).append(if (placeItems.size == 1) " prodotto" else " prodotti")
        if (late > 0) append(" · ").append(late).append(if (late == 1) " scaduto" else " scaduti")
        if (soon > 0) append(" · ").append(soon).append(" da usare presto")
    }

    fun newItem(shelf: String, name: String = "") = PantryItem(
        id = "p" + System.currentTimeMillis(),
        name = name,
        place = place,
        shelf = shelf,
        qty = "",
        expiry = null,
        addedAt = System.currentTimeMillis(),
    )

    fun scan() {
        if (scanning) return
        scanning = true
        scope.launch {
            val res = BarcodeTools.scan(context)
            val code = res.getOrNull()
            if (res.isFailure) {
                Toast.makeText(context, res.exceptionOrNull()?.message ?: "Scanner non disponibile.", Toast.LENGTH_LONG).show()
            } else if (code != null) {
                val name = BarcodeTools.productName(code).getOrNull()
                if (name == null) Toast.makeText(context, "Prodotto non trovato: scrivi tu il nome.", Toast.LENGTH_LONG).show()
                draft = PantryDraft(newItem(shelves.first(), name.orEmpty()), isNew = true, fromScan = true)
            }
            scanning = false
        }
    }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text("Frigo e dispensa") },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = cs.background),
            )
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = place == "frigo", onClick = { place = "frigo" }, label = { Text("Frigo") })
                    FilterChip(selected = place == "dispensa", onClick = { place = "dispensa" }, label = { Text("Dispensa") })
                }
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !listView, onClick = { listView = false }, label = { Text("Disegno") })
                    FilterChip(selected = listView, onClick = { listView = true }, label = { Text("Elenco") })
                }

                if (!listView) {
                    BoxWithConstraints(Modifier.fillMaxWidth()) {
                        val gap = 8.dp
                        // Cornice 3 dp per lato + margini interni 12 dp: tre schede per riga.
                        val chipW: Dp = (maxWidth - 6.dp - 24.dp - gap * 2) / 3
                        val frame = RoundedCornerShape(24.dp)
                        Column(
                            Modifier.fillMaxWidth()
                                .clip(frame)
                                .background(cs.surfaceContainerLow)
                                .border(3.dp, cs.outline, frame)
                                .padding(3.dp),
                        ) {
                            shelves.forEachIndexed { index, shelf ->
                                val onShelf = Pantry.sorted(
                                    placeItems.filter { (if (it.shelf in shelves) it.shelf else shelves.first()) == shelf },
                                )
                                Text(
                                    shelf.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = cs.onSurfaceVariant,
                                    modifier = Modifier.padding(start = 12.dp, top = 12.dp),
                                )
                                FlowRow(
                                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.spacedBy(gap),
                                    verticalArrangement = Arrangement.spacedBy(gap),
                                ) {
                                    onShelf.forEach { item ->
                                        PantryChip(item, chipW) { draft = PantryDraft(item, isNew = false, fromScan = false) }
                                    }
                                    PantryAddChip(chipW) { draft = PantryDraft(newItem(shelf), isNew = true, fromScan = false) }
                                }
                                if (index < shelves.lastIndex) HorizontalDivider(thickness = 5.dp, color = cs.outline)
                            }
                        }
                    }
                } else {
                    if (placeItems.isEmpty()) {
                        Text(
                            "Qui non c'è ancora niente: tocca + o scansiona un prodotto.",
                            color = cs.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 16.dp),
                        )
                    }
                    Pantry.sorted(placeItems).forEach { item ->
                        PantryRow(item) { draft = PantryDraft(item, isNew = false, fromScan = false) }
                    }
                }
                Spacer(Modifier.size(8.dp))
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Button(
                    onClick = { onCook(Pantry.cookPrompt(placeItems, place)) },
                    enabled = canCook && placeItems.isNotEmpty(),
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                ) { Text("Cosa ci cucino?") }
                FilledTonalIconButton(onClick = { scan() }, enabled = !scanning) {
                    Icon(Icons.Filled.QrCodeScanner, contentDescription = "Scansiona codice a barre")
                }
                FilledTonalIconButton(onClick = { draft = PantryDraft(newItem(shelves.first()), isNew = true, fromScan = false) }) {
                    Icon(Icons.Filled.Add, contentDescription = "Aggiungi prodotto")
                }
            }
        }
    }

    draft?.let { d ->
        PantryItemDialog(
            draft = d,
            onSave = { item, again ->
                onChange(if (d.isNew) items + item else items.map { if (it.id == item.id) item else it })
                draft = null
                if (again) scan()
            },
            onDelete = {
                onChange(items.filter { it.id != d.item.id })
                draft = null
            },
            onDismiss = { draft = null },
        )
    }
}

@Composable
private fun freshnessColor(f: Freshness): Color {
    val cs = MaterialTheme.colorScheme
    return when (f) {
        Freshness.LATE -> cs.error
        Freshness.SOON -> SoonColor
        Freshness.OK -> cs.primary
        Freshness.NONE -> cs.outline
    }
}

/** Scheda di un prodotto sul ripiano: scaduto = bordo pieno, da usare presto = bordo tratteggiato. */
@Composable
private fun PantryChip(item: PantryItem, width: Dp, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val f = Pantry.freshness(item)
    val dot = freshnessColor(f)
    val shape = RoundedCornerShape(12.dp)
    val detail = (if (item.qty.isBlank()) "" else item.qty + " · ") + Pantry.label(item.expiry)
    Column(
        Modifier
            .width(width)
            .clip(shape)
            .background(cs.surfaceContainerHigh)
            .then(
                when (f) {
                    Freshness.LATE -> Modifier.border(2.dp, cs.error, shape)
                    Freshness.SOON -> Modifier.drawBehind {
                        drawRoundRect(
                            color = SoonColor,
                            cornerRadius = CornerRadius(12.dp.toPx()),
                            style = Stroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))),
                        )
                    }
                    else -> Modifier
                },
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).background(dot, CircleShape))
            Spacer(Modifier.width(5.dp))
            Text(
                item.name,
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                color = cs.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Text(
            detail,
            style = MaterialTheme.typography.labelSmall,
            color = cs.onSurfaceVariant,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}

@Composable
private fun PantryAddChip(width: Dp, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(12.dp)
    Box(
        Modifier
            .width(width)
            .heightIn(min = 52.dp)
            .clip(shape)
            .border(2.dp, cs.outline, shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Filled.Add, contentDescription = "Aggiungi prodotto su questo ripiano", tint = cs.onSurfaceVariant)
    }
}

@Composable
private fun PantryRow(item: PantryItem, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val f = Pantry.freshness(item)
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(cs.surfaceContainerHigh).clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(10.dp).background(freshnessColor(f), CircleShape))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.name, style = MaterialTheme.typography.bodyLarge, color = cs.onSurface, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(
                item.shelf + (if (item.qty.isBlank()) "" else " · " + item.qty),
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(
            Pantry.label(item.expiry),
            style = MaterialTheme.typography.labelLarge,
            color = if (f == Freshness.LATE) cs.error else cs.onSurfaceVariant,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun PantryItemDialog(
    draft: PantryDraft,
    onSave: (PantryItem, Boolean) -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val shelves = Pantry.shelves(draft.item.place)
    var name by remember { mutableStateOf(draft.item.name) }
    var qty by remember { mutableStateOf(draft.item.qty) }
    var shelf by remember { mutableStateOf(if (draft.item.shelf in shelves) draft.item.shelf else shelves.first()) }
    var expiry by remember { mutableStateOf(draft.item.expiry) }
    var picking by remember { mutableStateOf(false) }
    val today = Pantry.today()
    val quick = listOf("Domani" to 1L, "3 giorni" to 3L, "1 settimana" to 7L, "2 settimane" to 14L, "1 mese" to 30L, "3 mesi" to 90L, "6 mesi" to 180L)

    fun result() = draft.item.copy(name = name.trim(), qty = qty.trim(), shelf = shelf, expiry = expiry)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (draft.isNew) "Nuovo prodotto" else "Modifica prodotto") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nome") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = qty,
                    onValueChange = { qty = it },
                    label = { Text("Quantità (facoltativa)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("Dove", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    shelves.forEach { s -> FilterChip(selected = s == shelf, onClick = { shelf = s }, label = { Text(s) }) }
                }
                Text(
                    "Scadenza: " + (expiry?.let { Pantry.dateText(it) + " · " + Pantry.label(it) } ?: "nessuna"),
                    style = MaterialTheme.typography.labelLarge,
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    quick.forEach { (label, days) ->
                        FilterChip(selected = expiry == today + days, onClick = { expiry = today + days }, label = { Text(label) })
                    }
                    FilterChip(selected = false, onClick = { picking = true }, label = { Text("Data…") })
                    FilterChip(selected = expiry == null, onClick = { expiry = null }, label = { Text("Nessuna") })
                }
                if (!draft.isNew) {
                    TextButton(onClick = onDelete) { Text("Elimina prodotto", color = cs.error) }
                }
            }
        },
        confirmButton = {
            Row {
                if (draft.fromScan) {
                    TextButton(onClick = { onSave(result(), true) }, enabled = name.isNotBlank()) { Text("Salva e altro") }
                }
                TextButton(onClick = { onSave(result(), false) }, enabled = name.isNotBlank()) { Text("Salva") }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annulla") } },
    )

    if (picking) {
        val state = rememberDatePickerState(initialSelectedDateMillis = (expiry ?: today) * 86_400_000L)
        DatePickerDialog(
            onDismissRequest = { picking = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { expiry = it / 86_400_000L }
                    picking = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { picking = false }) { Text("Annulla") } },
        ) { DatePicker(state = state) }
    }
}
