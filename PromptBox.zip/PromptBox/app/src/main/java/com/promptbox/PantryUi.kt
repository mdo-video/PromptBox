package com.promptbox

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Kitchen
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.EditCalendar
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/** Prodotto in modifica (o nuovo) nella finestra. [fromScan]: arriva dallo scanner, c'è "Salva e altro". */
private class PantryDraft(val item: PantryItem, val isNew: Boolean, val fromScan: Boolean)

/** Frigo o dispensa ([place] = "frigo" | "dispensa"): ripiani in stile Material 3, elenco, scadenze, scanner. */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PantryScreen(
    place: String,
    items: List<PantryItem>,
    canCook: Boolean,
    store: Store,
    onChange: (List<PantryItem>) -> Unit,
    onCook: (String) -> Unit,
    onReceipt: (Receipt) -> Unit,
    onToStock: (List<PantryItem>) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var listView by rememberSaveable { mutableStateOf(false) }
    var draft by remember { mutableStateOf<PantryDraft?>(null) }
    var scanning by remember { mutableStateOf(false) }
    var fromReceipt by remember { mutableStateOf(false) }
    var confirming by remember { mutableStateOf(false) }

    val shelves = Pantry.shelves(place)
    val placeItems = remember(items, place) { items.filter { it.place == place } }
    val late = remember(placeItems) { placeItems.count { Pantry.freshness(it) == Freshness.LATE } }
    val soon = remember(placeItems) { placeItems.count { Pantry.freshness(it) == Freshness.SOON } }
    val urgentNames = remember(placeItems) {
        Pantry.sorted(placeItems)
            .filter { Pantry.freshness(it).let { f -> f == Freshness.LATE || f == Freshness.SOON } }
            .take(2).joinToString(" e ") { it.name }
    }
    val isFridge = place == "frigo"
    val toConfirm = remember(placeItems) { Pantry.toConfirm(placeItems) }

    fun newItem(shelf: String, name: String = "") = PantryItem(
        id = "p" + System.currentTimeMillis(),
        name = name,
        place = place,
        shelf = shelf,
        qty = "",
        expiry = null,
        addedAt = System.currentTimeMillis(),
    )

    fun scan() {
        if (scanning) return
        scanning = true
        scope.launch {
            val res = BarcodeTools.scan(context)
            val code = res.getOrNull()
            if (res.isFailure) {
                Toast.makeText(context, res.exceptionOrNull()?.message ?: "Scanner non disponibile.", Toast.LENGTH_LONG).show()
            } else if (code != null) {
                val name = BarcodeTools.productName(code).getOrNull()
                if (name == null) Toast.makeText(context, "Prodotto non trovato: scrivi tu il nome.", Toast.LENGTH_LONG).show()
                draft = PantryDraft(newItem(shelves.first(), name.orEmpty()), isNew = true, fromScan = true)
            }
            scanning = false
        }
    }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text(if (isFridge) "Frigo" else "Dispensa") },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = cs.background),
            )
        },
        floatingActionButton = {
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SmallFloatingActionButton(
                    onClick = { fromReceipt = true },
                    containerColor = cs.secondaryContainer,
                    contentColor = cs.onSecondaryContainer,
                ) { Icon(Icons.Filled.Receipt, contentDescription = "Aggiungi da scontrino") }
                SmallFloatingActionButton(
                    onClick = { scan() },
                    containerColor = cs.secondaryContainer,
                    contentColor = cs.onSecondaryContainer,
                ) { Icon(Icons.Filled.QrCodeScanner, contentDescription = "Scansiona codice a barre") }
                ExtendedFloatingActionButton(
                    onClick = { draft = PantryDraft(newItem(shelves.first()), isNew = true, fromScan = false) },
                    icon = { Icon(Icons.Filled.Add, null) },
                    text = { Text("Aggiungi") },
                )
            }
        },
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // Riepilogo: quanti prodotti e a che punto sono le scadenze.
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusPill(
                    placeItems.size.toString() + if (placeItems.size == 1) " prodotto" else " prodotti",
                    cs.secondaryContainer, cs.onSecondaryContainer, if (isFridge) Icons.Filled.Kitchen else Icons.Filled.Inventory2,
                )
                if (late > 0) {
                    StatusPill(late.toString() + if (late == 1) " scaduto" else " scaduti", cs.errorContainer, cs.onErrorContainer, Icons.Filled.ErrorOutline)
                }
                if (soon > 0) {
                    StatusPill(soon.toString() + " da usare presto", cs.tertiaryContainer, cs.onTertiaryContainer, Icons.Filled.Schedule)
                }
                if (late == 0 && soon == 0 && placeItems.isNotEmpty()) {
                    StatusPill("Tutto sotto controllo", cs.primaryContainer, cs.onPrimaryContainer, Icons.Filled.CheckCircle)
                }
            }

            if (toConfirm.isNotEmpty()) {
                Card(
                    onClick = { confirming = true },
                    colors = CardDefaults.cardColors(containerColor = cs.secondaryContainer, contentColor = cs.onSecondaryContainer),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.EditCalendar, contentDescription = null)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Aggiungi le scadenze", style = MaterialTheme.typography.titleMedium)
                            Text(
                                toConfirm.size.toString() + (if (toConfirm.size == 1) " prodotto ha" else " prodotti hanno") + " una scadenza stimata",
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                }
            }

            Card(
                onClick = { onCook(Pantry.cookPrompt(placeItems, place)) },
                enabled = canCook && placeItems.isNotEmpty(),
                colors = CardDefaults.cardColors(
                    containerColor = cs.primaryContainer,
                    contentColor = cs.onPrimaryContainer,
                    disabledContainerColor = cs.surfaceContainerHigh,
                    disabledContentColor = cs.onSurfaceVariant,
                ),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Restaurant, contentDescription = null)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Cosa ci cucino?", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (urgentNames.isNotEmpty()) "Usa prima " + urgentNames else "Idee con quello che hai",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }

            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = !listView,
                    onClick = { listView = false },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                    label = { Text("Disegno") },
                )
                SegmentedButton(
                    selected = listView,
                    onClick = { listView = true },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                    label = { Text("Elenco") },
                )
            }

            if (!listView) {
                BoxWithConstraints(Modifier.fillMaxWidth()) {
                    val gap = 8.dp
                    // Contenitore 8 dp per lato + ripiano 12 dp per lato: due schede per riga.
                    val cardW: Dp = (maxWidth - 16.dp - 24.dp - gap) / 2
                    Surface(shape = RoundedCornerShape(32.dp), color = cs.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            shelves.forEach { shelf ->
                                val onShelf = Pantry.sorted(
                                    placeItems.filter { (if (it.shelf in shelves) it.shelf else shelves.first()) == shelf },
                                )
                                Surface(shape = RoundedCornerShape(24.dp), color = cs.surfaceContainerLow, modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                Pantry.shelfEmoji(shelf) + "  " + shelf,
                                                style = MaterialTheme.typography.titleSmall,
                                                modifier = Modifier.weight(1f),
                                            )
                                            FilledTonalIconButton(
                                                onClick = { draft = PantryDraft(newItem(shelf), isNew = true, fromScan = false) },
                                                modifier = Modifier.size(36.dp),
                                            ) { Icon(Icons.Filled.Add, contentDescription = "Aggiungi in $shelf", modifier = Modifier.size(18.dp)) }
                                        }
                                        if (onShelf.isEmpty()) {
                                            Text("Vuoto", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                                        } else {
                                            FlowRow(horizontalArrangement = Arrangement.spacedBy(gap), verticalArrangement = Arrangement.spacedBy(gap)) {
                                                onShelf.forEach { item ->
                                                    PantryCard(item, cardW) { draft = PantryDraft(item, isNew = false, fromScan = false) }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (placeItems.isEmpty()) {
                    Text(
                        "Qui non c'è ancora niente: tocca Aggiungi o scansiona un prodotto.",
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 16.dp),
                    )
                }
                Pantry.sorted(placeItems).forEach { item ->
                    PantryListRow(item) { draft = PantryDraft(item, isNew = false, fromScan = false) }
                }
            }
            Spacer(Modifier.height(132.dp)) // spazio per i pulsanti in basso
        }
    }

    if (fromReceipt) {
        ReceiptToPantryFlow(
            store = store,
            onReceipt = onReceipt,
            onToStock = onToStock,
            onDismiss = { fromReceipt = false },
        )
    }

    if (confirming && toConfirm.isNotEmpty()) {
        ExpiryWalkthroughDialog(
            items = toConfirm,
            store = store,
            onDone = { updated ->
                confirming = false
                val byId = updated.associateBy { it.id }
                onChange(items.map { byId[it.id] ?: it })
            },
        )
    }

    draft?.let { d ->
        PantryItemDialog(
            draft = d,
            onSave = { item, again ->
                onChange(if (d.isNew) items + item else items.map { if (it.id == item.id) item else it })
                draft = null
                if (again) scan()
            },
            onDelete = {
                onChange(items.filter { it.id != d.item.id })
                draft = null
            },
            onDismiss = { draft = null },
        )
    }
}

@Composable
private fun StatusPill(text: String, container: Color, content: Color, icon: ImageVector) {
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(container).padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp), tint = content)
        Spacer(Modifier.width(6.dp))
        Text(text, style = MaterialTheme.typography.labelLarge, color = content)
    }
}

/** Colori della scheda: il contenitore cambia con lo stato, così si capisce anche senza leggere. */
@Composable
private fun freshnessColors(f: Freshness): Pair<Color, Color> {
    val cs = MaterialTheme.colorScheme
    return when (f) {
        Freshness.LATE -> cs.errorContainer to cs.onErrorContainer
        Freshness.SOON -> cs.tertiaryContainer to cs.onTertiaryContainer
        else -> cs.surfaceContainerHighest to cs.onSurface
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PantryCard(item: PantryItem, width: Dp, onClick: () -> Unit) {
    val f = Pantry.freshness(item)
    val (bg, fg) = freshnessColors(f)
    val detail = (if (item.qty.isBlank()) "" else item.qty + " · ") + Pantry.labelOf(item)
    Surface(onClick = onClick, shape = RoundedCornerShape(16.dp), color = bg, contentColor = fg, modifier = Modifier.width(width)) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    item.name,
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                when (f) {
                    Freshness.LATE -> Icon(Icons.Filled.ErrorOutline, contentDescription = "Scaduto", modifier = Modifier.size(18.dp))
                    Freshness.SOON -> Icon(Icons.Filled.Schedule, contentDescription = "Da usare presto", modifier = Modifier.size(18.dp))
                    else -> {}
                }
            }
            Text(
                detail,
                style = MaterialTheme.typography.bodySmall,
                color = fg.copy(alpha = 0.8f),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PantryListRow(item: PantryItem, onClick: () -> Unit) {
    val f = Pantry.freshness(item)
    val (bg, fg) = freshnessColors(f)
    Surface(onClick = onClick, shape = RoundedCornerShape(20.dp), color = bg, contentColor = fg, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(Pantry.shelfEmoji(item.shelf), style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.name, style = MaterialTheme.typography.bodyLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(
                    item.shelf + if (item.qty.isBlank()) "" else " · " + item.qty,
                    style = MaterialTheme.typography.bodySmall,
                    color = fg.copy(alpha = 0.8f),
                )
            }
            Spacer(Modifier.width(8.dp))
            Text(Pantry.labelOf(item), style = MaterialTheme.typography.labelLarge)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun PantryItemDialog(
    draft: PantryDraft,
    onSave: (PantryItem, Boolean) -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val shelves = Pantry.shelves(draft.item.place)
    var name by remember { mutableStateOf(draft.item.name) }
    var qty by remember { mutableStateOf(draft.item.qty) }
    var shelf by remember { mutableStateOf(if (draft.item.shelf in shelves) draft.item.shelf else shelves.first()) }
    var expiry by remember { mutableStateOf(draft.item.expiry) }
    var picking by remember { mutableStateOf(false) }
    val today = Pantry.today()
    val quick = listOf("Domani" to 1L, "3 giorni" to 3L, "1 settimana" to 7L, "2 settimane" to 14L, "1 mese" to 30L, "3 mesi" to 90L, "6 mesi" to 180L)

    // Se la scadenza è cambiata a mano non è più una stima.
    fun result() = draft.item.copy(
        name = name.trim(), qty = qty.trim(), shelf = shelf, expiry = expiry,
        estimated = draft.item.estimated && expiry == draft.item.expiry,
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (draft.isNew) "Nuovo prodotto" else "Modifica prodotto") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nome") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = qty,
                    onValueChange = { qty = it },
                    label = { Text("Quantità (facoltativa)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("Dove", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    shelves.forEach { s -> FilterChip(selected = s == shelf, onClick = { shelf = s }, label = { Text(s) }) }
                }
                Text(
                    "Scadenza: " + (expiry?.let { Pantry.dateText(it) + " · " + Pantry.label(it) } ?: "nessuna") +
                        if (draft.item.estimated && expiry == draft.item.expiry) " (stimata)" else "",
                    style = MaterialTheme.typography.labelLarge,
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    quick.forEach { (label, days) ->
                        FilterChip(selected = expiry == today + days, onClick = { expiry = today + days }, label = { Text(label) })
                    }
                    FilterChip(selected = false, onClick = { picking = true }, label = { Text("Data…") })
                    FilterChip(selected = expiry == null, onClick = { expiry = null }, label = { Text("Nessuna") })
                }
                if (!draft.isNew) {
                    TextButton(onClick = onDelete) { Text("Elimina prodotto", color = cs.error) }
                }
            }
        },
        confirmButton = {
            Row {
                if (draft.fromScan) {
                    TextButton(onClick = { onSave(result(), true) }, enabled = name.isNotBlank()) { Text("Salva e altro") }
                }
                TextButton(onClick = { onSave(result(), false) }, enabled = name.isNotBlank()) { Text("Salva") }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annulla") } },
    )

    if (picking) {
        val state = rememberDatePickerState(initialSelectedDateMillis = (expiry ?: today) * 86_400_000L)
        DatePickerDialog(
            onDismissRequest = { picking = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { expiry = it / 86_400_000L }
                    picking = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { picking = false }) { Text("Annulla") } },
        ) { DatePicker(state = state) }
    }
}
