package com.promptbox

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material3.CircularProgressIndicator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Kitchen
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.EditCalendar
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.IconButton
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Switch
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import kotlinx.coroutines.launch

/** Prodotto in modifica (o nuovo) nella finestra. [fromScan] / [fromPhoto]: arriva dallo scanner o dalla foto, c'è "Salva e altro". */
private class PantryDraft(val item: PantryItem, val isNew: Boolean, val fromScan: Boolean, val fromPhoto: Boolean = false)

/** Frigo o dispensa ([place] = "frigo" | "dispensa"): ripiani in stile Material 3, elenco, scadenze, scanner. */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PantryScreen(
    place: String,
    items: List<PantryItem>,
    canCook: Boolean,
    store: Store,
    onChange: (List<PantryItem>) -> Unit,
    onCook: (String) -> Unit,
    onReceipt: (Receipt) -> Unit,
    onToStock: (List<PantryItem>) -> Unit,
    /** Mette i prodotti nella lista della spesa. Restituisce come annullare, o null se non è stato aggiunto niente. */
    onToShopping: (List<ListSuggestion>) -> (() -> Unit)?,
    /** Prodotti scaduti buttati (per contare lo spreco in euro) e come annullare. */
    onWaste: (List<PantryItem>) -> Unit,
    onUnwaste: (Set<String>) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var draft by remember { mutableStateOf<PantryDraft?>(null) }
    var scanning by remember { mutableStateOf(false) }
    // Testo della lettura in corso (foto o codice a barre); null = niente in corso.
    var reading by remember { mutableStateOf<String?>(null) }
    var productUri by remember { mutableStateOf<Uri?>(null) }
    var lastProductUri by remember { mutableStateOf<Uri?>(null) }
    var fromReceipt by remember { mutableStateOf(false) }
    var confirming by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var actions by remember { mutableStateOf<PantryItem?>(null) }
    var moving by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }
    val latestItems by rememberUpdatedState(items)

    val shelves = Pantry.shelves(place)
    val placeItems = remember(items, place) { items.filter { it.place == place } }
    // Ricerca: compare quando i prodotti sono tanti e filtra sia il disegno sia l'elenco.
    var query by rememberSaveable { mutableStateOf("") }
    val q = query.trim().lowercase()
    val shownItems = remember(placeItems, q) { if (q.isEmpty()) placeItems else placeItems.filter { it.name.lowercase().contains(q) } }
    val late = remember(placeItems) { placeItems.count { Pantry.freshness(it) == Freshness.LATE } }
    val soon = remember(placeItems) { placeItems.count { Pantry.freshness(it) == Freshness.SOON } }
    val urgentNames = remember(placeItems) {
        Pantry.sorted(placeItems)
            .filter { Pantry.freshness(it).let { f -> f == Freshness.LATE || f == Freshness.SOON } }
            .take(2).joinToString(" e ") { it.name }
    }
    val isFridge = place == "frigo"
    val toConfirm = remember(placeItems) { Pantry.toConfirm(placeItems) }
    val lateItems = remember(placeItems) { placeItems.filter { Pantry.freshness(it) == Freshness.LATE } }
    val selectedItems = remember(placeItems, selected) { placeItems.filter { it.id in selected } }

    fun newItem(shelf: String, name: String = "") = PantryItem(
        id = "p" + System.currentTimeMillis(),
        name = name,
        place = place,
        shelf = shelf,
        qty = "",
        expiry = null,
        addedAt = System.currentTimeMillis(),
    )

    /** "Finito" (o scaduto): il prodotto esce da qui e, se si vuole, va nella lista della spesa. C'è sempre Annulla. */
    fun finish(done: List<PantryItem>, relist: Boolean, wasted: Boolean = false) {
        if (done.isEmpty()) return
        val ids = done.map { it.id }.toSet()
        onChange(latestItems.filter { it.id !in ids })
        // Buttati davvero (scaduti): si contano nello spreco, con il prezzo dello scontrino se c'è.
        val lost = if (wasted) done.filter { Pantry.freshness(it) == Freshness.LATE } else emptyList()
        if (lost.isNotEmpty()) onWaste(lost)
        selected = emptySet()
        val undoList = if (relist) onToShopping(Pantry.toShopping(done)) else null
        val what = if (done.size == 1) "«" + done[0].name + "» finito" else done.size.toString() + " prodotti finiti"
        val msg = when {
            !relist -> what
            undoList != null -> "$what · messo nella lista della spesa"
            else -> "$what · era già in lista"
        }
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            val r = snackbar.showSnackbar(msg, actionLabel = "Annulla", duration = SnackbarDuration.Long)
            if (r == SnackbarResult.ActionPerformed) {
                onChange(latestItems.filter { it.id !in ids } + done)
                if (lost.isNotEmpty()) onUnwaste(lost.map { it.id }.toSet())
                undoList?.invoke()
            }
        }
    }

    fun tapItem(item: PantryItem) {
        if (selected.isNotEmpty()) {
            selected = if (item.id in selected) selected - item.id else selected + item.id
        } else {
            actions = item
        }
    }

    /** Elimina in blocco, con Annulla. I già scaduti contano come buttati. */
    fun deleteMany(gone: List<PantryItem>) {
        if (gone.isEmpty()) return
        val ids = gone.map { it.id }.toSet()
        val lost = gone.filter { Pantry.freshness(it) == Freshness.LATE }
        if (lost.isNotEmpty()) onWaste(lost)
        onChange(latestItems.filter { it.id !in ids })
        selected = emptySet()
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            val msg = if (gone.size == 1) "«" + gone[0].name + "» eliminato" else gone.size.toString() + " prodotti eliminati"
            val r = snackbar.showSnackbar(msg, actionLabel = "Annulla", duration = SnackbarDuration.Long)
            if (r == SnackbarResult.ActionPerformed) {
                onChange(latestItems.filter { it.id !in ids } + gone)
                if (lost.isNotEmpty()) onUnwaste(lost.map { it.id }.toSet())
            }
        }
    }

    /** Sposta in blocco su un altro ripiano (anche nell'altro posto); la scadenza non cambia. Con Annulla. */
    fun moveMany(moved: List<PantryItem>, toPlace: String, toShelf: String) {
        if (moved.isEmpty()) return
        val ids = moved.map { it.id }.toSet()
        onChange(latestItems.map { if (it.id in ids) it.copy(place = toPlace, shelf = toShelf) else it })
        selected = emptySet()
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            val where = (if (toPlace == "dispensa") "dispensa · " else "frigo · ") + toShelf
            val msg = (if (moved.size == 1) "1 prodotto spostato" else moved.size.toString() + " prodotti spostati") + " in " + where
            val r = snackbar.showSnackbar(msg, actionLabel = "Annulla", duration = SnackbarDuration.Long)
            if (r == SnackbarResult.ActionPerformed) {
                onChange(latestItems.filter { it.id !in ids } + moved)
            }
        }
    }

    // Tocco breve: foglio con le azioni (Finito, Modifica, Seleziona, Elimina). Tenendo premuto: modifica diretta. In selezione, il tocco lungo toglie o aggiunge.
    fun longTapItem(item: PantryItem) {
        if (selected.isNotEmpty()) {
            selected = if (item.id in selected) selected - item.id else selected + item.id
        } else {
            draft = PantryDraft(item, isNew = false, fromScan = false)
        }
    }

    /** Un avviso breve in basso, al posto di quello precedente. */
    fun notify(msg: String) {
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            snackbar.showSnackbar(msg, duration = SnackbarDuration.Short)
        }
    }

    fun deleteItem(gone: PantryItem) {
        // Eliminare un prodotto già scaduto conta come buttato.
        val lost = Pantry.freshness(gone) == Freshness.LATE
        if (lost) onWaste(listOf(gone))
        onChange(latestItems.filter { it.id != gone.id })
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            val r = snackbar.showSnackbar("«" + gone.name + "» eliminato", actionLabel = "Annulla", duration = SnackbarDuration.Long)
            if (r == SnackbarResult.ActionPerformed) {
                onChange(latestItems.filter { it.id != gone.id } + gone)
                if (lost) onUnwaste(setOf(gone.id))
            }
        }
    }

    /** Apre la finestra con quello che si è capito (nome, ripiano, quantità, scadenza); g = null: tutto vuoto. */
    fun draftFrom(g: PantryGuess?, fromScan: Boolean, fromPhoto: Boolean) {
        val base = newItem(g?.shelf ?: shelves.first(), g?.name.orEmpty())
        draft = PantryDraft(
            base.copy(qty = g?.qty.orEmpty(), expiry = g?.expiry, estimated = g?.estimated == true),
            isNew = true, fromScan = fromScan, fromPhoto = fromPhoto,
        )
    }

    fun scan() {
        if (scanning) return
        scanning = true
        scope.launch {
            val res = BarcodeTools.scan(context)
            val code = res.getOrNull()
            if (res.isFailure) {
                Toast.makeText(context, res.exceptionOrNull()?.message ?: "Scanner non disponibile.", Toast.LENGTH_LONG).show()
            } else if (code != null) {
                reading = "Cerco il prodotto…"
                val g = PantryPhoto.fromBarcode(store, place, code)
                reading = null
                g.onSuccess { draftFrom(it, fromScan = true, fromPhoto = false) }
                    .onFailure {
                        Toast.makeText(context, it.message ?: "Prodotto non trovato: scrivi tu il nome.", Toast.LENGTH_LONG).show()
                        draftFrom(null, fromScan = true, fromPhoto = false)
                    }
            }
            scanning = false
        }
    }

    /** Una foto della confezione: l'AI compila nome, ripiano, quantità e scadenza (se si vede). Se fallisce, "Riprova" senza rifare la foto. */
    fun readProduct(uri: Uri) {
        lastProductUri = uri
        scope.launch {
            reading = "Leggo il prodotto…"
            val bmp = withContext(Dispatchers.IO) { ImageUtils.load(context, uri, maxSide = 1600) }
            if (bmp == null) {
                reading = null
                notify("Non riesco ad aprire la foto.")
                return@launch
            }
            val res = PantryPhoto.fromPhoto(store, place, bmp)
            reading = null
            res.onSuccess { draftFrom(it, fromScan = false, fromPhoto = true) }
                .onFailure { e ->
                    snackbar.currentSnackbarData?.dismiss()
                    val r = snackbar.showSnackbar(e.message ?: "Errore sconosciuto", actionLabel = "Riprova", duration = SnackbarDuration.Long)
                    if (r == SnackbarResult.ActionPerformed) readProduct(uri)
                }
        }
    }

    val takeProduct = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) productUri?.let { readProduct(it) }
    }

    fun photo() {
        val dir = File(context.cacheDir, "photos").apply { mkdirs() }
        val file = File.createTempFile("prodotto", ".jpg", dir)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        productUri = uri
        takeProduct.launch(uri)
    }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            if (selected.isEmpty()) {
                TopAppBar(
                    title = { Text(if (isFridge) "Frigo" else "Dispensa") },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = cs.background),
                )
            } else {
                TopAppBar(
                    navigationIcon = { IconButton(onClick = { selected = emptySet() }) { Icon(Icons.Filled.Close, contentDescription = "Esci dalla selezione") } },
                    title = { Text(selected.size.toString() + if (selected.size == 1) " selezionato" else " selezionati") },
                    actions = { TextButton(onClick = { selected = placeItems.map { it.id }.toSet() }) { Text("Seleziona tutti") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = cs.background),
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            if (selected.isNotEmpty()) {
                // Barra delle azioni in blocco: Finiti (pieno), Sposta, Elimina.
                Surface(
                    shape = RoundedCornerShape(32.dp),
                    color = cs.surfaceContainerHigh,
                    shadowElevation = 6.dp,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp).fillMaxWidth(),
                ) {
                    Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { finish(selectedItems, relist = true) }, modifier = Modifier.weight(1.3f).height(52.dp)) {
                            Icon(Icons.Filled.CheckCircle, null, Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Finiti", fontWeight = FontWeight.Bold)
                        }
                        FilledTonalButton(onClick = { moving = true }, modifier = Modifier.weight(1f).height(52.dp), contentPadding = PaddingValues(horizontal = 8.dp)) {
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, null, Modifier.size(20.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Sposta")
                        }
                        OutlinedButton(onClick = { deleteMany(selectedItems) }, modifier = Modifier.weight(1f).height(52.dp), contentPadding = PaddingValues(horizontal = 8.dp)) {
                            Icon(Icons.Filled.Delete, null, Modifier.size(20.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Elimina")
                        }
                    }
                }
            }
        },
        floatingActionButton = {
            if (selected.isEmpty()) {
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (menu) {
                        ExtendedFloatingActionButton(
                            onClick = { menu = false; photo() },
                            icon = { Icon(Icons.Filled.CameraAlt, null) },
                            text = { Text("Foto prodotto") },
                            containerColor = cs.primaryContainer,
                            contentColor = cs.onPrimaryContainer,
                        )
                        ExtendedFloatingActionButton(
                            onClick = { menu = false; fromReceipt = true },
                            icon = { Icon(Icons.Filled.Receipt, null) },
                            text = { Text("Da scontrino") },
                            containerColor = cs.secondaryContainer,
                            contentColor = cs.onSecondaryContainer,
                        )
                        ExtendedFloatingActionButton(
                            onClick = { menu = false; scan() },
                            icon = { Icon(Icons.Filled.QrCodeScanner, null) },
                            text = { Text("Scansiona codice") },
                            containerColor = cs.secondaryContainer,
                            contentColor = cs.onSecondaryContainer,
                        )
                        ExtendedFloatingActionButton(
                            onClick = {
                                menu = false
                                draft = PantryDraft(newItem(shelves.first()), isNew = true, fromScan = false)
                            },
                            icon = { Icon(Icons.Filled.Edit, null) },
                            text = { Text("Manualmente") },
                            containerColor = cs.secondaryContainer,
                            contentColor = cs.onSecondaryContainer,
                        )
                    }
                    ExtendedFloatingActionButton(
                        onClick = { menu = !menu },
                        icon = { Icon(if (menu) Icons.Filled.Close else Icons.Filled.Add, null) },
                        text = { Text(if (menu) "Chiudi" else "Aggiungi") },
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (placeItems.size >= 8 || q.isNotEmpty()) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    singleLine = true,
                    placeholder = { Text(if (isFridge) "Cerca nel frigo" else "Cerca in dispensa") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, contentDescription = "Cancella la ricerca") }
                        }
                    },
                )
            }

            // Riepilogo: quanti prodotti e a che punto sono le scadenze.
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusPill(
                    placeItems.size.toString() + if (placeItems.size == 1) " prodotto" else " prodotti",
                    cs.onSurfaceVariant, if (isFridge) Icons.Filled.Kitchen else Icons.Filled.Inventory2,
                )
                if (late > 0) {
                    StatusPill(late.toString() + if (late == 1) " scaduto" else " scaduti", cs.error, Icons.Filled.ErrorOutline)
                }
                if (soon > 0) {
                    StatusPill(soon.toString() + " da usare presto", cs.tertiary, Icons.Filled.Schedule)
                }
                if (late == 0 && soon == 0 && placeItems.isNotEmpty()) {
                    StatusPill("Tutto sotto controllo", cs.primary, Icons.Filled.CheckCircle)
                }
            }

            if (q.isEmpty() && lateItems.isNotEmpty() && selected.isEmpty()) {
                Card(
                    onClick = { finish(lateItems, relist = true, wasted = true) },
                    colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh, contentColor = cs.onSurface),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = cs.error)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                lateItems.size.toString() + if (lateItems.size == 1) " scaduto: butta e rimetti in lista" else " scaduti: butta e rimetti in lista",
                                style = MaterialTheme.typography.titleMedium,
                            )
                            val lostEuro = lateItems.sumOf { it.price ?: 0.0 }
                            Text(
                                "Escono da qui e vanno nella lista della spesa" + if (lostEuro > 0.0) " · circa " + ReceiptTools.euro(lostEuro) + " buttati" else "",
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                }
            }

            if (q.isEmpty() && toConfirm.isNotEmpty()) {
                Card(
                    onClick = { confirming = true },
                    colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh, contentColor = cs.onSurface),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.EditCalendar, contentDescription = null, tint = cs.primary)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Aggiungi le scadenze", style = MaterialTheme.typography.titleMedium)
                            Text(
                                toConfirm.size.toString() + (if (toConfirm.size == 1) " prodotto ha" else " prodotti hanno") + " una scadenza stimata",
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                }
            }

            if (q.isEmpty()) Card(
                onClick = { onCook(Pantry.cookPrompt(placeItems, place)) },
                enabled = canCook && placeItems.isNotEmpty(),
                colors = CardDefaults.cardColors(
                    containerColor = cs.surfaceContainerHigh,
                    contentColor = cs.onSurface,
                    disabledContainerColor = cs.surfaceContainerHigh,
                    disabledContentColor = cs.onSurfaceVariant,
                ),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Restaurant, contentDescription = null, tint = if (canCook && placeItems.isNotEmpty()) cs.primary else cs.onSurfaceVariant)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Cosa ci cucino?", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (urgentNames.isNotEmpty()) "Usa prima " + urgentNames else "Idee con quello che hai",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }

            run {
                BoxWithConstraints(Modifier.fillMaxWidth()) {
                    val gap = 8.dp
                    // Contenitore 8 dp per lato + ripiano 12 dp per lato: due schede per riga.
                    val cardW: Dp = (maxWidth - 16.dp - 24.dp - gap) / 2
                    Surface(shape = RoundedCornerShape(32.dp), color = cs.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            shelves.forEach { shelf ->
                                val onShelf = Pantry.sorted(
                                    shownItems.filter { (if (it.shelf in shelves) it.shelf else shelves.first()) == shelf },
                                )
                                // Solo i ripiani con prodotti: quelli vuoti si aggiungono dalla scheda in fondo.
                                if (onShelf.isEmpty()) return@forEach
                                Surface(shape = RoundedCornerShape(24.dp), color = cs.surfaceContainerLow, modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                Pantry.shelfEmoji(shelf) + "  " + shelf,
                                                style = MaterialTheme.typography.titleSmall,
                                                modifier = Modifier.weight(1f),
                                            )
                                            FilledTonalIconButton(
                                                onClick = { draft = PantryDraft(newItem(shelf), isNew = true, fromScan = false) },
                                                modifier = Modifier.size(36.dp),
                                            ) { Icon(Icons.Filled.Add, contentDescription = "Aggiungi in $shelf", modifier = Modifier.size(18.dp)) }
                                        }
                                        FlowRow(horizontalArrangement = Arrangement.spacedBy(gap), verticalArrangement = Arrangement.spacedBy(gap)) {
                                            onShelf.forEach { item ->
                                                PantryCard(item, cardW, item.id in selected, { longTapItem(item) }) { tapItem(item) }
                                            }
                                        }
                                    }
                                }
                            }
                            // I ripiani vuoti, come pulsanti per aggiungere un prodotto.
                            val emptyShelves = shelves.filter { sh ->
                                shownItems.none { (if (it.shelf in shelves) it.shelf else shelves.first()) == sh }
                            }
                            if (q.isEmpty() && emptyShelves.isNotEmpty()) {
                                Surface(shape = RoundedCornerShape(24.dp), color = cs.surfaceContainerLow, modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text(
                                            if (emptyShelves.size == shelves.size) "Aggiungi in un ripiano" else "Aggiungi in un altro ripiano",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = cs.onSurfaceVariant,
                                        )
                                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            emptyShelves.forEach { sh ->
                                                FilterChip(
                                                    selected = false,
                                                    onClick = { draft = PantryDraft(newItem(sh), isNew = true, fromScan = false) },
                                                    label = { Text(Pantry.shelfEmoji(sh) + " " + sh) },
                                                    leadingIcon = { Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (q.isNotEmpty() && shownItems.isEmpty()) {
                Text(
                    "Nessun prodotto trovato per «" + query.trim() + "».",
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 8.dp),
                )
            }
            Spacer(Modifier.height(96.dp)) // spazio per il pulsante in basso
        }
        if (menu) {
            // Sfondo scuro: un tocco fuori dal menu lo chiude.
            Box(Modifier.fillMaxSize().background(cs.scrim.copy(alpha = 0.32f)).clickable { menu = false })
        }
        }
    }

    ExpiryNotifyPrompt(store = store, hasExpiry = items.any { it.expiry != null })

    reading?.let { msg ->
        AlertDialog(
            onDismissRequest = {},
            confirmButton = {},
            title = { Text(msg) },
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
                    Spacer(Modifier.width(14.dp))
                    Text("Ci vuole qualche secondo.", color = cs.onSurfaceVariant)
                }
            },
        )
    }

    if (fromReceipt) {
        ReceiptToPantryFlow(
            store = store,
            onReceipt = onReceipt,
            onToStock = {
                onToStock(it)
                notify(if (it.size == 1) "1 prodotto aggiunto" else it.size.toString() + " prodotti aggiunti")
            },
            onDismiss = { fromReceipt = false },
        )
    }

    if (confirming && toConfirm.isNotEmpty()) {
        ExpiryWalkthroughDialog(
            items = toConfirm,
            store = store,
            onDone = { updated ->
                confirming = false
                val byId = updated.associateBy { it.id }
                onChange(items.map { byId[it.id] ?: it })
            },
        )
    }

    if (moving) {
        PantryMoveSheet(
            count = selectedItems.size,
            currentPlace = place,
            onPick = { toPlace, toShelf -> moving = false; moveMany(selectedItems, toPlace, toShelf) },
            onDismiss = { moving = false },
        )
    }

    actions?.let { item ->
        PantryActionsSheet(
            item = item,
            onFinished = { relist -> actions = null; finish(listOf(item), relist) },
            onEdit = { actions = null; draft = PantryDraft(item, isNew = false, fromScan = false) },
            onSelect = { actions = null; selected = setOf(item.id) },
            onDelete = { actions = null; deleteItem(item) },
            onDismiss = { actions = null },
        )
    }

    draft?.let { d ->
        PantryItemDialog(
            draft = d,
            store = store,
            onSave = { item, again ->
                onChange(if (d.isNew) items + item else items.map { if (it.id == item.id) item else it })
                draft = null
                notify(if (d.isNew) "«" + item.name + "» aggiunto" else "Modifiche salvate")
                if (again) { if (d.fromPhoto) photo() else scan() }
            },
            onDismiss = { draft = null },
        )
    }
}

@Composable
private fun StatusPill(text: String, tint: Color, icon: ImageVector) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(cs.surfaceContainerHigh).padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp), tint = tint)
        Spacer(Modifier.width(6.dp))
        Text(text, style = MaterialTheme.typography.labelLarge, color = cs.onSurface)
    }
}

/** Colori della scheda: il contenitore cambia con lo stato, così si capisce anche senza leggere. */
@Composable
private fun freshnessColors(f: Freshness): Pair<Color, Color> {
    val cs = MaterialTheme.colorScheme
    return cs.surfaceContainerHigh to cs.onSurface
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PantryCard(item: PantryItem, width: Dp, selected: Boolean, onLong: () -> Unit, onClick: () -> Unit) {
    val f = Pantry.freshness(item)
    val (bg, fg) = freshnessColors(f)
    val detail = (if (item.qty.isBlank()) "" else item.qty + " · ") + Pantry.labelOf(item)
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = bg,
        contentColor = fg,
        border = if (selected) BorderStroke(3.dp, MaterialTheme.colorScheme.primary) else null,
        modifier = Modifier.width(width).clip(RoundedCornerShape(16.dp)).combinedClickable(onClick = onClick, onLongClick = onLong),
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    item.name,
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                if (selected) Icon(Icons.Filled.CheckCircle, contentDescription = "Selezionato", modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary) else when (f) {
                    Freshness.LATE -> Icon(Icons.Filled.ErrorOutline, contentDescription = "Scaduto", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.error)
                    Freshness.SOON -> Icon(Icons.Filled.Schedule, contentDescription = "Da usare presto", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.tertiary)
                    else -> {}
                }
            }
            Text(
                detail,
                style = MaterialTheme.typography.bodySmall,
                color = fg.copy(alpha = 0.8f),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}

/** Dove spostare i prodotti selezionati: prima i ripiani di questo posto, poi quelli dell'altro. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PantryMoveSheet(count: Int, currentPlace: String, onPick: (String, String) -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val other = if (currentPlace == "dispensa") "frigo" else "dispensa"
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = cs.surfaceContainerHigh,
    ) {
        Column(Modifier.navigationBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 56.dp)) {
            Text(
                if (count == 1) "Sposta 1 prodotto" else "Sposta $count prodotti",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 4.dp),
            )
            Text("Scegli dove vanno. La scadenza resta com'è.", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 4.dp, top = 4.dp))
            listOf(currentPlace, other).forEachIndexed { gi, p ->
                Text(
                    (if (gi == 0) (if (p == "dispensa") "IN QUESTA DISPENSA" else "IN QUESTO FRIGO") else (if (p == "dispensa") "IN DISPENSA" else "NEL FRIGO")),
                    style = MaterialTheme.typography.labelMedium,
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(start = 4.dp, top = 18.dp, bottom = 2.dp),
                )
                Pantry.shelves(p).forEachIndexed { i, sh ->
                    Column(Modifier.fillMaxWidth()) {
                        if (i > 0) HorizontalDivider(color = cs.outlineVariant)
                        Row(
                            Modifier.fillMaxWidth().clickable { onPick(p, sh) }.padding(vertical = 10.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(Modifier.size(40.dp).clip(CircleShape).background(cs.primary.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                                Text(Pantry.shelfEmoji(sh), style = MaterialTheme.typography.titleMedium)
                            }
                            Spacer(Modifier.width(14.dp))
                            Text(sh, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

/** Tenendo premuto un prodotto: Finito in evidenza, poi Modifica, Seleziona più prodotti ed Elimina. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PantryActionsSheet(
    item: PantryItem,
    onFinished: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onSelect: () -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var relist by remember { mutableStateOf(true) }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = cs.surfaceContainerHigh,
    ) {
        Column(Modifier.navigationBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 56.dp)) {
            Row(Modifier.padding(start = 4.dp, bottom = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).clip(CircleShape).background(cs.primary.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center,
                ) { Text(Pantry.shelfEmoji(item.shelf), style = MaterialTheme.typography.titleLarge) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(
                        (if (item.qty.isBlank()) "" else item.qty + " · ") + item.shelf + " · " + Pantry.labelOf(item),
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                }
            }
            Button(onClick = { onFinished(relist) }, modifier = Modifier.fillMaxWidth().height(56.dp)) {
                Icon(Icons.Filled.CheckCircle, null, Modifier.size(22.dp))
                Spacer(Modifier.width(10.dp))
                Text("Finito", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = relist, onCheckedChange = { relist = it })
                Spacer(Modifier.width(12.dp))
                Text("Rimetti nella lista della spesa", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            }
            ChooserRow(icon = Icons.Filled.Edit, title = "Modifica", subtitle = "Nome, quantità, ripiano, scadenza", divider = false, onClick = onEdit)
            ChooserRow(icon = Icons.Filled.Checklist, title = "Seleziona più prodotti", subtitle = "Per segnarli finiti insieme", onClick = onSelect)
            ChooserRow(icon = Icons.Filled.Delete, title = "Elimina", subtitle = "Senza metterlo nella lista; puoi annullare", onClick = onDelete)
        }
    }
}

/** Modifica (o nuovo prodotto): nome con scanner, quantità, ripiano, scadenza. Salva è l'unico tasto pieno. */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun PantryItemDialog(
    draft: PantryDraft,
    store: Store,
    onSave: (PantryItem, Boolean) -> Unit,
    onDismiss: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val shelves = Pantry.shelves(draft.item.place)
    var name by remember { mutableStateOf(draft.item.name) }
    var qty by remember { mutableStateOf(draft.item.qty) }
    var shelf by remember { mutableStateOf(if (draft.item.shelf in shelves) draft.item.shelf else shelves.first()) }
    var expiry by remember { mutableStateOf(draft.item.expiry) }
    // Una scadenza stimata resta "stimata" finché non la si legge dalla foto o la si sceglie a mano.
    var estimated by remember { mutableStateOf(draft.item.estimated) }
    var picking by remember { mutableStateOf(false) }
    val dialogContext = LocalContext.current
    val dialogScope = rememberCoroutineScope()
    var scanningName by remember { mutableStateOf(false) }
    var dateBusy by remember { mutableStateOf(false) }
    var dateNote by remember { mutableStateOf<String?>(null) }
    var dateUri by remember { mutableStateOf<Uri?>(null) }
    val today = Pantry.today()

    fun setDate(day: Long?) {
        expiry = day
        estimated = false
    }

    fun result() = draft.item.copy(
        name = name.trim(), qty = qty.trim(), shelf = shelf, expiry = expiry,
        estimated = estimated && expiry != null,
    )

    /** Legge la data di scadenza dalla foto dell'etichetta (come un OCR). */
    fun readDate(uri: Uri) {
        dialogScope.launch {
            dateBusy = true
            dateNote = null
            val bmp = withContext(Dispatchers.IO) { ImageUtils.load(dialogContext, uri, maxSide = 1600) }
            if (bmp == null) {
                dateNote = "Non riesco ad aprire la foto."
            } else {
                ExpiryTools.read(store.apiKey, store.model, bmp)
                    .onSuccess { day ->
                        store.countRequest()
                        if (day == null) {
                            dateNote = "Non vedo una data di scadenza: scegli la data a mano."
                        } else {
                            setDate(day)
                            dateNote = "Letta dall'etichetta: " + Pantry.dateText(day) + ". Controlla che sia giusta."
                        }
                    }
                    .onFailure { dateNote = it.message ?: "Errore sconosciuto" }
            }
            dateBusy = false
        }
    }

    val takeDate = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) dateUri?.let { readDate(it) }
    }

    fun dateCamera() {
        val dir = File(dialogContext.cacheDir, "photos").apply { mkdirs() }
        val file = File.createTempFile("etichetta", ".jpg", dir)
        val uri = FileProvider.getUriForFile(dialogContext, "${dialogContext.packageName}.fileprovider", file)
        dateUri = uri
        takeDate.launch(uri)
    }

    @Composable
    fun Caption(text: String, right: String = "") {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 18.dp, bottom = 8.dp), verticalAlignment = Alignment.Bottom) {
            Text(text.uppercase(), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant, modifier = Modifier.weight(1f))
            if (right.isNotEmpty()) Text(right, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = cs.surfaceContainerHigh,
    ) {
        Column(Modifier.navigationBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 56.dp)) {
            Text(
                if (draft.isNew) "Nuovo prodotto" else "Modifica prodotto",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 4.dp, bottom = 16.dp),
            )
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nome") },
                singleLine = true,
                trailingIcon = {
                    // Il codice a barre dà il nome preciso (e la quantità) al posto della sigla dello scontrino.
                    IconButton(
                        enabled = !scanningName,
                        onClick = {
                            scanningName = true
                            dialogScope.launch {
                                val scanned = BarcodeTools.scan(dialogContext)
                                val code = scanned.getOrNull()
                                if (scanned.isFailure) {
                                    Toast.makeText(dialogContext, scanned.exceptionOrNull()?.message ?: "Scanner non disponibile.", Toast.LENGTH_LONG).show()
                                } else if (code != null) {
                                    PantryPhoto.fromBarcode(store, draft.item.place, code)
                                        .onSuccess { g ->
                                            name = g.name
                                            if (g.qty.isNotBlank()) qty = g.qty
                                            g.shelf?.let { shelf = it }
                                            // La scadenza stimata si propone solo se non ce n'è già una vera.
                                            if (g.expiry != null && (expiry == null || estimated)) {
                                                expiry = g.expiry
                                                estimated = g.estimated
                                            }
                                        }
                                        .onFailure {
                                            Toast.makeText(dialogContext, it.message ?: "Prodotto non trovato: scrivi tu il nome.", Toast.LENGTH_LONG).show()
                                        }
                                }
                                scanningName = false
                            }
                        },
                    ) { Icon(Icons.Filled.QrCodeScanner, contentDescription = "Scansiona il codice a barre", tint = cs.primary) }
                },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = qty,
                onValueChange = { qty = it },
                label = { Text("Quantità") },
                supportingText = { Text("Pezzi nella confezione, es. 3 o 3 × 100 g") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth(),
            )
            Caption("Ripiano")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                shelves.forEach { sh -> FilterChip(selected = sh == shelf, onClick = { shelf = sh }, label = { Text(sh) }) }
            }
            Caption(
                "Scadenza",
                (expiry?.let { Pantry.dateText(it) + " · " + Pantry.label(it) } ?: "nessuna") + if (estimated && expiry != null) " (stimata)" else "",
            )
            FilledTonalButton(
                onClick = { dateCamera() },
                enabled = !dateBusy && store.apiKey.isNotBlank(),
                modifier = Modifier.fillMaxWidth().height(48.dp),
            ) {
                Icon(Icons.Filled.CameraAlt, null, Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Fotografa la data sull'etichetta")
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = false, onClick = { picking = true }, label = { Text("Scegli la data…") })
                FilterChip(selected = expiry == null, onClick = { setDate(null) }, label = { Text("Nessuna") })
            }
            if (store.apiKey.isBlank()) {
                Text(
                    "Per leggere la data dalla foto serve la chiave API nelle Impostazioni.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
            if (dateBusy) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Leggo la data…", color = cs.onSurfaceVariant)
                }
            }
            dateNote?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp)) }
            Spacer(Modifier.height(24.dp))
            Button(onClick = { onSave(result(), false) }, enabled = name.isNotBlank(), modifier = Modifier.fillMaxWidth().height(54.dp)) {
                Text("Salva", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            if (draft.fromScan || draft.fromPhoto) {
                FilledTonalButton(
                    onClick = { onSave(result(), true) },
                    enabled = name.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp).height(48.dp),
                ) { Text(if (draft.fromPhoto) "Salva e fotografa un altro" else "Salva e scansiona un altro") }
            }
            TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 4.dp)) { Text("Annulla") }
        }
    }

    if (picking) {
        val state = rememberDatePickerState(initialSelectedDateMillis = (expiry ?: today) * 86_400_000L)
        DatePickerDialog(
            onDismissRequest = { picking = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { setDate(it / 86_400_000L) }
                    picking = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { picking = false }) { Text("Annulla") } },
        ) { DatePicker(state = state) }
    }
}
