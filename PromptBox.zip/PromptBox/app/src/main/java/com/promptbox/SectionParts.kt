package com.promptbox

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.Dialog
import androidx.compose.material3.Surface
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.text.font.FontFamily
import org.json.JSONObject
import android.os.ParcelFileDescriptor
import android.graphics.pdf.PdfRenderer
import android.content.Context
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items as lazyRowItems
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.OutlinedButton
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.Switch
import androidx.compose.material3.AlertDialog
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material3.AssistChip
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import android.widget.Toast
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Stop
import androidx.compose.runtime.DisposableEffect
import java.util.Locale
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.TextToSpeech
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Event
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.InputChip
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TextField
import androidx.compose.foundation.border
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Brush
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Parti di supporto della schermata di una sezione (dialoghi, bolle, risposta, barra azioni, composer). */
@Composable
internal fun ArchiveDialog(
    on: Boolean,
    onToggle: (Boolean) -> Unit,
    items: List<DocItem>,
    onOpen: (DocItem) -> Unit,
    onDelete: (DocItem) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Chiudi") } },
        title = { Text("Archivio schede") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Archivia i file che allego", Modifier.weight(1f))
                    Switch(checked = on, onCheckedChange = onToggle)
                }
                Text(
                    if (on) "Un PDF con i DATI SCHEDA in fondo viene salvato qui e l'AI risponde da queste schede."
                    else "Spento: i file allegati vengono solo letti dall'AI, senza salvarli.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (items.isEmpty()) {
                    Text("Nessuna scheda salvata.")
                } else {
                    Text("Tocca una scheda per aprirla.", style = MaterialTheme.typography.labelMedium)
                    LazyColumn(Modifier.heightIn(max = 280.dp)) {
                        lazyRowItems(items) { item ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    (if (item.file != null) "📄 " else "") + item.name,
                                    Modifier.weight(1f).clickable { onOpen(item) }.padding(vertical = 12.dp),
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                IconButton(onClick = { onDelete(item) }) { Icon(Icons.Filled.Delete, "Elimina") }
                            }
                        }
                    }
                }
            }
        },
    )
}

internal fun openPdfExternal(context: Context, file: File) {
    runCatching {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(i)
    }.onFailure { Toast.makeText(context, "Nessuna app per aprire i PDF.", Toast.LENGTH_SHORT).show() }
}

/** Schermo intero con le pagine del PDF salvato, immagini comprese (PdfRenderer di Android). */
@Composable
internal fun PdfViewerDialog(file: File, title: String, onOpenExternal: () -> Unit, onDismiss: () -> Unit) {
    val pages = remember(file) { mutableStateListOf<Bitmap>() }
    var failed by remember(file) { mutableStateOf(false) }
    LaunchedEffect(file) {
        withContext(Dispatchers.IO) {
            var fd: ParcelFileDescriptor? = null
            var renderer: PdfRenderer? = null
            try {
                fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                renderer = PdfRenderer(fd)
                for (i in 0 until renderer.pageCount) {
                    val page = renderer.openPage(i)
                    try {
                        val w = 1100
                        val h = (w.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(android.graphics.Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        pages.add(bmp)
                    } finally {
                        page.close()
                    }
                }
            } catch (e: Exception) {
                failed = true
            } finally {
                runCatching { renderer?.close() }
                runCatching { fd?.close() }
            }
        }
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, "Chiudi") }
                    Text(
                        title,
                        Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.titleMedium,
                    )
                    TextButton(onClick = onOpenExternal) { Text("Apri con…") }
                }
                if (failed && pages.isEmpty()) {
                    Text("Non riesco ad aprire il PDF.", Modifier.padding(16.dp))
                }
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    lazyRowItems(pages) { bmp ->
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = null,
                            contentScale = ContentScale.FillWidth,
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)),
                        )
                    }
                }
            }
        }
    }
}

/** Per le schede archiviate solo con i dati (senza PDF): mostra il JSON. */
@Composable
internal fun JsonDialog(item: DocItem, onDismiss: () -> Unit) {
    val pretty = remember(item.id) { runCatching { JSONObject(item.json).toString(2) }.getOrDefault(item.json) }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Chiudi") } },
        title = { Text(item.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "Solo dati: di questa scheda non c'è un PDF salvato. Riallegalo con l'archivio acceso per salvarlo.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                SelectionContainer { Text(pretty, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall) }
            }
        },
    )
}

@Composable
internal fun UserBubble(turn: ChatTurn, accent: Accent) {
    val cs = MaterialTheme.colorScheme
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
        Column(
            modifier = Modifier
                .widthIn(max = 320.dp)
                .clip(RoundedCornerShape(24.dp, 24.dp, 6.dp, 24.dp))
                .background(accent.container)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (turn.image != null) {
                Image(
                    bitmap = turn.image.asImageBitmap(),
                    contentDescription = "Foto",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(16.dp)),
                )
            } else if (turn.hadImage) {
                Text("📷 Foto", color = accent.onContainer.copy(alpha = 0.8f), style = MaterialTheme.typography.labelLarge)
            }
            if (turn.docName != null) {
                Text("📄 ${turn.docName}", color = accent.onContainer.copy(alpha = 0.8f), style = MaterialTheme.typography.labelLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            if (turn.text.isNotBlank()) {
                SelectionContainer {
                    Text(turn.text, color = accent.onContainer, style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}

/** Divide la risposta in un'introduzione e una parte per ogni titoletto (una proposta per scheda). */
internal fun splitProposals(raw: String): Pair<String, List<String>> {
    val head = Regex("^#{1,6}\\s+.*")
    val intro = StringBuilder()
    val parts = mutableListOf<StringBuilder>()
    for (line in raw.replace("\r", "").lines()) {
        if (head.matches(line.trimEnd())) parts += StringBuilder()
        if (parts.isEmpty()) intro.append(line).append('\n') else parts.last().append(line).append('\n')
    }
    return intro.toString().trim() to parts.map { it.toString().trim() }.filter { it.isNotEmpty() }
}

@Composable
internal fun AiResponse(raw: String, accent: Accent, onLongPress: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val (intro, parts) = remember(raw) { splitProposals(raw) }
    if (parts.size < 2) {
        Card(
            modifier = Modifier.pointerInput(raw) { detectTapGestures(onLongPress = { onLongPress() }) },
            colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh),
            shape = RoundedCornerShape(6.dp, 28.dp, 28.dp, 28.dp),
        ) {
            Column(Modifier.padding(20.dp)) {
                MarkdownText(raw, accent = accent.strong)
            }
        }
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (intro.isNotBlank()) {
            MarkdownText(
                intro,
                Modifier.padding(horizontal = 4.dp).pointerInput(raw) { detectTapGestures(onLongPress = { onLongPress() }) },
                accent = accent.strong,
            )
        }
        // Fino a 5 proposte in colonna; oltre, un carosello orizzontale.
        if (parts.size > 5) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                lazyRowItems(parts) { p -> ProposalCard(p, accent, Modifier.width(300.dp), onLongPress) }
            }
        } else {
            parts.forEach { ProposalCard(it, accent, Modifier.fillMaxWidth(), onLongPress) }
        }
    }
}

@Composable
internal fun ProposalCard(text: String, accent: Accent, modifier: Modifier = Modifier, onLongPress: () -> Unit = {}) {
    Card(
        modifier = modifier.pointerInput(text) { detectTapGestures(onLongPress = { onLongPress() }) },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
        shape = RoundedCornerShape(24.dp),
    ) {
        Column(Modifier.padding(16.dp)) {
            MarkdownText(text, accent = accent.strong)
        }
    }
}

/** Barra azioni fissa in fondo alla risposta: Alla lista, Cosa ci cucino?, Leggi, Timer, Manda a…, Copia, Condividi. */
@Composable
internal fun ResponseActions(
    accent: Accent,
    onToList: (() -> Unit)?,
    onCook: (() -> Unit)?,
    calendarEvents: List<CalEvent>,
    onCalendarOne: (CalEvent) -> Unit,
    onCalendarAll: () -> Unit,
    onSendTo: (() -> Unit)?,
    timers: List<TimerHit>,
    onTimer: (List<TimerHit>) -> Unit,
    speaking: Boolean,
    onSpeak: () -> Unit,
    onCopy: () -> Unit,
    onShare: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val tonal = ButtonDefaults.filledTonalButtonColors(containerColor = accent.container, contentColor = accent.onContainer)
        if (onToList != null) {
            FilledTonalButton(onClick = onToList, colors = tonal) {
                Icon(Icons.Filled.AddShoppingCart, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Alla lista")
            }
        }
        if (onCook != null) {
            FilledTonalButton(onClick = onCook, colors = tonal) {
                Icon(Icons.Filled.Restaurant, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Cosa ci cucino?")
            }
        }
        if (calendarEvents.isNotEmpty()) {
            CalendarFanButton(events = calendarEvents, accent = accent, onOne = onCalendarOne, onAll = onCalendarAll)
        }
        FilledTonalButton(onClick = onSpeak, colors = tonal) {
            Icon(
                if (speaking) Icons.Filled.Stop else Icons.AutoMirrored.Filled.VolumeUp,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
            )
            Spacer(Modifier.width(6.dp))
            Text(if (speaking) "Ferma" else "Leggi")
        }
        if (timers.isNotEmpty()) {
            FilledTonalButton(onClick = { onTimer(timers) }, colors = tonal) {
                Icon(Icons.Filled.Timer, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(if (timers.size == 1) "Timer " + timers[0].label else "Timer")
            }
        }
        if (onSendTo != null) {
            FilledTonalButton(onClick = onSendTo, colors = tonal) {
                Icon(Icons.AutoMirrored.Filled.Send, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Manda a…")
            }
        }
        OutlinedButton(onClick = onCopy) {
            Icon(Icons.Filled.ContentCopy, null, Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Copia")
        }
        OutlinedButton(onClick = onShare) {
            Icon(Icons.Filled.Share, null, Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Condividi")
        }
    }
}

@Composable
internal fun ErrorCard(message: String) {
    val cs = MaterialTheme.colorScheme
    Card(
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh, contentColor = cs.onSurface),
        shape = RoundedCornerShape(24.dp),
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ErrorOutline, null, tint = cs.error)
            Spacer(Modifier.width(12.dp))
            Text(message)
        }
    }
}

/** Colori della sezione: uno stile solo, sempre l'accento viola dell'app (l'indice resta per compatibilità). */
internal class Accent(val container: Color, val onContainer: Color, val strong: Color, val onStrong: Color)

@Composable
internal fun accentFor(index: Int): Accent {
    val cs = MaterialTheme.colorScheme
    return Accent(cs.primaryContainer, cs.onPrimaryContainer, cs.primary, cs.onPrimary)
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
internal fun Composer(
    text: String,
    onText: (String) -> Unit,
    bitmap: Bitmap?,
    onRemovePhoto: () -> Unit,
    docName: String?,
    onRemoveDoc: () -> Unit,
    onPickDoc: () -> Unit,
    archiveCount: Int,
    onArchive: () -> Unit,
    onScan: () -> Unit,
    chips: List<QuickChip>,
    onChip: (String) -> Unit,
    onCamera: () -> Unit,
    onGallery: () -> Unit,
    onMic: () -> Unit,
    onSend: () -> Unit,
    canSend: Boolean,
    followUp: Boolean,
    accent: Accent,
) {
    val cs = MaterialTheme.colorScheme
    var menu by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .background(cs.surfaceContainerHigh, RoundedCornerShape(34.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp),
    ) {
        bitmap?.let { bmp ->
            Box(Modifier.padding(start = 8.dp, top = 6.dp, bottom = 4.dp).clip(RoundedCornerShape(18.dp))) {
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = "Foto",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(88.dp),
                )
                FilledIconButton(
                    onClick = onRemovePhoto,
                    modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).size(26.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = Color.Black.copy(alpha = 0.55f),
                        contentColor = Color.White,
                    ),
                ) { Icon(Icons.Filled.Close, "Rimuovi foto", Modifier.size(14.dp)) }
            }
        }
        docName?.let { n ->
            InputChip(
                selected = true,
                onClick = onRemoveDoc,
                label = { Text(n, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 220.dp)) },
                leadingIcon = { Icon(Icons.Filled.AttachFile, null, Modifier.size(18.dp)) },
                trailingIcon = { Icon(Icons.Filled.Close, "Rimuovi file", Modifier.size(18.dp)) },
                modifier = Modifier.padding(start = 8.dp, top = 6.dp, bottom = 2.dp),
            )
        }
        if (chips.isNotEmpty()) {
            FlowRow(
                modifier = Modifier.fillMaxWidth().padding(start = 6.dp, top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                maxLines = 2,
            ) {
                chips.forEach { c ->
                    AssistChip(onClick = { onChip(c.text) }, label = { Text(c.label) })
                }
            }
        }
        Row(verticalAlignment = Alignment.Bottom) {
            // "+" apre la scelta tra fotocamera e galleria.
            Box(Modifier.padding(bottom = 4.dp)) {
                IconButton(onClick = { menu = true }) {
                    Icon(Icons.Filled.Add, "Aggiungi", tint = cs.onSurface)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Scatta una foto") },
                        leadingIcon = { Icon(Icons.Filled.CameraAlt, null, tint = accent.strong) },
                        onClick = { menu = false; onCamera() },
                    )
                    DropdownMenuItem(
                        text = { Text("Dalla galleria") },
                        leadingIcon = { Icon(Icons.Filled.PhotoLibrary, null, tint = accent.strong) },
                        onClick = { menu = false; onGallery() },
                    )
                    DropdownMenuItem(
                        text = { Text("Da file (PDF, testo)") },
                        leadingIcon = { Icon(Icons.Filled.AttachFile, null, tint = accent.strong) },
                        onClick = { menu = false; onPickDoc() },
                    )
                    DropdownMenuItem(
                        text = { Text(if (archiveCount > 0) "Archivio schede ($archiveCount)" else "Archivio schede") },
                        leadingIcon = { Icon(Icons.Filled.Folder, null, tint = accent.strong) },
                        onClick = { menu = false; onArchive() },
                    )
                    DropdownMenuItem(
                        text = { Text("Scansiona codice a barre") },
                        leadingIcon = { Icon(Icons.Filled.QrCodeScanner, null, tint = accent.strong) },
                        onClick = { menu = false; onScan() },
                    )
                }
            }
            TextField(
                value = text,
                onValueChange = onText,
                modifier = Modifier.weight(1f),
                placeholder = { Text(if (followUp) "Chiedi di più..." else "Scrivi qui...") },
                maxLines = 5,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    disabledContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent,
                    cursorColor = accent.strong,
                ),
            )
            Box(Modifier.padding(bottom = 4.dp)) {
                IconButton(onClick = onMic) { Icon(Icons.Filled.Mic, "Detta a voce", tint = cs.onSurface) }
            }
            FilledIconButton(
                onClick = onSend,
                enabled = canSend,
                modifier = Modifier.padding(start = 2.dp, bottom = 4.dp, end = 2.dp).size(48.dp),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = accent.strong,
                    contentColor = accent.onStrong,
                    disabledContainerColor = accent.container,
                    disabledContentColor = accent.onContainer.copy(alpha = 0.6f),
                ),
            ) { Icon(Icons.AutoMirrored.Filled.Send, "Invia") }
        }
    }
}
