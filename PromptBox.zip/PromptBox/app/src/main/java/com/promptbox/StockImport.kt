package com.promptbox

import kotlinx.coroutines.launch
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.material.icons.filled.QrCodeScanner
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray

/** Un prodotto che sta per entrare in frigo o in dispensa (dalla spesa o da uno scontrino). */
data class StockCandidate(val name: String, val dept: String, val price: Double? = null, val qty: String = "")

/** Dove va un prodotto e quanto dura da oggi. [place] vuoto = non va né in frigo né in dispensa. */
data class StockPlan(val name: String, val place: String, val shelf: String, val days: Int, val price: Double? = null, val qty: String = "")

object Stock {
    private val LADDER = listOf(1, 2, 3, 5, 7, 10, 14, 21, 30, 60, 90, 180, 365, 730)

    /** Proposta veloce in base al reparto (senza AI). "Altro" resta fuori; Casa e igiene va nella scheda Pulizie. */
    fun guess(c: StockCandidate): StockPlan = guessByDept(c).copy(price = c.price, qty = c.qty)

    private fun guessByDept(c: StockCandidate): StockPlan {
        val n = c.name.lowercase()
        return when (c.dept) {
            "Frutta e verdura" -> StockPlan(c.name, "frigo", "Cassetto verdure", 6)
            "Carne e pesce" -> StockPlan(c.name, "frigo", "Carne e pesce", 3)
            "Latticini e uova" -> StockPlan(c.name, "frigo", "Latticini", if ("uov" in n) 21 else 10)
            "Pane e cereali" ->
                if ("pane" in n || "focaccia" in n || "pizza" in n) StockPlan(c.name, "dispensa", "Pasta e cereali", 3)
                else StockPlan(c.name, "dispensa", "Pasta e cereali", 270)
            "Dispensa" -> StockPlan(c.name, "dispensa", "Conserve", 365)
            "Bevande" -> StockPlan(c.name, "dispensa", "Snack e bevande", 120)
            // Surgelati: vanno nel congelatore; [days] è la durata a -18 °C del ripiano.
            "Surgelati" -> {
                val shelf = freezerShelfFor(n)
                StockPlan(c.name, "congelatore", shelf, Freezer.lifeDays(Freezer.defaultMonths(shelf)))
            }
            // Detersivi, igiene, carta: vanno nella scheda Pulizie della Casa, senza scadenza.
            "Casa e igiene" -> StockPlan(c.name, "casa", homeShelfFor(n), 0)
            else -> StockPlan(c.name, "", "", 0)
        }
    }

    /** Il ripiano della Casa più probabile dal nome (lavanderia, bagno e igiene, carta e sacchetti, pulizie). */
    fun homeShelfFor(name: String): String {
        val n = name.lowercase()
        fun has(vararg w: String) = w.any { it in n }
        return when {
            has("detersiv", "ammorbid", "lavatric", "candeggin", "bucato", "smacchiat") -> "Lavanderia"
            has("shampoo", "bagnoschiuma", "docciaschiuma", "dentifric", "spazzolin", "sapone", "deodor", "rasoi", "assorbent", "cotone", "collutor", "balsamo", "crema") -> "Bagno e igiene"
            has("carta", "scottex", "rotol", "sacchett", "pellicola", "alluminio", "fazzolett", "tovagliol", "tovaglio") -> "Carta e sacchetti"
            else -> "Pulizie"
        }
    }

    /** Il ripiano del congelatore più probabile dal nome (pesce, verdure, carne, pane e dolci, piatti pronti). */
    fun freezerShelfFor(name: String): String {
        val n = name.lowercase()
        fun has(vararg w: String) = w.any { it in n }
        return when {
            has("pesce", "mare", "merluzz", "salmon", "gamber", "calamar", "bastoncin", "orata", "branzin", "polpo", "cozze", "vongol") -> "Pesce"
            has("verdur", "spinac", "pisell", "minestron", "fagiolin", "patat", "broccol", "frutti", "mirtill", "fragol", "zucchin", "carciof") -> "Verdure e frutta"
            has("hamburger", "pollo", "manzo", "maiale", "tacchin", "salsicc", "cotolett", "bistecc", "macinat", "carne") -> "Carne"
            has("pane", "cornett", "brioche", "croissant", "torta", "dolce", "gelato", "sfogli") -> "Pane e dolci"
            has("pizza", "lasagn", "sugo", "rag", "zuppa", "crocchett", "arancin", "nuggets", "piatto", "pronto") -> "Pronti e sughi"
            else -> "Altro"
        }
    }

    /** Il ripiano è valido per quel posto? Altrimenti il primo. */
    fun validShelf(place: String, shelf: String): String {
        val shelves = Pantry.shelves(place)
        return if (shelf in shelves) shelf else shelves.first()
    }

    /** Sale o scende di un gradino nella scala dei giorni (1, 2, 3, 5, 7, 10, 14, 21, 30, 60, 90...). */
    fun step(days: Int, up: Boolean): Int =
        if (up) LADDER.firstOrNull { it > days } ?: LADDER.last()
        else LADDER.lastOrNull { it < days } ?: LADDER.first()

    /** I prodotti da aggiungere davvero: solo quelli con un posto. */
    fun toItems(
        plans: List<StockPlan>,
        now: Long = System.currentTimeMillis(),
        today: Long = Pantry.today(),
        freezerTemp: Int = Freezer.DEFAULT_TEMP,
    ): List<PantryItem> =
        plans.filter { it.place.isNotEmpty() && it.name.isNotBlank() }.mapIndexed { i, p ->
            val days = p.days.coerceAtLeast(1)
            val item = PantryItem(
                id = "p$now-$i",
                name = p.name.trim(),
                place = p.place,
                shelf = validShelf(p.place, p.shelf),
                qty = p.qty.trim(),
                expiry = today + days,
                addedAt = now,
                estimated = true,
                price = p.price,
            )
            // Congelatore: i giorni sono la durata a -18 °C, contata da oggi; la scadenza segue la temperatura.
            if (!Pantry.tracksExpiry(p.place, item.shelf)) {
                // Prodotti della casa, o posto/ripiano con le scadenze spente: nessuna data.
                item.copy(expiry = null, estimated = false)
            } else if (p.place == "congelatore") {
                item.copy(frozenAt = today, lifeDays = days, expiry = Freezer.expiry(today, days, freezerTemp), estimated = false)
            } else item
        }

    /** Aggiunge i nuovi prodotti: se c'è già lo stesso nome nello stesso posto, lo rinnova (scadenza nuova) invece di duplicarlo. */
    fun merge(existing: List<PantryItem>, added: List<PantryItem>): List<PantryItem> {
        val out = existing.toMutableList()
        added.forEach { a ->
            val i = out.indexOfFirst { it.place == a.place && it.name.trim().equals(a.name.trim(), ignoreCase = true) }
            if (i >= 0) out[i] = out[i].copy(expiry = a.expiry, addedAt = a.addedAt, estimated = a.estimated, frozenAt = a.frozenAt, lifeDays = a.lifeDays, price = a.price ?: out[i].price, qty = a.qty.ifBlank { out[i].qty }) else out.add(a)
        }
        return out
    }

    /** Legge la risposta dell'AI: un array JSON con nome, luogo, ripiano e giorni. Ciò che manca si completa con [guess]. */
    fun parseAi(raw: String, cands: List<StockCandidate>): List<StockPlan> {
        val clean = raw.replace("```json", "").replace("```", "").trim()
        val a = clean.indexOf('[')
        val b = clean.lastIndexOf(']')
        require(a >= 0 && b > a) { "Risposta non valida." }
        val arr = JSONArray(clean.substring(a, b + 1))
        return cands.mapIndexed { i, c ->
            // Detersivi e simili non li smista l'AI (pensa al cibo): li mette la regola dei reparti.
            if (c.dept == "Casa e igiene") return@mapIndexed guess(c)
            val byName = (0 until arr.length()).map { arr.optJSONObject(it) }
                .firstOrNull { it != null && it.optString("nome").trim().equals(c.name.trim(), ignoreCase = true) }
            val o = byName ?: if (arr.length() == cands.size) arr.optJSONObject(i) else null
            (if (o == null) {
                guess(c)
            } else {
                val place = when (o.optString("luogo").trim().lowercase()) {
                    "frigo" -> "frigo"
                    "dispensa" -> "dispensa"
                    "congelatore" -> "congelatore"
                    else -> ""
                }
                if (place.isEmpty()) StockPlan(c.name, "", "", 0)
                else StockPlan(c.name, place, validShelf(place, o.optString("ripiano").trim()), o.optInt("giorni", 7).coerceIn(1, if (place == "congelatore") 1460 else 1095))
            }).copy(price = c.price, qty = c.qty)
        }
    }
}

/**
 * Finestra "Metti in frigo e dispensa": per ogni prodotto propone posto, ripiano e scadenza (l'AI se c'è la chiave,
 * altrimenti una stima per reparto). Ogni riga si può cambiare prima di confermare.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StockImportDialog(
    candidates: List<StockCandidate>,
    store: Store,
    onConfirm: (List<PantryItem>) -> Unit,
    onDismiss: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var scanningRow by remember { mutableStateOf(-1) }
    // Ciò che l'app ha imparato dalle tue correzioni ha la precedenza sull'AI: i prodotti già visti si smistano da soli.
    val memos = remember { store.productMemory() }
    val known = remember { candidates.map { Learning.find(memos, it.name) } }
    val unknownIdx = remember { candidates.indices.filter { known[it] == null } }
    val plans = remember {
        mutableStateListOf<StockPlan>().also { l ->
            l.addAll(candidates.mapIndexed { i, c -> known[i]?.let { m -> Learning.applyMemo(Stock.guess(c), m) } ?: Stock.guess(c) })
        }
    }
    // Le proposte di partenza: servono a capire quali durate hai cambiato tu.
    var initialPlans by remember { mutableStateOf(plans.toList()) }
    var loading by remember { mutableStateOf(store.apiKey.isNotBlank() && unknownIdx.isNotEmpty()) }
    // Dopo "Aggiungi" si chiede se mettere subito le scadenze vere; le righe confermate restano qui finché non si finisce.
    var pending by remember { mutableStateOf<List<PantryItem>?>(null) }
    var walking by remember { mutableStateOf(false) }
    var note by remember {
        mutableStateOf<String?>(
            when {
                unknownIdx.isEmpty() -> "Smistato come hai corretto le altre volte."
                store.apiKey.isBlank() -> "Scadenze stimate in base al reparto."
                else -> null
            },
        )
    }

    LaunchedEffect(Unit) {
        // L'AI si chiede solo per i prodotti che l'app non conosce ancora.
        if (store.apiKey.isNotBlank() && unknownIdx.isNotEmpty()) {
            GeminiClient.suggestStock(store.apiKey, store.model, unknownIdx.map { candidates[it] })
                .onSuccess { list ->
                    unknownIdx.forEachIndexed { j, idx -> if (j < list.size) plans[idx] = list[j] }
                    initialPlans = plans.toList()
                }
                .onFailure { note = "Scadenze stimate in base al reparto (l'AI non ha risposto)." }
            loading = false
        }
    }

    val walkItems = pending
    if (walking && walkItems != null) {
        ExpiryWalkthroughDialog(items = walkItems, store = store, onDone = { onConfirm(it) })
    } else AlertDialog(
        onDismissRequest = { if (pending == null) onDismiss() },
        title = { Text(if (pending == null) "Metti in frigo e dispensa" else "Scadenze") },
        text = {
            if (pending != null) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Ho preparato " + pending!!.size + (if (pending!!.size == 1) " prodotto" else " prodotti") +
                            " con una scadenza stimata. Vuoi mettere ora le date vere, prodotto per prodotto?",
                    )
                    Text(
                        "Puoi anche farlo dopo: in Frigo e Dispensa trovi \"Aggiungi le scadenze\" finché ce n'è qualcuna stimata.",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                }
            } else if (loading) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(12.dp))
                    Text("Cerco dove va e quanto dura…")
                }
            } else {
                Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    note?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
                    plans.forEachIndexed { i, p ->
                        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            // Il nome si può correggere se l'AI ha letto male lo scontrino.
                            OutlinedTextField(
                                value = p.name,
                                onValueChange = { plans[i] = p.copy(name = it) },
                                singleLine = true,
                                textStyle = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                trailingIcon = {
                                    // Scansiona il codice a barre per avere il nome preciso del prodotto.
                                    IconButton(
                                        enabled = scanningRow < 0,
                                        onClick = {
                                            scanningRow = i
                                            scope.launch {
                                                val scanned = BarcodeTools.scan(context)
                                                val code = scanned.getOrNull()
                                                if (scanned.isFailure) {
                                                    Toast.makeText(context, scanned.exceptionOrNull()?.message ?: "Scanner non disponibile.", Toast.LENGTH_LONG).show()
                                                } else if (code != null) {
                                                    BarcodeTools.product(code)
                                                        .onSuccess { found -> plans[i] = plans[i].copy(name = found.name) }
                                                        .onFailure { Toast.makeText(context, it.message ?: "Prodotto non trovato: scrivi tu il nome.", Toast.LENGTH_LONG).show() }
                                                }
                                                scanningRow = -1
                                            }
                                        },
                                    ) { Icon(Icons.Filled.QrCodeScanner, contentDescription = "Scansiona il codice a barre") }
                                },
                                modifier = Modifier.fillMaxWidth(),
                            )
                            // Quantità letta dallo scontrino (es. "2 x"): si può correggere.
                            OutlinedTextField(
                                value = p.qty,
                                onValueChange = { plans[i] = p.copy(qty = it.take(20)) },
                                singleLine = true,
                                label = { Text("Quantità") },
                                modifier = Modifier.fillMaxWidth(0.5f),
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("frigo" to "Frigo", "dispensa" to "Dispensa", "congelatore" to "Congelatore", "casa" to "Casa", "" to "Salta").forEach { (value, label) ->
                                    FilterChip(
                                        selected = p.place == value,
                                        onClick = {
                                            plans[i] = if (value.isEmpty()) {
                                                p.copy(place = "")
                                            } else {
                                                p.copy(place = value, shelf = Stock.validShelf(value, p.shelf), days = if (p.days <= 0) 7 else p.days)
                                            }
                                        },
                                        label = { Text(label) },
                                    )
                                }
                            }
                            if (p.place.isNotEmpty()) {
                                val shelves = Pantry.shelves(p.place)
                                val shelf = Stock.validShelf(p.place, p.shelf)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    // Un tocco sul ripiano passa al successivo.
                                    TextButton(onClick = { plans[i] = p.copy(shelf = shelves[(shelves.indexOf(shelf) + 1) % shelves.size]) }) {
                                        Text(Pantry.shelfEmoji(shelf) + " " + shelf)
                                    }
                                    Spacer(Modifier.weight(1f))
                                    if (p.place == "casa") {
                                        Text("senza scadenza", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant, modifier = Modifier.padding(end = 12.dp))
                                    } else {
                                    IconButton(onClick = { plans[i] = p.copy(days = Stock.step(p.days, up = false)) }) {
                                        Icon(Icons.Filled.Remove, contentDescription = "Scade prima")
                                    }
                                    Text(
                                        if (p.place == "congelatore") "dura " + Freezer.durationText(p.days) else Pantry.label(Pantry.today() + p.days),
                                        style = MaterialTheme.typography.labelLarge,
                                        modifier = Modifier.padding(horizontal = 2.dp),
                                    )
                                    IconButton(onClick = { plans[i] = p.copy(days = Stock.step(p.days, up = true)) }) {
                                        Icon(Icons.Filled.Add, contentDescription = "Scade dopo")
                                    }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (pending != null) {
                TextButton(onClick = { walking = true }) { Text("Sì, adesso") }
            } else {
                TextButton(
                    enabled = !loading && plans.any { it.place.isNotEmpty() && it.name.isNotBlank() },
                    onClick = {
                        // L'app impara da quello che hai scelto: la prossima volta lo stesso prodotto si smista da solo.
                        val finalPlans = plans.toList()
                        val start = initialPlans
                        val learned = candidates.indices.map { i ->
                            Triple(candidates[i].name, finalPlans[i], start.getOrNull(i)?.days ?: finalPlans[i].days)
                        }
                        store.inBackground { store.saveProductMemory(Learning.learn(store.productMemory(), learned, System.currentTimeMillis())) }
                        pending = Stock.toItems(plans, freezerTemp = store.freezerTemp)
                    },
                ) { Text("Aggiungi") }
            }
        },
        dismissButton = {
            if (pending != null) {
                TextButton(onClick = { onConfirm(pending!!) }) { Text("Più tardi") }
            } else {
                TextButton(onClick = onDismiss) { Text("Annulla") }
            }
        },
    )
}
