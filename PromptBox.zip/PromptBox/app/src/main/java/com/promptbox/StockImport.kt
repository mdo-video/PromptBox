package com.promptbox

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray

/** Un prodotto che sta per entrare in frigo o in dispensa (dalla spesa o da uno scontrino). */
data class StockCandidate(val name: String, val dept: String)

/** Dove va un prodotto e quanto dura da oggi. [place] vuoto = non va né in frigo né in dispensa. */
data class StockPlan(val name: String, val place: String, val shelf: String, val days: Int)

object Stock {
    private val LADDER = listOf(1, 2, 3, 5, 7, 10, 14, 21, 30, 60, 90, 180, 365, 730)

    /** Proposta veloce in base al reparto (senza AI). Surgelati, casa e igiene e "Altro" restano fuori. */
    fun guess(c: StockCandidate): StockPlan {
        val n = c.name.lowercase()
        return when (c.dept) {
            "Frutta e verdura" -> StockPlan(c.name, "frigo", "Cassetto verdure", 6)
            "Carne e pesce" -> StockPlan(c.name, "frigo", "Carne e pesce", 3)
            "Latticini e uova" -> StockPlan(c.name, "frigo", "Latticini", if ("uov" in n) 21 else 10)
            "Pane e cereali" ->
                if ("pane" in n || "focaccia" in n || "pizza" in n) StockPlan(c.name, "dispensa", "Pasta e cereali", 3)
                else StockPlan(c.name, "dispensa", "Pasta e cereali", 270)
            "Dispensa" -> StockPlan(c.name, "dispensa", "Conserve", 365)
            "Bevande" -> StockPlan(c.name, "dispensa", "Snack e bevande", 120)
            else -> StockPlan(c.name, "", "", 0)
        }
    }

    /** Il ripiano è valido per quel posto? Altrimenti il primo. */
    fun validShelf(place: String, shelf: String): String {
        val shelves = Pantry.shelves(place)
        return if (shelf in shelves) shelf else shelves.first()
    }

    /** Sale o scende di un gradino nella scala dei giorni (1, 2, 3, 5, 7, 10, 14, 21, 30, 60, 90...). */
    fun step(days: Int, up: Boolean): Int =
        if (up) LADDER.firstOrNull { it > days } ?: LADDER.last()
        else LADDER.lastOrNull { it < days } ?: LADDER.first()

    /** I prodotti da aggiungere davvero: solo quelli con un posto. */
    fun toItems(plans: List<StockPlan>, now: Long = System.currentTimeMillis(), today: Long = Pantry.today()): List<PantryItem> =
        plans.filter { it.place.isNotEmpty() && it.name.isNotBlank() }.mapIndexed { i, p ->
            PantryItem(
                id = "p$now-$i",
                name = p.name.trim(),
                place = p.place,
                shelf = validShelf(p.place, p.shelf),
                qty = "",
                expiry = today + p.days.coerceAtLeast(1),
                addedAt = now,
                estimated = true,
            )
        }

    /** Aggiunge i nuovi prodotti: se c'è già lo stesso nome nello stesso posto, lo rinnova (scadenza nuova) invece di duplicarlo. */
    fun merge(existing: List<PantryItem>, added: List<PantryItem>): List<PantryItem> {
        val out = existing.toMutableList()
        added.forEach { a ->
            val i = out.indexOfFirst { it.place == a.place && it.name.trim().equals(a.name.trim(), ignoreCase = true) }
            if (i >= 0) out[i] = out[i].copy(expiry = a.expiry, addedAt = a.addedAt, estimated = a.estimated) else out.add(a)
        }
        return out
    }

    /** Legge la risposta dell'AI: un array JSON con nome, luogo, ripiano e giorni. Ciò che manca si completa con [guess]. */
    fun parseAi(raw: String, cands: List<StockCandidate>): List<StockPlan> {
        val clean = raw.replace("```json", "").replace("```", "").trim()
        val a = clean.indexOf('[')
        val b = clean.lastIndexOf(']')
        require(a >= 0 && b > a) { "Risposta non valida." }
        val arr = JSONArray(clean.substring(a, b + 1))
        return cands.mapIndexed { i, c ->
            val byName = (0 until arr.length()).map { arr.optJSONObject(it) }
                .firstOrNull { it != null && it.optString("nome").trim().equals(c.name.trim(), ignoreCase = true) }
            val o = byName ?: if (arr.length() == cands.size) arr.optJSONObject(i) else null
            if (o == null) {
                guess(c)
            } else {
                val place = when (o.optString("luogo").trim().lowercase()) {
                    "frigo" -> "frigo"
                    "dispensa" -> "dispensa"
                    else -> ""
                }
                if (place.isEmpty()) StockPlan(c.name, "", "", 0)
                else StockPlan(c.name, place, validShelf(place, o.optString("ripiano").trim()), o.optInt("giorni", 7).coerceIn(1, 1095))
            }
        }
    }
}

/**
 * Finestra "Metti in frigo e dispensa": per ogni prodotto propone posto, ripiano e scadenza (l'AI se c'è la chiave,
 * altrimenti una stima per reparto). Ogni riga si può cambiare prima di confermare.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StockImportDialog(
    candidates: List<StockCandidate>,
    store: Store,
    onConfirm: (List<PantryItem>) -> Unit,
    onDismiss: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val plans = remember { mutableStateListOf<StockPlan>().also { l -> l.addAll(candidates.map { Stock.guess(it) }) } }
    var loading by remember { mutableStateOf(store.apiKey.isNotBlank()) }
    // Dopo "Aggiungi" si chiede se mettere subito le scadenze vere; le righe confermate restano qui finché non si finisce.
    var pending by remember { mutableStateOf<List<PantryItem>?>(null) }
    var walking by remember { mutableStateOf(false) }
    var note by remember {
        mutableStateOf<String?>(if (store.apiKey.isBlank()) "Scadenze stimate in base al reparto." else null)
    }

    LaunchedEffect(Unit) {
        if (store.apiKey.isNotBlank()) {
            GeminiClient.suggestStock(store.apiKey, store.model, candidates)
                .onSuccess { list ->
                    plans.clear()
                    plans.addAll(list)
                }
                .onFailure { note = "Scadenze stimate in base al reparto (l'AI non ha risposto)." }
            loading = false
        }
    }

    val walkItems = pending
    if (walking && walkItems != null) {
        ExpiryWalkthroughDialog(items = walkItems, store = store, onDone = { onConfirm(it) })
    } else AlertDialog(
        onDismissRequest = { if (pending == null) onDismiss() },
        title = { Text(if (pending == null) "Metti in frigo e dispensa" else "Scadenze") },
        text = {
            if (pending != null) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Ho preparato " + pending!!.size + (if (pending!!.size == 1) " prodotto" else " prodotti") +
                            " con una scadenza stimata. Vuoi mettere ora le date vere, prodotto per prodotto?",
                    )
                    Text(
                        "Puoi anche farlo dopo: in Frigo e Dispensa trovi \"Aggiungi le scadenze\" finché ce n'è qualcuna stimata.",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                }
            } else if (loading) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(12.dp))
                    Text("Cerco dove va e quanto dura…")
                }
            } else {
                Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    note?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
                    plans.forEachIndexed { i, p ->
                        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            // Il nome si può correggere se l'AI ha letto male lo scontrino.
                            OutlinedTextField(
                                value = p.name,
                                onValueChange = { plans[i] = p.copy(name = it) },
                                singleLine = true,
                                textStyle = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                modifier = Modifier.fillMaxWidth(),
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("frigo" to "Frigo", "dispensa" to "Dispensa", "" to "Salta").forEach { (value, label) ->
                                    FilterChip(
                                        selected = p.place == value,
                                        onClick = {
                                            plans[i] = if (value.isEmpty()) {
                                                p.copy(place = "")
                                            } else {
                                                p.copy(place = value, shelf = Stock.validShelf(value, p.shelf), days = if (p.days <= 0) 7 else p.days)
                                            }
                                        },
                                        label = { Text(label) },
                                    )
                                }
                            }
                            if (p.place.isNotEmpty()) {
                                val shelves = Pantry.shelves(p.place)
                                val shelf = Stock.validShelf(p.place, p.shelf)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    // Un tocco sul ripiano passa al successivo.
                                    TextButton(onClick = { plans[i] = p.copy(shelf = shelves[(shelves.indexOf(shelf) + 1) % shelves.size]) }) {
                                        Text(Pantry.shelfEmoji(shelf) + " " + shelf)
                                    }
                                    Spacer(Modifier.weight(1f))
                                    IconButton(onClick = { plans[i] = p.copy(days = Stock.step(p.days, up = false)) }) {
                                        Icon(Icons.Filled.Remove, contentDescription = "Scade prima")
                                    }
                                    Text(
                                        Pantry.label(Pantry.today() + p.days),
                                        style = MaterialTheme.typography.labelLarge,
                                        modifier = Modifier.padding(horizontal = 2.dp),
                                    )
                                    IconButton(onClick = { plans[i] = p.copy(days = Stock.step(p.days, up = true)) }) {
                                        Icon(Icons.Filled.Add, contentDescription = "Scade dopo")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (pending != null) {
                TextButton(onClick = { walking = true }) { Text("Sì, adesso") }
            } else {
                TextButton(
                    enabled = !loading && plans.any { it.place.isNotEmpty() && it.name.isNotBlank() },
                    onClick = { pending = Stock.toItems(plans) },
                ) { Text("Aggiungi") }
            }
        },
        dismissButton = {
            if (pending != null) {
                TextButton(onClick = { onConfirm(pending!!) }) { Text("Più tardi") }
            } else {
                TextButton(onClick = onDismiss) { Text("Annulla") }
            }
        },
    )
}
