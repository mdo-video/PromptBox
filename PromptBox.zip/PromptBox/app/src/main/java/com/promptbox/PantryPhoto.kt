package com.promptbox

import android.graphics.Bitmap
import org.json.JSONObject

/**
 * Quello che si capisce di un prodotto da una foto e/o dal codice a barre.
 * Un campo vuoto (o null) vuol dire "non l'ho trovato": lo lascia libero all'utente.
 */
data class PantryGuess(
    val name: String,
    /** Ripiano scelto dall'AI tra quelli del posto (frigo o dispensa); null = non deciso. */
    val shelf: String?,
    /** Es. "3" (tre pezzi), "3 × 100 g", "500 g"; vuoto = non si sa. */
    val qty: String,
    /** Giorno di scadenza: letto dalla foto, oppure stimato (vedi [estimated]); null = niente. */
    val expiry: Long?,
    val estimated: Boolean,
    /** Codice a barre, solo se letto con cifra di controllo corretta. */
    val barcode: String?,
)

/**
 * Da una sola foto della confezione (o dal codice a barre) a un prodotto già compilato:
 * nome, ripiano, quantità nella confezione, scadenza se si vede. Il resto si rifinisce a mano.
 */
object PantryPhoto {
    private const val PRIMARY_MODEL = "gemini-3.7-flash"
    private const val SECOND_MODEL = "gemini-3.5-flash"

    internal fun system(place: String): String {
        val where = if (place == "dispensa") "dispensa" else "frigo"
        val shelves = Pantry.shelves(place).joinToString(", ")
        return "Ti arriva la foto di un prodotto (confezione, etichetta, a volte anche il codice a barre o la data di scadenza), " +
            "oppure solo il nome di un prodotto. Rispondi SOLO con un oggetto JSON: " +
            "{\"nome\":\"Mozzarella Consilia\",\"ripiano\":\"Latticini\",\"pezzi\":3,\"peso\":\"100 g\"," +
            "\"scadenza\":\"AAAA-MM-GG\",\"codice\":\"8001234567890\",\"giorni\":5}. " +
            "Regole: nome = tipo di prodotto + marca, corto, in italiano, senza peso e senza numeri di confezione; " +
            "ripiano = uno tra: $shelves (il prodotto va in $where); " +
            "pezzi = quanti pezzi o porzioni ci sono nella confezione come si vende (mozzarelle da 3 = 3, yogurt da 2 = 2, uova da 6 = 6); " +
            "1 se è un solo pezzo; se non è scritto usa quello che sai di quel prodotto; " +
            "peso = peso o volume di ogni pezzo (o della confezione, se è un pezzo solo), come \"100 g\" o \"1 l\"; \"\" se non lo sai; " +
            "scadenza = SOLO se la data di scadenza si vede nella foto (\"da consumarsi entro\", \"scad.\", \"TMC\", \"EXP\"): formato AAAA-MM-GG, " +
            "se c'è solo mese e anno l'ultimo giorno di quel mese, altrimenti \"\"; " +
            "codice = le cifre del codice a barre solo se le leggi con sicurezza, altrimenti \"\"; " +
            "giorni = se la scadenza non si vede, dopo quanti giorni scade in media quel prodotto chiuso e tenuto in $where " +
            "(numero intero), 0 se non lo sai. Non inventare: lascia vuoto ciò che non capisci. " +
            "Se nell'immagine non c'è un prodotto rispondi {\"errore\":\"nessun prodotto\"}."
    }

    private fun str(o: JSONObject, key: String): String = if (o.isNull(key)) "" else o.optString(key).trim()

    /** Giusta se la cifra di controllo (ultima) torna: EAN-8, UPC-A (12) ed EAN-13. */
    fun validEan(code: String): Boolean {
        if (code.length != 8 && code.length != 12 && code.length != 13) return false
        if (!code.all { it in '0'..'9' }) return false
        val d = code.map { it - '0' }
        var sum = 0
        for (i in 0 until d.size - 1) {
            val fromCheck = d.size - 1 - i
            sum += d[i] * (if (fromCheck % 2 == 1) 3 else 1)
        }
        return (10 - sum % 10) % 10 == d.last()
    }

    /** Il testo della quantità: "3 × 100 g", "3", "500 g" oppure vuoto. */
    fun qtyText(pieces: Int, weight: String): String {
        val w = weight.trim()
        return when {
            pieces > 1 && w.isNotEmpty() -> "$pieces × $w"
            pieces > 1 -> pieces.toString()
            else -> w
        }.take(20)
    }

    private val MULTI = Regex("""^\s*(\d{1,3})\s*[x×*]\s*(.+)$""", RegexOption.IGNORE_CASE)
    private val WEIGHT = Regex("""^\d+([.,]\d+)?\s*(kg|g|gr|ml|cl|l)\b.*$""", RegexOption.IGNORE_CASE)
    private val COUNT = Regex("""^\s*(\d{1,3})\s+\S+.*$""")

    /** Dalla quantità di Open Food Facts ("3 x 100 g", "125 g", "6 uova") alla quantità dell'app. */
    fun qtyFromOff(quantity: String): String {
        val q = quantity.trim()
        if (q.isEmpty()) return ""
        MULTI.find(q)?.let { m ->
            val n = m.groupValues[1].toIntOrNull() ?: 1
            return qtyText(n, m.groupValues[2].replace(Regex("""\s+"""), " "))
        }
        if (WEIGHT.matches(q)) return q.take(20)
        COUNT.find(q)?.let { m ->
            val n = m.groupValues[1].toIntOrNull() ?: 1
            return if (n > 1) n.toString() else ""
        }
        return ""
    }

    /** Dalla risposta dell'AI al prodotto. Lancia un errore leggibile se non c'è un prodotto. */
    internal fun parse(raw: String, place: String, today: Long = Pantry.today()): PantryGuess {
        val clean = raw.replace("```json", "").replace("```", "").trim()
        val a = clean.indexOf('{')
        val b = clean.lastIndexOf('}')
        require(a >= 0 && b > a) { "Non riesco a leggere il prodotto. Riprova con la stessa foto." }
        val o = JSONObject(clean.substring(a, b + 1))
        require(!o.has("errore")) { "Nella foto non vedo un prodotto: inquadra la confezione." }
        val shelves = Pantry.shelves(place)
        val shelf = shelves.firstOrNull { it.equals(str(o, "ripiano"), ignoreCase = true) }
        val pieces = o.optInt("pezzi", 1).coerceIn(1, 999)
        val read = ExpiryTools.parseDate(str(o, "scadenza"))
        val days = o.optInt("giorni", 0)
        val code = str(o, "codice").filter { it.isDigit() }.takeIf { validEan(it) }
        val expiry = read ?: if (days in 1..3650) today + days else null
        return PantryGuess(
            name = str(o, "nome").take(80),
            shelf = shelf,
            qty = qtyText(pieces, str(o, "peso")),
            expiry = expiry,
            estimated = read == null && expiry != null,
            barcode = code,
        )
    }

    private suspend fun ask(store: Store, place: String, bitmap: Bitmap?, text: String): Result<PantryGuess> {
        if (store.apiKey.isBlank()) return Result.failure(RuntimeException("Per leggere il prodotto serve la chiave API nelle Impostazioni."))
        val models = listOf(PRIMARY_MODEL, SECOND_MODEL, store.model).distinct()
        return GeminiClient.askJson(store.apiKey, models, system(place), text, bitmap, maxTokens = 2048)
            .mapCatching { parse(it, place) }
            .onSuccess { store.countRequest() }
    }

    /**
     * Una foto → prodotto compilato. Se nella foto si legge il codice a barre, nome e quantità della confezione
     * si controllano su Open Food Facts: da lì si sa, per esempio, che le mozzarelle si vendono a tre.
     */
    suspend fun fromPhoto(store: Store, place: String, bitmap: Bitmap): Result<PantryGuess> {
        val g = ask(store, place, bitmap, "Leggi il prodotto.").getOrElse { return Result.failure(it) }
        val code = g.barcode ?: return Result.success(g)
        val off = BarcodeTools.product(code).getOrNull() ?: return Result.success(g)
        val offQty = qtyFromOff(off.quantity)
        return Result.success(
            g.copy(
                name = g.name.ifBlank { off.name },
                qty = offQty.ifBlank { g.qty },
            ),
        )
    }

    /**
     * Codice a barre → prodotto compilato: nome e quantità da Open Food Facts, ripiano e scadenza stimata dall'AI.
     * Se l'AI non risponde resta quello che dà Open Food Facts. Fallisce solo se il prodotto non si trova.
     */
    suspend fun fromBarcode(store: Store, place: String, code: String): Result<PantryGuess> {
        val off = BarcodeTools.product(code).getOrElse { return Result.failure(it) }
        val offQty = qtyFromOff(off.quantity)
        val base = PantryGuess(off.name, null, offQty, null, false, code)
        if (store.apiKey.isBlank()) return Result.success(base)
        val hint = "Prodotto: ${off.name}" + (if (off.quantity.isNotBlank()) ", confezione ${off.quantity}" else "") + "."
        val g = ask(store, place, null, hint).getOrNull() ?: return Result.success(base)
        return Result.success(
            g.copy(
                name = off.name,
                qty = offQty.ifBlank { g.qty },
                barcode = code,
            ),
        )
    }
}
