package com.promptbox

import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.net.ssl.SSLException

/**
 * Errori di rete spiegati in italiano e decisione se vale la pena riprovare.
 * Niente dipendenze da Android, così si prova con i test sul JVM.
 */
object NetErrors {

    /**
     * Riprovare da soli ha senso solo se la richiesta non è nemmeno partita (niente rete, server irraggiungibile):
     * così non si spreca una richiesta del piano gratuito e non si rischia di ripetere una risposta già iniziata.
     */
    fun isRetryable(t: Throwable): Boolean = when (t) {
        is UnknownHostException, is ConnectException -> true
        is SocketTimeoutException -> t.message?.contains("connect", ignoreCase = true) == true
        else -> false
    }

    /** Per sincronizzazione e aggiornamenti: errore di rete -> frase chiara, altrimenti il messaggio che c'è (o [fallback]). */
    fun message(t: Throwable, fallback: String): String = when (t) {
        is SocketTimeoutException -> "La connessione è troppo lenta. Riprova tra poco."
        is IOException -> friendly(t)
        else -> t.message ?: fallback
    }

    /** Il messaggio da mostrare: al posto di "Unable to resolve host…" una frase chiara con cosa fare. */
    fun friendly(t: Throwable): String = when (t) {
        is UnknownHostException, is ConnectException ->
            "Nessuna connessione a internet. Controlla la rete e riprova."
        is SocketTimeoutException ->
            "L'AI ci sta mettendo troppo a rispondere. Riprova tra poco."
        is SSLException ->
            "Connessione non sicura o interrotta. Controlla la rete e riprova."
        is IOException ->
            "Connessione interrotta. Riprova."
        else -> t.message ?: "Errore sconosciuto"
    }
}
