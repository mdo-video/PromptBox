package com.promptbox

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.time.ZonedDateTime

/** Una routine: a quest'ora la sezione [sectionId] ti manda una notifica e, toccandola, si apre e la richiesta parte da sola. */
data class Routine(
    val id: String,
    val sectionId: String,
    val title: String, // es. "🛒 SPESA", mostrato nella notifica
    val hour: Int,
    val minute: Int,
    val days: Set<Int>, // 1 = lunedì ... 7 = domenica; vuoto = tutti i giorni
    val text: String,
    val usePantry: Boolean, // aggiunge alla richiesta i prodotti che hai in frigo
    val enabled: Boolean,
)

/** Routine programmate e avvisi di scadenza: allarmi di sistema (inesatti, senza permessi speciali) + notifiche. */
object Reminders {
    const val CHANNEL = "prisma_reminders"
    const val ACTION_ROUTINE = "com.promptbox.ROUTINE"
    const val ACTION_EXPIRY = "com.promptbox.EXPIRY"
    private const val EXPIRY_HOUR = 8
    private const val EXPIRY_ID = "expiry"
    private val DAY_NAMES = listOf("Lun", "Mar", "Mer", "Gio", "Ven", "Sab", "Dom")

    fun dayName(day: Int): String = DAY_NAMES[day - 1]

    fun daysLabel(days: Set<Int>): String =
        if (days.isEmpty() || days.size == 7) "Ogni giorno" else days.sorted().joinToString(" ") { dayName(it) }

    fun timeLabel(hour: Int, minute: Int): String = String.format("%02d:%02d", hour, minute)

    fun listToJson(list: List<Routine>): String {
        val arr = JSONArray()
        list.forEach { r ->
            arr.put(
                JSONObject().put("i", r.id).put("s", r.sectionId).put("t", r.title).put("h", r.hour).put("m", r.minute)
                    .put("d", JSONArray(r.days.sorted())).put("x", r.text).put("p", r.usePantry).put("e", r.enabled),
            )
        }
        return arr.toString()
    }

    fun listFromJson(raw: String?): List<Routine> = runCatching {
        val arr = JSONArray(raw ?: "[]")
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val d = o.optJSONArray("d")
            Routine(
                id = o.getString("i"),
                sectionId = o.getString("s"),
                title = o.optString("t", ""),
                hour = o.optInt("h", 8),
                minute = o.optInt("m", 0),
                days = (0 until (d?.length() ?: 0)).map { d!!.getInt(it) }.toSet(),
                text = o.optString("x", ""),
                usePantry = o.optBoolean("p", false),
                enabled = o.optBoolean("e", true),
            )
        }
    }.getOrDefault(emptyList())

    /** Il prossimo momento (ms) in cui scatta una routine all'ora [hour]:[minute] nei giorni [days]. */
    fun nextRun(hour: Int, minute: Int, days: Set<Int>, now: ZonedDateTime = ZonedDateTime.now()): Long {
        for (d in 0..7) {
            val c = now.toLocalDate().plusDays(d.toLong()).atTime(hour, minute).atZone(now.zone)
            if (c.isAfter(now) && (days.isEmpty() || c.dayOfWeek.value in days)) return c.toInstant().toEpochMilli()
        }
        return now.plusDays(1).toInstant().toEpochMilli()
    }

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val ch = NotificationChannel(CHANNEL, "Routine e scadenze", NotificationManager.IMPORTANCE_DEFAULT)
            ch.description = "Routine programmate e avvisi di scadenza di frigo e dispensa"
            nm.createNotificationChannel(ch)
        }
    }

    private fun alarmIntent(ctx: Context, action: String, id: String): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).setAction(action).putExtra("id", id)
        return PendingIntent.getBroadcast(ctx, (action + id).hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /** Toglie l'allarme di una routine (da usare quando la elimini). */
    fun cancel(ctx: Context, routineId: String) {
        val am = ctx.applicationContext.getSystemService(AlarmManager::class.java) ?: return
        am.cancel(alarmIntent(ctx.applicationContext, ACTION_ROUTINE, routineId))
    }

    /** Rimette in piedi tutti gli allarmi: routine attive e avviso di scadenza delle 8. */
    fun rescheduleAll(ctx: Context, store: Store = Store(ctx.applicationContext)) {
        val app = ctx.applicationContext
        val am = app.getSystemService(AlarmManager::class.java) ?: return
        ensureChannel(app)
        store.routines().forEach { r ->
            val pi = alarmIntent(app, ACTION_ROUTINE, r.id)
            am.cancel(pi)
            if (r.enabled) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextRun(r.hour, r.minute, r.days), pi)
        }
        val ex = alarmIntent(app, ACTION_EXPIRY, EXPIRY_ID)
        am.cancel(ex)
        if (store.expiryNotify) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextRun(EXPIRY_HOUR, 0, emptySet()), ex)
    }

    /** Il testo da mettere nella casella quando apri la sezione dalla notifica. */
    fun routineText(r: Routine, pantry: List<PantryItem>): String {
        val fridge = pantry.filter { it.place == "frigo" }
        val parts = listOfNotNull(
            r.text.trim().ifEmpty { null },
            if (r.usePantry && fridge.isNotEmpty()) Pantry.cookPrompt(fridge, "frigo") else null,
        )
        return parts.joinToString("\n\n")
    }

    private fun open(ctx: Context, action: String, code: Int): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).putExtra("action", action)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun post(
        ctx: Context, id: Int, title: String, text: String, tap: PendingIntent,
        actionLabel: String? = null, actionIntent: PendingIntent? = null,
    ) {
        if (!NotificationManagerCompat.from(ctx).areNotificationsEnabled()) return
        ensureChannel(ctx)
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher_monochrome)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(tap)
            .setAutoCancel(true)
            .apply { if (actionLabel != null && actionIntent != null) addAction(0, actionLabel, actionIntent) }
            .build()
        ctx.getSystemService(NotificationManager::class.java)?.notify(id, n)
    }

    fun postRoutine(ctx: Context, r: Routine) {
        val text = r.text.trim().ifEmpty { "Tocca per avviare." }
        post(ctx, r.id.hashCode(), r.title, text, open(ctx, "routine:" + r.id, r.id.hashCode()))
    }

    /** Testo dell'avviso di scadenza. [place] è la scheda da aprire (frigo o dispensa), [late] quanti sono già scaduti. */
    class ExpiryNote(val title: String, val text: String, val place: String, val late: Int)

    /**
     * Cosa dire stamattina: prima i scaduti, poi quelli che scadono a breve (3 giorni in frigo, 14 in dispensa, come nella schermata).
     * Le scadenze solo stimate sono scritte "circa". null = niente di urgente.
     */
    fun expiryNote(items: List<PantryItem>, today: Long = Pantry.today()): ExpiryNote? {
        // Niente per i ripiani senza scadenze e per i posti con gli avvisi spenti (Impostazioni di ogni posto).
        val dated = items.filter { it.expiry != null && Pantry.tracksExpiry(it.place, it.shelf) && Pantry.notifyOn(it.place) }
        val late = Pantry.sorted(dated.filter { it.expiry!! < today })
        val soon = Pantry.sorted(dated.filter { it.expiry!! in today..(today + Pantry.soonLimit(it.place)) })
        if (late.isEmpty() && soon.isEmpty()) return null

        fun line(head: String, list: List<PantryItem>): String? {
            if (list.isEmpty()) return null
            val shown = list.take(4).joinToString(", ") { it.name + " (" + Pantry.labelOf(it).replaceFirstChar { c -> c.lowercase() } + ")" }
            return head + ": " + shown + if (list.size > 4) " e altri " + (list.size - 4) else ""
        }

        val text = listOfNotNull(line("Scaduti", late), line("In scadenza", soon)).joinToString("\n")
        val title = when {
            late.size == 1 -> "1 prodotto scaduto"
            late.isNotEmpty() -> late.size.toString() + " prodotti scaduti"
            else -> "Da usare presto"
        }
        return ExpiryNote(title, text, (late + soon).first().place, late.size)
    }

    /** Avvisa dei prodotti scaduti o in scadenza (frigo e dispensa). */
    fun postExpiry(ctx: Context, store: Store) {
        val note = expiryNote(store.pantryItems()) ?: return
        val tap = open(ctx, "place:" + note.place, 4242)
        val where = if (KitchenTabs.isCustom(note.place)) KitchenTabs.label(note.place) else note.place
        val label = if (note.late > 0) "Apri $where e rimetti in lista" else "Apri $where"
        post(ctx, 4242, note.title, note.text, tap, label, open(ctx, "place:" + note.place, 4243))
    }
}

/** Riceve gli allarmi (routine e scadenze) e il riavvio del telefono, e rimette gli allarmi a posto. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> Reminders.rescheduleAll(app)
            Reminders.ACTION_ROUTINE -> {
                val store = Store(app)
                val id = intent.getStringExtra("id")
                store.routines().firstOrNull { it.id == id && it.enabled }?.let { Reminders.postRoutine(app, it) }
                Reminders.rescheduleAll(app, store)
            }
            Reminders.ACTION_EXPIRY -> {
                val store = Store(app)
                if (store.expiryNotify) Reminders.postExpiry(app, store)
                Reminders.rescheduleAll(app, store)
            }
        }
    }
}
