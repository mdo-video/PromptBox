package com.promptbox

import android.content.Context
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.coroutines.resume

/**
 * Scanner di codici a barre (ML Kit, schermata fornita da Google Play Services: nessun permesso fotocamera)
 * e ricerca del prodotto su Open Food Facts (gratuito, senza chiave).
 */
object BarcodeTools {

    /** Restituisce il codice letto, oppure null se l'utente ha annullato. */
    suspend fun scan(context: Context): Result<String?> = suspendCancellableCoroutine { cont ->
        val options = GmsBarcodeScannerOptions.Builder()
            .setBarcodeFormats(
                Barcode.FORMAT_EAN_13,
                Barcode.FORMAT_EAN_8,
                Barcode.FORMAT_UPC_A,
                Barcode.FORMAT_UPC_E,
            )
            .build()
        GmsBarcodeScanning.getClient(context, options).startScan()
            .addOnSuccessListener { if (cont.isActive) cont.resume(Result.success(it.rawValue)) }
            .addOnCanceledListener { if (cont.isActive) cont.resume(Result.success(null)) }
            .addOnFailureListener {
                if (cont.isActive) {
                    cont.resume(
                        Result.failure(
                            RuntimeException(
                                "Scanner non disponibile. La prima volta Google scarica un modulo: riprova tra qualche secondo.",
                            ),
                        ),
                    )
                }
            }
    }

    /** Cerca il prodotto e restituisce un testo pronto da mandare all'AI. */
    suspend fun lookup(code: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val fields = "product_name,brands,quantity,ingredients_text,nutriscore_grade,nova_group,nutriments"
            val url = URL("https://world.openfoodfacts.org/api/v2/product/$code.json?fields=$fields")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 20_000
                // Open Food Facts chiede uno User-Agent che identifichi l'app.
                setRequestProperty("User-Agent", "Prisma-Android/1.0 (app personale)")
            }
            val body = try {
                val c = conn.responseCode
                if (c == 404) throw RuntimeException("Prodotto $code non trovato su Open Food Facts.")
                if (c !in 200..299) throw RuntimeException("Open Food Facts non risponde ($c). Riprova.")
                conn.inputStream.bufferedReader().use { it.readText() }
            } finally {
                conn.disconnect()
            }

            val root = JSONObject(body)
            if (root.optInt("status") != 1) throw RuntimeException("Prodotto $code non trovato su Open Food Facts.")
            val p = root.getJSONObject("product")

            val name = p.optString("product_name").ifBlank { "prodotto senza nome" }
            val brand = p.optString("brands")
            val qty = p.optString("quantity")
            val sb = StringBuilder("Prodotto (codice a barre $code): $name")
            if (brand.isNotBlank()) sb.append(" - $brand")
            if (qty.isNotBlank()) sb.append(", $qty")
            sb.append('.')

            val ingredients = p.optString("ingredients_text")
            if (ingredients.isNotBlank()) sb.append("\nIngredienti: ").append(ingredients.trim())

            val n = p.optJSONObject("nutriments")
            if (n != null) {
                val parts = listOf(
                    "energia" to ("energy-kcal_100g" to "kcal"),
                    "proteine" to ("proteins_100g" to "g"),
                    "carboidrati" to ("carbohydrates_100g" to "g"),
                    "di cui zuccheri" to ("sugars_100g" to "g"),
                    "grassi" to ("fat_100g" to "g"),
                    "di cui saturi" to ("saturated-fat_100g" to "g"),
                    "fibre" to ("fiber_100g" to "g"),
                    "sale" to ("salt_100g" to "g"),
                ).mapNotNull { (label, spec) ->
                    val v = n.optDouble(spec.first, Double.NaN)
                    if (v.isNaN()) null else "$label ${format(v)} ${spec.second}"
                }
                if (parts.isNotEmpty()) sb.append("\nValori per 100 g: ").append(parts.joinToString(", ")).append('.')
            }

            val nutri = p.optString("nutriscore_grade")
            val nova = p.optInt("nova_group", 0)
            val extra = buildList {
                if (nutri.isNotBlank() && nutri != "unknown") add("Nutri-Score ${nutri.uppercase()}")
                if (nova in 1..4) add("NOVA $nova")
            }
            if (extra.isNotEmpty()) sb.append('\n').append(extra.joinToString(", ")).append('.')

            sb.append("\n(Dati da Open Food Facts, possono essere incompleti.)")
            sb.toString()
        }
    }

    private fun format(v: Double): String =
        if (v >= 10 || v == Math.floor(v)) String.format(Locale.ITALY, "%.0f", v)
        else String.format(Locale.ITALY, "%.1f", v)
}
