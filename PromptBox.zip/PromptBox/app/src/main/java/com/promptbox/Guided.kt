package com.promptbox

import org.json.JSONArray
import org.json.JSONObject

/** Un campo del modulo guidato di una sezione. Senza [options] è un campo di testo breve. */
data class GuidedField(val label: String, val options: List<String>)

object GuidedFields {
    fun toJson(list: List<GuidedField>): String {
        val arr = JSONArray()
        list.forEach { f ->
            arr.put(JSONObject().put("l", f.label).put("o", JSONArray(f.options)))
        }
        return arr.toString()
    }

    fun fromJson(raw: String?): List<GuidedField> = runCatching {
        val arr = JSONArray(raw ?: "[]")
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val opts = o.optJSONArray("o")
            GuidedField(o.getString("l"), (0 until (opts?.length() ?: 0)).map { opts!!.getString(it) })
        }
    }.getOrDefault(emptyList())

    fun valuesToJson(map: Map<String, String>): String {
        val o = JSONObject()
        map.forEach { (k, v) -> o.put(k, v) }
        return o.toString()
    }

    fun valuesFromJson(raw: String?): Map<String, String> = runCatching {
        val o = JSONObject(raw ?: "{}")
        o.keys().asSequence().associateWith { o.getString(it) }
    }.getOrDefault(emptyMap())

    /** Le scelte fatte, una per riga ("Persone: 2"), da mettere prima del testo scritto. */
    fun prefix(fields: List<GuidedField>, values: Map<String, String>): String =
        fields.mapNotNull { f ->
            values[f.label]?.trim()?.takeIf { it.isNotEmpty() }?.let { f.label + ": " + it }
        }.joinToString("\n")

    /** Legge la proposta dell'AI: un array JSON di {"label": "...", "options": ["..."]}. */
    fun parseSuggestion(raw: String): List<GuidedField> {
        val clean = raw.replace("```json", "").replace("```", "").trim()
        val a = clean.indexOf('[')
        val b = clean.lastIndexOf(']')
        require(a >= 0 && b > a) { "Nessun campo proposto. Riprova." }
        val arr = JSONArray(clean.substring(a, b + 1))
        val out = (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val label = o.optString("label").trim()
            if (label.isEmpty()) return@mapNotNull null
            val opts = o.optJSONArray("options")
            GuidedField(label, (0 until (opts?.length() ?: 0)).map { opts!!.optString(it).trim() }.filter { it.isNotEmpty() }.take(8))
        }.distinctBy { it.label }.take(5)
        require(out.isNotEmpty()) { "Nessun campo proposto. Riprova." }
        return out
    }
}
