package com.promptbox

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.EventRepeat
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/** Routine programmate e avviso di scadenza dei prodotti. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoutinesScreen(store: Store, sections: List<Section>, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    var routines by remember { mutableStateOf(store.routines()) }
    var expiry by remember { mutableStateOf(store.expiryNotify) }
    var notifOn by remember { mutableStateOf(NotificationManagerCompat.from(context).areNotificationsEnabled()) }
    var editing by remember { mutableStateOf<Routine?>(null) }
    var creating by remember { mutableStateOf(false) }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        notifOn = NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    fun ensureNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            permission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun saveRoutines(list: List<Routine>) {
        routines = list
        store.inBackground {
            store.saveRoutines(list)
            Reminders.rescheduleAll(context, store)
        }
    }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text("Routine e avvisi") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
        floatingActionButton = {
            if (sections.isNotEmpty()) {
                ExtendedFloatingActionButton(
                    onClick = { creating = true },
                    icon = { Icon(Icons.Filled.Add, null) },
                    text = { Text("Nuova routine") },
                )
            }
        },
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (!notifOn) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = cs.errorContainer, contentColor = cs.onErrorContainer),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Le notifiche di Prisma sono disattivate", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Senza notifiche routine e avvisi non possono avvisarti. Consenti le notifiche per l'app.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                        TextButton(onClick = { ensureNotifications() }) { Text("Consenti notifiche") }
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.NotificationsActive, null, tint = cs.primary)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Avvisi di scadenza", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Ogni mattina alle 8, se in frigo o in dispensa c'è qualcosa scaduto o che scade entro 3 giorni.",
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant,
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Switch(checked = expiry, onCheckedChange = {
                        expiry = it
                        store.expiryNotify = it
                        if (it) ensureNotifications()
                        Reminders.rescheduleAll(context, store)
                    })
                }
            }

            Text("Routine programmate", style = MaterialTheme.typography.titleSmall, color = cs.primary, modifier = Modifier.padding(top = 8.dp))
            if (routines.isEmpty()) {
                Text(
                    "Una routine è una richiesta che parte a un'ora fissa: arriva la notifica, la tocchi e la sezione si apre con il testo già scritto. " +
                        "Per esempio \"Menù di oggi\" ogni mattina, con quello che hai in frigo.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant,
                )
            }
            routines.forEach { r ->
                Card(
                    onClick = { editing = r },
                    colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                Reminders.timeLabel(r.hour, r.minute) + " · " + Reminders.daysLabel(r.days),
                                style = MaterialTheme.typography.labelLarge,
                                color = cs.primary,
                            )
                            val preview = r.text.trim().ifEmpty { if (r.usePantry) "Con i prodotti del frigo" else "" }
                            if (preview.isNotEmpty()) {
                                Text(preview, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        Spacer(Modifier.width(8.dp))
                        Switch(checked = r.enabled, onCheckedChange = { on ->
                            saveRoutines(routines.map { if (it.id == r.id) it.copy(enabled = on) else it })
                            if (on) ensureNotifications()
                        })
                    }
                }
            }
            Spacer(Modifier.height(88.dp))
        }
    }

    if (creating || editing != null) {
        RoutineDialog(
            initial = editing,
            sections = sections,
            onSave = { r ->
                val exists = routines.any { it.id == r.id }
                saveRoutines(if (exists) routines.map { if (it.id == r.id) r else it } else routines + r)
                if (r.enabled) ensureNotifications()
                creating = false
                editing = null
            },
            onDelete = {
                editing?.let { Reminders.cancel(context, it.id) }
                saveRoutines(routines.filter { it.id != editing?.id })
                creating = false
                editing = null
            },
            onDismiss = {
                creating = false
                editing = null
            },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun RoutineDialog(
    initial: Routine?,
    sections: List<Section>,
    onSave: (Routine) -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var sectionId by remember { mutableStateOf(initial?.sectionId ?: sections.first().id) }
    var hour by remember { mutableStateOf(initial?.hour ?: 8) }
    var minute by remember { mutableStateOf(initial?.minute ?: 0) }
    var days by remember { mutableStateOf(initial?.days ?: emptySet()) }
    var text by remember { mutableStateOf(initial?.text ?: "") }
    var usePantry by remember { mutableStateOf(initial?.usePantry ?: false) }
    var pickingTime by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Nuova routine" else "Modifica routine") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Sezione", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    sections.forEach { s ->
                        FilterChip(
                            selected = s.id == sectionId,
                            onClick = { sectionId = s.id },
                            label = { Text(s.emoji + " " + s.title.lowercase().replaceFirstChar { it.uppercase() }) },
                        )
                    }
                }
                Text("Ora", style = MaterialTheme.typography.labelLarge)
                OutlinedButton(onClick = { pickingTime = true }) {
                    Icon(Icons.Filled.Schedule, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(Reminders.timeLabel(hour, minute))
                }
                Text("Giorni (nessuno = ogni giorno)", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    (1..7).forEach { d ->
                        FilterChip(
                            selected = d in days,
                            onClick = { days = if (d in days) days - d else days + d },
                            label = { Text(Reminders.dayName(d)) },
                        )
                    }
                }
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("Cosa chiedere (es. Menù di oggi)") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.EventRepeat, null, tint = cs.onSurfaceVariant)
                    Spacer(Modifier.width(10.dp))
                    Text("Aggiungi i prodotti che ho in frigo", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = usePantry, onCheckedChange = { usePantry = it })
                }
                if (initial != null) {
                    TextButton(onClick = onDelete) { Text("Elimina routine", color = cs.error) }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = text.isNotBlank() || usePantry,
                onClick = {
                    val s = sections.firstOrNull { it.id == sectionId } ?: sections.first()
                    onSave(
                        Routine(
                            id = initial?.id ?: ("rt" + System.currentTimeMillis()),
                            sectionId = s.id,
                            title = s.emoji + " " + s.title.lowercase().replaceFirstChar { it.uppercase() },
                            hour = hour,
                            minute = minute,
                            days = days,
                            text = text.trim(),
                            usePantry = usePantry,
                            enabled = initial?.enabled ?: true,
                        ),
                    )
                },
            ) { Text("Salva") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annulla") } },
    )

    if (pickingTime) {
        val state = rememberTimePickerState(initialHour = hour, initialMinute = minute, is24Hour = true)
        AlertDialog(
            onDismissRequest = { pickingTime = false },
            confirmButton = {
                TextButton(onClick = {
                    hour = state.hour
                    minute = state.minute
                    pickingTime = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { pickingTime = false }) { Text("Annulla") } },
            text = { TimePicker(state = state) },
        )
    }
}
