package com.promptbox

import java.time.LocalDate

/** Un prodotto in frigo o in dispensa. [expiry] è un giorno (epoch day); null = nessuna scadenza. */
data class PantryItem(
    val id: String,
    val name: String,
    val place: String, // "frigo" | "dispensa"
    val shelf: String,
    val qty: String,
    val expiry: Long?,
    val addedAt: Long,
)

enum class Freshness { OK, SOON, LATE, NONE }

object Pantry {
    val FRIDGE = listOf("Latticini", "Pronti", "Carne e pesce", "Cassetto verdure", "Sportello")
    val PANTRY = listOf("Pasta e cereali", "Conserve", "Colazione e dolci", "Condimenti", "Snack e bevande")

    /** Un'emoji per ogni ripiano, per riconoscerlo a colpo d'occhio. */
    fun shelfEmoji(shelf: String): String = when (shelf) {
        "Latticini" -> "🥛"
        "Pronti" -> "🍱"
        "Carne e pesce" -> "🥩"
        "Cassetto verdure" -> "🥬"
        "Sportello" -> "🧃"
        "Pasta e cereali" -> "🍝"
        "Conserve" -> "🥫"
        "Colazione e dolci" -> "🍪"
        "Condimenti" -> "🧂"
        "Snack e bevande" -> "🍫"
        else -> "📦"
    }

    fun shelves(place: String): List<String> = if (place == "dispensa") PANTRY else FRIDGE

    fun today(): Long = LocalDate.now().toEpochDay()

    /** Fino a quanti giorni dalla scadenza un prodotto è "da usare presto". */
    private fun soonLimit(place: String): Long = if (place == "dispensa") 14L else 3L

    fun freshness(item: PantryItem): Freshness {
        val e = item.expiry ?: return Freshness.NONE
        val d = e - today()
        return when {
            d < 0L -> Freshness.LATE
            d <= soonLimit(item.place) -> Freshness.SOON
            else -> Freshness.OK
        }
    }

    /** "Scade domani", "Tra 5 gg", "Tra 2 mesi"... */
    fun label(expiry: Long?): String {
        val d = (expiry ?: return "Senza scadenza") - today()
        return when {
            d < -1L -> "Scaduto da ${-d} gg"
            d == -1L -> "Scaduto ieri"
            d == 0L -> "Scade oggi"
            d == 1L -> "Scade domani"
            d < 14L -> "Tra $d gg"
            d < 60L -> "Tra ${d / 7} sett."
            else -> "Tra ${d / 30} mesi"
        }
    }

    fun dateText(epochDay: Long): String {
        val d = LocalDate.ofEpochDay(epochDay)
        return String.format("%02d/%02d/%d", d.dayOfMonth, d.monthValue, d.year)
    }

    /** Prima quelli che scadono prima; senza scadenza in fondo. */
    fun sorted(items: List<PantryItem>): List<PantryItem> =
        items.sortedWith(compareBy<PantryItem> { it.expiry ?: Long.MAX_VALUE }.thenBy { it.name.lowercase() })

    /** Testo pronto per la sezione FRIGO: i prodotti in ordine di scadenza. */
    fun cookPrompt(items: List<PantryItem>, place: String): String {
        val where = if (place == "dispensa") "dispensa" else "frigo"
        val list = sorted(items).take(18).joinToString(", ") { it.name + " (" + label(it.expiry).replaceFirstChar { c -> c.lowercase() } + ")" }
        return "Questi sono i prodotti che ho in $where, in ordine di scadenza: $list. " +
            "Proponimi ricette che usino per primi quelli che scadono prima. Cosa posso cucinare?"
    }
}
