package com.promptbox

import java.time.LocalDate

/** Un prodotto in frigo o in dispensa. [expiry] è un giorno (epoch day); null = nessuna scadenza. */
data class PantryItem(
    val id: String,
    val name: String,
    val place: String, // "frigo" | "dispensa"
    val shelf: String,
    val qty: String,
    val expiry: Long?,
    val addedAt: Long,
    /** true = la scadenza è una stima (AI o reparto), non la data stampata sulla confezione. */
    val estimated: Boolean = false,
    /** Quanto è costato (dallo scontrino), se si sa: serve a contare quanto butti quando scade. */
    val price: Double? = null,
    /** Solo congelatore: giorno in cui è stato congelato (la data letta sulla busta, o oggi). */
    val frozenAt: Long? = null,
    /** Solo congelatore: quanti giorni dura a -18 °C. La scadenza si ricalcola da qui se cambia la temperatura. */
    val lifeDays: Int? = null,
)

enum class Freshness { OK, SOON, LATE, NONE }

object Pantry {
    val FRIDGE = listOf("Latticini", "Pronti", "Carne e pesce", "Cassetto verdure", "Sportello")
    val PANTRY = listOf("Pasta e cereali", "Conserve", "Colazione e dolci", "Condimenti", "Snack e bevande")
    val FREEZER = listOf("Carne", "Pesce", "Verdure e frutta", "Pronti e sughi", "Pane e dolci", "Altro")

    /** Un'emoji per ogni ripiano, per riconoscerlo a colpo d'occhio. */
    fun shelfEmoji(shelf: String): String = when (shelf) {
        "Latticini" -> "🥛"
        "Pronti" -> "🍱"
        "Carne e pesce" -> "🥩"
        "Cassetto verdure" -> "🥬"
        "Sportello" -> "🧃"
        "Pasta e cereali" -> "🍝"
        "Conserve" -> "🥫"
        "Colazione e dolci" -> "🍪"
        "Condimenti" -> "🧂"
        "Snack e bevande" -> "🍫"
        "Carne" -> "🥩"
        "Pesce" -> "🐟"
        "Verdure e frutta" -> "🥦"
        "Pronti e sughi" -> "🍲"
        "Pane e dolci" -> "🍞"
        else -> "📦"
    }

    fun shelves(place: String): List<String> = when (place) {
        "dispensa" -> PANTRY
        "congelatore" -> FREEZER
        else -> FRIDGE
    }

    fun today(): Long = LocalDate.now().toEpochDay()

    /** Dal congelatore al frigo: ripiano del frigo e giorni da usare una volta scongelato (carne e pesce 2, il resto 3). */
    fun thawedPlace(shelf: String): Pair<String, Int> = when (shelf) {
        "Carne", "Pesce" -> "Carne e pesce" to 2
        "Verdure e frutta" -> "Cassetto verdure" to 3
        "Pronti e sughi" -> "Pronti" to 3
        else -> "Sportello" to 3
    }

    /** Il prodotto scongelato: va in frigo, perde la scadenza del congelamento e ne ha una nuova di pochi giorni. */
    fun thawed(item: PantryItem, today: Long = today()): PantryItem {
        val (shelf, days) = thawedPlace(item.shelf)
        return item.copy(place = "frigo", shelf = shelf, expiry = today + days, estimated = false, frozenAt = null, lifeDays = null)
    }

    /** Fino a quanti giorni dalla scadenza un prodotto è "da usare presto". */
    fun soonLimit(place: String): Long = when (place) {
        "dispensa" -> 14L
        "congelatore" -> 30L
        else -> 3L
    }

    fun freshness(item: PantryItem): Freshness {
        val e = item.expiry ?: return Freshness.NONE
        val d = e - today()
        return when {
            d < 0L -> Freshness.LATE
            d <= soonLimit(item.place) -> Freshness.SOON
            else -> Freshness.OK
        }
    }

    /** "Scade domani", "Tra 5 gg", "Tra 2 mesi"... */
    fun label(expiry: Long?): String {
        val d = (expiry ?: return "Senza scadenza") - today()
        return when {
            d < -1L -> "Scaduto da ${-d} gg"
            d == -1L -> "Scaduto ieri"
            d == 0L -> "Scade oggi"
            d == 1L -> "Scade domani"
            d < 14L -> "Tra $d gg"
            d < 60L -> "Tra ${d / 7} sett."
            else -> "Tra ${d / 30} mesi"
        }
    }

    /** Come [label], ma con "circa" se la scadenza è solo una stima. */
    fun labelOf(item: PantryItem): String =
        if (item.estimated && item.expiry != null) "circa " + label(item.expiry).replaceFirstChar { it.lowercase() } else label(item.expiry)

    /** Prodotti con scadenza stimata: quelli per cui ha senso chiedere la data vera. */
    fun toConfirm(items: List<PantryItem>): List<PantryItem> = sorted(items.filter { it.estimated })

    /** Reparto della spesa di un prodotto, dal ripiano dove stava. Vuoto = "Altro". */
    fun deptFor(item: PantryItem): String = when (item.shelf) {
        "Carne", "Pesce", "Verdure e frutta", "Pronti e sughi", "Pane e dolci" -> "Surgelati"
        "Latticini" -> "Latticini e uova"
        "Carne e pesce" -> "Carne e pesce"
        "Cassetto verdure" -> "Frutta e verdura"
        "Pasta e cereali" -> "Pane e cereali"
        "Conserve", "Colazione e dolci", "Condimenti" -> "Dispensa"
        else -> ""
    }

    /** I prodotti finiti, pronti per la lista della spesa (solo il nome: la quantità si decide al supermercato). */
    fun toShopping(items: List<PantryItem>): List<ListSuggestion> =
        items.map { ListSuggestion(it.name.trim(), deptFor(it)) }

    fun dateText(epochDay: Long): String {
        val d = LocalDate.ofEpochDay(epochDay)
        return String.format("%02d/%02d/%d", d.dayOfMonth, d.monthValue, d.year)
    }

    /** Prima quelli che scadono prima; senza scadenza in fondo. */
    fun sorted(items: List<PantryItem>): List<PantryItem> =
        items.sortedWith(compareBy<PantryItem> { it.expiry ?: Long.MAX_VALUE }.thenBy { it.name.lowercase() })

    /** Testo pronto per la sezione FRIGO: i prodotti in ordine di scadenza. */
    fun cookPrompt(items: List<PantryItem>, place: String): String {
        val where = when (place) { "dispensa" -> "dispensa"; "congelatore" -> "congelatore"; else -> "frigo" }
        val list = sorted(items).take(18).joinToString(", ") { it.name + " (" + label(it.expiry).replaceFirstChar { c -> c.lowercase() } + ")" }
        return "Questi sono i prodotti che ho in $where, in ordine di scadenza: $list. " +
            "Proponimi ricette che usino per primi quelli che scadono prima. Cosa posso cucinare?"
    }
}
