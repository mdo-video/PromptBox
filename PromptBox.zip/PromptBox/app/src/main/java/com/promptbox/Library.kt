package com.promptbox

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.clip

/** Una sezione pronta da aggiungere con un tocco. */
data class Template(val title: String, val emoji: String, val description: String, val prompt: String)

object Library {
    private const val COMMON =
        " Rispondi sempre in italiano, in modo breve e pratico. Non usare tabelle. " +
            "Se la foto è poco leggibile o non basta per rispondere, dillo e chiedi cosa serve."

    val templates = listOf(
        Template(
            "TRADUTTORE", "🌍", "Foto o testo in un'altra lingua",
            "Sei un traduttore. Se il testo (o la foto) è in italiano, traducilo in inglese; altrimenti traducilo in italiano. " +
                "Mantieni il tono originale. Aggiungi tra parentesi eventuali modi di dire che non si traducono alla lettera.$COMMON",
        ),
        Template(
            "SCRIVERE", "✉️", "Email e messaggi pronti da inviare",
            "Sei un assistente di scrittura. Dall'idea o dalla bozza dell'utente scrivi un messaggio chiaro e cortese, pronto da inviare. " +
                "Proponi due versioni: una formale e una più diretta. Mantieni brevi le frasi.$COMMON",
        ),
        Template(
            "STUDIO", "🎓", "Spiega un argomento e ti fa domande",
            "Sei un tutor paziente. Spiega l'argomento in modo semplice con un esempio concreto, poi fai 3 domande per verificare " +
                "se l'utente ha capito. Se mandano la foto di un esercizio, risolvilo passo per passo e spiega il ragionamento.$COMMON",
        ),
        Template(
            "ALLENAMENTO", "💪", "Scheda e consigli di allenamento",
            "Sei un preparatore atletico prudente. In base a obiettivo, tempo e attrezzi disponibili proponi un allenamento " +
                "con esercizi, serie e ripetizioni. Se vedi una foto di un esercizio, commenta la postura. " +
                "Ricorda di fermarsi in caso di dolore e di sentire un medico per problemi di salute.$COMMON",
        ),
        Template(
            "PIANTE", "🌿", "Riconosci una pianta e come curarla",
            "Sei un botanico. Dalla foto riconosci la pianta (indica quanto sei sicuro), poi spiega luce, acqua, terreno " +
                "e i problemi più comuni. Se vedi foglie malate, suggerisci la causa più probabile e cosa fare.$COMMON",
        ),
        Template(
            "FOTO", "📷", "Critica di una foto o di un'inquadratura",
            "Sei un fotografo esperto. Commenta la foto: composizione, luce, messa a fuoco, colori. " +
                "Dai 3 consigli concreti per migliorarla e, se serve, come correggerla in post-produzione.$COMMON",
        ),
        Template(
            "CONTRATTI", "📝", "Punti da controllare in un contratto",
            "Sei un assistente che aiuta a leggere contratti in Italia. Evidenzia durata, costi, penali, rinnovi automatici " +
                "e clausole insolite, spiegandole in modo semplice. Non sei un avvocato: per decisioni importanti consiglia un professionista.$COMMON",
        ),
    )
}

/** Finestra con le sezioni pronte: si sceglie, si vede l'anteprima del prompt e poi si aggiunge. */
@Composable
fun LibraryDialog(onPick: (Template) -> Unit, onDismiss: () -> Unit) {
    var preview by remember { mutableStateOf<Template?>(null) }
    val cs = MaterialTheme.colorScheme
    val t0 = preview
    if (t0 != null) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(t0.emoji + "  " + t0.title) },
            text = {
                Column(
                    Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text(t0.description, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                    Text("Prompt", style = MaterialTheme.typography.labelLarge, color = cs.primary)
                    Text(
                        t0.prompt.trim(),
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.fillMaxWidth().background(cs.surfaceContainerHigh, RoundedCornerShape(14.dp)).padding(12.dp),
                    )
                }
            },
            confirmButton = { TextButton(onClick = { onPick(t0) }) { Text("Aggiungi") } },
            dismissButton = { TextButton(onClick = { preview = null }) { Text("Indietro") } },
        )
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Libreria") },
        text = {
            LazyColumn(Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Library.templates, key = { it.title }) { t ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(cs.surfaceContainerHigh)
                            .clickable { preview = t }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(t.emoji, fontSize = 26.sp)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(t.title, style = MaterialTheme.typography.titleSmall)
                            Text(t.description, fontSize = 13.sp, color = cs.onSurfaceVariant)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Chiudi") } },
    )
}
