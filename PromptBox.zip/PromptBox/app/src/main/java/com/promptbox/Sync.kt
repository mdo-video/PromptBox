package com.promptbox

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Base64
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.Scopes
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.coroutines.resume

/** Stato della sincronizzazione, passato alle Impostazioni. */
class SyncUi(
    val on: Boolean,
    val email: String,
    val busy: Boolean,
    val message: String?,
    /** Riga di dettaglio: dimensione del file su Drive e stato dei PDF grandi. */
    val detail: String? = null,
    val lastSync: Long,
    val onSignIn: () -> Unit,
    val onSyncNow: () -> Unit,
    val onBackupDrive: () -> Unit,
    val onRestoreDrive: () -> Unit,
    val onSignOut: () -> Unit,
)

sealed interface AuthResult {
    data class Token(val token: String, val email: String) : AuthResult
    data class NeedsConsent(val pendingIntent: PendingIntent) : AuthResult
    data class Failure(val message: String) : AuthResult
}

/** Accesso con Google: chiede solo il permesso per la cartella nascosta di Prisma su Drive. */
object GoogleAuth {
    private const val DRIVE_APPDATA = "https://www.googleapis.com/auth/drive.appdata"

    private fun request(): AuthorizationRequest = AuthorizationRequest.builder()
        .setRequestedScopes(listOf(Scope(DRIVE_APPDATA), Scope(Scopes.EMAIL)))
        .build()

    private fun AuthorizationResult.toAuth(): AuthResult {
        val token = accessToken
        val pending = pendingIntent
        return when {
            token != null -> AuthResult.Token(token, runCatching { toGoogleSignInAccount()?.email }.getOrNull().orEmpty())
            hasResolution() && pending != null -> AuthResult.NeedsConsent(pending)
            else -> AuthResult.Failure("Google non ha concesso l'accesso.")
        }
    }

    private fun friendly(e: Throwable): String {
        val code = (e as? ApiException)?.statusCode
        return when (code) {
            10 -> "Google non riconosce l'app: controlla nome pacchetto e impronta SHA-1 del client Android."
            7 -> "Nessuna connessione a Internet."
            else -> "Accesso non riuscito" + (if (code != null) " (codice $code)." else ": ${e.message}")
        }
    }

    /** Se il permesso è già stato dato risponde subito col token, senza mostrare nulla. */
    suspend fun authorize(context: Context): AuthResult = suspendCancellableCoroutine { cont ->
        Identity.getAuthorizationClient(context).authorize(request())
            .addOnSuccessListener { if (cont.isActive) cont.resume(it.toAuth()) }
            .addOnFailureListener { if (cont.isActive) cont.resume(AuthResult.Failure(friendly(it))) }
    }

    fun fromIntent(context: Context, data: Intent?): AuthResult = runCatching {
        Identity.getAuthorizationClient(context).getAuthorizationResultFromIntent(data).toAuth()
    }.getOrElse { AuthResult.Failure(friendly(it)) }
}

/** Quello che c'è su questo dispositivo e va unito con Drive. */
class LocalSync(
    val sections: List<Section>,
    val deleted: Map<String, Long>,
    val shopping: List<ShopItem>,
    val shoppingDeleted: Map<String, Long>,
    val history: Map<String, Int>,
    val profile: String,
    val profileAt: Long,
    /** Impostazioni condivise (JSON di Store.settingsJson) e quando sono state cambiate. */
    val settings: String,
    val settingsAt: Long,
    /** Frigo, scontrini, routine e campi guidati: ognuno è un blocco intero con la sua data (vedi [SyncBlock]). */
    val blocks: Map<String, SyncBlock> = emptyMap(),
    /** Stato delle chat all'ultima sincronizzazione riuscita (vedi Store.chatsBase), per unire le chat a tre vie. */
    val chatsBase: String? = null,
)

/**
 * Un gruppo di dati che si sincronizza per intero: vince il blocco modificato più di recente.
 * [json] è il contenuto così come lo salva Store, [at] l'ultima modifica (0 = mai toccato su questo dispositivo).
 */
data class SyncBlock(val json: String, val at: Long)

class SyncResult(
    val sections: List<Section>,
    val deleted: Map<String, Long>,
    val changedLocal: Boolean,
    val shopping: List<ShopItem>,
    val shoppingDeleted: Map<String, Long>,
    val changedShopping: Boolean,
    val history: Map<String, Int>,
    val profile: String,
    val profileAt: Long,
    val changedProfile: Boolean,
    val settings: String,
    val settingsAt: Long,
    val changedSettings: Boolean,
    /** Stato dei blocchi dopo l'unione e quali vanno applicati su questo dispositivo. */
    val blocks: Map<String, SyncBlock>,
    val changedBlocks: Set<String>,
    /** Dimensione del file scritto su Drive in questa sincronizzazione (-1 se non è stato riscritto). */
    val uploadedBytes: Long = -1L,
)

internal class Remote(
    val sections: List<Section>,
    val deleted: Map<String, Long>,
    val shopping: List<ShopItem>,
    val shoppingDeleted: Map<String, Long>,
    val history: Map<String, Int>,
    val profile: String,
    val profileAt: Long,
    val settings: String,
    val settingsAt: Long,
    val blocks: Map<String, SyncBlock> = emptyMap(),
)

/**
 * Un solo file (prisma-sync.json) nella cartella nascosta dell'app su Drive.
 * Unione per sezione e per prodotto della spesa: vince la versione modificata più di recente;
 * un'eliminazione più recente di una modifica cancella l'elemento anche sugli altri dispositivi.
 */
object DriveSync {
    private const val NAME = "prisma-sync.json"
    private const val API = "https://www.googleapis.com/drive/v3/files"
    private const val UPLOAD = "https://www.googleapis.com/upload/drive/v3/files"
    private const val BOUNDARY = "prisma_boundary_7d1f"

    suspend fun sync(token: String, local: LocalSync): Result<SyncResult> =
        withContext(Dispatchers.IO) { runCatching { syncBlocking(token, local) } }

    /**
     * Legge il file, unisce e lo riscrive. Se tra la lettura e la scrittura un altro dispositivo ha cambiato il file
     * (la versione su Drive è diversa) si rifà l'unione da capo, fino a 3 volte: così due dispositivi che
     * sincronizzano insieme non si cancellano le modifiche a vicenda.
     */
    private fun syncBlocking(token: String, local: LocalSync): SyncResult {
        for (attempt in 0..2) {
            val fileId = findFile(token)
            val versionBefore = fileId?.let { fileVersion(token, it) }
            val remote = fileId?.let { parse(call("GET", "$API/$it?alt=media", token)) }
            val now = System.currentTimeMillis()
            val blockMerge = mergeBlocks(local.blocks, remote?.blocks.orEmpty(), now, local.chatsBase)
            val merged = merge(local.sections, local.deleted, remote?.sections.orEmpty(), remote?.deleted.orEmpty())
            val shop = mergeShopping(
                local.shopping, local.shoppingDeleted,
                remote?.shopping.orEmpty(), remote?.shoppingDeleted.orEmpty(),
            )
            val history = mergeHistory(local.history, remote?.history.orEmpty())

            // "Su di me": vince la modifica più recente, ma solo se l'utente ha attivato l'opzione.
            // Se è spenta, nel file resta ciò che c'era e sul telefono non cambia nulla.
            var profile = local.profile
            var profileAt = local.profileAt
            var changedProfile = false
            if (remote != null && remote.profileAt > local.profileAt) {
                profile = remote.profile
                profileAt = remote.profileAt
                changedProfile = profile != local.profile
            }
            val fileProfile = profile
            val fileProfileAt = profileAt

            // Impostazioni (tema, colori categorie, account Bring...): vince la modifica più recente.
            var settings = local.settings
            var settingsAt = local.settingsAt
            var changedSettings = false
            if (remote != null && remote.settings.isNotBlank() &&
                (remote.settingsAt > local.settingsAt || local.settingsAt == 0L)
            ) {
                // Un dispositivo che non ha mai cambiato nulla (data 0) prende sempre quelle già su Drive.
                settings = remote.settings
                settingsAt = remote.settingsAt
                changedSettings = settings != local.settings || settingsAt != local.settingsAt
            } else if (local.settingsAt == 0L) {
                settingsAt = System.currentTimeMillis()
            }
            // La chiave API non si perde mai: se le impostazioni scelte non ce l'hanno e l'altra parte sì, si aggiunge.
            val before = settings
            settings = fillSecret(settings, if (settings == local.settings) remote?.settings.orEmpty() else local.settings, "apiKey")
            if (settings != before) changedSettings = true

            var uploadedBytes = -1L
            val remoteSame = remote != null &&
                remote.sections == merged.first && remote.deleted == merged.second &&
                remote.shopping.toSet() == shop.first.toSet() && remote.shoppingDeleted == shop.second &&
                remote.history == history &&
                remote.profile == fileProfile && remote.profileAt == fileProfileAt &&
                remote.settingsAt == settingsAt &&
                secretOf(remote.settings, "apiKey") == secretOf(settings, "apiKey") &&
                remote.blocks == blockMerge.first
            if (!remoteSame) {
                // Il file è cambiato mentre univo (o è comparso adesso)? Allora si ricomincia dalla lettura.
                val changedMeanwhile =
                    if (fileId != null) fileVersion(token, fileId) != versionBefore else findFile(token) != null
                if (changedMeanwhile && attempt < 2) continue
                val payload = serialize(
                    merged.first, merged.second, shop.first, shop.second, history,
                    fileProfile, fileProfileAt, settings, settingsAt, blockMerge.first,
                )
                uploadedBytes = payload.toByteArray().size.toLong()
                upload(token, fileId, payload)
            }
            return SyncResult(
                merged.first, merged.second, merged.first != local.sections,
                shop.first, shop.second, shop.first.toSet() != local.shopping.toSet(),
                history, profile, profileAt, changedProfile,
                settings, settingsAt, changedSettings,
                blockMerge.first, blockMerge.second, uploadedBytes,
            )
        }
        error("Sincronizzazione non riuscita.")
    }

    private const val PDF_PREFIX = "prisma-pdf-"
    private const val MAX_BIG_PDF = 15_000_000L
    private val SAFE_PDF = Regex("[A-Za-z0-9_-]+\\.pdf")

    /** Esito della sincronizzazione dei PDF grandi: caricati, scaricati, ancora in attesa dall'altro dispositivo. */
    class PdfSyncResult(val uploaded: Int, val downloaded: Int, val waiting: Int)

    /** Nomi dei PDF citati dalle schede archiviate di un blocco "docs". */
    internal fun docFiles(docsJson: String): Set<String> = runCatching {
        val items = JSONObject(docsJson).optJSONObject("items") ?: return@runCatching emptySet<String>()
        val out = HashSet<String>()
        items.keys().forEach { k ->
            val arr = JSONArray(items.getString(k))
            for (i in 0 until arr.length()) {
                val n = arr.getJSONObject(i).optString("file")
                if (n.isNotBlank()) out += n
            }
        }
        out
    }.getOrDefault(emptySet())

    /**
     * PDF più grandi di [minBig] (quelli piccoli viaggiano dentro il file principale): ognuno è un file separato
     * "prisma-pdf-<nome>" nella cartella nascosta di Drive, in base64. Carica i grandi che mancano su Drive, scarica
     * quelli citati dalle schede (blocco [docsJson] già unito) che mancano qui, toglie da Drive quelli che nessuna scheda cita.
     */
    suspend fun syncPdfs(token: String, dir: File, docsJson: String?, minBig: Long): Result<PdfSyncResult> =
        withContext(Dispatchers.IO) { runCatching { syncPdfsBlocking(token, dir, docsJson, minBig) } }

    private fun syncPdfsBlocking(token: String, dir: File, docsJson: String?, minBig: Long): PdfSyncResult {
        val referenced = docsJson?.let { docFiles(it) }.orEmpty()
        val locals = dir.listFiles()?.filter { it.isFile && it.name.matches(SAFE_PDF) }.orEmpty()
        val localBig = locals.filter { it.length() > minBig && it.length() <= MAX_BIG_PDF }
        val missing = referenced.filter { it.matches(SAFE_PDF) && !File(dir, it).exists() }
        if (locals.isEmpty() && referenced.isEmpty()) return PdfSyncResult(0, 0, 0)

        val fields = URLEncoder.encode("files(id,name)", "UTF-8")
        val list = JSONObject(call("GET", "$API?spaces=appDataFolder&fields=$fields&pageSize=1000", token)).optJSONArray("files")
        val onDrive = HashMap<String, MutableList<String>>()
        if (list != null) {
            for (i in 0 until list.length()) {
                val o = list.getJSONObject(i)
                val n = o.getString("name")
                if (n.startsWith(PDF_PREFIX)) onDrive.getOrPut(n) { ArrayList() }.add(o.getString("id"))
            }
        }
        var up = 0
        var down = 0
        var waiting = 0
        for (f in localBig) {
            if (PDF_PREFIX + f.name !in onDrive) {
                upload(token, null, Base64.encodeToString(f.readBytes(), Base64.NO_WRAP), PDF_PREFIX + f.name)
                up++
            }
        }
        for (n in missing) {
            val id = onDrive[PDF_PREFIX + n]?.firstOrNull()
            if (id == null) {
                waiting++
                continue
            }
            val text = call("GET", "$API/$id?alt=media", token)
            File(dir, n).writeBytes(Base64.decode(text.trim(), Base64.NO_WRAP))
            down++
        }
        // Pulizia: su Drive restano solo i PDF citati da una scheda o presenti qui; i doppioni (due dispositivi che caricano insieme) si tolgono.
        val keep = referenced + locals.map { it.name }
        for ((name, ids) in onDrive) {
            val n = name.removePrefix(PDF_PREFIX)
            val extra = if (n in keep) ids.drop(1) else ids
            extra.forEach { runCatching { call("DELETE", "$API/$it", token) } }
        }
        return PdfSyncResult(up, down, waiting)
    }

    /** Un valore segreto dentro le impostazioni (JSON), o "" se non c'è. */
    internal fun secretOf(settings: String, key: String): String =
        runCatching { JSONObject(settings).optString(key) }.getOrDefault("")

    /** Se [chosen] non ha il segreto [key] e [other] sì, lo aggiunge a [chosen]. */
    internal fun fillSecret(chosen: String, other: String, key: String): String {
        if (chosen.isBlank() || secretOf(chosen, key).isNotBlank()) return chosen
        val v = secretOf(other, key)
        return if (v.isBlank()) chosen else runCatching { JSONObject(chosen).put(key, v).toString() }.getOrDefault(chosen)
    }

    /** Versione del file su Drive: cambia a ogni scrittura, serve a capire se un altro dispositivo l'ha modificato. */
    private fun fileVersion(token: String, id: String): String =
        JSONObject(call("GET", "$API/$id?fields=version", token)).optString("version")

    /** Blocchi che contano come "vuoti": un dispositivo che li ha solo vuoti non deve cancellare quelli degli altri. */
    internal fun isEmptyBlock(name: String, json: String): Boolean = runCatching {
        when (name) {
            "routines" -> {
                val o = JSONObject(json)
                JSONArray(o.optString("r", "[]")).length() == 0 && !o.optBoolean("x", false) && o.optString("kt", "").isBlank()
            }
            "guided" -> JSONObject(json).length() == 0
            "chats" -> {
                val o = JSONObject(json)
                (o.optJSONObject("cur")?.length() ?: 0) == 0 && JSONArray(o.optString("arch", "[]")).length() == 0
            }
            "docs" -> {
                val o = JSONObject(json)
                listOf("items", "on", "chat").all { (o.optJSONObject(it)?.length() ?: 0) == 0 }
            }
            else -> JSONArray(json).length() == 0
        }
    }.getOrDefault(json.isBlank())

    /** Unisce due liste di oggetti con lo stesso campo "i" (id): prima quelli remoti, poi quelli locali che mancano. */
    private fun unionById(local: JSONArray, remote: JSONArray): JSONArray {
        val out = JSONArray()
        val ids = HashSet<String>()
        for (i in 0 until remote.length()) {
            val o = remote.getJSONObject(i)
            ids += o.optString("i")
            out.put(o)
        }
        for (i in 0 until local.length()) {
            val o = local.getJSONObject(i)
            if (ids.add(o.optString("i"))) out.put(o)
        }
        return out
    }

    /**
     * Primo incontro tra dati che esistevano già su questo dispositivo (data 0) e quelli su Drive:
     * si uniscono per id invece di sostituirli, così nessuno dei due dispositivi perde elementi.
     */
    private fun chatKey(o: JSONObject) = "${o.optBoolean("u")}|${o.optString("t")}"

    /**
     * Due versioni della stessa chat: si tiene la parte comune, poi i messaggi nuovi di entrambe in ordine di ora.
     * Se una è la continuazione dell'altra vince la più lunga.
     */
    internal fun mergeTurns(local: String, remote: String): String {
        val l = JSONArray(local)
        val r = JSONArray(remote)
        var p = 0
        while (p < l.length() && p < r.length() && chatKey(l.getJSONObject(p)) == chatKey(r.getJSONObject(p))) p++
        val out = ArrayList<JSONObject>()
        for (i in 0 until p) out += l.getJSONObject(i)
        val tailL = (p until l.length()).map { l.getJSONObject(it) }
        val tailR = (p until r.length()).map { r.getJSONObject(it) }
        val tail = when {
            tailL.isEmpty() -> tailR
            tailR.isEmpty() -> tailL
            else -> {
                val seen = HashSet<String>()
                (tailR + tailL).filter { seen.add(chatKey(it) + "|" + it.optLong("ts", 0L)) }.sortedBy { it.optLong("ts", 0L) }
            }
        }
        out += tail
        return JSONArray(out.takeLast(40)).toString() // come MAX_TURNS in Store
    }

    /**
     * Unione a tre vie delle chat. [base] è lo stato dell'ultima sincronizzazione: una chat o una chat archiviata che c'era
     * lì e ora manca da un lato è stata cancellata e resta cancellata; una modificata da un solo lato prende quella modifica;
     * se è cambiata su entrambi i lati si uniscono i messaggi ([mergeTurns]).
     */
    internal fun mergeChats(base: String, local: String, remote: String): String {
        val b = JSONObject(base)
        val l = JSONObject(local)
        val r = JSONObject(remote)
        val bc = b.optJSONObject("cur") ?: JSONObject()
        val lc = l.optJSONObject("cur") ?: JSONObject()
        val rc = r.optJSONObject("cur") ?: JSONObject()
        val cur = JSONObject()
        val keys = LinkedHashSet<String>()
        lc.keys().forEach { keys += it }
        rc.keys().forEach { keys += it }
        for (k in keys) {
            val bv = if (bc.has(k)) bc.getString(k) else null
            val lv = if (lc.has(k)) lc.getString(k) else null
            val rv = if (rc.has(k)) rc.getString(k) else null
            val v = when {
                lv == rv -> lv
                lv == bv -> rv
                rv == bv -> lv
                lv == null -> rv
                rv == null -> lv
                else -> mergeTurns(lv, rv)
            }
            if (v != null) cur.put(k, v)
        }
        val ba = JSONArray(b.optString("arch", "[]"))
        val la = JSONArray(l.optString("arch", "[]"))
        val ra = JSONArray(r.optString("arch", "[]"))
        fun ids(a: JSONArray) = (0 until a.length()).map { a.getJSONObject(it).optLong("id") }.toSet()
        val inBase = ids(ba)
        val inLocal = ids(la)
        val inRemote = ids(ra)
        // Una chat archiviata che c'era nella base e manca da un lato è stata eliminata lì.
        val dropped = inBase.filter { it !in inLocal || it !in inRemote }.toSet()
        val arch = unionByLong(la, ra, "id").filter { it.optLong("id") !in dropped }.sortedByDescending { it.optLong("a") }.take(60)
        return JSONObject().put("cur", cur).put("arch", JSONArray(arch).toString()).toString()
    }

    /** Unisce due liste di oggetti con lo stesso campo numerico [field]: prima i remoti, poi i locali che mancano. */
    private fun unionByLong(local: JSONArray, remote: JSONArray, field: String): List<JSONObject> {
        val out = ArrayList<JSONObject>()
        val ids = HashSet<Long>()
        for (i in 0 until remote.length()) {
            val o = remote.getJSONObject(i)
            if (ids.add(o.optLong(field))) out += o
        }
        for (i in 0 until local.length()) {
            val o = local.getJSONObject(i)
            if (ids.add(o.optLong(field))) out += o
        }
        return out
    }

    internal fun unionBlock(name: String, local: String, remote: String): String = runCatching {
        when (name) {
            "chats" -> {
                val l = JSONObject(local)
                val r = JSONObject(remote)
                val cur = JSONObject(r.optJSONObject("cur")?.toString() ?: "{}")
                l.optJSONObject("cur")?.let { lc ->
                    lc.keys().forEach { k ->
                        val lv = lc.getString(k)
                        // Per ogni sezione si tiene la chat con più messaggi.
                        if (!cur.has(k) || JSONArray(lv).length() > JSONArray(cur.getString(k)).length()) cur.put(k, lv)
                    }
                }
                val arch = unionByLong(JSONArray(l.optString("arch", "[]")), JSONArray(r.optString("arch", "[]")), "id")
                    .sortedByDescending { it.optLong("a") }
                    .take(60) // come MAX_ARCHIVE in Store
                JSONObject().put("cur", cur).put("arch", JSONArray(arch).toString()).toString()
            }
            "docs" -> {
                val l = JSONObject(local)
                val r = JSONObject(remote)
                val items = JSONObject(r.optJSONObject("items")?.toString() ?: "{}")
                l.optJSONObject("items")?.let { li ->
                    li.keys().forEach { k ->
                        if (items.has(k)) {
                            items.put(k, JSONArray(unionByLong(JSONArray(li.getString(k)), JSONArray(items.getString(k)), "id")).toString())
                        } else {
                            items.put(k, li.getString(k))
                        }
                    }
                }
                val on = JSONObject(r.optJSONObject("on")?.toString() ?: "{}")
                l.optJSONObject("on")?.let { lo -> lo.keys().forEach { k -> if (!on.has(k) || lo.getBoolean(k)) on.put(k, lo.getBoolean(k) || on.optBoolean(k, false)) } }
                val chat = JSONObject(r.optJSONObject("chat")?.toString() ?: "{}")
                l.optJSONObject("chat")?.let { lc -> lc.keys().forEach { k -> if (!chat.has(k)) chat.put(k, lc.getBoolean(k)) } }
                JSONObject().put("items", items).put("on", on).put("chat", chat).toString()
            }
            "routines" -> {
                val l = JSONObject(local)
                val r = JSONObject(remote)
                JSONObject()
                    .put("r", unionById(JSONArray(l.optString("r", "[]")), JSONArray(r.optString("r", "[]"))).toString())
                    .put("x", l.optBoolean("x", false) || r.optBoolean("x", false))
                    .toString()
            }
            "guided" -> {
                val l = JSONObject(local)
                val out = JSONObject(remote)
                l.keys().forEach { k -> if (!out.has(k)) out.put(k, l.get(k)) }
                out.toString()
            }
            else -> unionById(JSONArray(local), JSONArray(remote)).toString()
        }
    }.getOrDefault(remote)

    /**
     * Frigo, scontrini, routine, campi guidati: per ogni blocco vince quello modificato più di recente.
     * Un blocco mai sincronizzato (data 0) con dati dentro viene unito a quello su Drive invece di essere sostituito.
     * Restituisce lo stato finale dei blocchi e i nomi di quelli da applicare su questo dispositivo.
     */
    fun mergeBlocks(
        local: Map<String, SyncBlock>,
        remote: Map<String, SyncBlock>,
        now: Long,
        chatsBase: String? = null,
    ): Pair<Map<String, SyncBlock>, Set<String>> {
        val out = LinkedHashMap<String, SyncBlock>()
        val changed = LinkedHashSet<String>()
        for (name in local.keys + remote.keys) {
            val l = local[name]
            val r = remote[name]
            if (l == null) {
                if (r != null) {
                    out[name] = r
                    changed += name
                }
                continue
            }
            if (r == null) {
                if (l.at == 0L && !isEmptyBlock(name, l.json)) {
                    // Dati già presenti prima della sincronizzazione e ancora assenti su Drive: prendono la data di adesso.
                    out[name] = SyncBlock(l.json, now)
                    changed += name
                } else {
                    out[name] = l
                }
                continue
            }
            when {
                name == "chats" && chatsBase != null && l.at != 0L && l.json != r.json &&
                    !isEmptyBlock(name, l.json) && !isEmptyBlock(name, r.json) -> {
                    // Chat modificate su due dispositivi: unione a tre vie (non vince l'ultimo, si tengono i messaggi di entrambi).
                    val u = mergeChats(chatsBase, l.json, r.json)
                    if (u == r.json) {
                        out[name] = r
                        changed += name
                    } else {
                        out[name] = SyncBlock(u, now)
                        changed += name
                    }
                }
                l.at == 0L && !isEmptyBlock(name, l.json) -> {
                    val u = unionBlock(name, l.json, r.json)
                    out[name] = SyncBlock(u, if (u == r.json) r.at else now)
                    if (u != l.json || out.getValue(name).at != l.at) changed += name
                }
                r.at > l.at -> {
                    out[name] = r
                    if (r.json != l.json || r.at != l.at) changed += name
                }
                else -> out[name] = l
            }
        }
        return out to changed
    }

    private const val BACKUP_NAME = "prisma-backup.json"

    /** Mette il backup completo nella cartella di Prisma su Drive (sostituisce il precedente). Restituisce l'ora salvata. */
    suspend fun saveBackup(token: String, content: String): Result<Long> = withContext(Dispatchers.IO) {
        runCatching {
            upload(token, findFile(token, BACKUP_NAME), content, BACKUP_NAME)
            System.currentTimeMillis()
        }
    }

    /** Scarica il backup salvato su Drive (null se non ce n'è nessuno). */
    suspend fun loadBackup(token: String): Result<String?> = withContext(Dispatchers.IO) {
        runCatching {
            findFile(token, BACKUP_NAME)?.let { call("GET", "$API/$it?alt=media", token) }
        }
    }

    /** Storico "ricomprare": per ogni prodotto vale il conteggio più alto tra i dispositivi. */
    fun mergeHistory(a: Map<String, Int>, b: Map<String, Int>): Map<String, Int> =
        (a.keys + b.keys).associateWith { maxOf(a[it] ?: 0, b[it] ?: 0) }

    /** Unisce due mappe di eliminazioni tenendo, per ogni chiave, la data più recente. */
    fun mergeDeleted(a: Map<String, Long>, b: Map<String, Long>): Map<String, Long> =
        (a.keys + b.keys).associateWith { maxOf(a[it] ?: 0L, b[it] ?: 0L) }

    /** Lista della spesa: per ogni prodotto vince la modifica più recente; l'ordine è dal più nuovo. */
    fun mergeShopping(
        local: List<ShopItem>,
        localDeleted: Map<String, Long>,
        remote: List<ShopItem>,
        remoteDeleted: Map<String, Long>,
    ): Pair<List<ShopItem>, Map<String, Long>> {
        val deleted = mergeDeleted(localDeleted, remoteDeleted)
        val byKey = LinkedHashMap<String, ShopItem>()
        // Prima il remoto, poi il locale: a parità di data vince quello locale.
        for (i in remote + local) {
            val cur = byKey[i.key]
            if (cur == null || i.updatedAt >= cur.updatedAt) byKey[i.key] = i
        }
        val items = byKey.values
            .filter { i -> deleted[i.key]?.let { it < i.updatedAt } ?: true }
            .sortedWith(compareByDescending<ShopItem> { it.updatedAt }.thenBy { it.key })
        return items to deleted
    }

    fun merge(
        local: List<Section>,
        localDeleted: Map<String, Long>,
        remote: List<Section>,
        remoteDeleted: Map<String, Long>,
    ): Pair<List<Section>, Map<String, Long>> {
        val deleted = (localDeleted.keys + remoteDeleted.keys).associateWith {
            maxOf(localDeleted[it] ?: 0L, remoteDeleted[it] ?: 0L)
        }
        fun dropped(s: Section): Boolean = deleted[s.id]?.let { it >= s.updatedAt } ?: false

        val remoteById = remote.associateBy { it.id }
        val seen = HashSet<String>()
        val result = mutableListOf<Section>()
        for (l in local) {
            seen += l.id
            val r = remoteById[l.id]
            val best = if (r != null && r.updatedAt > l.updatedAt) r else l
            if (!dropped(best)) result += best
        }
        for (r in remote) {
            if (r.id !in seen && !dropped(r)) result += r
        }
        return result to deleted
    }

    private fun findFile(token: String, name: String = NAME): String? {
        val q = URLEncoder.encode("name = '$name'", "UTF-8")
        val fields = URLEncoder.encode("files(id)", "UTF-8")
        val json = JSONObject(call("GET", "$API?spaces=appDataFolder&q=$q&fields=$fields", token))
        val files = json.optJSONArray("files") ?: return null
        return if (files.length() > 0) files.getJSONObject(0).getString("id") else null
    }

    private fun upload(token: String, fileId: String?, content: String, name: String = NAME) {
        if (fileId == null) {
            val meta = JSONObject().put("name", name).put("parents", JSONArray().put("appDataFolder")).toString()
            val body = "--$BOUNDARY\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n" +
                "--$BOUNDARY\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$content\r\n--$BOUNDARY--"
            call(
                "POST", "$UPLOAD?uploadType=multipart", token,
                body.toByteArray(), "multipart/related; boundary=$BOUNDARY",
            )
        } else {
            // HttpURLConnection non conosce PATCH: Google accetta POST con l'header di override.
            call(
                "POST", "$UPLOAD/$fileId?uploadType=media", token,
                content.toByteArray(), "application/json; charset=UTF-8", override = "PATCH",
            )
        }
    }

    internal fun serialize(
        sections: List<Section>,
        deleted: Map<String, Long>,
        shopping: List<ShopItem>,
        shoppingDeleted: Map<String, Long>,
        history: Map<String, Int>,
        profile: String,
        profileAt: Long,
        settings: String = "",
        settingsAt: Long = 0L,
        blocks: Map<String, SyncBlock> = emptyMap(),
    ): String {
        val arr = JSONArray()
        sections.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("title", it.title).put("emoji", it.emoji)
                    .put("hint", it.hint).put("prompt", it.systemPrompt).put("u", it.updatedAt)
                    .put("cat", it.category),
            )
        }
        val del = JSONObject()
        deleted.forEach { (k, v) -> del.put(k, v) }
        val shop = JSONArray()
        shopping.forEach {
            shop.put(JSONObject().put("t", it.text).put("d", it.done).put("u", it.updatedAt).put("p", it.dept))
        }
        val shopDel = JSONObject()
        shoppingDeleted.forEach { (k, v) -> shopDel.put(k, v) }
        val hist = JSONObject()
        history.forEach { (k, v) -> hist.put(k, v) }
        val blk = JSONObject()
        blocks.forEach { (k, b) -> blk.put(k, JSONObject().put("j", b.json).put("at", b.at)) }
        return JSONObject().put("v", 1).put("blocks", blk).put("sections", arr).put("deleted", del)
            .put("shopping", shop).put("shoppingDeleted", shopDel)
            .put("history", hist).put("profile", profile).put("profileAt", profileAt)
            .put("prefs", if (settings.isBlank()) JSONObject() else JSONObject(settings)).put("prefsAt", settingsAt)
            .toString()
    }

    internal fun parse(raw: String): Remote {
        val o = JSONObject(raw)
        val arr = o.optJSONArray("sections") ?: JSONArray()
        val sections = (0 until arr.length()).map { i ->
            val s = arr.getJSONObject(i)
            Section(
                id = s.getString("id"),
                title = s.getString("title"),
                emoji = s.optString("emoji", "📌").ifBlank { "📌" },
                hint = s.optString("hint", "Foto e/o testo"),
                systemPrompt = s.getString("prompt"),
                updatedAt = s.optLong("u", 0L),
                category = s.optString("cat", ""),
            )
        }
        val deleted = mutableMapOf<String, Long>()
        o.optJSONObject("deleted")?.let { d -> d.keys().forEach { k -> deleted[k] = d.getLong(k) } }
        val shopArr = o.optJSONArray("shopping") ?: JSONArray()
        val shopping = (0 until shopArr.length()).map { i ->
            val s = shopArr.getJSONObject(i)
            ShopItem(s.getString("t"), s.optBoolean("d", false), s.optLong("u", 0L), s.optString("p", ""))
        }
        val shopDeleted = mutableMapOf<String, Long>()
        o.optJSONObject("shoppingDeleted")?.let { d -> d.keys().forEach { k -> shopDeleted[k] = d.getLong(k) } }
        val history = mutableMapOf<String, Int>()
        o.optJSONObject("history")?.let { d -> d.keys().forEach { k -> history[k] = d.getInt(k) } }
        val blocks = LinkedHashMap<String, SyncBlock>()
        o.optJSONObject("blocks")?.let { d ->
            d.keys().forEach { k ->
                val b = d.optJSONObject(k) ?: return@forEach
                blocks[k] = SyncBlock(b.optString("j", ""), b.optLong("at", 0L))
            }
        }
        return Remote(
            sections, deleted, shopping, shopDeleted, history,
            o.optString("profile", ""), o.optLong("profileAt", 0L),
            o.optJSONObject("prefs")?.takeIf { it.length() > 0 }?.toString().orEmpty(), o.optLong("prefsAt", 0L),
            blocks,
        )
    }

    private fun call(
        method: String,
        url: String,
        token: String,
        body: ByteArray? = null,
        contentType: String? = null,
        override: String? = null,
    ): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 20_000
            c.readTimeout = 30_000
            c.setRequestProperty("Authorization", "Bearer $token")
            if (override != null) c.setRequestProperty("X-HTTP-Method-Override", override)
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", contentType ?: "application/json")
                c.outputStream.use { it.write(body) }
            }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                throw RuntimeException(
                    when (code) {
                        401 -> "Accesso scaduto: riaccedi a Google dalle Impostazioni."
                        403 -> "Drive ha rifiutato l'accesso: controlla che la Drive API sia attiva e il permesso concesso."
                        else -> "Errore di Google Drive ($code)."
                    },
                )
            }
            return text
        } finally {
            c.disconnect()
        }
    }
}
