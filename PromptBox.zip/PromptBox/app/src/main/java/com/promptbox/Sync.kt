package com.promptbox

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.Scopes
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.coroutines.resume

/** Stato della sincronizzazione, passato alle Impostazioni. */
class SyncUi(
    val on: Boolean,
    val email: String,
    val busy: Boolean,
    val message: String?,
    val lastSync: Long,
    val onSignIn: () -> Unit,
    val onSyncNow: () -> Unit,
    val onSignOut: () -> Unit,
)

sealed interface AuthResult {
    data class Token(val token: String, val email: String) : AuthResult
    data class NeedsConsent(val pendingIntent: PendingIntent) : AuthResult
    data class Failure(val message: String) : AuthResult
}

/** Accesso con Google: chiede solo il permesso per la cartella nascosta di Prisma su Drive. */
object GoogleAuth {
    private const val DRIVE_APPDATA = "https://www.googleapis.com/auth/drive.appdata"

    private fun request(): AuthorizationRequest = AuthorizationRequest.builder()
        .setRequestedScopes(listOf(Scope(DRIVE_APPDATA), Scope(Scopes.EMAIL)))
        .build()

    private fun AuthorizationResult.toAuth(): AuthResult {
        val token = accessToken
        val pending = pendingIntent
        return when {
            token != null -> AuthResult.Token(token, runCatching { toGoogleSignInAccount()?.email }.getOrNull().orEmpty())
            hasResolution() && pending != null -> AuthResult.NeedsConsent(pending)
            else -> AuthResult.Failure("Google non ha concesso l'accesso.")
        }
    }

    private fun friendly(e: Throwable): String {
        val code = (e as? ApiException)?.statusCode
        return when (code) {
            10 -> "Google non riconosce l'app: controlla nome pacchetto e impronta SHA-1 del client Android."
            7 -> "Nessuna connessione a Internet."
            else -> "Accesso non riuscito" + (if (code != null) " (codice $code)." else ": ${e.message}")
        }
    }

    /** Se il permesso è già stato dato risponde subito col token, senza mostrare nulla. */
    suspend fun authorize(context: Context): AuthResult = suspendCancellableCoroutine { cont ->
        Identity.getAuthorizationClient(context).authorize(request())
            .addOnSuccessListener { if (cont.isActive) cont.resume(it.toAuth()) }
            .addOnFailureListener { if (cont.isActive) cont.resume(AuthResult.Failure(friendly(it))) }
    }

    fun fromIntent(context: Context, data: Intent?): AuthResult = runCatching {
        Identity.getAuthorizationClient(context).getAuthorizationResultFromIntent(data).toAuth()
    }.getOrElse { AuthResult.Failure(friendly(it)) }
}

class SyncResult(
    val sections: List<Section>,
    val deleted: Map<String, Long>,
    val changedLocal: Boolean,
)

/**
 * Un solo file (prisma-sync.json) nella cartella nascosta dell'app su Drive.
 * Unione per sezione: vince la versione modificata più di recente; un'eliminazione
 * più recente di una modifica cancella la sezione anche sugli altri telefoni.
 */
object DriveSync {
    private const val NAME = "prisma-sync.json"
    private const val API = "https://www.googleapis.com/drive/v3/files"
    private const val UPLOAD = "https://www.googleapis.com/upload/drive/v3/files"
    private const val BOUNDARY = "prisma_boundary_7d1f"

    suspend fun sync(token: String, local: List<Section>, localDeleted: Map<String, Long>): Result<SyncResult> =
        withContext(Dispatchers.IO) {
            runCatching {
                val fileId = findFile(token)
                val remote = fileId?.let { parse(call("GET", "$API/$it?alt=media", token)) }
                val merged = merge(local, localDeleted, remote?.first.orEmpty(), remote?.second.orEmpty())
                val remoteSame = remote != null && remote.first == merged.first && remote.second == merged.second
                if (!remoteSame) upload(token, fileId, serialize(merged.first, merged.second))
                SyncResult(merged.first, merged.second, merged.first != local)
            }
        }

    fun merge(
        local: List<Section>,
        localDeleted: Map<String, Long>,
        remote: List<Section>,
        remoteDeleted: Map<String, Long>,
    ): Pair<List<Section>, Map<String, Long>> {
        val deleted = (localDeleted.keys + remoteDeleted.keys).associateWith {
            maxOf(localDeleted[it] ?: 0L, remoteDeleted[it] ?: 0L)
        }
        fun dropped(s: Section): Boolean = deleted[s.id]?.let { it >= s.updatedAt } ?: false

        val remoteById = remote.associateBy { it.id }
        val seen = HashSet<String>()
        val result = mutableListOf<Section>()
        for (l in local) {
            seen += l.id
            val r = remoteById[l.id]
            val best = if (r != null && r.updatedAt > l.updatedAt) r else l
            if (!dropped(best)) result += best
        }
        for (r in remote) {
            if (r.id !in seen && !dropped(r)) result += r
        }
        return result to deleted
    }

    private fun findFile(token: String): String? {
        val q = URLEncoder.encode("name = '$NAME'", "UTF-8")
        val fields = URLEncoder.encode("files(id)", "UTF-8")
        val json = JSONObject(call("GET", "$API?spaces=appDataFolder&q=$q&fields=$fields", token))
        val files = json.optJSONArray("files") ?: return null
        return if (files.length() > 0) files.getJSONObject(0).getString("id") else null
    }

    private fun upload(token: String, fileId: String?, content: String) {
        if (fileId == null) {
            val meta = JSONObject().put("name", NAME).put("parents", JSONArray().put("appDataFolder")).toString()
            val body = "--$BOUNDARY\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n" +
                "--$BOUNDARY\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$content\r\n--$BOUNDARY--"
            call(
                "POST", "$UPLOAD?uploadType=multipart", token,
                body.toByteArray(), "multipart/related; boundary=$BOUNDARY",
            )
        } else {
            // HttpURLConnection non conosce PATCH: Google accetta POST con l'header di override.
            call(
                "POST", "$UPLOAD/$fileId?uploadType=media", token,
                content.toByteArray(), "application/json; charset=UTF-8", override = "PATCH",
            )
        }
    }

    private fun serialize(sections: List<Section>, deleted: Map<String, Long>): String {
        val arr = JSONArray()
        sections.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("title", it.title).put("emoji", it.emoji)
                    .put("hint", it.hint).put("prompt", it.systemPrompt).put("u", it.updatedAt),
            )
        }
        val del = JSONObject()
        deleted.forEach { (k, v) -> del.put(k, v) }
        return JSONObject().put("v", 1).put("sections", arr).put("deleted", del).toString()
    }

    private fun parse(raw: String): Pair<List<Section>, Map<String, Long>> {
        val o = JSONObject(raw)
        val arr = o.optJSONArray("sections") ?: JSONArray()
        val sections = (0 until arr.length()).map { i ->
            val s = arr.getJSONObject(i)
            Section(
                id = s.getString("id"),
                title = s.getString("title"),
                emoji = s.optString("emoji", "📌").ifBlank { "📌" },
                hint = s.optString("hint", "Foto e/o testo"),
                systemPrompt = s.getString("prompt"),
                updatedAt = s.optLong("u", 0L),
            )
        }
        val deleted = mutableMapOf<String, Long>()
        o.optJSONObject("deleted")?.let { d -> d.keys().forEach { k -> deleted[k] = d.getLong(k) } }
        return sections to deleted
    }

    private fun call(
        method: String,
        url: String,
        token: String,
        body: ByteArray? = null,
        contentType: String? = null,
        override: String? = null,
    ): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 20_000
            c.readTimeout = 30_000
            c.setRequestProperty("Authorization", "Bearer $token")
            if (override != null) c.setRequestProperty("X-HTTP-Method-Override", override)
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", contentType ?: "application/json")
                c.outputStream.use { it.write(body) }
            }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                throw RuntimeException(
                    when (code) {
                        401 -> "Accesso scaduto: riaccedi a Google dalle Impostazioni."
                        403 -> "Drive ha rifiutato l'accesso: controlla che la Drive API sia attiva e il permesso concesso."
                        else -> "Errore di Google Drive ($code)."
                    },
                )
            }
            return text
        } finally {
            c.disconnect()
        }
    }
}
