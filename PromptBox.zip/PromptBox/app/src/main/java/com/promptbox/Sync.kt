package com.promptbox

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.Scopes
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.coroutines.resume

/** Stato della sincronizzazione, passato alle Impostazioni. */
class SyncUi(
    val on: Boolean,
    val email: String,
    val busy: Boolean,
    val message: String?,
    val lastSync: Long,
    val onSignIn: () -> Unit,
    val onSyncNow: () -> Unit,
    val onBackupDrive: () -> Unit,
    val onRestoreDrive: () -> Unit,
    val onSignOut: () -> Unit,
)

sealed interface AuthResult {
    data class Token(val token: String, val email: String) : AuthResult
    data class NeedsConsent(val pendingIntent: PendingIntent) : AuthResult
    data class Failure(val message: String) : AuthResult
}

/** Accesso con Google: chiede solo il permesso per la cartella nascosta di Prisma su Drive. */
object GoogleAuth {
    private const val DRIVE_APPDATA = "https://www.googleapis.com/auth/drive.appdata"

    private fun request(): AuthorizationRequest = AuthorizationRequest.builder()
        .setRequestedScopes(listOf(Scope(DRIVE_APPDATA), Scope(Scopes.EMAIL)))
        .build()

    private fun AuthorizationResult.toAuth(): AuthResult {
        val token = accessToken
        val pending = pendingIntent
        return when {
            token != null -> AuthResult.Token(token, runCatching { toGoogleSignInAccount()?.email }.getOrNull().orEmpty())
            hasResolution() && pending != null -> AuthResult.NeedsConsent(pending)
            else -> AuthResult.Failure("Google non ha concesso l'accesso.")
        }
    }

    private fun friendly(e: Throwable): String {
        val code = (e as? ApiException)?.statusCode
        return when (code) {
            10 -> "Google non riconosce l'app: controlla nome pacchetto e impronta SHA-1 del client Android."
            7 -> "Nessuna connessione a Internet."
            else -> "Accesso non riuscito" + (if (code != null) " (codice $code)." else ": ${e.message}")
        }
    }

    /** Se il permesso è già stato dato risponde subito col token, senza mostrare nulla. */
    suspend fun authorize(context: Context): AuthResult = suspendCancellableCoroutine { cont ->
        Identity.getAuthorizationClient(context).authorize(request())
            .addOnSuccessListener { if (cont.isActive) cont.resume(it.toAuth()) }
            .addOnFailureListener { if (cont.isActive) cont.resume(AuthResult.Failure(friendly(it))) }
    }

    fun fromIntent(context: Context, data: Intent?): AuthResult = runCatching {
        Identity.getAuthorizationClient(context).getAuthorizationResultFromIntent(data).toAuth()
    }.getOrElse { AuthResult.Failure(friendly(it)) }
}

/** Quello che c'è su questo dispositivo e va unito con Drive. */
class LocalSync(
    val sections: List<Section>,
    val deleted: Map<String, Long>,
    val shopping: List<ShopItem>,
    val shoppingDeleted: Map<String, Long>,
    val history: Map<String, Int>,
    val profile: String,
    val profileAt: Long,
    /** Impostazioni condivise (JSON di Store.settingsJson) e quando sono state cambiate. */
    val settings: String,
    val settingsAt: Long,
)

class SyncResult(
    val sections: List<Section>,
    val deleted: Map<String, Long>,
    val changedLocal: Boolean,
    val shopping: List<ShopItem>,
    val shoppingDeleted: Map<String, Long>,
    val changedShopping: Boolean,
    val history: Map<String, Int>,
    val profile: String,
    val profileAt: Long,
    val changedProfile: Boolean,
    val settings: String,
    val settingsAt: Long,
    val changedSettings: Boolean,
)

internal class Remote(
    val sections: List<Section>,
    val deleted: Map<String, Long>,
    val shopping: List<ShopItem>,
    val shoppingDeleted: Map<String, Long>,
    val history: Map<String, Int>,
    val profile: String,
    val profileAt: Long,
    val settings: String,
    val settingsAt: Long,
)

/**
 * Un solo file (prisma-sync.json) nella cartella nascosta dell'app su Drive.
 * Unione per sezione e per prodotto della spesa: vince la versione modificata più di recente;
 * un'eliminazione più recente di una modifica cancella l'elemento anche sugli altri dispositivi.
 */
object DriveSync {
    private const val NAME = "prisma-sync.json"
    private const val API = "https://www.googleapis.com/drive/v3/files"
    private const val UPLOAD = "https://www.googleapis.com/upload/drive/v3/files"
    private const val BOUNDARY = "prisma_boundary_7d1f"

    suspend fun sync(token: String, local: LocalSync): Result<SyncResult> =
        withContext(Dispatchers.IO) {
            runCatching {
                val fileId = findFile(token)
                val remote = fileId?.let { parse(call("GET", "$API/$it?alt=media", token)) }
                val merged = merge(local.sections, local.deleted, remote?.sections.orEmpty(), remote?.deleted.orEmpty())
                val shop = mergeShopping(
                    local.shopping, local.shoppingDeleted,
                    remote?.shopping.orEmpty(), remote?.shoppingDeleted.orEmpty(),
                )
                val history = mergeHistory(local.history, remote?.history.orEmpty())

                // "Su di me": vince la modifica più recente, ma solo se l'utente ha attivato l'opzione.
                // Se è spenta, nel file resta ciò che c'era e sul telefono non cambia nulla.
                var profile = local.profile
                var profileAt = local.profileAt
                var changedProfile = false
                if (remote != null && remote.profileAt > local.profileAt) {
                    profile = remote.profile
                    profileAt = remote.profileAt
                    changedProfile = profile != local.profile
                }
                val fileProfile = profile
                val fileProfileAt = profileAt

                // Impostazioni (tema, colori categorie, account Bring...): vince la modifica più recente.
                var settings = local.settings
                var settingsAt = local.settingsAt
                var changedSettings = false
                if (remote != null && remote.settings.isNotBlank() &&
                    (remote.settingsAt > local.settingsAt || local.settingsAt == 0L)
                ) {
                    // Un dispositivo che non ha mai cambiato nulla (data 0) prende sempre quelle già su Drive.
                    settings = remote.settings
                    settingsAt = remote.settingsAt
                    changedSettings = settings != local.settings || settingsAt != local.settingsAt
                } else if (local.settingsAt == 0L) {
                    settingsAt = System.currentTimeMillis()
                }

                val remoteSame = remote != null &&
                    remote.sections == merged.first && remote.deleted == merged.second &&
                    remote.shopping.toSet() == shop.first.toSet() && remote.shoppingDeleted == shop.second &&
                    remote.history == history &&
                    remote.profile == fileProfile && remote.profileAt == fileProfileAt &&
                    remote.settingsAt == settingsAt
                if (!remoteSame) {
                    upload(
                        token, fileId,
                        serialize(
                            merged.first, merged.second, shop.first, shop.second, history,
                            fileProfile, fileProfileAt, settings, settingsAt,
                        ),
                    )
                }
                SyncResult(
                    merged.first, merged.second, merged.first != local.sections,
                    shop.first, shop.second, shop.first.toSet() != local.shopping.toSet(),
                    history, profile, profileAt, changedProfile,
                    settings, settingsAt, changedSettings,
                )
            }
        }

    private const val BACKUP_NAME = "prisma-backup.json"

    /** Mette il backup completo nella cartella di Prisma su Drive (sostituisce il precedente). Restituisce l'ora salvata. */
    suspend fun saveBackup(token: String, content: String): Result<Long> = withContext(Dispatchers.IO) {
        runCatching {
            upload(token, findFile(token, BACKUP_NAME), content, BACKUP_NAME)
            System.currentTimeMillis()
        }
    }

    /** Scarica il backup salvato su Drive (null se non ce n'è nessuno). */
    suspend fun loadBackup(token: String): Result<String?> = withContext(Dispatchers.IO) {
        runCatching {
            findFile(token, BACKUP_NAME)?.let { call("GET", "$API/$it?alt=media", token) }
        }
    }

    /** Storico "ricomprare": per ogni prodotto vale il conteggio più alto tra i dispositivi. */
    fun mergeHistory(a: Map<String, Int>, b: Map<String, Int>): Map<String, Int> =
        (a.keys + b.keys).associateWith { maxOf(a[it] ?: 0, b[it] ?: 0) }

    /** Unisce due mappe di eliminazioni tenendo, per ogni chiave, la data più recente. */
    fun mergeDeleted(a: Map<String, Long>, b: Map<String, Long>): Map<String, Long> =
        (a.keys + b.keys).associateWith { maxOf(a[it] ?: 0L, b[it] ?: 0L) }

    /** Lista della spesa: per ogni prodotto vince la modifica più recente; l'ordine è dal più nuovo. */
    fun mergeShopping(
        local: List<ShopItem>,
        localDeleted: Map<String, Long>,
        remote: List<ShopItem>,
        remoteDeleted: Map<String, Long>,
    ): Pair<List<ShopItem>, Map<String, Long>> {
        val deleted = mergeDeleted(localDeleted, remoteDeleted)
        val byKey = LinkedHashMap<String, ShopItem>()
        // Prima il remoto, poi il locale: a parità di data vince quello locale.
        for (i in remote + local) {
            val cur = byKey[i.key]
            if (cur == null || i.updatedAt >= cur.updatedAt) byKey[i.key] = i
        }
        val items = byKey.values
            .filter { i -> deleted[i.key]?.let { it < i.updatedAt } ?: true }
            .sortedWith(compareByDescending<ShopItem> { it.updatedAt }.thenBy { it.key })
        return items to deleted
    }

    fun merge(
        local: List<Section>,
        localDeleted: Map<String, Long>,
        remote: List<Section>,
        remoteDeleted: Map<String, Long>,
    ): Pair<List<Section>, Map<String, Long>> {
        val deleted = (localDeleted.keys + remoteDeleted.keys).associateWith {
            maxOf(localDeleted[it] ?: 0L, remoteDeleted[it] ?: 0L)
        }
        fun dropped(s: Section): Boolean = deleted[s.id]?.let { it >= s.updatedAt } ?: false

        val remoteById = remote.associateBy { it.id }
        val seen = HashSet<String>()
        val result = mutableListOf<Section>()
        for (l in local) {
            seen += l.id
            val r = remoteById[l.id]
            val best = if (r != null && r.updatedAt > l.updatedAt) r else l
            if (!dropped(best)) result += best
        }
        for (r in remote) {
            if (r.id !in seen && !dropped(r)) result += r
        }
        return result to deleted
    }

    private fun findFile(token: String, name: String = NAME): String? {
        val q = URLEncoder.encode("name = '$name'", "UTF-8")
        val fields = URLEncoder.encode("files(id)", "UTF-8")
        val json = JSONObject(call("GET", "$API?spaces=appDataFolder&q=$q&fields=$fields", token))
        val files = json.optJSONArray("files") ?: return null
        return if (files.length() > 0) files.getJSONObject(0).getString("id") else null
    }

    private fun upload(token: String, fileId: String?, content: String, name: String = NAME) {
        if (fileId == null) {
            val meta = JSONObject().put("name", name).put("parents", JSONArray().put("appDataFolder")).toString()
            val body = "--$BOUNDARY\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n" +
                "--$BOUNDARY\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$content\r\n--$BOUNDARY--"
            call(
                "POST", "$UPLOAD?uploadType=multipart", token,
                body.toByteArray(), "multipart/related; boundary=$BOUNDARY",
            )
        } else {
            // HttpURLConnection non conosce PATCH: Google accetta POST con l'header di override.
            call(
                "POST", "$UPLOAD/$fileId?uploadType=media", token,
                content.toByteArray(), "application/json; charset=UTF-8", override = "PATCH",
            )
        }
    }

    internal fun serialize(
        sections: List<Section>,
        deleted: Map<String, Long>,
        shopping: List<ShopItem>,
        shoppingDeleted: Map<String, Long>,
        history: Map<String, Int>,
        profile: String,
        profileAt: Long,
        settings: String = "",
        settingsAt: Long = 0L,
    ): String {
        val arr = JSONArray()
        sections.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("title", it.title).put("emoji", it.emoji)
                    .put("hint", it.hint).put("prompt", it.systemPrompt).put("u", it.updatedAt)
                    .put("cat", it.category),
            )
        }
        val del = JSONObject()
        deleted.forEach { (k, v) -> del.put(k, v) }
        val shop = JSONArray()
        shopping.forEach {
            shop.put(JSONObject().put("t", it.text).put("d", it.done).put("u", it.updatedAt).put("p", it.dept))
        }
        val shopDel = JSONObject()
        shoppingDeleted.forEach { (k, v) -> shopDel.put(k, v) }
        val hist = JSONObject()
        history.forEach { (k, v) -> hist.put(k, v) }
        return JSONObject().put("v", 1).put("sections", arr).put("deleted", del)
            .put("shopping", shop).put("shoppingDeleted", shopDel)
            .put("history", hist).put("profile", profile).put("profileAt", profileAt)
            .put("prefs", if (settings.isBlank()) JSONObject() else JSONObject(settings)).put("prefsAt", settingsAt)
            .toString()
    }

    internal fun parse(raw: String): Remote {
        val o = JSONObject(raw)
        val arr = o.optJSONArray("sections") ?: JSONArray()
        val sections = (0 until arr.length()).map { i ->
            val s = arr.getJSONObject(i)
            Section(
                id = s.getString("id"),
                title = s.getString("title"),
                emoji = s.optString("emoji", "📌").ifBlank { "📌" },
                hint = s.optString("hint", "Foto e/o testo"),
                systemPrompt = s.getString("prompt"),
                updatedAt = s.optLong("u", 0L),
                category = s.optString("cat", ""),
            )
        }
        val deleted = mutableMapOf<String, Long>()
        o.optJSONObject("deleted")?.let { d -> d.keys().forEach { k -> deleted[k] = d.getLong(k) } }
        val shopArr = o.optJSONArray("shopping") ?: JSONArray()
        val shopping = (0 until shopArr.length()).map { i ->
            val s = shopArr.getJSONObject(i)
            ShopItem(s.getString("t"), s.optBoolean("d", false), s.optLong("u", 0L), s.optString("p", ""))
        }
        val shopDeleted = mutableMapOf<String, Long>()
        o.optJSONObject("shoppingDeleted")?.let { d -> d.keys().forEach { k -> shopDeleted[k] = d.getLong(k) } }
        val history = mutableMapOf<String, Int>()
        o.optJSONObject("history")?.let { d -> d.keys().forEach { k -> history[k] = d.getInt(k) } }
        return Remote(
            sections, deleted, shopping, shopDeleted, history,
            o.optString("profile", ""), o.optLong("profileAt", 0L),
            o.optJSONObject("prefs")?.takeIf { it.length() > 0 }?.toString().orEmpty(), o.optLong("prefsAt", 0L),
        )
    }

    private fun call(
        method: String,
        url: String,
        token: String,
        body: ByteArray? = null,
        contentType: String? = null,
        override: String? = null,
    ): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 20_000
            c.readTimeout = 30_000
            c.setRequestProperty("Authorization", "Bearer $token")
            if (override != null) c.setRequestProperty("X-HTTP-Method-Override", override)
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", contentType ?: "application/json")
                c.outputStream.use { it.write(body) }
            }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                throw RuntimeException(
                    when (code) {
                        401 -> "Accesso scaduto: riaccedi a Google dalle Impostazioni."
                        403 -> "Drive ha rifiutato l'accesso: controlla che la Drive API sia attiva e il permesso concesso."
                        else -> "Errore di Google Drive ($code)."
                    },
                )
            }
            return text
        } finally {
            c.disconnect()
        }
    }
}
