package com.promptbox

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate
import java.time.YearMonth

/** Lettura della data di scadenza dalla foto di un'etichetta. */
object ExpiryTools {
    private const val SYSTEM =
        "Nell'immagine c'è la confezione o l'etichetta di un prodotto. Trova la data di scadenza " +
            "(\"da consumarsi entro\", \"scad.\", \"TMC\", \"best before\", \"EXP\"). " +
            "Rispondi SOLO con la data nel formato AAAA-MM-GG, senza altro testo. " +
            "Se c'è solo mese e anno, scrivi l'ultimo giorno di quel mese. " +
            "Se non c'è nessuna data di scadenza leggibile rispondi esattamente NESSUNA."

    suspend fun read(apiKey: String, model: String, bitmap: Bitmap): Result<Long?> =
        GeminiClient.ask(apiKey, model, SYSTEM, "Leggi la scadenza.", bitmap).mapCatching { parseDate(it) }

    private val ISO = Regex("""(\d{4})-(\d{1,2})-(\d{1,2})""")
    private val EU = Regex("""(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{4})""")
    private val ISO_MONTH = Regex("""(\d{4})-(\d{1,2})""")
    private val EU_MONTH = Regex("""(\d{1,2})[/.\-](\d{4})""")

    /** Trasforma la risposta dell'AI in un giorno (epoch day). null = nessuna data valida. */
    fun parseDate(raw: String): Long? {
        val t = raw.replace("`", "").replace("\"", "").trim()
        if (t.isEmpty() || t.contains("NESSUNA", ignoreCase = true)) return null
        return runCatching {
            ISO.find(t)?.let { m ->
                return@runCatching LocalDate.of(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt()).toEpochDay()
            }
            EU.find(t)?.let { m ->
                return@runCatching LocalDate.of(m.groupValues[3].toInt(), m.groupValues[2].toInt(), m.groupValues[1].toInt()).toEpochDay()
            }
            ISO_MONTH.find(t)?.let { m ->
                return@runCatching YearMonth.of(m.groupValues[1].toInt(), m.groupValues[2].toInt()).atEndOfMonth().toEpochDay()
            }
            EU_MONTH.find(t)?.let { m ->
                return@runCatching YearMonth.of(m.groupValues[2].toInt(), m.groupValues[1].toInt()).atEndOfMonth().toEpochDay()
            }
            null
        }.getOrNull()
    }
}

/**
 * Le scadenze vere, un prodotto alla volta: scorciatoie, calendario o foto dell'etichetta.
 * "Salta" lascia la stima. Si esce sempre con [onDone] (anche chiudendo a metà): non si perde niente.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ExpiryWalkthroughDialog(
    items: List<PantryItem>,
    store: Store,
    onDone: (List<PantryItem>) -> Unit,
) {
    if (items.isEmpty()) {
        LaunchedEffect(Unit) { onDone(items) }
        return
    }
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val list = remember { mutableStateListOf<PantryItem>().also { it.addAll(items) } }
    var index by remember { mutableStateOf(0) }
    var picking by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf<String?>(null) }
    var pendingUri by remember { mutableStateOf<Uri?>(null) }
    val today = Pantry.today()
    val quick = listOf("Domani" to 1L, "3 giorni" to 3L, "1 settimana" to 7L, "2 settimane" to 14L, "1 mese" to 30L, "3 mesi" to 90L, "6 mesi" to 180L)

    val at = index.coerceIn(0, list.lastIndex)
    val cur = list[at]
    val last = at == list.lastIndex

    fun setDate(position: Int, day: Long?) {
        if (position in list.indices) list[position] = list[position].copy(expiry = day, estimated = false)
    }

    fun readPhoto(uri: Uri) {
        val position = at
        scope.launch {
            busy = true
            note = null
            val bmp = withContext(Dispatchers.IO) { ImageUtils.load(context, uri, maxSide = 1600) }
            if (bmp == null) {
                note = "Non riesco ad aprire la foto."
            } else {
                ExpiryTools.read(store.apiKey, store.model, bmp)
                    .onSuccess { day ->
                        store.countRequest()
                        if (day == null) {
                            note = "Non vedo una data di scadenza: sceglila tu qui sopra."
                        } else {
                            setDate(position, day)
                            note = "Letta dall'etichetta: " + Pantry.dateText(day) + ". Controlla che sia giusta."
                        }
                    }
                    .onFailure { note = it.message ?: "Errore sconosciuto" }
            }
            busy = false
        }
    }

    val take = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) pendingUri?.let { readPhoto(it) }
    }

    fun camera() {
        val dir = File(context.cacheDir, "photos").apply { mkdirs() }
        val file = File.createTempFile("etichetta", ".jpg", dir)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        pendingUri = uri
        take.launch(uri)
    }

    fun next() {
        if (last) {
            onDone(list.toList())
        } else {
            index = at + 1
            note = null
        }
    }

    AlertDialog(
        onDismissRequest = { onDone(list.toList()) },
        title = { Text("Scadenza " + (at + 1) + " di " + list.size) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(cur.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    Pantry.shelfEmoji(cur.shelf) + " " + cur.shelf,
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                )
                Text(
                    "Scadenza: " + (cur.expiry?.let { Pantry.dateText(it) + " · " + Pantry.label(it) } ?: "nessuna") +
                        if (cur.estimated) " (stimata)" else "",
                    style = MaterialTheme.typography.labelLarge,
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    quick.forEach { (label, days) ->
                        FilterChip(
                            selected = !cur.estimated && cur.expiry == today + days,
                            onClick = { setDate(at, today + days) },
                            label = { Text(label) },
                        )
                    }
                    FilterChip(selected = false, onClick = { picking = true }, label = { Text("Data…") })
                    FilterChip(selected = !cur.estimated && cur.expiry == null, onClick = { setDate(at, null) }, label = { Text("Nessuna") })
                }
                FilledTonalButton(onClick = { camera() }, enabled = !busy && store.apiKey.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.CameraAlt, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Fotografa la data sull'etichetta")
                }
                if (store.apiKey.isBlank()) {
                    Text(
                        "Per leggere la data dalla foto serve la chiave API nelle Impostazioni.",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                }
                if (busy) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(10.dp))
                        Text("Leggo la data…", color = cs.onSurfaceVariant)
                    }
                }
                note?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = { next() }) {
                Text(
                    when {
                        cur.estimated && last -> "Salta e finisci"
                        cur.estimated -> "Salta"
                        last -> "Fine"
                        else -> "Avanti"
                    },
                )
            }
        },
        dismissButton = { TextButton(onClick = { onDone(list.toList()) }) { Text("Chiudi") } },
    )

    if (picking) {
        val state = rememberDatePickerState(initialSelectedDateMillis = (cur.expiry ?: today) * 86_400_000L)
        DatePickerDialog(
            onDismissRequest = { picking = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { setDate(at, it / 86_400_000L) }
                    picking = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { picking = false }) { Text("Annulla") } },
        ) { DatePicker(state = state) }
    }
}
