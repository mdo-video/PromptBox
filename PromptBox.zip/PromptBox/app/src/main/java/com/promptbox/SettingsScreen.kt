package com.promptbox

import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.foundation.clickable
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Contrast
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Surface
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.CheckCircle
import android.app.Activity
import android.app.KeyguardManager
import android.os.Build
import android.widget.Toast
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.History
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.size
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    store: Store,
    dynamic: Boolean,
    onDynamic: (Boolean) -> Unit,
    sync: SyncUi,
    themeMode: Int,
    onTheme: (Int) -> Unit,
    palette: Int,
    onPalette: (Int) -> Unit,
    amoled: Boolean,
    onAmoled: (Boolean) -> Unit,
    onBackupDone: () -> Unit,
    onChangelog: () -> Unit,
    onHistory: () -> Unit,
    onRoutines: () -> Unit,
    onBack: () -> Unit,
) {
    val uriHandler = LocalUriHandler.current
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var key by remember { mutableStateOf(store.apiKey) }
    var model by remember { mutableStateOf(store.model) }
    var profile by remember { mutableStateOf(store.profile) }
    val clipboard = LocalClipboardManager.current
    // Chiave visibile solo dopo il PIN, e solo finché resti in questa schermata.
    var revealed by remember { mutableStateOf(false) }
    var pinMode by remember { mutableStateOf<String?>(null) } // "ask" = chiede il PIN, "new" = sceglie un PIN nuovo
    val credentialLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) pinMode = "new"
    }
    fun forgotPin() {
        val intent = context.getSystemService(KeyguardManager::class.java)
            ?.createConfirmDeviceCredentialIntent("Recupera il PIN", "Conferma con lo sblocco del telefono per scegliere un nuovo PIN.")
        if (intent == null) {
            Toast.makeText(
                context,
                "Per recuperare il PIN serve un blocco schermo sul telefono. In alternativa crea una nuova chiave su Google AI Studio.",
                Toast.LENGTH_LONG,
            ).show()
        } else {
            credentialLauncher.launch(intent)
        }
    }

    pinMode?.let { mode ->
        PinDialog(
            ask = mode == "ask",
            store = store,
            onOk = { revealed = true; pinMode = null },
            onForgot = { forgotPin() },
            onDismiss = { pinMode = null },
        )
    }

    // ── Stato che deve sopravvivere alle righe aperte/chiuse e al filtro della ricerca ──────────────────────────
    var baseKey by remember { mutableStateOf(store.apiKey) }
    var baseModel by remember { mutableStateOf(store.model) }
    var baseProfile by remember { mutableStateOf(store.profile) }
    val dirty = key != baseKey || model != baseModel || profile != baseProfile
    var length by remember { mutableStateOf(store.length) }
    var fallback by remember { mutableStateOf(store.fallback) }
    var bringEmail by remember { mutableStateOf(store.bringEmail) }
    var bringMap by remember { mutableStateOf(store.bringDeptLists) }
    var query by rememberSaveable { mutableStateOf("") }
    var openId by rememberSaveable { mutableStateOf<String?>(null) }

    val darkNow = themeMode == 2 || (themeMode == 0 && isSystemInDarkTheme())
    val hasMaterialYou = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val materialYouOn = hasMaterialYou && dynamic

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json"),
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)!!.use { it.write(BackupTools.export(store).toByteArray()) }
            }
                .onSuccess { Toast.makeText(context, "Backup salvato.", Toast.LENGTH_SHORT).show() }
                .onFailure { Toast.makeText(context, "Non sono riuscito a salvare il backup.", Toast.LENGTH_LONG).show() }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val result = runCatching {
                context.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
            }.mapCatching { BackupTools.import(store, it).getOrThrow() }
            result
                .onSuccess {
                    onBackupDone()
                    Toast.makeText(context, it, Toast.LENGTH_LONG).show()
                }
                .onFailure {
                    Toast.makeText(context, it.message ?: "File non valido.", Toast.LENGTH_LONG).show()
                }
        }
    }

    val syncStatus = when {
        sync.busy -> "Sincronizzo..."
        sync.lastSync > 0 ->
            "Ultima sincronizzazione: " + SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(sync.lastSync))
        else -> "Non ancora sincronizzato"
    }

    // ── Le voci: ognuna è una riga con icona, titolo e descrizione ──────────────────────────────────────────────
    val entries = listOf(
        // AI
        SettingsEntry(
            id = "history", section = "AI", icon = Icons.Filled.History,
            title = "Cronologia", description = "Le chat passate di tutte le sezioni",
            keywords = "chat storico conversazioni passate",
            onClick = onHistory,
        ),
        SettingsEntry(
            id = "routines", section = "AI", icon = Icons.Filled.NotificationsActive,
            title = "Routine e avvisi", description = "Richieste a ora fissa e avvisi di scadenza",
            keywords = "promemoria notifiche scadenze orari",
            onClick = onRoutines,
        ),
        SettingsEntry(
            id = "apikey", section = "AI", icon = Icons.Filled.Key,
            title = "Chiave API",
            description = if (key.isNotBlank()) "Chiave inserita" else "Chiave mancante",
            keywords = "gemini google ai studio pin password copia",
            content = {
                StatusLine(ok = key.isNotBlank(), text = if (key.isNotBlank()) "Chiave inserita" else "Chiave mancante")
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    label = { Text("Chiave API Gemini") },
                    singleLine = true,
                    visualTransformation = if (revealed) VisualTransformation.None else PasswordVisualTransformation(),
                )
                if (!revealed) {
                    FilledTonalButton(onClick = { pinMode = if (store.hasPin) "ask" else "new" }) { Text("Mostra e copia la chiave") }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(onClick = {
                            clipboard.setText(AnnotatedString(key))
                            Toast.makeText(context, "Chiave copiata.", Toast.LENGTH_SHORT).show()
                        }) { Text("Copia") }
                        OutlinedButton(onClick = { revealed = false }) { Text("Nascondi") }
                        TextButton(onClick = { pinMode = "new" }) { Text("Cambia PIN") }
                    }
                }
                Text(
                    "Il PIN è di 6 cifre e vale su tutti i tuoi dispositivi con l'accesso a Google. " +
                        "Se lo dimentichi, ti basta lo sblocco del telefono per sceglierne uno nuovo.",
                    fontSize = 13.sp,
                    color = cs.onSurfaceVariant,
                )
                TextButton(onClick = { uriHandler.openUri("https://aistudio.google.com/apikey") }) {
                    Text("Crea una chiave gratuita su Google AI Studio")
                }
            },
        ),
        SettingsEntry(
            id = "model", section = "AI", icon = Icons.Filled.Memory,
            title = "Modello", description = model.ifBlank { "Nessun modello scelto" },
            keywords = "gemini flash lite nome modello non trovato",
            content = {
                OutlinedTextField(
                    value = model,
                    onValueChange = { model = it },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    label = { Text("Nome del modello") },
                    singleLine = true,
                )
                Text(
                    "Se ricevi \"modello non trovato\" scegline uno qui sotto.",
                    fontSize = 13.sp,
                    color = cs.onSurfaceVariant,
                )
                listOf(Store.DEFAULT_MODEL, "gemini-3.5-flash-lite").forEach { name ->
                    AssistChip(
                        onClick = { model = name },
                        label = { Text(name) },
                    )
                }
            },
        ),
        SettingsEntry(
            id = "answers", section = "AI", icon = Icons.Filled.Tune,
            title = "Risposte",
            description = "Lunghezza " + listOf("breve", "normale", "dettagliata")[length.coerceIn(0, 2)] +
                if (fallback) " · cambio modello automatico" else "",
            keywords = "lunghezza breve normale dettagliata cambia modello da solo richieste oggi",
            content = {
                Text("Lunghezza", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Breve", "Normale", "Dettagliata").forEachIndexed { i, label ->
                        FilterChip(
                            selected = length == i,
                            onClick = { length = i; store.length = i },
                            label = { Text(label) },
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Cambia modello da solo", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Se il modello scelto non risponde o ha finito le richieste, prova un altro modello gratuito.",
                            fontSize = 13.sp,
                            color = cs.onSurfaceVariant,
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Switch(checked = fallback, onCheckedChange = { fallback = it; store.fallback = it })
                }
                Text(
                    "Richieste fatte oggi: ${store.requestsToday()}",
                    fontSize = 13.sp,
                    color = cs.onSurfaceVariant,
                )
            },
        ),
        SettingsEntry(
            id = "profile", section = "AI", icon = Icons.Filled.Person,
            title = "Su di me", description = "Obiettivi, allergie e preferenze aggiunti a ogni richiesta",
            keywords = "profilo allergie preferenze obiettivi dati personali",
            content = {
                OutlinedTextField(
                    value = profile,
                    onValueChange = { profile = it },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    label = { Text("Obiettivi, allergie, preferenze") },
                    placeholder = { Text("Es. voglio più proteine, niente lattosio, cucino per 2") },
                    minLines = 3,
                    maxLines = 6,
                )
                Text(
                    "Viene aggiunto a ogni richiesta, così le risposte sono su misura. Resta cifrato su questo telefono; " +
                        "con l'accesso a Google si specchia anche sugli altri dispositivi. " +
                        "Con il piano gratuito Google può usare i testi inviati: scrivi solo ciò che ti sta bene condividere.",
                    fontSize = 13.sp,
                    color = cs.onSurfaceVariant,
                )
            },
        ),

        // Aspetto
        SettingsEntry(
            id = "theme", section = "Aspetto", icon = Icons.Filled.DarkMode,
            title = "Tema", description = listOf("Automatico (segue il telefono)", "Chiaro", "Scuro")[themeMode.coerceIn(0, 2)],
            keywords = "chiaro scuro automatico notte modalità",
            content = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Automatico", "Chiaro", "Scuro").forEachIndexed { i, label ->
                        FilterChip(selected = themeMode == i, onClick = { onTheme(i) }, label = { Text(label) })
                    }
                }
            },
        ),
        SettingsEntry(
            id = "colors", section = "Aspetto", icon = Icons.Filled.Palette,
            title = "Colori",
            description = if (materialYouOn) "Material You" else Palettes.names[palette.coerceIn(0, Palettes.names.lastIndex)],
            keywords = "palette material you menta oceano lavanda tramonto ciliegia grafite colore tinta dinamici",
            content = {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    if (hasMaterialYou) {
                        PaletteSwatch(label = "Material You", selected = materialYouOn, onClick = { onDynamic(true) }) {
                            Box(
                                Modifier.fillMaxSize().background(cs.primaryContainer),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(Icons.Filled.Palette, contentDescription = null, tint = cs.onPrimaryContainer, modifier = Modifier.size(22.dp))
                            }
                        }
                    }
                    Palettes.names.forEachIndexed { i, name ->
                        val (first, second) = Palettes.swatch(i, darkNow)
                        PaletteSwatch(
                            label = name,
                            selected = !materialYouOn && palette == i,
                            onClick = {
                                onPalette(i)
                                if (dynamic) onDynamic(false)
                            },
                        ) {
                            Row(Modifier.fillMaxSize()) {
                                Box(Modifier.weight(1f).fillMaxHeight().background(first))
                                Box(Modifier.weight(1f).fillMaxHeight().background(second))
                            }
                        }
                    }
                }
                if (hasMaterialYou) {
                    Text(
                        "Material You usa i colori del tuo sfondo; le altre sono palette di Prisma.",
                        fontSize = 13.sp,
                        color = cs.onSurfaceVariant,
                    )
                }
            },
        ),
        SettingsEntry(
            id = "amoled", section = "Aspetto", icon = Icons.Filled.Contrast,
            title = "Nero AMOLED",
            description = if (darkNow) "Sfondo nero puro: spegne i pixel sugli schermi OLED"
            else "Sfondo nero puro nel tema scuro (ora il tema è chiaro)",
            keywords = "oled nero scuro batteria sfondo",
            onClick = { onAmoled(!amoled) },
            trailing = { Switch(checked = amoled, onCheckedChange = null) },
        ),

        // Bring
        SettingsEntry(
            id = "bring", section = "Bring", icon = Icons.Filled.ShoppingCart,
            title = "Account e liste", description = bringEmail.ifBlank { "Non collegato" },
            keywords = "bring spesa liste reparto macelleria account esci",
            content = {
                StatusLine(ok = bringEmail.isNotBlank(), text = bringEmail.ifBlank { "Non collegato" })
                if (bringMap.isNotEmpty()) {
                    val names = store.bringListNames
                    Text("Lista per reparto", style = MaterialTheme.typography.titleSmall)
                    bringMap.entries.sortedBy { Depts.rank(it.key) }.forEach { (d, u) ->
                        Text(
                            Depts.icon(d) + " " + d + "  →  " + (if (u == "-") "Non mandare" else names[u] ?: "lista scelta"),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                    OutlinedButton(onClick = { store.bringDeptLists = emptyMap(); bringMap = emptyMap() }) { Text("Azzera le scelte") }
                } else {
                    Text(
                        "La lista di ogni reparto (es. Carne e pesce → Macelleria) si sceglie la prima volta che mandi la spesa a Bring, dalla Lista della spesa.",
                        fontSize = 13.sp,
                        color = cs.onSurfaceVariant,
                    )
                }
                if (bringEmail.isNotBlank()) {
                    TextButton(onClick = {
                        store.bringEmail = ""
                        store.bringPassword = ""
                        store.bringDeptLists = emptyMap()
                        bringEmail = ""
                        bringMap = emptyMap()
                    }) { Text("Esci da Bring") }
                }
            },
        ),

        // Sincronizzazione e backup
        SettingsEntry(
            id = "google", section = "Sincronizzazione e backup", icon = Icons.Filled.AccountCircle,
            title = "Account Google",
            description = if (sync.on) sync.email.ifBlank { "Account Google collegato" } + " · " + syncStatus
            else "Non collegato: accedi per sincronizzare i dispositivi",
            keywords = "sincronizzazione sincronizza accedi esci drive email dispositivi account",
            content = {
                if (!sync.on) {
                    Text(
                        "Accedi per ritrovare su tutti i tuoi dispositivi, in automatico, sezioni, categorie e colori, lista della spesa, frigo e dispensa, scontrini, routine, chat, archivi documenti, " +
                            "\"Su di me\", account Bring e impostazioni. Vanno solo nella cartella nascosta di Prisma sul tuo Drive. " +
                            "La chiave API si sincronizza con il tuo account Google (cartella privata di Prisma su Drive), non nei file di backup.",
                        fontSize = 13.sp,
                        color = cs.onSurfaceVariant,
                    )
                    Button(onClick = sync.onSignIn, enabled = !sync.busy, modifier = Modifier.fillMaxWidth()) {
                        Text(if (sync.busy) "Un attimo..." else "Accedi con Google")
                    }
                } else {
                    Text(
                        sync.email.ifBlank { "Account Google collegato" },
                        style = MaterialTheme.typography.titleSmall,
                    )
                    Text(syncStatus, fontSize = 13.sp, color = cs.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        FilledTonalButton(onClick = sync.onSyncNow, enabled = !sync.busy) { Text("Sincronizza ora") }
                        TextButton(onClick = sync.onSignOut) { Text("Esci") }
                    }
                }
                sync.detail?.let { Text(it, fontSize = 13.sp, color = cs.onSurfaceVariant) }
                sync.message?.let { Text(it, fontSize = 13.sp, color = cs.error) }
            },
        ),
        SettingsEntry(
            id = "backupfile", section = "Sincronizzazione e backup", icon = Icons.Filled.SaveAlt,
            title = "Backup su file", description = "Salva o ripristina un file di backup",
            keywords = "esporta importa json ripristina salva file copia",
            content = {
                Text(
                    "Salva tutto: sezioni, categorie e colori, lista della spesa, \"Su di me\", account Bring e impostazioni. " +
                        "Non include la chiave API (viaggia solo con la sincronizzazione su Drive). Le chat sono nel backup su Drive (cartella privata), non nel file. Ripristinando, i dati si uniscono a quelli presenti. " +
                        "Nel file puoi scegliere anche una cartella di Drive.",
                    fontSize = 13.sp,
                    color = cs.onSurfaceVariant,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { exportLauncher.launch("prisma-backup.json") }) { Text("Salva backup") }
                    OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }) { Text("Ripristina") }
                }
            },
        ),
        SettingsEntry(
            id = "backupdrive", section = "Sincronizzazione e backup", icon = Icons.Filled.CloudUpload,
            title = "Backup su Drive",
            description = if (sync.on) "Una copia sul tuo Drive, da ritrovare su ogni dispositivo"
            else "Richiede l'accesso con Google",
            keywords = "drive cloud ripristina da drive copia online",
            content = {
                if (sync.on) {
                    Text(
                        "Tieni una copia sul tuo Drive: la ritrovi da qualsiasi dispositivo con il tuo account, senza passare file.",
                        fontSize = 13.sp,
                        color = cs.onSurfaceVariant,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(onClick = sync.onBackupDrive, enabled = !sync.busy) { Text("Backup su Drive") }
                        OutlinedButton(onClick = sync.onRestoreDrive, enabled = !sync.busy) { Text("Ripristina da Drive") }
                    }
                } else {
                    Text(
                        "Per tenere una copia sul tuo Drive accedi prima con l'account Google.",
                        fontSize = 13.sp,
                        color = cs.onSurfaceVariant,
                    )
                    Button(onClick = sync.onSignIn, enabled = !sync.busy, modifier = Modifier.fillMaxWidth()) {
                        Text(if (sync.busy) "Un attimo..." else "Accedi con Google")
                    }
                }
            },
        ),

        // Informazioni
        SettingsEntry(
            id = "updates", section = "Informazioni", icon = Icons.Filled.SystemUpdate,
            title = "Aggiornamenti",
            description = "Versione ${BuildConfig.VERSION_NAME} · revisione ${AppInfo.revision}",
            keywords = "versione aggiorna aggiornamento app download installa controlla revisione",
            alwaysOpen = true,
            content = { UpdateSection(onChangelog = onChangelog, embedded = true) },
        ),
        SettingsEntry(
            id = "changelog", section = "Informazioni", icon = Icons.Filled.AutoAwesome,
            title = "Novità", description = "Cosa c'è di nuovo in Prisma",
            keywords = "changelog novità versioni modifiche cosa c'è di nuovo",
            onClick = onChangelog,
        ),
        SettingsEntry(
            id = "privacy", section = "Informazioni", icon = Icons.Filled.Lock,
            title = "Privacy e dati", description = "Chiave cifrata sul dispositivo; piano gratuito di Google",
            keywords = "privacy sicurezza dati sensibili cifrata chiave google gratuito",
            content = {
                Text(
                    "La chiave resta cifrata su questo dispositivo e non viene mai inclusa nell'app. " +
                        "Nel piano gratuito Google può usare i testi e le foto inviati per migliorare i suoi prodotti: " +
                        "non inviare dati sensibili.",
                    fontSize = 13.sp,
                    color = cs.onSurfaceVariant,
                )
            },
        ),
    )

    // ── Ricerca: tutte le parole devono comparire in sezione, titolo, descrizione o parole chiave ────────────────
    val visible = entries.filter { e -> settingsMatch("${e.section} ${e.title} ${e.description} ${e.keywords}", query) }
    val sections = listOf("AI", "Aspetto", "Bring", "Sincronizzazione e backup", "Informazioni")

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text("Impostazioni", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
        bottomBar = {
            // Chiave, modello e "Su di me" si salvano con un solo pulsante, che compare solo quando c'è qualcosa da salvare.
            if (dirty) {
                Surface(color = cs.background) {
                    Button(
                        onClick = {
                            store.apiKey = key
                            store.model = model
                            store.profile = profile
                            baseKey = key
                            baseModel = model
                            baseProfile = profile
                            Toast.makeText(context, "Salvato", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                            .navigationBarsPadding()
                            .height(54.dp),
                    ) { Text("Salva modifiche") }
                }
            }
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
        ) {
            TextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                placeholder = { Text("Cerca nelle impostazioni") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, contentDescription = "Cancella la ricerca") }
                    }
                },
                singleLine = true,
                shape = CircleShape,
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent,
                    errorIndicatorColor = Color.Transparent,
                    focusedContainerColor = cs.surfaceContainerHigh,
                    unfocusedContainerColor = cs.surfaceContainerHigh,
                ),
            )
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if (visible.isEmpty()) {
                    Text(
                        "Nessuna impostazione trovata per \"${query.trim()}\".",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 24.dp),
                    )
                }
                sections.forEach { section ->
                    val items = visible.filter { it.section == section }
                    if (items.isNotEmpty()) {
                        SettingsGroup(section)
                        Card(
                            colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer),
                            shape = RoundedCornerShape(24.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Column {
                                items.forEachIndexed { i, entry ->
                                    if (i > 0) {
                                        HorizontalDivider(
                                            modifier = Modifier.padding(start = 70.dp),
                                            color = cs.outlineVariant.copy(alpha = 0.6f),
                                        )
                                    }
                                    SettingsRow(
                                        entry = entry,
                                        expanded = openId == entry.id,
                                        onToggle = { openId = if (openId == entry.id) null else entry.id },
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

/**
 * Una voce delle Impostazioni, mostrata come riga con icona, titolo e descrizione.
 * - [onClick]: la riga porta altrove (o fa scattare l'azione, come l'interruttore in [trailing]);
 * - [content]: la riga si apre e mostra i controlli sotto di sé ([alwaysOpen]: sempre aperta, senza freccia);
 * - [keywords]: parole in più su cui lavora la ricerca.
 */
private class SettingsEntry(
    val id: String,
    val section: String,
    val icon: ImageVector,
    val title: String,
    val description: String,
    val keywords: String = "",
    val onClick: (() -> Unit)? = null,
    val trailing: (@Composable () -> Unit)? = null,
    val alwaysOpen: Boolean = false,
    val content: (@Composable ColumnScope.() -> Unit)? = null,
)

@Composable
private fun SettingsRow(entry: SettingsEntry, expanded: Boolean, onToggle: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val content = entry.content
    val onClick = entry.onClick
    val trailing = entry.trailing
    val canOpen = content != null && !entry.alwaysOpen
    val open = content != null && (entry.alwaysOpen || expanded)
    val rowClick: (() -> Unit)? = when {
        onClick != null -> onClick
        canOpen -> onToggle
        else -> null
    }
    Column(Modifier.fillMaxWidth().animateContentSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .then(if (rowClick != null) Modifier.clickable(onClick = rowClick) else Modifier)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(cs.primary.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center,
            ) { Icon(entry.icon, contentDescription = null, tint = cs.primary) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(entry.title, style = MaterialTheme.typography.titleMedium)
                Text(entry.description, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            if (trailing != null) {
                Spacer(Modifier.width(8.dp))
                trailing()
            } else if (onClick != null) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = cs.onSurfaceVariant)
            } else if (canOpen) {
                Icon(
                    if (open) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                    contentDescription = if (open) "Chiudi" else "Apri",
                    tint = cs.onSurfaceVariant,
                )
            }
        }
        if (open && content != null) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) { content() }
        }
    }
}

/** Minuscolo e senza accenti, così "cronologia", "Cronologìa" e "CRONOLOGIA" si equivalgono nella ricerca. */
internal fun normalizeForSearch(s: String): String =
    java.text.Normalizer.normalize(s.lowercase(Locale.ROOT), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .trim()

/** Ricerca nelle Impostazioni: vero se ogni parola di [query] compare in [text] (senza badare a maiuscole e accenti). Query vuota: tutto. */
internal fun settingsMatch(text: String, query: String): Boolean {
    val words = normalizeForSearch(query).split(' ').filter { it.isNotBlank() }
    if (words.isEmpty()) return true
    val hay = normalizeForSearch(text)
    return words.all { hay.contains(it) }
}

/** Campione tondo di una palette: anello e spunta quando è quella scelta, nome sotto. */
@Composable
private fun PaletteSwatch(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    preview: @Composable () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(56.dp)) {
            Box(
                Modifier
                    .fillMaxSize()
                    .border(if (selected) 3.dp else 1.dp, if (selected) cs.primary else cs.outlineVariant, CircleShape)
                    .padding(5.dp)
                    .clip(CircleShape),
            ) { preview() }
            if (selected) {
                Box(
                    Modifier
                        .align(Alignment.BottomEnd)
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(cs.primary),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.Check, contentDescription = "Selezionata", tint = cs.onPrimary, modifier = Modifier.size(14.dp))
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            label,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (selected) cs.primary else cs.onSurfaceVariant,
        )
    }
}

/** Titolo di una sezione delle impostazioni (AI, Aspetto, Bring, Sincronizzazione e backup, Informazioni). */
@Composable
private fun SettingsGroup(title: String) {
    Text(
        title,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 8.dp, top = 8.dp),
    )
}

/** Pallino di stato: verde = a posto, rosso = manca. */
@Composable
private fun StatusLine(ok: Boolean, text: String) {
    val cs = MaterialTheme.colorScheme
    val tint = if (ok) cs.primary else cs.error
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(32.dp).clip(CircleShape).background(tint.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (ok) Icons.Filled.CheckCircle else Icons.Filled.ErrorOutline,
                contentDescription = null,
                tint = tint,
                modifier = Modifier.size(18.dp),
            )
        }
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun PinDialog(ask: Boolean, store: Store, onOk: () -> Unit, onForgot: () -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var first by remember { mutableStateOf("") } // nuovo PIN: la prima immissione, in attesa della ripetizione
    var cur by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    val confirming = !ask && first.isNotEmpty()

    fun submit(code: String) {
        if (ask) {
            val wait = store.pinLockSeconds()
            if (wait > 0) {
                err = "Troppi tentativi. Riprova tra $wait secondi."
                cur = ""
            } else if (store.checkPin(code)) {
                onOk()
            } else {
                err = "PIN sbagliato."
                cur = ""
            }
        } else if (!confirming) {
            first = code
            cur = ""
        } else if (code != first) {
            err = "I due PIN non coincidono. Ricomincia."
            first = ""
            cur = ""
        } else {
            store.setPin(code)
            onOk()
        }
    }

    fun press(digit: Char) {
        if (cur.length >= 6) return
        err = null
        cur += digit
        if (cur.length == 6) submit(cur)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (ask) "Inserisci il PIN" else if (confirming) "Ripeti il PIN" else "Scegli un PIN") },
        text = {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                if (!ask && !confirming) {
                    Text(
                        "6 cifre. Lo stesso PIN vale su tutti i tuoi dispositivi con l'accesso a Google.",
                        fontSize = 13.sp,
                        color = cs.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(12.dp))
                }
                // I sei punti: si riempiono man mano che digiti.
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                    repeat(6) { i ->
                        Box(
                            Modifier.size(14.dp).clip(CircleShape)
                                .background(if (i < cur.length) cs.primary else cs.outlineVariant),
                        )
                    }
                }
                Box(Modifier.height(20.dp), contentAlignment = Alignment.Center) {
                    err?.let { Text(it, color = cs.error, fontSize = 13.sp) }
                }
                Spacer(Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf("123", "456", "789").forEach { line ->
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            line.forEach { ch -> PinKey(ch.toString()) { press(ch) } }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Spacer(Modifier.size(64.dp))
                        PinKey("0") { press('0') }
                        Box(
                            Modifier.size(64.dp).clip(CircleShape)
                                .clickable(enabled = cur.isNotEmpty(), onClickLabel = "Cancella l'ultima cifra") {
                                    cur = cur.dropLast(1)
                                    err = null
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.Backspace,
                                contentDescription = "Cancella",
                                tint = if (cur.isNotEmpty()) cs.onSurface else cs.onSurface.copy(alpha = 0.3f),
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (ask) TextButton(onClick = onForgot) { Text("Dimenticato il PIN?") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annulla") } },
    )
}

/** Un tasto del tastierino del PIN. */
@Composable
private fun PinKey(label: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.size(64.dp).clip(CircleShape).background(cs.surfaceContainerHighest).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, fontSize = 24.sp, fontWeight = FontWeight.Medium)
    }
}
