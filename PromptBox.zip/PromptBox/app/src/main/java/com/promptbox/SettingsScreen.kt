package com.promptbox

import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.size
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    store: Store,
    dynamic: Boolean,
    onDynamic: (Boolean) -> Unit,
    sync: SyncUi,
    themeMode: Int,
    onTheme: (Int) -> Unit,
    onBackupDone: () -> Unit,
    onChangelog: () -> Unit,
    onBack: () -> Unit,
) {
    val uriHandler = LocalUriHandler.current
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var key by remember { mutableStateOf(store.apiKey) }
    var model by remember { mutableStateOf(store.model) }
    var profile by remember { mutableStateOf(store.profile) }
    var saved by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text("Impostazioni", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            SettingsGroup("AI")
            SettingsCard("Chiave API") {
                StatusLine(ok = key.isNotBlank(), text = if (key.isNotBlank()) "Chiave inserita" else "Chiave mancante")
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it; saved = false },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    label = { Text("Chiave API Gemini") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                )
                TextButton(onClick = { uriHandler.openUri("https://aistudio.google.com/apikey") }) {
                    Text("Crea una chiave gratuita su Google AI Studio")
                }
            }

            SettingsCard("Modello") {
                OutlinedTextField(
                    value = model,
                    onValueChange = { model = it; saved = false },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    label = { Text("Nome del modello") },
                    singleLine = true,
                )
                Text(
                    "Se ricevi \"modello non trovato\" scegline uno qui sotto.",
                    fontSize = 13.sp,
                    color = cs.onSurfaceVariant,
                )
                listOf(Store.DEFAULT_MODEL, "gemini-3.5-flash-lite").forEach { name ->
                    AssistChip(
                        onClick = { model = name; saved = false },
                        label = { Text(name) },
                    )
                }
            }

            var length by remember { mutableStateOf(store.length) }
            var fallback by remember { mutableStateOf(store.fallback) }
            SettingsCard("Risposte") {
                Text("Lunghezza", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Breve", "Normale", "Dettagliata").forEachIndexed { i, label ->
                        FilterChip(
                            selected = length == i,
                            onClick = { length = i; store.length = i },
                            label = { Text(label) },
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Cambia modello da solo", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Se il modello scelto non risponde o ha finito le richieste, prova un altro modello gratuito.",
                            fontSize = 13.sp,
                            color = cs.onSurfaceVariant,
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Switch(checked = fallback, onCheckedChange = { fallback = it; store.fallback = it })
                }
                Text(
                    "Richieste fatte oggi: ${store.requestsToday()}",
                    fontSize = 13.sp,
                    color = cs.onSurfaceVariant,
                )
            }

            SettingsCard("Su di me") {
                OutlinedTextField(
                    value = profile,
                    onValueChange = { profile = it; saved = false },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    label = { Text("Obiettivi, allergie, preferenze") },
                    placeholder = { Text("Es. voglio più proteine, niente lattosio, cucino per 2") },
                    minLines = 3,
                    maxLines = 6,
                )
                Text(
                    "Viene aggiunto a ogni richiesta, così le risposte sono su misura. Resta cifrato su questo telefono; " +
                        "con l'accesso a Google si specchia anche sugli altri dispositivi. " +
                        "Con il piano gratuito Google può usare i testi inviati: scrivi solo ciò che ti sta bene condividere.",
                    fontSize = 13.sp,
                    color = cs.onSurfaceVariant,
                )
            }

            Button(
                onClick = {
                    store.apiKey = key
                    store.model = model
                    store.profile = profile
                    saved = true
                },
                modifier = Modifier.fillMaxWidth().height(54.dp),
            ) { Text(if (saved) "Salvato ✓" else "Salva") }

            SettingsGroup("Sincronizzazione")
            SettingsCard("Account Google") {
                if (!sync.on) {
                    Text(
                        "Accedi per ritrovare su tutti i tuoi dispositivi, in automatico, sezioni, categorie e colori, lista della spesa, " +
                            "\"Su di me\", account Bring e impostazioni. Vanno solo nella cartella nascosta di Prisma sul tuo Drive: " +
                            "né la chiave API né le chat.",
                        fontSize = 13.sp,
                        color = cs.onSurfaceVariant,
                    )
                    Button(onClick = sync.onSignIn, enabled = !sync.busy, modifier = Modifier.fillMaxWidth()) {
                        Text(if (sync.busy) "Un attimo..." else "Accedi con Google")
                    }
                } else {
                    Text(
                        sync.email.ifBlank { "Account Google collegato" },
                        style = MaterialTheme.typography.titleSmall,
                    )
                    Text(
                        when {
                            sync.busy -> "Sincronizzo..."
                            sync.lastSync > 0 ->
                                "Ultima sincronizzazione: " +
                                    SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(sync.lastSync))
                            else -> "Non ancora sincronizzato"
                        },
                        fontSize = 13.sp,
                        color = cs.onSurfaceVariant,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        FilledTonalButton(onClick = sync.onSyncNow, enabled = !sync.busy) { Text("Sincronizza ora") }
                        TextButton(onClick = sync.onSignOut) { Text("Esci") }
                    }
                }
                sync.message?.let { Text(it, fontSize = 13.sp, color = cs.error) }
            }

            SettingsGroup("Bring")
            var bringEmail by remember { mutableStateOf(store.bringEmail) }
            var bringMap by remember { mutableStateOf(store.bringDeptLists) }
            SettingsCard("Account e liste") {
                StatusLine(ok = bringEmail.isNotBlank(), text = bringEmail.ifBlank { "Non collegato" })
                if (bringMap.isNotEmpty()) {
                    val names = store.bringListNames
                    Text("Lista per reparto", style = MaterialTheme.typography.titleSmall)
                    bringMap.entries.sortedBy { Depts.rank(it.key) }.forEach { (d, u) ->
                        Text(
                            Depts.icon(d) + " " + d + "  →  " + (if (u == "-") "Non mandare" else names[u] ?: "lista scelta"),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                    OutlinedButton(onClick = { store.bringDeptLists = emptyMap(); bringMap = emptyMap() }) { Text("Azzera le scelte") }
                } else {
                    Text(
                        "La lista di ogni reparto (es. Carne e pesce → Macelleria) si sceglie la prima volta che mandi la spesa a Bring, dalla Lista della spesa.",
                        fontSize = 13.sp,
                        color = cs.onSurfaceVariant,
                    )
                }
                if (bringEmail.isNotBlank()) {
                    TextButton(onClick = {
                        store.bringEmail = ""
                        store.bringPassword = ""
                        store.bringDeptLists = emptyMap()
                        bringEmail = ""
                        bringMap = emptyMap()
                    }) { Text("Esci da Bring") }
                }
            }

            SettingsGroup("Aspetto")
            SettingsCard("Tema") {
                Text("Tema", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Automatico", "Chiaro", "Scuro").forEachIndexed { i, label ->
                        FilterChip(selected = themeMode == i, onClick = { onTheme(i) }, label = { Text(label) })
                    }
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Colori dinamici", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "Usa i colori dello sfondo (Material You)",
                                fontSize = 13.sp,
                                color = cs.onSurfaceVariant,
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Switch(checked = dynamic, onCheckedChange = onDynamic)
                    }
                }
            }

            SettingsGroup("Altro")
            val exportLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.CreateDocument("application/json"),
            ) { uri ->
                if (uri != null) {
                    runCatching {
                        context.contentResolver.openOutputStream(uri)!!.use { it.write(BackupTools.export(store).toByteArray()) }
                    }
                        .onSuccess { Toast.makeText(context, "Backup salvato.", Toast.LENGTH_SHORT).show() }
                        .onFailure { Toast.makeText(context, "Non sono riuscito a salvare il backup.", Toast.LENGTH_LONG).show() }
                }
            }
            val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                if (uri != null) {
                    val result = runCatching {
                        context.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                    }.mapCatching { BackupTools.import(store, it).getOrThrow() }
                    result
                        .onSuccess {
                            onBackupDone()
                            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
                        }
                        .onFailure {
                            Toast.makeText(context, it.message ?: "File non valido.", Toast.LENGTH_LONG).show()
                        }
                }
            }
            SettingsCard("Backup") {
                Text(
"Salva tutto: sezioni, categorie e colori, lista della spesa, \"Su di me\", account Bring e impostazioni. " +
                        "Non include la chiave API né le chat. Ripristinando, i dati si uniscono a quelli presenti. " +
                        "Nel file puoi scegliere anche una cartella di Drive.",
                    fontSize = 13.sp,
                    color = cs.onSurfaceVariant,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { exportLauncher.launch("prisma-backup.json") }) { Text("Salva backup") }
                    OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }) { Text("Ripristina") }
                }
                if (sync.on) {
                    Text(
                        "Oppure tieni una copia sul tuo Drive: la ritrovi da qualsiasi dispositivo con il tuo account, senza passare file.",
                        fontSize = 13.sp,
                        color = cs.onSurfaceVariant,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(onClick = sync.onBackupDrive, enabled = !sync.busy) { Text("Backup su Drive") }
                        OutlinedButton(onClick = sync.onRestoreDrive, enabled = !sync.busy) { Text("Ripristina da Drive") }
                    }
                }
            }

            SettingsCard("Aggiornamenti") {
                UpdateSection()
                OutlinedButton(onClick = onChangelog, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                    Text("Cosa c'è di nuovo")
                }
            }

            Text(
                "La chiave resta cifrata su questo dispositivo e non viene mai inclusa nell'app. " +
                    "Nel piano gratuito Google può usare i testi e le foto inviati per migliorare i suoi prodotti: " +
                    "non inviare dati sensibili.",
                fontSize = 13.sp,
                color = cs.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

/** Titolo di una delle sezioni delle impostazioni (AI, Sincronizzazione, Bring, Aspetto, Altro). */
@Composable
private fun SettingsGroup(title: String) {
    Text(
        title.uppercase(),
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.2.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 6.dp, top = 10.dp),
    )
}

/** Pallino di stato: verde = a posto, rosso = manca. */
@Composable
private fun StatusLine(ok: Boolean, text: String) {
    val cs = MaterialTheme.colorScheme
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(if (ok) cs.primary else cs.error))
        Spacer(Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = cs.primary)
            content()
        }
    }
}
