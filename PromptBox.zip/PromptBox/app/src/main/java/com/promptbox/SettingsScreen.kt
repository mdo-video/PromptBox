package com.promptbox

import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    store: Store,
    dynamic: Boolean,
    onDynamic: (Boolean) -> Unit,
    sync: SyncUi,
    onBack: () -> Unit,
) {
    val uriHandler = LocalUriHandler.current
    val cs = MaterialTheme.colorScheme
    var key by remember { mutableStateOf(store.apiKey) }
    var model by remember { mutableStateOf(store.model) }
    var saved by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text("Impostazioni", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            SettingsCard("Chiave API") {
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it; saved = false },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    label = { Text("Chiave API Gemini") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                )
                TextButton(onClick = { uriHandler.openUri("https://aistudio.google.com/apikey") }) {
                    Text("Crea una chiave gratuita su Google AI Studio")
                }
            }

            SettingsCard("Modello") {
                OutlinedTextField(
                    value = model,
                    onValueChange = { model = it; saved = false },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    label = { Text("Nome del modello") },
                    singleLine = true,
                )
                Text(
                    "Se ricevi \"modello non trovato\" scegline uno qui sotto.",
                    fontSize = 13.sp,
                    color = cs.onSurfaceVariant,
                )
                listOf(Store.DEFAULT_MODEL, "gemini-3.5-flash-lite").forEach { name ->
                    AssistChip(
                        onClick = { model = name; saved = false },
                        label = { Text(name) },
                    )
                }
            }

            Button(
                onClick = {
                    store.apiKey = key
                    store.model = model
                    saved = true
                },
                modifier = Modifier.fillMaxWidth().height(54.dp),
            ) { Text(if (saved) "Salvato ✓" else "Salva") }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                SettingsCard("Aspetto") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Colori dinamici", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "Usa i colori dello sfondo (Material You)",
                                fontSize = 13.sp,
                                color = cs.onSurfaceVariant,
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Switch(checked = dynamic, onCheckedChange = onDynamic)
                    }
                }
            }

            SettingsCard("Account Google") {
                if (!sync.on) {
                    Text(
                        "Accedi per ritrovare sezioni, icone e prompt su tutti i tuoi telefoni, in automatico. " +
                            "Vanno solo nella cartella nascosta di Prisma sul tuo Drive: né la chiave API né le chat.",
                        fontSize = 13.sp,
                        color = cs.onSurfaceVariant,
                    )
                    Button(onClick = sync.onSignIn, enabled = !sync.busy, modifier = Modifier.fillMaxWidth()) {
                        Text(if (sync.busy) "Un attimo..." else "Accedi con Google")
                    }
                } else {
                    Text(
                        sync.email.ifBlank { "Account Google collegato" },
                        style = MaterialTheme.typography.titleSmall,
                    )
                    Text(
                        when {
                            sync.busy -> "Sincronizzo..."
                            sync.lastSync > 0 ->
                                "Ultima sincronizzazione: " +
                                    SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(sync.lastSync))
                            else -> "Non ancora sincronizzato"
                        },
                        fontSize = 13.sp,
                        color = cs.onSurfaceVariant,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        FilledTonalButton(onClick = sync.onSyncNow, enabled = !sync.busy) { Text("Sincronizza ora") }
                        TextButton(onClick = sync.onSignOut) { Text("Esci") }
                    }
                }
                sync.message?.let { Text(it, fontSize = 13.sp, color = cs.error) }
            }

            SettingsCard("Aggiornamenti") { UpdateSection() }

            Text(
                "La chiave resta cifrata su questo dispositivo e non viene mai inclusa nell'app. " +
                    "Nel piano gratuito Google può usare i testi e le foto inviati per migliorare i suoi prodotti: " +
                    "non inviare dati sensibili.",
                fontSize = 13.sp,
                color = cs.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = cs.primary)
            content()
        }
    }
}
