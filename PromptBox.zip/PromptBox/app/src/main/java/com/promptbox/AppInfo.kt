package com.promptbox

/**
 * Revisione del codice: serve a sapere quale versione dei sorgenti si ha in mano (anche solo guardando lo zip),
 * perché il numero di versione dell'APK (2.N dalla versione 2.0) lo decide GitHub Actions al momento della compilazione.
 *
 * Non va aggiornata a mano: è la voce più in alto di [Changelog]. Ad ogni nuova versione si aggiunge una voce
 * al changelog con l'id successivo e la revisione si aggiorna da sola (app, Impostazioni e schermata Novità).
 * Per leggerla dai sorgenti: cerca "id = " nella prima voce di Changelog.kt.
 */
object AppInfo {
    /** Numero di revisione (id della voce più recente del changelog). */
    val revision: Int get() = Changelog.latestId

    /** Data della revisione, come scritta nel changelog. */
    val date: String get() = Changelog.entries.first().date

    /** "Revisione 32 · 18 nov 2026". */
    val label: String get() = "Revisione $revision · $date"

    /** Nome di versione (es. "2.3") di una versione con quel versionCode: serve a mostrare le versioni trovate dall'aggiornatore. */
    fun versionName(code: Int): String = "${BuildConfig.MAJOR_VERSION}.${(code - BuildConfig.BUILD_BASE).coerceAtLeast(0)}"

    /** "v2.3 · revisione 32": versione dell'APK installato e revisione dei sorgenti da cui è nato. */
    val full: String get() = "v${BuildConfig.VERSION_NAME} · revisione $revision"
}
