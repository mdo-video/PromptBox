package com.promptbox

/**
 * Revisione del codice: serve a sapere quale versione dei sorgenti si ha in mano (anche solo guardando lo zip),
 * perché il numero di versione dell'APK (1.N) lo decide GitHub Actions al momento della compilazione.
 *
 * Non va aggiornata a mano: è la voce più in alto di [Changelog]. Ad ogni nuova versione si aggiunge una voce
 * al changelog con l'id successivo e la revisione si aggiorna da sola (app, Impostazioni e schermata Novità).
 * Per leggerla dai sorgenti: cerca "id = " nella prima voce di Changelog.kt.
 */
object AppInfo {
    /** Numero di revisione (id della voce più recente del changelog). */
    val revision: Int get() = Changelog.latestId

    /** Data della revisione, come scritta nel changelog. */
    val date: String get() = Changelog.entries.first().date

    /** "Revisione 32 · 18 nov 2026". */
    val label: String get() = "Revisione $revision · $date"

    /** "v1.57 · revisione 32": versione dell'APK installato e revisione dei sorgenti da cui è nato. */
    val full: String get() = "v${BuildConfig.VERSION_NAME} · revisione $revision"
}
