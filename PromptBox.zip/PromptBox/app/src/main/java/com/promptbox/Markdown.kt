package com.promptbox

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.sp

private val headingRegex = Regex("^#{1,6}\\s+(.*)")
private val bulletRegex = Regex("^\\s*[*-]\\s+(.*)")

/** Markdown leggero: titoli, elenchi puntati, **grassetto** e link toccabili (anche indirizzi scritti per esteso). */
fun renderMarkdown(raw: String, headingColor: Color): AnnotatedString = buildAnnotatedString {
    val lines = raw.replace("\r", "").lines()
    lines.forEachIndexed { i, line ->
        val clean = line.trimEnd()
        val heading = headingRegex.matchEntire(clean)
        val bullet = bulletRegex.matchEntire(clean)
        when {
            heading != null -> withStyle(
                SpanStyle(fontWeight = FontWeight.Bold, color = headingColor, fontSize = 18.sp),
            ) { appendInline(heading.groupValues[1], headingColor) }

            bullet != null -> {
                append("•  ")
                appendInline(bullet.groupValues[1], headingColor)
            }

            else -> appendInline(clean, headingColor)
        }
        if (i < lines.lastIndex) append("\n")
    }
}

// [testo](https://...) oppure un indirizzo https://... scritto per esteso.
private val linkRegex = Regex("""\[([^\]]+)\]\((https?://[^)\s]+)\)|(https?://[^\s)\]]+)""")

private fun AnnotatedString.Builder.appendInline(text: String, linkColor: Color) {
    var last = 0
    for (m in linkRegex.findAll(text)) {
        appendBold(text.substring(last, m.range.first))
        val styles = TextLinkStyles(SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline))
        val label = m.groups[1]?.value
        if (label != null) {
            val url = m.groups[2]!!.value
            withLink(LinkAnnotation.Url(url, styles)) { append(label) }
        } else {
            // La punteggiatura finale non fa parte dell'indirizzo.
            val raw = m.groups[3]!!.value
            val url = raw.trimEnd('.', ',', ';', ':', '!', '?')
            withLink(LinkAnnotation.Url(url, styles)) { append(url) }
            append(raw.substring(url.length))
        }
        last = m.range.last + 1
    }
    appendBold(text.substring(last))
}

private fun AnnotatedString.Builder.appendBold(text: String) {
    text.split("**").forEachIndexed { index, part ->
        if (index % 2 == 1) {
            withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(part) }
        } else {
            append(part)
        }
    }
}

/** Testo senza simboli Markdown, per copia e condivisione. */
fun plainText(raw: String): String =
    raw.replace(Regex("\\[([^\\]]+)\\]\\((https?://[^)\\s]+)\\)"), "$2")
        .replace("**", "")
        .replace(Regex("(?m)^#+\\s*"), "")
        .replace(Regex("(?m)^(\\s*)[*-]\\s+"), "$1• ")
        .trim()
