package com.promptbox

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.Spacer
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.clickable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Blocchi in cui viene diviso il testo della risposta. */
private sealed interface MdBlock {
    data class Heading(val level: Int, val text: String) : MdBlock
    data class Para(val text: String) : MdBlock
    data class Item(val indent: Int, val marker: String, val text: String) : MdBlock
    data class Quote(val text: String) : MdBlock
    data class Code(val text: String) : MdBlock
    data class Table(val rows: List<List<String>>) : MdBlock
    data class Steps(val title: String, val items: List<Item>) : MdBlock
    data object Rule : MdBlock
}

private val headingRegex = Regex("^#{1,6}\\s+(.*)")
private val ruleRegex = Regex("^\\s*([-*_])(\\s*\\1){2,}\\s*$")
private val bulletRegex = Regex("^(\\s*)[*+\\-•]\\s+(.*)")
private val numberRegex = Regex("^(\\s*)(\\d{1,2})[.)]\\s+(.*)")
private val quoteRegex = Regex("^>\\s?(.*)")
private val tableSepRegex = Regex("^\\|?\\s*:?-{2,}:?\\s*(\\|\\s*:?-{2,}:?\\s*)*\\|?$")

private fun parseBlocks(raw: String): List<MdBlock> {
    val out = mutableListOf<MdBlock>()
    val para = StringBuilder()
    val code = StringBuilder()
    var inCode = false
    var table = mutableListOf<List<String>>()

    fun flushPara() {
        if (para.isNotEmpty()) {
            out += MdBlock.Para(para.toString().trim())
            para.clear()
        }
    }

    fun flushTable() {
        if (table.isNotEmpty()) {
            out += MdBlock.Table(table)
            table = mutableListOf()
        }
    }

    for (line in raw.replace("\r", "").lines()) {
        val clean = line.trimEnd()

        if (clean.trimStart().startsWith("```")) {
            if (inCode) {
                out += MdBlock.Code(code.toString().trimEnd())
                code.clear()
                inCode = false
            } else {
                flushPara(); flushTable()
                inCode = true
            }
            continue
        }
        if (inCode) {
            code.append(line).append('\n')
            continue
        }

        val trimmed = clean.trim()
        if (trimmed.startsWith("|") && trimmed.count { it == '|' } >= 2) {
            flushPara()
            if (!tableSepRegex.matches(trimmed)) {
                table += trimmed.trim('|').split('|').map { it.trim() }
            }
            continue
        } else {
            flushTable()
        }

        val heading = headingRegex.matchEntire(clean)
        val bullet = bulletRegex.matchEntire(clean)
        val number = numberRegex.matchEntire(clean)
        val quote = quoteRegex.matchEntire(trimmed)
        when {
            clean.isBlank() -> flushPara()
            ruleRegex.matches(clean) -> { flushPara(); out += MdBlock.Rule }
            heading != null -> {
                flushPara()
                val level = clean.takeWhile { it == '#' }.length
                out += MdBlock.Heading(level, heading.groupValues[1].trim().trim('*'))
            }
            bullet != null -> {
                flushPara()
                out += MdBlock.Item(bullet.groupValues[1].length / 2, "•", bullet.groupValues[2])
            }
            number != null -> {
                flushPara()
                out += MdBlock.Item(number.groupValues[1].length / 2, number.groupValues[2] + ".", number.groupValues[3])
            }
            quote != null -> { flushPara(); out += MdBlock.Quote(quote.groupValues[1]) }
            else -> {
                if (para.isNotEmpty()) para.append('\n')
                para.append(clean.trim())
            }
        }
    }
    if (inCode && code.isNotEmpty()) out += MdBlock.Code(code.toString().trimEnd())
    flushPara(); flushTable()
    return groupSteps(out)
}

private val stepsTitleRegex = Regex("^\\**\\s*(passaggi|preparazione|procedimento)\\s*:?\\s*\\**$", RegexOption.IGNORE_CASE)

/** "Passaggi:" seguito da punti rientrati diventa un gruppo che si può richiudere. */
private fun groupSteps(blocks: List<MdBlock>): List<MdBlock> {
    val out = mutableListOf<MdBlock>()
    var i = 0
    while (i < blocks.size) {
        val b = blocks[i]
        if (b is MdBlock.Item && stepsTitleRegex.matches(b.text.trim())) {
            val kids = mutableListOf<MdBlock.Item>()
            var j = i + 1
            while (j < blocks.size) {
                val n = blocks[j]
                if (n is MdBlock.Item && n.indent > b.indent) { kids += n; j++ } else break
            }
            if (kids.isNotEmpty()) {
                out += MdBlock.Steps(b.text.trim().trim('*').trim().trimEnd(':').trim(), kids)
                i = j
                continue
            }
        }
        out += b
        i++
    }
    return out
}

/**
 * Risposta formattata: titoletti colorati, elenchi con rientro, citazioni, codice e tabelle semplici.
 * Va messa dentro un SelectionContainer se si vuole il testo selezionabile.
 */
@Composable
fun MarkdownText(raw: String, modifier: Modifier = Modifier, accent: Color = MaterialTheme.colorScheme.primary) {
    val cs = MaterialTheme.colorScheme
    val blocks = remember(raw) { parseBlocks(raw) }
    val style = InlineStyle(accent = accent, codeBg = cs.surfaceContainerHighest, codeText = cs.tertiary)
    val body = MaterialTheme.typography.bodyLarge

    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        blocks.forEachIndexed { index, block ->
            when (block) {
                is MdBlock.Heading -> {
                    // Un tempo tra parentesi quadre alla fine del titolo, es. "[15 min]", diventa una pillola.
                    val m = timePillRegex.find(block.text)
                    val title = if (m != null) block.text.substring(0, m.range.first).trim() else block.text
                    Row(
                        Modifier.padding(top = if (index == 0) 0.dp else 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = buildAnnotatedString { appendInline(title, style) },
                            style = if (block.level <= 2) MaterialTheme.typography.titleLarge else MaterialTheme.typography.titleMedium,
                            color = accent,
                            modifier = Modifier.weight(1f, fill = false),
                        )
                        if (m != null) {
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "⏱ " + m.groupValues[1].trim(),
                                style = MaterialTheme.typography.labelMedium,
                                color = accent,
                                modifier = Modifier
                                    .background(accent.copy(alpha = 0.16f), RoundedCornerShape(50))
                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                            )
                        }
                    }
                }

                is MdBlock.Para -> Text(
                    text = buildAnnotatedString { appendInline(block.text, style) },
                    style = body,
                    lineHeight = 25.sp,
                )

                is MdBlock.Item -> MdItem(block, style, accent, body)

                is MdBlock.Steps -> {
                    var open by remember(raw, index) { mutableStateOf(true) }
                    Column {
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { open = !open }.padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(block.title, style = body, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text(if (open) "▲" else "▼", color = accent, style = MaterialTheme.typography.labelLarge)
                        }
                        if (open) {
                            Column(Modifier.padding(top = 6.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                block.items.forEach { MdItem(it.copy(indent = it.indent - 1), style, accent, body) }
                            }
                        }
                    }
                }

                is MdBlock.Quote -> Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                    Box(
                        Modifier.width(3.dp).fillMaxHeight()
                            .background(accent.copy(alpha = 0.6f), RoundedCornerShape(2.dp)),
                    )
                    Text(
                        text = buildAnnotatedString { appendInline(block.text, style) },
                        style = body,
                        fontStyle = FontStyle.Italic,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.padding(start = 12.dp),
                    )
                }

                is MdBlock.Code -> Text(
                    text = block.text,
                    style = MaterialTheme.typography.bodyMedium,
                    fontFamily = FontFamily.Monospace,
                    color = cs.tertiary,
                    modifier = Modifier.fillMaxWidth()
                        .background(cs.surfaceContainerHighest, RoundedCornerShape(14.dp))
                        .padding(12.dp),
                )

                is MdBlock.Table -> Column(
                    Modifier.fillMaxWidth()
                        .background(cs.surfaceContainerHighest, RoundedCornerShape(14.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                ) {
                    block.rows.forEachIndexed { r, cells ->
                        if (r > 0) HorizontalDivider(color = cs.outlineVariant)
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            cells.forEach { cell ->
                                Text(
                                    text = buildAnnotatedString { appendInline(cell, style) },
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (r == 0) FontWeight.Bold else FontWeight.Normal,
                                    color = if (r == 0) accent else Color.Unspecified,
                                    modifier = Modifier.weight(1f),
                                )
                            }
                        }
                    }
                }

                MdBlock.Rule -> HorizontalDivider(Modifier.padding(vertical = 4.dp), color = cs.outlineVariant)
            }
        }
    }
}

private val timePillRegex = Regex("\\s*\\[([^\\]]{1,24})\\]\\s*$")
private val AMBER = Color(0xFFE0A93B)

@Composable
private fun MdItem(block: MdBlock.Item, style: InlineStyle, accent: Color, body: androidx.compose.ui.text.TextStyle) {
    // "Ingredienti" / "Hai" e "Manca" hanno ciascuno il suo colore.
    val plain = block.text.trimStart('*').lowercase()
    val tint = when {
        plain.startsWith("manca") -> AMBER
        plain.startsWith("ingredienti") || plain.startsWith("hai") -> accent
        else -> null
    }
    Row(
        Modifier
            .padding(start = (block.indent * 16).dp)
            .then(
                if (tint != null) Modifier.fillMaxWidth()
                    .background(tint.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                else Modifier,
            ),
    ) {
        Text(
            text = block.marker,
            style = body,
            color = tint ?: accent,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.width(if (block.marker == "•") 20.dp else 28.dp),
        )
        Text(
            text = buildAnnotatedString { appendInline(block.text, style) },
            style = body,
            lineHeight = 25.sp,
            modifier = Modifier.weight(1f),
        )
    }
}

private class InlineStyle(val accent: Color, val codeBg: Color, val codeText: Color)

// [testo](https://...) | indirizzo scritto per esteso | **grassetto** | `codice` | *corsivo*
private val inlineRegex = Regex(
    """\[([^\]]+)\]\((https?://[^)\s]+)\)|(https?://[^\s)\]]+)|\*\*(.+?)\*\*|`([^`]+)`|(?<![\w*])\*([^*\s][^*]*?)\*(?![\w*])""",
)

private fun AnnotatedString.Builder.appendInline(text: String, st: InlineStyle) {
    var last = 0
    for (m in inlineRegex.findAll(text)) {
        append(text.substring(last, m.range.first))
        val linkStyles = TextLinkStyles(SpanStyle(color = st.accent, textDecoration = TextDecoration.Underline))
        when {
            m.groups[1] != null ->
                withLink(LinkAnnotation.Url(m.groups[2]!!.value, linkStyles)) { append(m.groups[1]!!.value) }

            m.groups[3] != null -> {
                // La punteggiatura finale non fa parte dell'indirizzo.
                val raw = m.groups[3]!!.value
                val url = raw.trimEnd('.', ',', ';', ':', '!', '?')
                withLink(LinkAnnotation.Url(url, linkStyles)) { append(url) }
                append(raw.substring(url.length))
            }

            m.groups[4] != null ->
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { appendInline(m.groups[4]!!.value, st) }

            m.groups[5] != null -> withStyle(
                SpanStyle(fontFamily = FontFamily.Monospace, background = st.codeBg, color = st.codeText),
            ) { append(m.groups[5]!!.value) }

            m.groups[6] != null ->
                withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { appendInline(m.groups[6]!!.value, st) }
        }
        last = m.range.last + 1
    }
    append(text.substring(last))
}

/** Testo senza simboli Markdown, per copia e condivisione. */
fun plainText(raw: String): String =
    raw.replace(Regex("\\[([^\\]]+)\\]\\((https?://[^)\\s]+)\\)"), "$1 ($2)")
        .replace("**", "")
        .replace("`", "")
        .replace(Regex("(?m)^#+\\s*"), "")
        .replace(Regex("(?m)^>\\s?"), "")
        .replace(Regex("(?m)^(\\s*)[*+-]\\s+"), "$1• ")
        .trim()
