package com.promptbox

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.sp

private val headingRegex = Regex("^#{1,6}\\s+(.*)")
private val bulletRegex = Regex("^\\s*[*-]\\s+(.*)")

/** Markdown leggero: titoli, elenchi puntati e **grassetto**. */
fun renderMarkdown(raw: String, headingColor: Color): AnnotatedString = buildAnnotatedString {
    val lines = raw.replace("\r", "").lines()
    lines.forEachIndexed { i, line ->
        val clean = line.trimEnd()
        val heading = headingRegex.matchEntire(clean)
        val bullet = bulletRegex.matchEntire(clean)
        when {
            heading != null -> withStyle(
                SpanStyle(fontWeight = FontWeight.Bold, color = headingColor, fontSize = 18.sp),
            ) { appendInline(heading.groupValues[1]) }

            bullet != null -> {
                append("•  ")
                appendInline(bullet.groupValues[1])
            }

            else -> appendInline(clean)
        }
        if (i < lines.lastIndex) append("\n")
    }
}

private fun AnnotatedString.Builder.appendInline(text: String) {
    text.split("**").forEachIndexed { index, part ->
        if (index % 2 == 1) {
            withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(part) }
        } else {
            append(part)
        }
    }
}

/** Testo senza simboli Markdown, per copia e condivisione. */
fun plainText(raw: String): String =
    raw.replace("**", "")
        .replace(Regex("(?m)^#+\\s*"), "")
        .replace(Regex("(?m)^(\\s*)[*-]\\s+"), "$1• ")
        .trim()
