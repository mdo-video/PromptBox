package com.promptbox

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** Le opzioni in più che una scheda creata dall'utente può avere, oltre a ripiani e scadenze. */
enum class PlaceFeature(val key: String, val label: String) {
    TEMP("t", "Temperatura"),
    HUMIDITY("h", "Umidità"),
    SPACE("s", "Spazio occupato"),
}

/**
 * Le opzioni scelte per una scheda (quali sono accese, le soglie di avviso) e le ultime letture inserite a mano:
 * il telefono non misura temperatura e umidità, quindi le scrive l'utente e l'app avvisa quando escono dai limiti.
 * Non cambia mai: ogni modifica ne restituisce uno nuovo. Viaggia dentro [CustomTab], quindi si salva e si sincronizza con le schede.
 */
data class PlaceConditions(
    val features: Set<String> = emptySet(),
    val temp: Double? = null,
    val tempMin: Double? = null,
    val tempMax: Double? = null,
    val humidity: Int? = null,
    val humidityMax: Int? = null,
    val spacePct: Int? = null,
    val spaceM2: Double? = null,
) {
    fun has(f: PlaceFeature): Boolean = f.key in features

    fun isEmpty(): Boolean = this == PlaceConditions()

    fun with(f: PlaceFeature, on: Boolean): PlaceConditions = copy(features = if (on) features + f.key else features - f.key)

    /** Temperatura fuori dai limiti scelti. Senza lettura o senza limiti non c'è avviso. */
    fun tempOut(): Boolean {
        val t = temp ?: return false
        if (!has(PlaceFeature.TEMP)) return false
        return (tempMin != null && t < tempMin) || (tempMax != null && t > tempMax)
    }

    fun humidityOut(): Boolean {
        val h = humidity ?: return false
        if (!has(PlaceFeature.HUMIDITY)) return false
        return humidityMax != null && h > humidityMax
    }

    fun spaceFull(): Boolean = has(PlaceFeature.SPACE) && (spacePct ?: 0) >= FULL_PCT

    /** Gli avvisi da mostrare, uno per riga. Vuoto = tutto nei limiti. */
    fun alerts(): List<String> = buildList {
        if (tempOut()) add(if (tempMin != null && temp!! < tempMin) "Troppo freddo: ${num(temp)} °C" else "Troppo caldo: ${num(temp!!)} °C")
        if (humidityOut()) add("Troppa umidità: $humidity%")
        if (spaceFull()) add("Quasi pieno: $spacePct%")
    }

    fun toJson(): JSONObject {
        val o = JSONObject()
        if (features.isNotEmpty()) o.put("f", JSONArray(features.toList()))
        temp?.let { o.put("t", it) }
        tempMin?.let { o.put("tn", it) }
        tempMax?.let { o.put("tx", it) }
        humidity?.let { o.put("h", it) }
        humidityMax?.let { o.put("hx", it) }
        spacePct?.let { o.put("s", it) }
        spaceM2?.let { o.put("sm", it) }
        return o
    }

    companion object {
        /** Da questa percentuale lo spazio conta come quasi pieno. */
        const val FULL_PCT = 90

        private val KEYS = PlaceFeature.values().map { it.key }.toSet()

        fun parse(o: JSONObject?): PlaceConditions {
            if (o == null) return PlaceConditions()
            val f = o.optJSONArray("f")?.let { a -> (0 until a.length()).map { a.optString(it) }.filter { it in KEYS }.toSet() } ?: emptySet()
            fun dbl(k: String): Double? = if (o.has(k) && !o.isNull(k)) o.optDouble(k).takeIf { !it.isNaN() } else null
            fun int(k: String): Int? = dbl(k)?.toInt()
            return PlaceConditions(
                features = f,
                temp = dbl("t")?.coerceIn(-50.0, 80.0),
                tempMin = dbl("tn")?.coerceIn(-50.0, 80.0),
                tempMax = dbl("tx")?.coerceIn(-50.0, 80.0),
                humidity = int("h")?.coerceIn(0, 100),
                humidityMax = int("hx")?.coerceIn(0, 100),
                spacePct = int("s")?.coerceIn(0, 100),
                spaceM2 = dbl("sm")?.takeIf { it > 0 },
            )
        }

        /**
         * Le opzioni giuste per un nome, senza rete: serve subito mentre si scrive e quando l'AI non risponde.
         * Un nome che non si riconosce non accende niente (si può sempre accendere a mano).
         */
        fun guess(name: String): PlaceConditions {
            val n = name.trim().lowercase()
            fun any(vararg w: String) = w.any { n.contains(it) }
            return when {
                any("cantina", "taverna", "enoteca", "vini", "vino") ->
                    PlaceConditions(setOf(PlaceFeature.TEMP.key, PlaceFeature.HUMIDITY.key), tempMin = 10.0, tempMax = 16.0, humidityMax = 70)
                any("garage", "box", "autorimessa", "ripostiglio", "solaio", "soffitta", "magazzino", "deposito", "sgabuzzino") ->
                    PlaceConditions(setOf(PlaceFeature.SPACE.key))
                else -> PlaceConditions()
            }
        }

        /**
         * Legge la risposta dell'AI: un oggetto JSON con "temperatura", "umidita" e "spazio", ognuno con "attiva" e, se serve,
         * i limiti ("min", "max"). Lancia un errore se non c'è niente di leggibile, così chi chiama ripiega su [guess].
         */
        fun parseSuggestion(raw: String): PlaceConditions {
            val clean = raw.replace("```json", "").replace("```", "").trim()
            val a = clean.indexOf('{')
            val b = clean.lastIndexOf('}')
            require(a >= 0 && b > a) { "Nessuna opzione proposta." }
            val o = JSONObject(clean.substring(a, b + 1))
            fun on(k: String) = o.optJSONObject(k)?.optBoolean("attiva", false) == true
            fun lim(k: String, f: String): Double? = o.optJSONObject(k)?.let { if (it.has(f) && !it.isNull(f)) it.optDouble(f).takeIf { d -> !d.isNaN() } else null }
            val features = buildSet {
                if (on("temperatura")) add(PlaceFeature.TEMP.key)
                if (on("umidita")) add(PlaceFeature.HUMIDITY.key)
                if (on("spazio")) add(PlaceFeature.SPACE.key)
            }
            var tMin = lim("temperatura", "min")?.coerceIn(-50.0, 80.0)
            var tMax = lim("temperatura", "max")?.coerceIn(-50.0, 80.0)
            if (tMin != null && tMax != null && tMin > tMax) { val x = tMin; tMin = tMax; tMax = x }
            return PlaceConditions(
                features = features,
                tempMin = tMin.takeIf { PlaceFeature.TEMP.key in features },
                tempMax = tMax.takeIf { PlaceFeature.TEMP.key in features },
                humidityMax = lim("umidita", "max")?.toInt()?.coerceIn(0, 100)?.takeIf { PlaceFeature.HUMIDITY.key in features },
            )
        }

        /** Un numero come lo scrive un italiano: virgola, senza ",0" inutile. */
        fun num(d: Double): String = if (d == Math.rint(d)) d.toInt().toString() else String.format(Locale.ITALIAN, "%.1f", d)

        /** Legge un numero scritto a mano (accetta virgola o punto); vuoto o illeggibile = null. */
        fun readNumber(s: String): Double? = s.trim().replace(',', '.').toDoubleOrNull()?.takeIf { !it.isNaN() && !it.isInfinite() }
    }
}
