package com.promptbox

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** Le opzioni in più che una scheda creata dall'utente può avere, oltre a ripiani e scadenze. */
enum class PlaceFeature(val key: String, val label: String) {
    TEMP("t", "Temperatura"),
    HUMIDITY("h", "Umidità"),
    SPACE("s", "Spazio occupato"),
    MAP("m", "Piantina"),
    DEFROST("d", "Sbrinamento"),
    CLEAN("p", "Pulizia periodica"),
}

/**
 * Che tipo di posto è una scheda: lo si capisce dal nome ("Frigo 2" è un frigo, "Congelatore garage" un congelatore,
 * "Sottotetto" un ripostiglio) e decide ripiani, scadenze, avvisi e opzioni consigliate. Si può sempre cambiare a mano.
 */
enum class PlaceKind(val key: String, val label: String) {
    FRIDGE("frigo", "Frigo"),
    FREEZER("congelatore", "Congelatore"),
    PANTRY("dispensa", "Dispensa"),
    CELLAR("cantina", "Cantina"),
    STORAGE("deposito", "Ripostiglio o deposito"),
    CLEANING("pulizie", "Pulizie e igiene"),
    OTHER("altro", "Altro");

    /** Ci si tiene da mangiare (scadenze, ricette)? */
    val food: Boolean get() = this == FRIDGE || this == FREEZER || this == PANTRY || this == CELLAR

    companion object {
        fun fromKey(k: String?): PlaceKind? = values().firstOrNull { it.key == k }

        /** Il tipo giusto per un nome, senza rete; null se non si riconosce. Capisce anche "Frigo 2", "Congelatore garage". */
        fun guess(name: String): PlaceKind? {
            val words = name.lowercase().split(Regex("[^a-zàèéìòù]+")).filter { it.isNotEmpty() }
            fun starts(vararg w: String) = words.any { t -> w.any { t.startsWith(it) } }
            fun exact(vararg w: String) = words.any { it in w }
            return when {
                starts("congelator", "freezer", "surgelat", "congelat") -> FREEZER
                starts("frigo", "refriger", "minibar") -> FRIDGE
                starts("dispens", "credenz") -> PANTRY
                starts("pulizi", "detersiv", "lavander", "igiene") -> CLEANING
                starts("cantin", "tavern", "enotec", "vino", "vini") -> CELLAR
                starts("garage", "autorimess", "ripostigli", "solai", "soffitt", "sottotett", "mansard", "magazzin", "deposit", "sgabuzzin", "armadi", "stanzin", "capann", "attrezz", "cabina") ||
                    exact("box") -> STORAGE
                else -> null
            }
        }
    }
}

/**
 * Le opzioni scelte per una scheda (quali sono accese, le soglie di avviso) e le ultime letture inserite a mano:
 * il telefono non misura temperatura e umidità, quindi le scrive l'utente e l'app avvisa quando escono dai limiti.
 * Non cambia mai: ogni modifica ne restituisce uno nuovo. Viaggia dentro [CustomTab], quindi si salva e si sincronizza con le schede.
 */
data class PlaceConditions(
    val features: Set<String> = emptySet(),
    val temp: Double? = null,
    val tempMin: Double? = null,
    val tempMax: Double? = null,
    val humidity: Int? = null,
    val humidityMax: Int? = null,
    val spacePct: Int? = null,
    val spaceM2: Double? = null,
    /** Il posto serve a cucinare (scheda "Cosa ci cucino?")? null = non deciso, come prima: la scheda si vede. */
    val cook: Boolean? = null,
    /** La piantina: dove sta il riquadro di ogni ripiano (vedi [PlaceMap]). */
    val plan: List<PlanBox> = emptyList(),
    /** Il tipo di posto scelto (chiave di [PlaceKind]); null = si capisce dal nome. */
    val kind: String? = null,
    /** Sbrinamento: ogni quanti mesi e quando è stato fatto l'ultimo (giorno, come [PantryItem.expiry]). */
    val defrostMonths: Int? = null,
    val defrostAt: Long? = null,
    /** Pulizia periodica: ogni quanti giorni e quando è stata fatta l'ultima. */
    val cleanDays: Int? = null,
    val cleanAt: Long? = null,
) {
    fun has(f: PlaceFeature): Boolean = f.key in features

    fun isEmpty(): Boolean = this == PlaceConditions()

    /** Ha qualcosa da leggere (temperatura, umidità, spazio)? La sola piantina non ha letture. */
    fun hasReadings(): Boolean = has(PlaceFeature.TEMP) || has(PlaceFeature.HUMIDITY) || has(PlaceFeature.SPACE) ||
        has(PlaceFeature.DEFROST) || has(PlaceFeature.CLEAN)

    fun placeKind(): PlaceKind? = PlaceKind.fromKey(kind)

    /**
     * Giorni che mancano al prossimo sbrinamento o alla prossima pulizia (negativo = in ritardo).
     * null se l'opzione è spenta o non si sa ancora quando è stata fatta l'ultima volta.
     */
    fun dueIn(f: PlaceFeature, today: Long = java.time.LocalDate.now().toEpochDay()): Int? {
        if (!has(f)) return null
        val every = when (f) {
            PlaceFeature.DEFROST -> defrostMonths?.let { it * 30 }
            PlaceFeature.CLEAN -> cleanDays
            else -> null
        } ?: return null
        val last = (if (f == PlaceFeature.DEFROST) defrostAt else cleanAt) ?: return null
        return (last + every - today).toInt()
    }

    /** La scheda "Cosa ci cucino?" si mostra? Sì, finché non è stata spenta. */
    fun showsCook(): Boolean = cook != false

    fun with(f: PlaceFeature, on: Boolean): PlaceConditions = copy(features = if (on) features + f.key else features - f.key)

    /** Temperatura fuori dai limiti scelti. Senza lettura o senza limiti non c'è avviso. */
    fun tempOut(): Boolean {
        val t = temp ?: return false
        if (!has(PlaceFeature.TEMP)) return false
        return (tempMin != null && t < tempMin) || (tempMax != null && t > tempMax)
    }

    fun humidityOut(): Boolean {
        val h = humidity ?: return false
        if (!has(PlaceFeature.HUMIDITY)) return false
        return humidityMax != null && h > humidityMax
    }

    fun spaceFull(): Boolean = has(PlaceFeature.SPACE) && (spacePct ?: 0) >= FULL_PCT

    /** Gli avvisi da mostrare, uno per riga. Vuoto = tutto nei limiti. */
    fun alerts(today: Long = java.time.LocalDate.now().toEpochDay()): List<String> = buildList {
        if (tempOut()) add(if (tempMin != null && temp!! < tempMin) "Troppo freddo: ${num(temp)} °C" else "Troppo caldo: ${num(temp!!)} °C")
        if (humidityOut()) add("Troppa umidità: $humidity%")
        if (spaceFull()) add("Quasi pieno: $spacePct%")
        dueIn(PlaceFeature.DEFROST, today)?.let { d -> dueText("Sbrinamento", d)?.let { add(it) } }
        dueIn(PlaceFeature.CLEAN, today)?.let { d -> dueText("Pulizia", d)?.let { add(it) } }
    }

    /** "Sbrinamento in ritardo di 3 gg", "Pulizia tra 2 gg"; null se manca più di una settimana (niente da dire). */
    private fun dueText(what: String, d: Int): String? = when {
        d < 0 -> "$what in ritardo di ${-d} gg"
        d == 0 -> "$what: oggi"
        d <= 7 -> "$what tra $d gg"
        else -> null
    }

    fun toJson(): JSONObject {
        val o = JSONObject()
        if (features.isNotEmpty()) o.put("f", JSONArray(features.toList()))
        temp?.let { o.put("t", it) }
        tempMin?.let { o.put("tn", it) }
        tempMax?.let { o.put("tx", it) }
        humidity?.let { o.put("h", it) }
        humidityMax?.let { o.put("hx", it) }
        spacePct?.let { o.put("s", it) }
        spaceM2?.let { o.put("sm", it) }
        cook?.let { o.put("c", it) }
        if (plan.isNotEmpty()) o.put("p", JSONArray(plan.map { it.toJson() }))
        kind?.let { o.put("k", it) }
        defrostMonths?.let { o.put("dm", it) }
        defrostAt?.let { o.put("da", it) }
        cleanDays?.let { o.put("cd", it) }
        cleanAt?.let { o.put("ca", it) }
        return o
    }

    companion object {
        /** Da questa percentuale lo spazio conta come quasi pieno. */
        const val FULL_PCT = 90

        private val KEYS = PlaceFeature.values().map { it.key }.toSet()

        fun parse(o: JSONObject?): PlaceConditions {
            if (o == null) return PlaceConditions()
            val f = o.optJSONArray("f")?.let { a -> (0 until a.length()).map { a.optString(it) }.filter { it in KEYS }.toSet() } ?: emptySet()
            fun dbl(k: String): Double? = if (o.has(k) && !o.isNull(k)) o.optDouble(k).takeIf { !it.isNaN() } else null
            fun int(k: String): Int? = dbl(k)?.toInt()
            return PlaceConditions(
                features = f,
                temp = dbl("t")?.coerceIn(-50.0, 80.0),
                tempMin = dbl("tn")?.coerceIn(-50.0, 80.0),
                tempMax = dbl("tx")?.coerceIn(-50.0, 80.0),
                humidity = int("h")?.coerceIn(0, 100),
                humidityMax = int("hx")?.coerceIn(0, 100),
                spacePct = int("s")?.coerceIn(0, 100),
                spaceM2 = dbl("sm")?.takeIf { it > 0 },
                cook = if (o.has("c") && !o.isNull("c")) o.optBoolean("c") else null,
                plan = PlanBox.parseAll(o.optJSONArray("p")),
                kind = o.optString("k").takeIf { PlaceKind.fromKey(it) != null },
                defrostMonths = int("dm")?.coerceIn(1, 24),
                defrostAt = dbl("da")?.toLong(),
                cleanDays = int("cd")?.coerceIn(1, 365),
                cleanAt = dbl("ca")?.toLong(),
            )
        }

        /**
         * Le opzioni consigliate per un tipo di posto: servono subito mentre si scrive il nome e quando l'AI non risponde.
         * Un frigo vuole la temperatura (0–5 °C) e la pulizia, un congelatore anche lo sbrinamento, un sottotetto o un
         * ripostiglio lo spazio e la piantina (e niente ricette).
         */
        fun forKind(k: PlaceKind): PlaceConditions = when (k) {
            PlaceKind.FRIDGE -> PlaceConditions(
                setOf(PlaceFeature.TEMP.key, PlaceFeature.CLEAN.key), kind = k.key, tempMin = 0.0, tempMax = 5.0, cleanDays = 30, cook = true,
            )
            PlaceKind.FREEZER -> PlaceConditions(
                setOf(PlaceFeature.TEMP.key, PlaceFeature.DEFROST.key), kind = k.key, tempMin = -30.0, tempMax = -15.0, defrostMonths = 6, cook = true,
            )
            PlaceKind.PANTRY -> PlaceConditions(
                setOf(PlaceFeature.HUMIDITY.key, PlaceFeature.CLEAN.key), kind = k.key, humidityMax = 65, cleanDays = 90, cook = true,
            )
            PlaceKind.CELLAR -> PlaceConditions(
                setOf(PlaceFeature.TEMP.key, PlaceFeature.HUMIDITY.key), kind = k.key, tempMin = 10.0, tempMax = 16.0, humidityMax = 70,
            )
            PlaceKind.STORAGE -> PlaceConditions(setOf(PlaceFeature.SPACE.key, PlaceFeature.MAP.key), kind = k.key, cook = false)
            PlaceKind.CLEANING -> PlaceConditions(setOf(PlaceFeature.SPACE.key), kind = k.key, cook = false)
            PlaceKind.OTHER -> PlaceConditions(kind = k.key)
        }

        /** Le opzioni giuste per un nome, senza rete. Un nome che non si riconosce non accende niente (si può sempre accendere a mano). */
        fun guess(name: String): PlaceConditions = PlaceKind.guess(name)?.let { forKind(it) } ?: PlaceConditions()

        /**
         * Legge la risposta dell'AI: un oggetto JSON con "temperatura", "umidita" e "spazio", ognuno con "attiva" e, se serve,
         * i limiti ("min", "max"). Lancia un errore se non c'è niente di leggibile, così chi chiama ripiega su [guess].
         */
        fun parseSuggestion(raw: String): PlaceConditions {
            val clean = raw.replace("```json", "").replace("```", "").trim()
            val a = clean.indexOf('{')
            val b = clean.lastIndexOf('}')
            require(a >= 0 && b > a) { "Nessuna opzione proposta." }
            val o = JSONObject(clean.substring(a, b + 1))
            fun on(k: String) = o.optJSONObject(k)?.optBoolean("attiva", false) == true
            fun lim(k: String, f: String): Double? = o.optJSONObject(k)?.let { if (it.has(f) && !it.isNull(f)) it.optDouble(f).takeIf { d -> !d.isNaN() } else null }
            val features = buildSet {
                if (on("temperatura")) add(PlaceFeature.TEMP.key)
                if (on("umidita")) add(PlaceFeature.HUMIDITY.key)
                if (on("spazio")) add(PlaceFeature.SPACE.key)
                if (on("piantina")) add(PlaceFeature.MAP.key)
                if (on("sbrinamento")) add(PlaceFeature.DEFROST.key)
                if (on("pulizia")) add(PlaceFeature.CLEAN.key)
            }
            var tMin = lim("temperatura", "min")?.coerceIn(-50.0, 80.0)
            var tMax = lim("temperatura", "max")?.coerceIn(-50.0, 80.0)
            if (tMin != null && tMax != null && tMin > tMax) { val x = tMin; tMin = tMax; tMax = x }
            // "cucina": se nel posto si tiene da mangiare. Se l'AI non lo dice resta non deciso (la scheda "Cosa ci cucino?" si vede).
            val cook = o.optJSONObject("cucina")?.let { if (it.has("attiva")) it.optBoolean("attiva") else null }
            val kind = PlaceKind.fromKey(o.optString("tipo").trim().lowercase())?.key
            val defrost = o.optJSONObject("sbrinamento")?.optInt("mesi", 0)?.takeIf { it > 0 }?.coerceIn(1, 24)
            val cleanEvery = o.optJSONObject("pulizia")?.optInt("giorni", 0)?.takeIf { it > 0 }?.coerceIn(1, 365)
            return PlaceConditions(
                features = features,
                kind = kind,
                defrostMonths = (defrost ?: 6).takeIf { PlaceFeature.DEFROST.key in features },
                cleanDays = (cleanEvery ?: 30).takeIf { PlaceFeature.CLEAN.key in features },
                cook = cook,
                tempMin = tMin.takeIf { PlaceFeature.TEMP.key in features },
                tempMax = tMax.takeIf { PlaceFeature.TEMP.key in features },
                humidityMax = lim("umidita", "max")?.toInt()?.coerceIn(0, 100)?.takeIf { PlaceFeature.HUMIDITY.key in features },
            )
        }

        /** Un numero come lo scrive un italiano: virgola, senza ",0" inutile. */
        fun num(d: Double): String = if (d == Math.rint(d)) d.toInt().toString() else String.format(Locale.ITALIAN, "%.1f", d)

        /** Legge un numero scritto a mano (accetta virgola o punto); vuoto o illeggibile = null. */
        fun readNumber(s: String): Double? = s.trim().replace(',', '.').toDoubleOrNull()?.takeIf { !it.isNaN() && !it.isInfinite() }
    }
}
