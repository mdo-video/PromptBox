package com.promptbox

import android.os.Build
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Palette del prisma: verde menta come colore principale, azzurro e ambra come accenti. */
private val BrandDark = darkColorScheme(
    primary = Color(0xFF86D8A8),
    onPrimary = Color(0xFF003920),
    primaryContainer = Color(0xFF1B5133),
    onPrimaryContainer = Color(0xFFA3F5C3),
    secondary = Color(0xFFB5CCBC),
    onSecondary = Color(0xFF213528),
    secondaryContainer = Color(0xFF384B3E),
    onSecondaryContainer = Color(0xFFD1E8D8),
    tertiary = Color(0xFFA2CDDC),
    onTertiary = Color(0xFF023543),
    tertiaryContainer = Color(0xFF204C5B),
    onTertiaryContainer = Color(0xFFBEE9F9),
    background = Color(0xFF0F1411),
    onBackground = Color(0xFFDFE4DD),
    surface = Color(0xFF0F1411),
    onSurface = Color(0xFFDFE4DD),
    surfaceVariant = Color(0xFF404943),
    onSurfaceVariant = Color(0xFFC0C9C1),
    outline = Color(0xFF8A938B),
    outlineVariant = Color(0xFF404943),
    surfaceContainerLowest = Color(0xFF0A0F0C),
    surfaceContainerLow = Color(0xFF171D19),
    surfaceContainer = Color(0xFF1B211D),
    surfaceContainerHigh = Color(0xFF252B27),
    surfaceContainerHighest = Color(0xFF303632),
)

private val base = Typography()

private val PrismaTypography = base.copy(
    displaySmall = base.displaySmall.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp),
    headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.Bold),
    titleLarge = base.titleLarge.copy(fontWeight = FontWeight.SemiBold),
    titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
    labelLarge = base.labelLarge.copy(fontWeight = FontWeight.SemiBold),
)

private val PrismaShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun PrismaTheme(dynamic: Boolean, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val scheme = if (dynamic && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        dynamicDarkColorScheme(context)
    } else {
        BrandDark
    }
    MaterialTheme(
        colorScheme = scheme,
        typography = PrismaTypography,
        shapes = PrismaShapes,
        content = content,
    )
}
