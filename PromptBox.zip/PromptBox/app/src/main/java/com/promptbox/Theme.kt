package com.promptbox

import android.os.Build
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Palette Menta (quella di partenza di Prisma): verde menta come colore principale, azzurro come accento. */
private val MentaDark = darkColorScheme(
    primary = Color(0xFF86D8A8),
    onPrimary = Color(0xFF003920),
    primaryContainer = Color(0xFF1B5133),
    onPrimaryContainer = Color(0xFFA3F5C3),
    secondary = Color(0xFFB5CCBC),
    onSecondary = Color(0xFF213528),
    secondaryContainer = Color(0xFF384B3E),
    onSecondaryContainer = Color(0xFFD1E8D8),
    tertiary = Color(0xFFA2CDDC),
    onTertiary = Color(0xFF023543),
    tertiaryContainer = Color(0xFF204C5B),
    onTertiaryContainer = Color(0xFFBEE9F9),
    background = Color(0xFF0F1411),
    onBackground = Color(0xFFDFE4DD),
    surface = Color(0xFF0F1411),
    onSurface = Color(0xFFDFE4DD),
    surfaceVariant = Color(0xFF404943),
    onSurfaceVariant = Color(0xFFC0C9C1),
    outline = Color(0xFF8A938B),
    outlineVariant = Color(0xFF404943),
    surfaceContainerLowest = Color(0xFF0A0F0C),
    surfaceContainerLow = Color(0xFF171D19),
    surfaceContainer = Color(0xFF1B211D),
    surfaceContainerHigh = Color(0xFF252B27),
    surfaceContainerHighest = Color(0xFF303632),
)

/** Versione chiara di Menta. */
private val MentaLight = lightColorScheme(
    primary = Color(0xFF1E6B45),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFA3F5C3),
    onPrimaryContainer = Color(0xFF002111),
    secondary = Color(0xFF4E6354),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFD1E8D8),
    onSecondaryContainer = Color(0xFF0C1F13),
    tertiary = Color(0xFF3A6473),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFBEE9F9),
    onTertiaryContainer = Color(0xFF001F28),
    background = Color(0xFFF5FBF5),
    onBackground = Color(0xFF171D19),
    surface = Color(0xFFF5FBF5),
    onSurface = Color(0xFF171D19),
    surfaceVariant = Color(0xFFDCE5DC),
    onSurfaceVariant = Color(0xFF404943),
    outline = Color(0xFF707972),
    outlineVariant = Color(0xFFC0C9C1),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFEFF5EF),
    surfaceContainer = Color(0xFFE9EFE9),
    surfaceContainerHigh = Color(0xFFE4EAE3),
    surfaceContainerHighest = Color(0xFFDEE4DE),
)

// ── Palette di Prisma 2.0 ─────────────────────────────────────────────────────────────────────────────────
// Generate da una tinta (primario, secondario più spento, terziario in tinta vicina, superfici leggermente
// colorate). Contrasto testo/sfondo verificato ≥ 4,5:1 per ogni coppia on-colore / colore, chiaro e scuro.

private val OceanoDark = darkColorScheme(
    primary = Color(0xFF97C9ED),
    onPrimary = Color(0xFF0A2538),
    primaryContainer = Color(0xFF194C70),
    onPrimaryContainer = Color(0xFFC9E4F8),
    secondary = Color(0xFFBBC6D3),
    onSecondary = Color(0xFF1E262E),
    secondaryContainer = Color(0xFF364453),
    onSecondaryContainer = Color(0xFFDDE3E9),
    tertiary = Color(0xFFB3DBD5),
    onTertiary = Color(0xFF17302D),
    tertiaryContainer = Color(0xFF2D5D57),
    onTertiaryContainer = Color(0xFFD9EDEA),
    background = Color(0xFF0F1417),
    onBackground = Color(0xFFE0E3E6),
    surface = Color(0xFF0F1417),
    onSurface = Color(0xFFE0E3E6),
    surfaceVariant = Color(0xFF38434D),
    onSurfaceVariant = Color(0xFFC4CDD4),
    outline = Color(0xFF84939F),
    outlineVariant = Color(0xFF38434D),
    surfaceContainerLowest = Color(0xFF0A0D0F),
    surfaceContainerLow = Color(0xFF151B20),
    surfaceContainer = Color(0xFF1A2126),
    surfaceContainerHigh = Color(0xFF222B32),
    surfaceContainerHighest = Color(0xFF2A353F),
)

private val OceanoLight = lightColorScheme(
    primary = Color(0xFF1C679C),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFC9E4F8),
    onPrimaryContainer = Color(0xFF081F30),
    secondary = Color(0xFF445569),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFDCE3E9),
    onSecondaryContainer = Color(0xFF181E25),
    tertiary = Color(0xFF38756D),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFD9EDEA),
    onTertiaryContainer = Color(0xFF142926),
    background = Color(0xFFF5F9FC),
    onBackground = Color(0xFF161A1D),
    surface = Color(0xFFF5F9FC),
    onSurface = Color(0xFF161A1D),
    surfaceVariant = Color(0xFFDEE6ED),
    onSurfaceVariant = Color(0xFF3C4953),
    outline = Color(0xFF67747E),
    outlineVariant = Color(0xFFBAC8D4),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFEEF4F9),
    surfaceContainer = Color(0xFFE6EFF7),
    surfaceContainerHigh = Color(0xFFDEEAF4),
    surfaceContainerHighest = Color(0xFFD7E6F2),
)

private val LavandaDark = darkColorScheme(
    primary = Color(0xFFB89CE8),
    onPrimary = Color(0xFF1C0D36),
    primaryContainer = Color(0xFF3B1E6B),
    onPrimaryContainer = Color(0xFFDBCCF5),
    secondary = Color(0xFFC6BCD1),
    onSecondary = Color(0xFF261F2D),
    secondaryContainer = Color(0xFF443852),
    onSecondaryContainer = Color(0xFFE3DEE8),
    tertiary = Color(0xFFD8B6CC),
    onTertiary = Color(0xFF2F1927),
    tertiaryContainer = Color(0xFF5A304B),
    onTertiaryContainer = Color(0xFFECDAE5),
    background = Color(0xFF131016),
    onBackground = Color(0xFFE3E0E6),
    surface = Color(0xFF131016),
    onSurface = Color(0xFFE3E0E6),
    surfaceVariant = Color(0xFF413A4B),
    onSurfaceVariant = Color(0xFFCBC5D3),
    outline = Color(0xFF90879C),
    outlineVariant = Color(0xFF413A4B),
    surfaceContainerLowest = Color(0xFF0C0B0F),
    surfaceContainerLow = Color(0xFF1A161F),
    surfaceContainer = Color(0xFF1F1B25),
    surfaceContainerHigh = Color(0xFF292331),
    surfaceContainerHighest = Color(0xFF332C3D),
)

private val LavandaLight = lightColorScheme(
    primary = Color(0xFF622DBE),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFDBCCF5),
    onPrimaryContainer = Color(0xFF170B2D),
    secondary = Color(0xFF564767),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFE3DDE9),
    onSecondaryContainer = Color(0xFF1E1924),
    tertiary = Color(0xFF723C5E),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFECDAE5),
    onTertiaryContainer = Color(0xFF281521),
    background = Color(0xFFF8F5FC),
    onBackground = Color(0xFF19171C),
    surface = Color(0xFFF8F5FC),
    onSurface = Color(0xFF19171C),
    surfaceVariant = Color(0xFFE4DFEC),
    onSurfaceVariant = Color(0xFF463E51),
    outline = Color(0xFF716A7C),
    outlineVariant = Color(0xFFC5BCD2),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF3EFF8),
    surfaceContainer = Color(0xFFEDE7F5),
    surfaceContainerHigh = Color(0xFFE8E0F2),
    surfaceContainerHighest = Color(0xFFE2D9EF),
)

private val TramontoDark = darkColorScheme(
    primary = Color(0xFFF2B292),
    onPrimary = Color(0xFF3B1907),
    primaryContainer = Color(0xFF753515),
    onPrimaryContainer = Color(0xFFFBD8C6),
    secondary = Color(0xFFD4C1BA),
    onSecondary = Color(0xFF2F221D),
    secondaryContainer = Color(0xFF553D35),
    onSecondaryContainer = Color(0xFFEAE0DC),
    tertiary = Color(0xFFDDB1C1),
    onTertiary = Color(0xFF321620),
    tertiaryContainer = Color(0xFF602A3E),
    onTertiaryContainer = Color(0xFFEED8E0),
    background = Color(0xFF161210),
    onBackground = Color(0xFFE6E2E0),
    surface = Color(0xFF161210),
    onSurface = Color(0xFFE6E2E0),
    surfaceVariant = Color(0xFF4B403A),
    onSurfaceVariant = Color(0xFFD3CAC5),
    outline = Color(0xFF9C8F87),
    outlineVariant = Color(0xFF4B403A),
    surfaceContainerLowest = Color(0xFF0F0C0B),
    surfaceContainerLow = Color(0xFF1F1A16),
    surfaceContainer = Color(0xFF251F1B),
    surfaceContainerHigh = Color(0xFF312823),
    surfaceContainerHighest = Color(0xFF3D322C),
)

private val TramontoLight = lightColorScheme(
    primary = Color(0xFFB64B16),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFBD8C6),
    onPrimaryContainer = Color(0xFF321506),
    secondary = Color(0xFF6B4D42),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFEAE0DC),
    onSecondaryContainer = Color(0xFF261B17),
    tertiary = Color(0xFF79354E),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFEED8E0),
    onTertiaryContainer = Color(0xFF2B131B),
    background = Color(0xFFFCF8F5),
    onBackground = Color(0xFF1C1917),
    surface = Color(0xFFFCF8F5),
    onSurface = Color(0xFF1C1917),
    surfaceVariant = Color(0xFFECE4DF),
    onSurfaceVariant = Color(0xFF51453E),
    outline = Color(0xFF7C706A),
    outlineVariant = Color(0xFFD2C4BC),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF8F2EF),
    surfaceContainer = Color(0xFFF5EDE7),
    surfaceContainerHigh = Color(0xFFF2E7E0),
    surfaceContainerHighest = Color(0xFFEFE1D9),
)

private val CiliegiaDark = darkColorScheme(
    primary = Color(0xFFEE96A4),
    onPrimary = Color(0xFF390911),
    primaryContainer = Color(0xFF711827),
    onPrimaryContainer = Color(0xFFF9C8D0),
    secondary = Color(0xFFD3BBBE),
    onSecondary = Color(0xFF2F1E20),
    secondaryContainer = Color(0xFF54363A),
    onSecondaryContainer = Color(0xFFE9DDDF),
    tertiary = Color(0xFFDBC3B3),
    onTertiary = Color(0xFF312117),
    tertiaryContainer = Color(0xFF5E402C),
    onTertiaryContainer = Color(0xFFEDE1D9),
    background = Color(0xFF161011),
    onBackground = Color(0xFFE5E1E1),
    surface = Color(0xFF161011),
    onSurface = Color(0xFFE5E1E1),
    surfaceVariant = Color(0xFF4A3B3D),
    onSurfaceVariant = Color(0xFFD2C6C8),
    outline = Color(0xFF9B888B),
    outlineVariant = Color(0xFF4A3B3D),
    surfaceContainerLowest = Color(0xFF0F0B0C),
    surfaceContainerLow = Color(0xFF1F1718),
    surfaceContainer = Color(0xFF241B1D),
    surfaceContainerHigh = Color(0xFF302426),
    surfaceContainerHighest = Color(0xFF3C2D2F),
)

private val CiliegiaLight = lightColorScheme(
    primary = Color(0xFF91182C),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFF9C8D0),
    onPrimaryContainer = Color(0xFF30080F),
    secondary = Color(0xFF694449),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFEADCDE),
    onSecondaryContainer = Color(0xFF25181A),
    tertiary = Color(0xFF765037),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFEDE1D9),
    onTertiaryContainer = Color(0xFF2A1C14),
    background = Color(0xFFFCF6F7),
    onBackground = Color(0xFF1C1718),
    surface = Color(0xFFFCF6F7),
    onSurface = Color(0xFF1C1718),
    surfaceVariant = Color(0xFFEBE0E2),
    onSurfaceVariant = Color(0xFF4F3F42),
    outline = Color(0xFF7B6B6D),
    outlineVariant = Color(0xFFD0BDC1),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF8EFF1),
    surfaceContainer = Color(0xFFF5E8EA),
    surfaceContainerHigh = Color(0xFFF2E1E4),
    surfaceContainerHighest = Color(0xFFEEDADD),
)

private val GrafiteDark = darkColorScheme(
    primary = Color(0xFFB8C0CC),
    onPrimary = Color(0xFF1C2026),
    primaryContainer = Color(0xFF3B434F),
    onPrimaryContainer = Color(0xFFDBE0E6),
    secondary = Color(0xFFBFC5CF),
    onSecondary = Color(0xFF21252C),
    secondaryContainer = Color(0xFF3B424F),
    onSecondaryContainer = Color(0xFFDFE2E7),
    tertiary = Color(0xFFBECAD0),
    onTertiary = Color(0xFF1E2629),
    tertiaryContainer = Color(0xFF3A4950),
    onTertiaryContainer = Color(0xFFDEE4E7),
    background = Color(0xFF121314),
    onBackground = Color(0xFFE2E3E4),
    surface = Color(0xFF121314),
    onSurface = Color(0xFFE2E3E4),
    surfaceVariant = Color(0xFF404245),
    onSurfaceVariant = Color(0xFFCACCCE),
    outline = Color(0xFF8E9195),
    outlineVariant = Color(0xFF404245),
    surfaceContainerLowest = Color(0xFF0C0D0D),
    surfaceContainerLow = Color(0xFF191B1C),
    surfaceContainer = Color(0xFF1E2021),
    surfaceContainerHigh = Color(0xFF282A2C),
    surfaceContainerHighest = Color(0xFF323437),
)

private val GrafiteLight = lightColorScheme(
    primary = Color(0xFF404A59),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFDBE0E6),
    onPrimaryContainer = Color(0xFF181B21),
    secondary = Color(0xFF4A5363),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFDFE2E7),
    onSecondaryContainer = Color(0xFF1A1D23),
    tertiary = Color(0xFF495B65),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFDEE4E7),
    onTertiaryContainer = Color(0xFF1A2023),
    background = Color(0xFFF7F8FA),
    onBackground = Color(0xFF19191A),
    surface = Color(0xFFF7F8FA),
    onSurface = Color(0xFF19191A),
    surfaceVariant = Color(0xFFE3E5E8),
    onSurfaceVariant = Color(0xFF45474A),
    outline = Color(0xFF707276),
    outlineVariant = Color(0xFFC2C6CB),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF1F3F6),
    surfaceContainer = Color(0xFFEBEEF2),
    surfaceContainerHigh = Color(0xFFE5E9EE),
    surfaceContainerHighest = Color(0xFFDFE3EA),
)

/** Nero AMOLED: sfondo e superfici quasi nere (pixel spenti sugli schermi OLED); le card restano distinguibili. */
private fun ColorScheme.amoled(): ColorScheme = copy(
    background = Color.Black,
    surface = Color.Black,
    surfaceContainerLowest = Color.Black,
    surfaceContainerLow = Color(0xFF0B0B0B),
    surfaceContainer = Color(0xFF121212),
    surfaceContainerHigh = Color(0xFF1A1A1A),
    surfaceContainerHighest = Color(0xFF222222),
    surfaceVariant = Color(0xFF242424),
    outlineVariant = Color(0xFF2E2E2E),
)

/** Le sei palette scelte dalle Impostazioni (l'indice è quello salvato in `Store.palette`; 0 = Menta, la palette di sempre). */
object Palettes {
    val names = listOf("Menta", "Oceano", "Lavanda", "Tramonto", "Ciliegia", "Grafite")

    fun scheme(index: Int, dark: Boolean, amoled: Boolean = false): ColorScheme {
        val base = when (index.coerceIn(0, names.lastIndex)) {
            1 -> if (dark) OceanoDark else OceanoLight
            2 -> if (dark) LavandaDark else LavandaLight
            3 -> if (dark) TramontoDark else TramontoLight
            4 -> if (dark) CiliegiaDark else CiliegiaLight
            5 -> if (dark) GrafiteDark else GrafiteLight
            else -> if (dark) MentaDark else MentaLight
        }
        return if (dark && amoled) base.amoled() else base
    }

    /** I due colori mostrati nel campione della palette (primario e terziario). */
    fun swatch(index: Int, dark: Boolean): Pair<Color, Color> {
        val s = scheme(index, dark)
        return s.primary to s.tertiary
    }
}

private val base = Typography()

private val PrismaTypography = base.copy(
    displaySmall = base.displaySmall.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp),
    headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.Bold),
    titleLarge = base.titleLarge.copy(fontWeight = FontWeight.SemiBold),
    titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
    labelLarge = base.labelLarge.copy(fontWeight = FontWeight.SemiBold),
)

private val PrismaShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

/**
 * [dynamic] = Material You (colori dello sfondo, solo Android 12+). Altrimenti vale la palette [palette] (vedi [Palettes]).
 * [amoled] rende nero lo sfondo del tema scuro, con qualunque palette e anche con Material You.
 */
@Composable
fun PrismaTheme(
    dark: Boolean,
    dynamic: Boolean,
    palette: Int = 0,
    amoled: Boolean = false,
    content: @Composable () -> Unit,
) {
    val context = LocalContext.current
    val scheme = if (dynamic && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val base = if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        if (dark && amoled) base.amoled() else base
    } else {
        Palettes.scheme(palette, dark, amoled)
    }
    MaterialTheme(
        colorScheme = scheme,
        typography = PrismaTypography,
        shapes = PrismaShapes,
        content = content,
    )
}
