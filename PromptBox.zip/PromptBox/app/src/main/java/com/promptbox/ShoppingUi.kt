package com.promptbox

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Un prodotto della lista della spesa. */
data class ShopItem(val text: String, val done: Boolean = false, val updatedAt: Long = 0L) {
    /** Identifica il prodotto tra i dispositivi: stesso nome, maiuscole a parte. */
    val key: String get() = text.trim().lowercase()
}

private val BULLET = Regex("""^\s*(?:[-*•]|\d+[.)])\s+(.+)$""")

/**
 * Estrae i prodotti dagli elenchi puntati di una risposta: toglie il Markdown e, se la riga è
 * "Nome: spiegazione", tiene solo il nome. L'utente sceglie poi quali aggiungere.
 */
fun extractShoppingItems(raw: String): List<String> {
    val out = mutableListOf<String>()
    for (line in raw.lines()) {
        val m = BULLET.find(line) ?: continue
        var t = m.groupValues[1]
            .replace("**", "").replace("__", "").replace("`", "").replace("*", "")
            .trim()
        val colon = t.indexOf(':')
        t = if (colon in 3..60) t.substring(0, colon) else if (t.length > 60) t.take(57).trimEnd() + "…" else t
        t = t.trim().trimEnd('.', ',', ';').trim()
        if (t.length >= 2) out += t
    }
    return out.distinct()
}

/** Finestra con i prodotti trovati in una risposta: si tolgono le spunte a quelli che non servono. */
@Composable
fun AddToShoppingDialog(items: List<String>, onAdd: (List<String>) -> Unit, onDismiss: () -> Unit) {
    val checked = remember { mutableStateListOf<Boolean>().apply { addAll(items.map { true }) } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Aggiungi alla lista") },
        text = {
            LazyColumn(Modifier.heightIn(max = 360.dp)) {
                itemsIndexed(items) { i, name ->
                    Row(
                        Modifier.fillMaxWidth().clickable { checked[i] = !checked[i] },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = checked[i], onCheckedChange = { checked[i] = it })
                        Text(name, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = checked.any { it },
                onClick = { onAdd(items.filterIndexed { i, _ -> checked[i] }) },
            ) { Text("Aggiungi") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annulla") } },
    )
}

/** Aggiunge i nomi nuovi in cima (senza doppioni). Restituisce la lista nuova e quanti ne ha aggiunti. */
fun withNewItems(current: List<ShopItem>, names: List<String>): Pair<List<ShopItem>, Int> {
    val now = System.currentTimeMillis()
    val fresh = names.map { it.trim() }
        .filter { n -> n.isNotEmpty() && current.none { it.key == n.lowercase() } }
        .distinctBy { it.lowercase() }
    return (fresh.map { ShopItem(it, false, now) } + current) to fresh.size
}

/**
 * La lista vive in MainActivity (così la sincronizzazione la aggiorna anche a schermata aperta):
 * qui si chiama [onChange] con la lista nuova e le chiavi dei prodotti eliminati.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShoppingScreen(
    list: List<ShopItem>,
    syncing: Boolean,
    syncEnabled: Boolean,
    syncMessage: String?,
    onRefresh: () -> Unit,
    onChange: (List<ShopItem>, List<String>) -> Unit,
    onBack: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var input by remember { mutableStateOf("") }
    // Indicatore del "tira giù": si spegne quando la sincronizzazione forzata finisce.
    var pulled by remember { mutableStateOf(false) }
    LaunchedEffect(syncing) { if (!syncing) pulled = false }

    fun add() {
        val t = input.trim()
        if (t.isNotEmpty() && list.none { it.key == t.lowercase() }) {
            onChange(listOf(ShopItem(t, false, System.currentTimeMillis())) + list, emptyList())
        }
        input = ""
    }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text("Lista della spesa", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") }
                },
                actions = {
                    if (list.any { it.done }) {
                        TextButton(onClick = {
                            onChange(list.filter { !it.done }, list.filter { it.done }.map { it.key })
                        }) { Text("Togli spuntati") }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(28.dp),
                    singleLine = true,
                    placeholder = { Text("Aggiungi un prodotto") },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { add() }),
                )
                Spacer(Modifier.width(8.dp))
                FilledIconButton(onClick = { add() }, enabled = input.isNotBlank()) {
                    Icon(Icons.Filled.Add, "Aggiungi")
                }
            }

            syncMessage?.let {
                Text(
                    it,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                    fontSize = 13.sp,
                    color = cs.error,
                )
            }

            // Tirando giù la lista si forza la sincronizzazione (serve account Google collegato).
            PullToRefreshBox(
                isRefreshing = pulled,
                onRefresh = {
                    if (syncEnabled) {
                        pulled = true
                        onRefresh()
                    }
                },
                modifier = Modifier.weight(1f).fillMaxWidth(),
            ) {
                val shown = list.sortedBy { it.done }
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 8.dp, end = 8.dp, bottom = 24.dp),
                ) {
                    if (list.isEmpty()) {
                        item {
                            Box(Modifier.fillParentMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    "Lista vuota. Scrivi un prodotto qui sopra, tocca \"Alla lista\" sotto una risposta" +
                                        if (syncEnabled) " o tira giù per sincronizzare." else ".",
                                    color = cs.onSurfaceVariant,
                                )
                            }
                        }
                    }
                    items(shown, key = { it.key }) { item ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = item.done,
                                onCheckedChange = { v ->
                                    onChange(
                                        list.map {
                                            if (it.key == item.key) it.copy(done = v, updatedAt = System.currentTimeMillis()) else it
                                        },
                                        emptyList(),
                                    )
                                },
                            )
                            Text(
                                item.text,
                                modifier = Modifier.weight(1f),
                                style = MaterialTheme.typography.bodyLarge,
                                textDecoration = if (item.done) TextDecoration.LineThrough else null,
                                color = if (item.done) cs.onSurfaceVariant else cs.onSurface,
                            )
                            IconButton(onClick = {
                                onChange(list.filter { it.key != item.key }, listOf(item.key))
                            }) { Icon(Icons.Filled.Delete, "Elimina", tint = cs.onSurfaceVariant) }
                        }
                    }
                }
            }
        }
    }
}
