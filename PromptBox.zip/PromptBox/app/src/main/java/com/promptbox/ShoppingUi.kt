package com.promptbox

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** Un prodotto della lista della spesa. [dept] è il reparto: vuoto vale "Altro". */
data class ShopItem(
    val text: String,
    val done: Boolean = false,
    val updatedAt: Long = 0L,
    val dept: String = "",
) {
    /** Identifica il prodotto tra i dispositivi: stesso nome, maiuscole a parte. */
    val key: String get() = text.trim().lowercase()
}

/** Un prodotto proposto dall'AI, con il reparto. */
data class ListSuggestion(val name: String, val dept: String)

object Depts {
    val ORDER = listOf(
        "Frutta e verdura", "Carne e pesce", "Latticini e uova", "Pane e cereali",
        "Dispensa", "Surgelati", "Bevande", "Casa e igiene", "Altro",
    )

    fun icon(dept: String): String = when (dept) {
        "Frutta e verdura" -> "🥬"
        "Carne e pesce" -> "🥩"
        "Latticini e uova" -> "🥛"
        "Pane e cereali" -> "🍞"
        "Dispensa" -> "🥫"
        "Surgelati" -> "❄️"
        "Bevande" -> "🥤"
        "Casa e igiene" -> "🧴"
        else -> "📦"
    }

    /** Reparto vicino a [dept] nell'ordine dei reparti ([by] = +1 o -1), in giro. */
    fun shift(dept: String, by: Int): String {
        val i = rank(dept.ifBlank { "Altro" })
        return ORDER[((i + by) % ORDER.size + ORDER.size) % ORDER.size]
    }

    fun rank(dept: String): Int = ORDER.indexOf(dept).let { if (it < 0) ORDER.size - 1 else it }

    /** Porta il reparto scritto dall'AI a uno di quelli noti; "Altro" diventa vuoto. */
    fun normalize(raw: String): String {
        val t = raw.trim()
        if (t.isEmpty()) return ""
        val known = ORDER.firstOrNull { it.equals(t, ignoreCase = true) }
            ?: ORDER.firstOrNull { t.length >= 4 && it.startsWith(t.take(4), ignoreCase = true) }
        if (known == null) return t.replaceFirstChar { it.uppercase() }
        return if (known == "Altro") "" else known
    }
}

private val LIST_MARKER = Regex("""\[\[\s*LISTA\s*:(.*?)\]\]""", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
private val LIST_OPEN = Regex("""\[\[\s*LISTA\s*:[^\]]*$""", RegexOption.IGNORE_CASE)

/**
 * Decide l'AI se una risposta contiene prodotti concreti da comprare: in quel caso chiude con una riga
 * nascosta [[LISTA: nome #Reparto | nome #Reparto]]. Qui la riga si toglie dal testo da mostrare e si
 * restituiscono i prodotti. Senza riga (meteo, calcoli, pacchi, cose già acquistate...) l'elenco è vuoto
 * e "Alla lista" non compare.
 */
fun splitShoppingMarker(raw: String): Pair<String, List<ListSuggestion>> {
    val found = LIST_MARKER.find(raw)?.groupValues?.get(1)
        ?.split('|')
        ?.mapNotNull { piece ->
            val parts = piece.split('#', limit = 2)
            val name = parts[0].trim().trim('-', '•', '*', ' ')
            if (name.length < 2) null else ListSuggestion(name, Depts.normalize(parts.getOrNull(1).orEmpty()))
        }
        ?.distinctBy { it.name.lowercase() }
        ?.take(15)
        .orEmpty()
    val clean = CalendarTools.strip(raw.replace(LIST_MARKER, "").replace(LIST_OPEN, ""))
    return clean to found
}

/** Finestra con i prodotti proposti: si tolgono le spunte a quelli che non servono. */
@Composable
fun AddToShoppingDialog(items: List<ListSuggestion>, onAdd: (List<ListSuggestion>) -> Unit, onDismiss: () -> Unit) {
    val checked = remember { mutableStateListOf<Boolean>().apply { addAll(items.map { true }) } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Aggiungi alla lista") },
        text = {
            LazyColumn(Modifier.heightIn(max = 360.dp)) {
                itemsIndexed(items) { i, s ->
                    Row(
                        Modifier.fillMaxWidth().clickable { checked[i] = !checked[i] },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = checked[i], onCheckedChange = { checked[i] = it })
                        Column {
                            Text(s.name, style = MaterialTheme.typography.bodyMedium)
                            if (s.dept.isNotBlank()) {
                                Text(
                                    s.dept,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = checked.any { it },
                onClick = { onAdd(items.filterIndexed { i, _ -> checked[i] }) },
            ) { Text("Aggiungi") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annulla") } },
    )
}

/** Aggiunge i prodotti nuovi in cima (senza doppioni). Restituisce la lista nuova e quanti ne ha aggiunti. */
fun withNewItems(current: List<ShopItem>, names: List<ListSuggestion>): Pair<List<ShopItem>, Int> {
    val now = System.currentTimeMillis()
    val fresh = names
        .filter { n -> n.name.trim().isNotEmpty() && current.none { it.key == n.name.trim().lowercase() } }
        .distinctBy { it.name.trim().lowercase() }
    return (fresh.map { ShopItem(it.name.trim(), false, now, Depts.normalize(it.dept)) } + current) to fresh.size
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditItemDialog(item: ShopItem, onSave: (String, String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(item.text) }
    var dept by remember { mutableStateOf(item.dept.ifBlank { "Altro" }) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Modifica") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Prodotto e quantità") },
                )
                Text("Reparto", style = MaterialTheme.typography.labelLarge)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Depts.ORDER.forEach { d ->
                        FilterChip(selected = dept == d, onClick = { dept = d }, label = { Text(d) })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = text.isNotBlank(), onClick = { onSave(text.trim(), dept) }) { Text("Salva") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annulla") } },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ShopRow(
    item: ShopItem,
    highlight: Boolean,
    onCheck: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onSwipe: ((Int) -> Unit)? = null,
) {
    val cs = MaterialTheme.colorScheme
    val row: @Composable () -> Unit = {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(if (highlight) cs.primaryContainer else cs.background)
                .clickable(onClick = onEdit),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Checkbox(checked = item.done, onCheckedChange = onCheck)
            Text(
                item.text,
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyLarge,
                textDecoration = if (item.done) TextDecoration.LineThrough else null,
                color = if (item.done) cs.onSurfaceVariant else cs.onSurface,
            )
            IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "Elimina", tint = cs.onSurfaceVariant) }
        }
    }
    if (onSwipe == null) {
        row()
        return
    }
    // Swipe a destra / sinistra: il prodotto passa al reparto dopo / prima, poi la riga torna al suo posto.
    val state = rememberSwipeToDismissBoxState(
        confirmValueChange = { v ->
            when (v) {
                SwipeToDismissBoxValue.StartToEnd -> onSwipe(1)
                SwipeToDismissBoxValue.EndToStart -> onSwipe(-1)
                else -> {}
            }
            false
        },
    )
    SwipeToDismissBox(
        state = state,
        backgroundContent = {
            val dir = state.dismissDirection
            val target = when (dir) {
                SwipeToDismissBoxValue.StartToEnd -> Depts.shift(item.dept, 1)
                SwipeToDismissBoxValue.EndToStart -> Depts.shift(item.dept, -1)
                else -> null
            }
            Box(
                Modifier.fillMaxSize().clip(RoundedCornerShape(16.dp)).background(cs.secondaryContainer).padding(horizontal = 18.dp),
                contentAlignment = if (dir == SwipeToDismissBoxValue.EndToStart) Alignment.CenterEnd else Alignment.CenterStart,
            ) {
                if (target != null) {
                    Text(
                        Depts.icon(target) + " " + target,
                        style = MaterialTheme.typography.labelLarge,
                        color = cs.onSecondaryContainer,
                    )
                }
            }
        },
        content = { row() },
    )
}

private fun openBring(context: android.content.Context) {
    val pm = context.packageManager
    val intent = pm.getLaunchIntentForPackage("ch.publisheria.bring")
        ?: android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://web.getbring.com"))
    runCatching { context.startActivity(intent) }
}

/**
 * La lista vive in MainActivity (così la sincronizzazione la aggiorna anche a schermata aperta):
 * qui si chiama [onChange] con la lista nuova e le chiavi dei prodotti eliminati.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShoppingScreen(
    list: List<ShopItem>,
    history: Map<String, Int>,
    fresh: Set<String>,
    syncing: Boolean,
    syncEnabled: Boolean,
    syncMessage: String?,
    canCook: Boolean,
    onRefresh: () -> Unit,
    onChange: (List<ShopItem>, List<String>) -> Unit,
    onBought: (String) -> Unit,
    onCook: (String) -> Unit,
    onFreshSeen: () -> Unit,
    onBack: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<ShopItem?>(null) }
    // Indicatore del "tira giù": si spegne quando la sincronizzazione forzata finisce.
    var pulled by remember { mutableStateOf(false) }
    LaunchedEffect(syncing) { if (!syncing) pulled = false }
    // I prodotti arrivati dagli altri dispositivi restano evidenziati qualche secondo.
    LaunchedEffect(fresh) {
        if (fresh.isNotEmpty()) {
            delay(6_000)
            onFreshSeen()
        }
    }

    fun addItem(name: String) {
        val t = name.trim()
        if (t.isNotEmpty() && list.none { it.key == t.lowercase() }) {
            onChange(listOf(ShopItem(t, false, System.currentTimeMillis())) + list, emptyList())
        }
    }

    fun add() {
        addItem(input)
        input = ""
    }

    fun shareList() {
        val open = list.filter { !it.done }
        val text = buildString {
            append("Lista della spesa")
            open.groupBy { it.dept.ifBlank { "Altro" } }.entries
                .sortedBy { Depts.rank(it.key) }
                .forEach { (dept, rows) ->
                    append("\n\n").append(dept).append(':')
                    rows.forEach { append("\n- ").append(it.text) }
                }
        }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(send, null))
    }

    // Invio diretto a Bring: serve email e password di Bring (si chiedono una volta e restano cifrate sul telefono).
    val store = remember { Store(context) }
    val scope = rememberCoroutineScope()
    var bringDialog by remember { mutableStateOf<String?>(null) } // null chiusa, "" aperta, altro = messaggio d'errore
    var bringBusy by remember { mutableStateOf(false) }
    var bringResult by remember { mutableStateOf<List<String>?>(null) } // invio riuscito: righe "3 a Macelleria"
    var takenOpen by remember { mutableStateOf(true) }

    // Reparto automatico: i prodotti scritti a mano (o arrivati da un altro dispositivo) senza reparto
    // vengono assegnati dall'AI. Se risponde "Altro" o non risponde, restano senza e non si richiede nella stessa sessione.
    val latest by rememberUpdatedState(list)
    val tried = remember { mutableSetOf<String>() }

    /** Assegna il reparto ai prodotti che non ce l'hanno. Restituisce la lista aggiornata. */
    suspend fun autoDepts(): List<ShopItem> {
        val todo = latest.filter { !it.done && it.dept.isBlank() && it.key !in tried }
        if (todo.isEmpty() || store.apiKey.isBlank()) return latest
        tried += todo.map { it.key }
        val found = GeminiClient.classifyDepts(store.apiKey, store.model, todo.map { it.text }, store.fallback)
            .getOrElse { e ->
                Toast.makeText(context, "Reparto automatico non riuscito: ${e.message ?: "errore"}", Toast.LENGTH_LONG).show()
                return latest
            }
        if (found.isEmpty()) return latest
        val byKey = found.mapKeys { it.key.trim().lowercase() }
        val now = System.currentTimeMillis()
        // Si applica alla lista di adesso (non a quella di quando è partita la richiesta), solo dove il reparto è ancora vuoto.
        val updated = latest.map { if (it.dept.isBlank() && byKey[it.key] != null) it.copy(dept = byKey.getValue(it.key), updatedAt = now) else it }
        onChange(updated, emptyList())
        return updated
    }

    val pendingKeys = list.filter { !it.done && it.dept.isBlank() && it.key !in tried }.map { it.key }
    LaunchedEffect(pendingKeys) {
        if (pendingKeys.isNotEmpty()) {
            delay(1_000) // se scrivi più prodotti di fila, si classificano insieme
            // Nello scope della schermata e non qui: questo blocco viene annullato a ogni ricomposizione
            // (es. quando parte la sincronizzazione) e la richiesta all'AI andrebbe persa.
            scope.launch { autoDepts() }
        }
    }

    var bringLists by remember { mutableStateOf<List<BringApi.BringList>?>(null) } // non null = scelta liste aperta

    /** Scarica le liste di Bring e apre la scelta di dove mandare cibo e prodotti per la casa. */
    fun pushToBring(email: String, password: String) {
        scope.launch {
            bringBusy = true
            BringApi.fetchLists(email, password)
                .onSuccess {
                    bringLists = it
                    store.bringListNames = store.bringListNames + it.associate { l -> l.uuid to l.name }
                }
                .onFailure { e ->
                    if (e is BringApi.AuthFailed) {
                        store.bringPassword = ""
                        bringDialog = "Email o password non corrette. Riprova."
                    } else {
                        Toast.makeText(context, "Bring non raggiungibile: ${e.message ?: "errore di rete"}", Toast.LENGTH_LONG).show()
                    }
                }
            bringBusy = false
        }
    }

    fun deptOf(item: ShopItem) = item.dept.ifBlank { "Altro" }

    /** Manda ogni reparto alla sua lista ([choice]: reparto -> codice lista, "-" = non mandare). */
    fun sendSplit(lists: List<BringApi.BringList>, choice: Map<String, String>) {
        val open = list.filter { !it.done }
        // Un invio per lista, con i prodotti di tutti i reparti che puntano lì.
        val jobs = open.groupBy { choice[deptOf(it)] ?: "-" }.filterKeys { it != "-" }
        scope.launch {
            bringBusy = true
            val done = mutableListOf<String>()
            var failure: Throwable? = null
            for ((target, rows) in jobs) {
                BringApi.addItems(store.bringEmail, store.bringPassword, target, rows.map { it.text })
                    .onSuccess { n ->
                        val name = lists.firstOrNull { it.uuid == target }?.name ?: "Bring"
                        done += "$n a $name"
                    }
                    .onFailure { failure = it }
                if (failure != null) break
            }
            if (done.isNotEmpty()) bringResult = done
            failure?.let { e ->
                if (e is BringApi.AuthFailed) {
                    store.bringPassword = ""
                    bringDialog = "Email o password non corrette. Riprova."
                } else {
                    Toast.makeText(context, "Invio a Bring non riuscito: ${e.message ?: "errore di rete"}", Toast.LENGTH_LONG).show()
                }
            }
            bringBusy = false
        }
    }

    fun sendToBring() {
        if (store.bringEmail.isNotBlank() && store.bringPassword.isNotBlank()) {
            scope.launch {
                bringBusy = true
                autoDepts() // prima di scegliere le liste, i prodotti senza reparto vengono assegnati
                bringBusy = false
                pushToBring(store.bringEmail, store.bringPassword)
            }
        } else {
            bringDialog = ""
        }
    }

    fun cook() {
        // Prima si riconoscono i reparti, poi si tolgono i prodotti che non sono alimenti (detersivi, igiene...).
        scope.launch {
            bringBusy = true
            val now = autoDepts()
            bringBusy = false
            // Se hai già spuntato qualcosa si parte da quelli, altrimenti da tutta la lista.
            val pool = now.filter { it.done }.ifEmpty { now }.filter { it.dept != "Casa e igiene" }
            if (pool.isEmpty()) {
                Toast.makeText(context, "Nella lista non ci sono alimenti", Toast.LENGTH_SHORT).show()
                return@launch
            }
            val unsure = pool.any { it.dept.isBlank() }
            onCook(
                "Ho questi ingredienti: " + pool.joinToString(", ") { it.text } + ". Cosa posso cucinare?" +
                    if (unsure) " (Ignora i prodotti che non sono alimenti, come detersivi o articoli per la casa.)" else "",
            )
        }
    }

    val listKeys = list.map { it.key }.toSet()
    val frequent = history.entries
        .filter { it.value >= 2 && it.key !in listKeys }
        .sortedByDescending { it.value }
        .take(6)
        .map { it.key.replaceFirstChar { c -> c.uppercase() } }

    bringLists?.let { lists ->
        val open = list.filter { !it.done }
        val depts = open.groupBy { deptOf(it) }.toList().sortedBy { Depts.rank(it.first) }
        val saved = remember { store.bringDeptLists }
        // Scelta ricordata per reparto. Un reparto mai scelto prende la lista che usi di più per gli altri reparti;
        // se non ce n'è nessuna resta "" (da scegliere) e "Invia" aspetta.
        val common = saved.values.filter { v -> lists.any { it.uuid == v } }
            .groupingBy { it }.eachCount().maxByOrNull { it.value }?.key ?: ""
        val choice = remember {
            mutableStateMapOf<String, String>().apply {
                depts.forEach { (d, _) ->
                    val s0 = saved[d]
                    put(d, if (s0 != null && (s0 == "-" || lists.any { it.uuid == s0 })) s0 else common)
                }
            }
        }

        val sending = depts.filter { (choice[it.first] ?: "") != "" && choice[it.first] != "-" }.sumOf { it.second.size }
        val ready = depts.all { (choice[it.first] ?: "") != "" }
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

        ModalBottomSheet(
            onDismissRequest = { bringLists = null },
            sheetState = sheetState,
            containerColor = cs.surfaceContainer,
        ) {
            Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 20.dp)) {
                Text("Manda a Bring", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(
                    "Scegli la lista per ogni reparto. Le scelte restano salvate.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(top = 2.dp, bottom = 14.dp),
                )
                if (depts.size > 1) {
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("Tutto a", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                        lists.forEach { l ->
                            AssistChip(
                                onClick = { depts.forEach { (d, _) -> choice[d] = l.uuid } },
                                label = { Text(l.name) },
                                shape = RoundedCornerShape(12.dp),
                            )
                        }
                    }
                }
                Column(
                    Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    depts.forEach { (dept, rows) ->
                        val cur = choice[dept] ?: ""
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .background(cs.surfaceContainerHigh)
                                .padding(start = 16.dp, top = 14.dp, bottom = 12.dp),
                        ) {
                            Row(Modifier.padding(end = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(dept, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = cs.primary)
                                Spacer(Modifier.width(8.dp))
                                Text("${rows.size}", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                            }
                            Text(
                                rows.joinToString(", ") { it.text },
                                modifier = Modifier.padding(top = 2.dp, bottom = 10.dp, end = 16.dp),
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Row(
                                Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                lists.forEach { l ->
                                    FilterChip(
                                        selected = cur == l.uuid,
                                        onClick = { choice[dept] = l.uuid },
                                        label = { Text(l.name) },
                                        leadingIcon = if (cur == l.uuid) {
                                            { Icon(Icons.Filled.Check, null, Modifier.size(18.dp)) }
                                        } else null,
                                        shape = RoundedCornerShape(12.dp),
                                    )
                                }
                                FilterChip(
                                    selected = cur == "-",
                                    onClick = { choice[dept] = "-" },
                                    label = { Text("Non mandare") },
                                    leadingIcon = { Icon(Icons.Filled.Close, null, Modifier.size(18.dp)) },
                                    shape = RoundedCornerShape(12.dp),
                                )
                                Spacer(Modifier.width(8.dp))
                            }
                            if (cur == "") {
                                Text(
                                    "Scegli una lista",
                                    modifier = Modifier.padding(top = 8.dp),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = cs.error,
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Button(
                    enabled = ready,
                    onClick = {
                        val result = choice.toMap()
                        store.bringDeptLists = saved + result
                        bringLists = null
                        sendSplit(lists, result)
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(26.dp),
                ) {
                    Text(
                        if (sending == 0) "Invia" else if (sending == 1) "Invia 1 prodotto" else "Invia $sending prodotti",
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
        }
    }

    bringResult?.let { sent ->
        AlertDialog(
            onDismissRequest = { bringResult = null },
            icon = { Icon(Icons.Filled.Check, null, tint = cs.primary) },
            title = { Text("Inviato a Bring") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    sent.forEach { Text("Aggiunti $it", style = MaterialTheme.typography.bodyLarge) }
                }
            },
            confirmButton = { TextButton(onClick = { bringResult = null; openBring(context) }) { Text("Apri Bring") } },
            dismissButton = { TextButton(onClick = { bringResult = null }) { Text("Chiudi") } },
        )
    }

    bringDialog?.let { message ->
        var email by remember { mutableStateOf(store.bringEmail) }
        var password by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { bringDialog = null },
            title = { Text("Accedi a Bring") },
            text = {
                Column {
                    Text(
                        if (message.isNotBlank()) message
                        else "Per mandare la spesa a Bring serve l'accesso con email e password. " +
                            "Se entri con Google o Apple, in Bring vai su Profilo > Altre impostazioni > Cambia password per crearne una. " +
                            "I dati restano cifrati su questo telefono.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        email, { email = it },
                        label = { Text("Email di Bring") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        password, { password = it },
                        label = { Text("Password di Bring") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = email.isNotBlank() && password.isNotBlank(),
                    onClick = {
                        store.bringEmail = email
                        store.bringPassword = password
                        bringDialog = null
                        pushToBring(email, password)
                    },
                ) { Text("Salva e invia") }
            },
            dismissButton = { TextButton(onClick = { bringDialog = null }) { Text("Annulla") } },
        )
    }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text("Lista della spesa", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") }
                },
                actions = {
                    if (list.any { it.done }) {
                        TextButton(onClick = {
                            onChange(list.filter { !it.done }, list.filter { it.done }.map { it.key })
                        }) { Text("Togli spuntati") }
                    }
                    if (list.any { !it.done }) {
                        IconButton(onClick = { shareList() }) { Icon(Icons.Filled.Share, "Condividi la lista") }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(28.dp),
                    singleLine = true,
                    placeholder = { Text("Aggiungi un prodotto") },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { add() }),
                )
                Spacer(Modifier.width(8.dp))
                FilledIconButton(onClick = { add() }, enabled = input.isNotBlank()) {
                    Icon(Icons.Filled.Add, "Aggiungi")
                }
            }

            if (list.isNotEmpty() || frequent.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    if (canCook && list.any { !it.done }) {
                        // Tasto principale: pieno, arrotondato, nel colore dell'app.
                        Row(
                            Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(cs.primaryContainer)
                                .clickable(enabled = !bringBusy) { cook() }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Filled.Restaurant, null, Modifier.size(20.dp), tint = cs.onPrimaryContainer)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "Cosa ci cucino?",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = cs.onPrimaryContainer,
                            )
                        }
                    }
                    if (list.any { !it.done }) {
                        Row(
                            Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(cs.surfaceContainerHigh)
                                .clickable(enabled = !bringBusy) { sendToBring() }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            if (bringBusy) {
                                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.AutoMirrored.Filled.Send, null, Modifier.size(20.dp), tint = cs.onSurface)
                            }
                            Spacer(Modifier.width(8.dp))
                            Text("Bring", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    frequent.forEach { name ->
                        AssistChip(
                            onClick = { addItem(name) },
                            label = { Text("+ $name") },
                            shape = RoundedCornerShape(20.dp),
                            border = null,
                            colors = AssistChipDefaults.assistChipColors(containerColor = cs.surfaceContainerHigh),
                        )
                    }
                }
            }

            syncMessage?.let {
                Text(
                    it,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                    fontSize = 13.sp,
                    color = cs.error,
                )
            }

            // Tirando giù la lista si forza la sincronizzazione (serve account Google collegato).
            PullToRefreshBox(
                isRefreshing = pulled,
                onRefresh = {
                    if (syncEnabled) {
                        pulled = true
                        onRefresh()
                    }
                },
                modifier = Modifier.weight(1f).fillMaxWidth(),
            ) {
                val open = list.filter { !it.done }
                val groups = open.groupBy { it.dept.ifBlank { "Altro" } }.toList().sortedBy { Depts.rank(it.first) }
                val taken = list.filter { it.done }
                // Lista Bring scelta l'ultima volta per ogni reparto, da mostrare accanto al nome.
                val targets = remember(bringLists, bringResult) {
                    val names = store.bringListNames
                    store.bringDeptLists.mapNotNull { (d, u) -> names[u]?.takeIf { u != "-" }?.let { d to it } }.toMap()
                }

                fun check(item: ShopItem, v: Boolean) {
                    onChange(
                        list.map {
                            if (it.key == item.key) it.copy(done = v, updatedAt = System.currentTimeMillis()) else it
                        },
                        emptyList(),
                    )
                    if (v) onBought(item.key)
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 8.dp, end = 8.dp, bottom = 24.dp),
                ) {
                    if (list.isEmpty()) {
                        item {
                            Box(Modifier.fillParentMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    "Lista vuota. Scrivi un prodotto qui sopra, tocca \"Alla lista\" sotto una risposta" +
                                        if (syncEnabled) " o tira giù per sincronizzare." else ".",
                                    color = cs.onSurfaceVariant,
                                )
                            }
                        }
                    }
                    groups.forEach { (dept, rows) ->
                        item(key = "h_$dept") {
                            Row(
                                Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 14.dp, bottom = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(Depts.icon(dept), fontSize = 16.sp)
                                Spacer(Modifier.width(8.dp))
                                Text(dept, style = MaterialTheme.typography.labelLarge, color = cs.primary)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "${rows.size}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = cs.onPrimaryContainer,
                                    modifier = Modifier
                                        .background(cs.primaryContainer, RoundedCornerShape(50))
                                        .padding(horizontal = 8.dp, vertical = 2.dp),
                                )
                                targets[dept]?.let {
                                    Spacer(Modifier.weight(1f))
                                    Text("→ $it", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                                }
                            }
                        }
                        items(rows, key = { "i_" + it.key }) { row ->
                            ShopRow(
                                item = row,
                                highlight = row.key in fresh,
                                onCheck = { v -> check(row, v) },
                                onEdit = { editing = row },
                                onDelete = { onChange(list.filter { it.key != row.key }, listOf(row.key)) },
                                onSwipe = { by ->
                                    val nd = Depts.shift(row.dept, by)
                                    val now = System.currentTimeMillis()
                                    onChange(
                                        list.map {
                                            if (it.key == row.key) it.copy(dept = if (nd == "Altro") "" else nd, updatedAt = now) else it
                                        },
                                        emptyList(),
                                    )
                                },
                            )
                        }
                    }
                    if (taken.isNotEmpty()) {
                        item(key = "h_taken") {
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { takenOpen = !takenOpen }
                                    .padding(start = 12.dp, end = 12.dp, top = 18.dp, bottom = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    "Presi ${taken.size}",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = cs.onSurfaceVariant,
                                    modifier = Modifier.weight(1f),
                                )
                                Icon(
                                    if (takenOpen) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                                    if (takenOpen) "Chiudi" else "Apri",
                                    tint = cs.onSurfaceVariant,
                                )
                            }
                        }
                        if (takenOpen)                         items(taken, key = { "i_" + it.key }) { row ->
                            ShopRow(
                                item = row,
                                highlight = false,
                                onCheck = { v -> check(row, v) },
                                onEdit = { editing = row },
                                onDelete = { onChange(list.filter { it.key != row.key }, listOf(row.key)) },
                            )
                        }
                    }
                }
            }
        }
    }

    editing?.let { cur ->
        EditItemDialog(
            item = cur,
            onSave = { newText, newDept ->
                val newKey = newText.trim().lowercase()
                val others = list.filter { it.key != cur.key }
                val renamed = newKey != cur.key
                val updated = if (renamed && others.any { it.key == newKey }) {
                    others
                } else {
                    listOf(
                        cur.copy(
                            text = newText.trim(),
                            dept = if (newDept == "Altro") "" else newDept,
                            updatedAt = System.currentTimeMillis(),
                        ),
                    ) + others
                }
                onChange(updated, if (renamed) listOf(cur.key) else emptyList())
                editing = null
            },
            onDismiss = { editing = null },
        )
    }
}
