package com.promptbox

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** Un prodotto della lista della spesa. [dept] è il reparto: vuoto vale "Altro". */
data class ShopItem(
    val text: String,
    val done: Boolean = false,
    val updatedAt: Long = 0L,
    val dept: String = "",
) {
    /** Identifica il prodotto tra i dispositivi: stesso nome, maiuscole a parte. */
    val key: String get() = text.trim().lowercase()
}

/** Un prodotto proposto dall'AI, con il reparto. */
data class ListSuggestion(val name: String, val dept: String)

object Depts {
    val ORDER = listOf(
        "Frutta e verdura", "Carne e pesce", "Latticini e uova", "Pane e cereali",
        "Dispensa", "Surgelati", "Bevande", "Casa e igiene", "Altro",
    )

    fun rank(dept: String): Int = ORDER.indexOf(dept).let { if (it < 0) ORDER.size - 1 else it }

    /** Porta il reparto scritto dall'AI a uno di quelli noti; "Altro" diventa vuoto. */
    fun normalize(raw: String): String {
        val t = raw.trim()
        if (t.isEmpty()) return ""
        val known = ORDER.firstOrNull { it.equals(t, ignoreCase = true) }
            ?: ORDER.firstOrNull { t.length >= 4 && it.startsWith(t.take(4), ignoreCase = true) }
        if (known == null) return t.replaceFirstChar { it.uppercase() }
        return if (known == "Altro") "" else known
    }
}

private val LIST_MARKER = Regex("""\[\[\s*LISTA\s*:(.*?)\]\]""", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
private val LIST_OPEN = Regex("""\[\[\s*LISTA\s*:[^\]]*$""", RegexOption.IGNORE_CASE)

/**
 * Decide l'AI se una risposta contiene prodotti concreti da comprare: in quel caso chiude con una riga
 * nascosta [[LISTA: nome #Reparto | nome #Reparto]]. Qui la riga si toglie dal testo da mostrare e si
 * restituiscono i prodotti. Senza riga (meteo, calcoli, pacchi, cose già acquistate...) l'elenco è vuoto
 * e "Alla lista" non compare.
 */
fun splitShoppingMarker(raw: String): Pair<String, List<ListSuggestion>> {
    val found = LIST_MARKER.find(raw)?.groupValues?.get(1)
        ?.split('|')
        ?.mapNotNull { piece ->
            val parts = piece.split('#', limit = 2)
            val name = parts[0].trim().trim('-', '•', '*', ' ')
            if (name.length < 2) null else ListSuggestion(name, Depts.normalize(parts.getOrNull(1).orEmpty()))
        }
        ?.distinctBy { it.name.lowercase() }
        ?.take(15)
        .orEmpty()
    val clean = raw.replace(LIST_MARKER, "").replace(LIST_OPEN, "").trim()
    return clean to found
}

/** Finestra con i prodotti proposti: si tolgono le spunte a quelli che non servono. */
@Composable
fun AddToShoppingDialog(items: List<ListSuggestion>, onAdd: (List<ListSuggestion>) -> Unit, onDismiss: () -> Unit) {
    val checked = remember { mutableStateListOf<Boolean>().apply { addAll(items.map { true }) } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Aggiungi alla lista") },
        text = {
            LazyColumn(Modifier.heightIn(max = 360.dp)) {
                itemsIndexed(items) { i, s ->
                    Row(
                        Modifier.fillMaxWidth().clickable { checked[i] = !checked[i] },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = checked[i], onCheckedChange = { checked[i] = it })
                        Column {
                            Text(s.name, style = MaterialTheme.typography.bodyMedium)
                            if (s.dept.isNotBlank()) {
                                Text(
                                    s.dept,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = checked.any { it },
                onClick = { onAdd(items.filterIndexed { i, _ -> checked[i] }) },
            ) { Text("Aggiungi") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annulla") } },
    )
}

/** Aggiunge i prodotti nuovi in cima (senza doppioni). Restituisce la lista nuova e quanti ne ha aggiunti. */
fun withNewItems(current: List<ShopItem>, names: List<ListSuggestion>): Pair<List<ShopItem>, Int> {
    val now = System.currentTimeMillis()
    val fresh = names
        .filter { n -> n.name.trim().isNotEmpty() && current.none { it.key == n.name.trim().lowercase() } }
        .distinctBy { it.name.trim().lowercase() }
    return (fresh.map { ShopItem(it.name.trim(), false, now, Depts.normalize(it.dept)) } + current) to fresh.size
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditItemDialog(item: ShopItem, onSave: (String, String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(item.text) }
    var dept by remember { mutableStateOf(item.dept.ifBlank { "Altro" }) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Modifica") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Prodotto e quantità") },
                )
                Text("Reparto", style = MaterialTheme.typography.labelLarge)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Depts.ORDER.forEach { d ->
                        FilterChip(selected = dept == d, onClick = { dept = d }, label = { Text(d) })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = text.isNotBlank(), onClick = { onSave(text.trim(), dept) }) { Text("Salva") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annulla") } },
    )
}

@Composable
private fun ShopRow(
    item: ShopItem,
    highlight: Boolean,
    onCheck: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (highlight) cs.primaryContainer else Color.Transparent)
            .clickable(onClick = onEdit),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(checked = item.done, onCheckedChange = onCheck)
        Text(
            item.text,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyLarge,
            textDecoration = if (item.done) TextDecoration.LineThrough else null,
            color = if (item.done) cs.onSurfaceVariant else cs.onSurface,
        )
        IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "Elimina", tint = cs.onSurfaceVariant) }
    }
}

/**
 * La lista vive in MainActivity (così la sincronizzazione la aggiorna anche a schermata aperta):
 * qui si chiama [onChange] con la lista nuova e le chiavi dei prodotti eliminati.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShoppingScreen(
    list: List<ShopItem>,
    history: Map<String, Int>,
    fresh: Set<String>,
    syncing: Boolean,
    syncEnabled: Boolean,
    syncMessage: String?,
    canCook: Boolean,
    onRefresh: () -> Unit,
    onChange: (List<ShopItem>, List<String>) -> Unit,
    onBought: (String) -> Unit,
    onCook: (String) -> Unit,
    onFreshSeen: () -> Unit,
    onBack: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<ShopItem?>(null) }
    // Indicatore del "tira giù": si spegne quando la sincronizzazione forzata finisce.
    var pulled by remember { mutableStateOf(false) }
    LaunchedEffect(syncing) { if (!syncing) pulled = false }
    // I prodotti arrivati dagli altri dispositivi restano evidenziati qualche secondo.
    LaunchedEffect(fresh) {
        if (fresh.isNotEmpty()) {
            delay(6_000)
            onFreshSeen()
        }
    }

    fun addItem(name: String) {
        val t = name.trim()
        if (t.isNotEmpty() && list.none { it.key == t.lowercase() }) {
            onChange(listOf(ShopItem(t, false, System.currentTimeMillis())) + list, emptyList())
        }
    }

    fun add() {
        addItem(input)
        input = ""
    }

    fun shareList() {
        val open = list.filter { !it.done }
        val text = buildString {
            append("Lista della spesa")
            open.groupBy { it.dept.ifBlank { "Altro" } }.entries
                .sortedBy { Depts.rank(it.key) }
                .forEach { (dept, rows) ->
                    append("\n\n").append(dept).append(':')
                    rows.forEach { append("\n- ").append(it.text) }
                }
        }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(send, null))
    }

    fun cook() {
        // Se hai già spuntato qualcosa si parte da quelli, altrimenti da tutta la lista.
        val pool = list.filter { it.done }.ifEmpty { list }
        onCook("Ho questi ingredienti: " + pool.joinToString(", ") { it.text } + ". Cosa posso cucinare?")
    }

    val listKeys = list.map { it.key }.toSet()
    val frequent = history.entries
        .filter { it.value >= 2 && it.key !in listKeys }
        .sortedByDescending { it.value }
        .take(6)
        .map { it.key.replaceFirstChar { c -> c.uppercase() } }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text("Lista della spesa", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") }
                },
                actions = {
                    if (list.any { it.done }) {
                        TextButton(onClick = {
                            onChange(list.filter { !it.done }, list.filter { it.done }.map { it.key })
                        }) { Text("Togli spuntati") }
                    }
                    if (list.any { !it.done }) {
                        IconButton(onClick = { shareList() }) { Icon(Icons.Filled.Share, "Condividi la lista") }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(28.dp),
                    singleLine = true,
                    placeholder = { Text("Aggiungi un prodotto") },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { add() }),
                )
                Spacer(Modifier.width(8.dp))
                FilledIconButton(onClick = { add() }, enabled = input.isNotBlank()) {
                    Icon(Icons.Filled.Add, "Aggiungi")
                }
            }

            if ((canCook && list.isNotEmpty()) || frequent.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    if (canCook && list.isNotEmpty()) {
                        AssistChip(
                            onClick = { cook() },
                            label = { Text("Cosa ci cucino?") },
                            leadingIcon = { Icon(Icons.Filled.Restaurant, null) },
                        )
                    }
                    frequent.forEach { name ->
                        AssistChip(onClick = { addItem(name) }, label = { Text("+ $name") })
                    }
                }
            }

            syncMessage?.let {
                Text(
                    it,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                    fontSize = 13.sp,
                    color = cs.error,
                )
            }

            // Tirando giù la lista si forza la sincronizzazione (serve account Google collegato).
            PullToRefreshBox(
                isRefreshing = pulled,
                onRefresh = {
                    if (syncEnabled) {
                        pulled = true
                        onRefresh()
                    }
                },
                modifier = Modifier.weight(1f).fillMaxWidth(),
            ) {
                val open = list.filter { !it.done }
                val groups = open.groupBy { it.dept.ifBlank { "Altro" } }.toList().sortedBy { Depts.rank(it.first) }
                val taken = list.filter { it.done }

                fun check(item: ShopItem, v: Boolean) {
                    onChange(
                        list.map {
                            if (it.key == item.key) it.copy(done = v, updatedAt = System.currentTimeMillis()) else it
                        },
                        emptyList(),
                    )
                    if (v) onBought(item.key)
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 8.dp, end = 8.dp, bottom = 24.dp),
                ) {
                    if (list.isEmpty()) {
                        item {
                            Box(Modifier.fillParentMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    "Lista vuota. Scrivi un prodotto qui sopra, tocca \"Alla lista\" sotto una risposta" +
                                        if (syncEnabled) " o tira giù per sincronizzare." else ".",
                                    color = cs.onSurfaceVariant,
                                )
                            }
                        }
                    }
                    groups.forEach { (dept, rows) ->
                        item(key = "h_$dept") {
                            Text(
                                dept,
                                modifier = Modifier.padding(start = 12.dp, top = 14.dp, bottom = 2.dp),
                                style = MaterialTheme.typography.labelLarge,
                                color = cs.primary,
                            )
                        }
                        items(rows, key = { "i_" + it.key }) { row ->
                            ShopRow(
                                item = row,
                                highlight = row.key in fresh,
                                onCheck = { v -> check(row, v) },
                                onEdit = { editing = row },
                                onDelete = { onChange(list.filter { it.key != row.key }, listOf(row.key)) },
                            )
                        }
                    }
                    if (taken.isNotEmpty()) {
                        item(key = "h_taken") {
                            Text(
                                "Presi",
                                modifier = Modifier.padding(start = 12.dp, top = 18.dp, bottom = 2.dp),
                                style = MaterialTheme.typography.labelLarge,
                                color = cs.onSurfaceVariant,
                            )
                        }
                        items(taken, key = { "i_" + it.key }) { row ->
                            ShopRow(
                                item = row,
                                highlight = false,
                                onCheck = { v -> check(row, v) },
                                onEdit = { editing = row },
                                onDelete = { onChange(list.filter { it.key != row.key }, listOf(row.key)) },
                            )
                        }
                    }
                }
            }
        }
    }

    editing?.let { cur ->
        EditItemDialog(
            item = cur,
            onSave = { newText, newDept ->
                val newKey = newText.trim().lowercase()
                val others = list.filter { it.key != cur.key }
                val renamed = newKey != cur.key
                val updated = if (renamed && others.any { it.key == newKey }) {
                    others
                } else {
                    listOf(
                        cur.copy(
                            text = newText.trim(),
                            dept = if (newDept == "Altro") "" else newDept,
                            updatedAt = System.currentTimeMillis(),
                        ),
                    ) + others
                }
                onChange(updated, if (renamed) listOf(cur.key) else emptyList())
                editing = null
            },
            onDismiss = { editing = null },
        )
    }
}
