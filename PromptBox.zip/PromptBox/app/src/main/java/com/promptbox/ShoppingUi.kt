package com.promptbox

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp

/** Un prodotto della lista della spesa. */
data class ShopItem(val text: String, val done: Boolean = false)

private val BULLET = Regex("""^\s*(?:[-*•]|\d+[.)])\s+(.+)$""")

/**
 * Estrae i prodotti dagli elenchi puntati di una risposta: toglie il Markdown e, se la riga è
 * "Nome: spiegazione", tiene solo il nome. L'utente sceglie poi quali aggiungere.
 */
fun extractShoppingItems(raw: String): List<String> {
    val out = mutableListOf<String>()
    for (line in raw.lines()) {
        val m = BULLET.find(line) ?: continue
        var t = m.groupValues[1]
            .replace("**", "").replace("__", "").replace("`", "").replace("*", "")
            .trim()
        val colon = t.indexOf(':')
        t = if (colon in 3..60) t.substring(0, colon) else if (t.length > 60) t.take(57).trimEnd() + "…" else t
        t = t.trim().trimEnd('.', ',', ';').trim()
        if (t.length >= 2) out += t
    }
    return out.distinct()
}

/** Finestra con i prodotti trovati in una risposta: si tolgono le spunte a quelli che non servono. */
@Composable
fun AddToShoppingDialog(items: List<String>, onAdd: (List<String>) -> Unit, onDismiss: () -> Unit) {
    val checked = remember { mutableStateListOf<Boolean>().apply { addAll(items.map { true }) } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Aggiungi alla lista") },
        text = {
            LazyColumn(Modifier.heightIn(max = 360.dp)) {
                itemsIndexed(items) { i, name ->
                    Row(
                        Modifier.fillMaxWidth().clickable { checked[i] = !checked[i] },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = checked[i], onCheckedChange = { checked[i] = it })
                        Text(name, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = checked.any { it },
                onClick = { onAdd(items.filterIndexed { i, _ -> checked[i] }) },
            ) { Text("Aggiungi") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annulla") } },
    )
}

/** Aggiunge alla lista salvata i nomi nuovi (senza doppioni) e restituisce quanti ne ha aggiunti. */
fun addToShopping(store: Store, names: List<String>): Int {
    val current = store.shoppingList()
    val fresh = names.filter { n -> current.none { it.text.equals(n, ignoreCase = true) } }
    if (fresh.isNotEmpty()) store.saveShopping(fresh.map { ShopItem(it) } + current)
    return fresh.size
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShoppingScreen(store: Store, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val list = remember { mutableStateListOf<ShopItem>().apply { addAll(store.shoppingList()) } }
    var input by remember { mutableStateOf("") }

    fun save() = store.saveShopping(list.toList())
    fun add() {
        val t = input.trim()
        if (t.isNotEmpty() && list.none { it.text.equals(t, ignoreCase = true) }) {
            list.add(0, ShopItem(t))
            save()
        }
        input = ""
    }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text("Lista della spesa", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") }
                },
                actions = {
                    if (list.any { it.done }) {
                        TextButton(onClick = { list.removeAll { it.done }; save() }) { Text("Togli spuntati") }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(28.dp),
                    singleLine = true,
                    placeholder = { Text("Aggiungi un prodotto") },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { add() }),
                )
                Spacer(Modifier.width(8.dp))
                FilledIconButton(onClick = { add() }, enabled = input.isNotBlank()) {
                    Icon(Icons.Filled.Add, "Aggiungi")
                }
            }

            if (list.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "Lista vuota. Scrivi un prodotto qui sopra, oppure tocca \"Alla lista\" sotto una risposta.",
                        color = cs.onSurfaceVariant,
                    )
                }
            } else {
                val shown = list.sortedBy { it.done }
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(start = 8.dp, end = 8.dp, bottom = 24.dp),
                ) {
                    items(shown, key = { it.text }) { item ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = item.done,
                                onCheckedChange = { v ->
                                    val idx = list.indexOfFirst { it.text == item.text }
                                    if (idx >= 0) {
                                        list[idx] = list[idx].copy(done = v)
                                        save()
                                    }
                                },
                            )
                            Text(
                                item.text,
                                modifier = Modifier.weight(1f),
                                style = MaterialTheme.typography.bodyLarge,
                                textDecoration = if (item.done) TextDecoration.LineThrough else null,
                                color = if (item.done) cs.onSurfaceVariant else cs.onSurface,
                            )
                            IconButton(onClick = {
                                list.removeAll { it.text == item.text }
                                save()
                            }) { Icon(Icons.Filled.Delete, "Elimina", tint = cs.onSurfaceVariant) }
                        }
                    }
                }
            }
        }
    }
}
