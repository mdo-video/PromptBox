package com.promptbox

import android.graphics.Bitmap
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Un messaggio della conversazione. La foto resta in memoria solo finché l'app è aperta. */
data class ChatTurn(
    val fromUser: Boolean,
    val text: String,
    val image: Bitmap? = null,
    val hadImage: Boolean = image != null,
    val doc: ChatDoc? = null,
    val docName: String? = doc?.name,
)

/** Documento allegato (PDF o file di testo). Come la foto, resta in memoria solo finché l'app è aperta. */
class ChatDoc(val name: String, val mime: String, val bytes: ByteArray) {
    val isText: Boolean get() = mime.startsWith("text/")
}

object GeminiClient {

    /** Altri modelli gratuiti da provare, in ordine, quando quello scelto non risponde. */
    private val FALLBACK_MODELS = listOf("gemini-3.5-flash-lite", Store.DEFAULT_MODEL)
    private val RETRYABLE = setOf(404, 429, 500, 502, 503, 504)

    /** Aggiunto a ogni prompt di sistema: risposte ordinate e facili da leggere sul telefono. */
    private const val STYLE =
        "\n\nStile della risposta: usa Markdown semplice. Se la risposta è lunga, dividi in blocchi con titoletti " +
            "brevi (## con una emoji all'inizio), elenchi puntati con '-', le parole chiave in **grassetto**, " +
            "paragrafi corti. Se proponi ricette: un titoletto per ricetta, con il tempo di preparazione alla fine tra parentesi quadre (es. ## 🥗 Nome [15 min]), poi 'Ingredienti:', 'Manca:' e 'Passaggi:' come elenchi. Niente tabelle. Se l'utente fa una domanda di approfondimento, rispondi in modo " +
            "coerente con i messaggi precedenti, senza ripetere tutto da capo." +
            LIST_RULE

    private const val LIST_RULE =
        "\n\nLista della spesa: SOLO se la risposta propone o nomina prodotti concreti che l'utente può ancora " +
            "comprare (alimenti, articoli di supermercato, oggetti da acquistare), chiudi con una riga finale esatta " +
            "[[LISTA: nome 1 #Reparto | nome 2 #Reparto | nome 3 #Reparto]], con nomi brevi (massimo 4 parole) in italiano, " +
            "senza marca se non serve, e SEMPRE la quantità in fondo al nome (es. Petto di pollo 600 g, Uova 6, Mascarpone 250 g, Latte 1 l). " +
            "Se la risposta non indica la quantità, stimala tu in base a persone, giorni o porzioni citati. " +
            "Se la risposta è un menù o contiene più ricette, metti tutti gli ingredienti da comprare per l'intero periodo, " +
            "sommando le quantità dello stesso prodotto (un prodotto per riga, niente doppioni); nelle ricette con \"Manca:\" metti solo ciò che manca. " +
            "Il reparto è uno tra: Frutta e verdura, Carne e pesce, Latticini e uova, Pane e cereali, Dispensa, Surgelati, " +
            "Bevande, Casa e igiene, Altro. " +
            "NON aggiungere la riga per meteo, calcoli o matematica, spiegazioni, traduzioni, tracciamento di pacchi " +
            "o spedizioni, cose già acquistate, servizi o argomenti non acquistabili. Non parlare mai di questa riga."

    /**
     * Dopo che l'utente ha modificato a mano una risposta: rilegge il testo nuovo e rifà le righe nascoste
     * (lista della spesa e/o calendario), così "Alla lista" e "Aggiungi a Calendar" riflettono le modifiche.
     */
    suspend fun refreshMarkers(apiKey: String, model: String, text: String, list: Boolean, calendar: Boolean, fallback: Boolean): Result<String> {
        val others = if (fallback) FALLBACK_MODELS.filter { it != model } else emptyList()
        val system = "Ti viene dato il testo di una risposta già scritta. NON riscriverlo e non commentarlo: rispondi SOLO con " +
            "le righe finali richieste qui sotto, una per riga, senza altro testo. Se una riga non serve, non scriverla." +
            (if (list) LIST_RULE else "") + (if (calendar) CalendarTools.promptRule() else "")
        return generate(apiKey, model, system, listOf(ChatTurn(true, text)), others)
    }

    private const val EXTRACT_SYSTEM =
        "Nel documento allegato c'è una sezione \"DATI SCHEDA\" che contiene un oggetto JSON. " +
            "Copialo identico, carattere per carattere. Rispondi SOLO con il JSON, senza testo prima o dopo " +
            "e senza backtick. Se la sezione non esiste rispondi esattamente NESSUN_DATO."

    /** Fa copiare all'AI il blocco DATI SCHEDA di un PDF (nessuno stile aggiunto, solo il JSON). */
    suspend fun extractData(apiKey: String, model: String, doc: ChatDoc, fallback: Boolean): Result<String> {
        val others = if (fallback) FALLBACK_MODELS.filter { it != model } else emptyList()
        return generate(apiKey, model, EXTRACT_SYSTEM, listOf(ChatTurn(true, "Estrai il JSON.", doc = doc)), others)
    }

    suspend fun ask(
        apiKey: String,
        model: String,
        systemPrompt: String,
        userText: String,
        image: Bitmap?,
    ): Result<String> = generate(apiKey, model, systemPrompt, listOf(ChatTurn(true, userText, image)))

    /** Conversazione completa: i turni si alternano utente / AI, l'ultimo è dell'utente. */
    suspend fun chat(
        apiKey: String,
        model: String,
        systemPrompt: String,
        turns: List<ChatTurn>,
        profile: String = "",
        length: Int = 1,
        fallback: Boolean = false,
    ): Result<String> {
        val about = if (profile.isBlank()) "" else
            "\n\nInformazioni sull'utente (tienine conto quando sono utili, senza ripeterle): ${profile.trim()}"
        val size = when (length) {
            0 -> "\n\nLunghezza: sii molto sintetico, al massimo 6-8 righe, solo l'essenziale."
            2 -> "\n\nLunghezza: dai una risposta più completa, con più dettagli e motivazioni " +
                "(questa indicazione ha la precedenza su qualsiasi richiesta di essere breve)."
            else -> ""
        }
        val others = if (fallback) FALLBACK_MODELS.filter { it != model } else emptyList()
        return generate(apiKey, model, systemPrompt + about + size + STYLE + CalendarTools.promptRule(), turns, others)
    }

    /** Errore HTTP di Gemini: il codice serve a decidere se provare un altro modello. */
    private class HttpFail(val code: Int, message: String) : RuntimeException(message)

    private suspend fun generate(
        apiKey: String,
        model: String,
        systemPrompt: String,
        turns: List<ChatTurn>,
        fallbackModels: List<String> = emptyList(),
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            require(apiKey.isNotBlank()) { "Manca la chiave API. Inseriscila nelle Impostazioni." }

            val contents = JSONArray()
            turns.forEach { t ->
                val parts = JSONArray()
                if (t.text.isNotBlank()) parts.put(JSONObject().put("text", t.text.trim()))
                if (t.doc != null) {
                    if (t.doc.isText) {
                        // I file di testo vanno come testo; i PDF come dati allegati.
                        parts.put(
                            JSONObject().put(
                                "text",
                                "[File allegato: ${t.doc.name}]\n" + String(t.doc.bytes, Charsets.UTF_8),
                            ),
                        )
                    } else {
                        parts.put(
                            JSONObject().put(
                                "inline_data",
                                JSONObject().put("mime_type", t.doc.mime)
                                    .put("data", Base64.encodeToString(t.doc.bytes, Base64.NO_WRAP)),
                            ),
                        )
                    }
                }
                if (t.image != null) {
                    parts.put(
                        JSONObject().put(
                            "inline_data",
                            JSONObject().put("mime_type", "image/jpeg").put("data", t.image.toBase64()),
                        ),
                    )
                }
                if (parts.length() == 0) {
                    parts.put(JSONObject().put("text", if (t.fromUser) "Analizza." else "..."))
                }
                contents.put(JSONObject().put("role", if (t.fromUser) "user" else "model").put("parts", parts))
            }

            val body = JSONObject()
                .put(
                    "systemInstruction",
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))),
                )
                .put("contents", contents)
                .toString()

            // Modello scelto per primo; se non c'è (404) o ha finito le richieste (429) o il server è giù, prova gli altri.
            var last: HttpFail? = null
            for (m in listOf(model) + fallbackModels) {
                try {
                    return@runCatching post(apiKey, m, body)
                } catch (e: HttpFail) {
                    last = e
                    if (e.code !in RETRYABLE) throw e
                }
            }
            throw last ?: RuntimeException("Errore sconosciuto.")
        }
    }

    private fun post(apiKey: String, model: String, body: String): String {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 90_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", apiKey.trim())
        }
        try {
            conn.outputStream.use { it.write(body.toByteArray()) }
            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw HttpFail(code, friendlyError(code, text))
            return extractText(text)
        } finally {
            conn.disconnect()
        }
    }

    /**
     * Fa scegliere all'AI una sola emoji per la sezione, nello stesso stile di quelle fisse
     * (🛒 🏷️ 🥦 ✨). Se qualcosa va storto restituisce un errore e l'app usa 📌.
     */
    suspend fun pickEmoji(apiKey: String, model: String, title: String, prompt: String): Result<String> =
        ask(
            apiKey = apiKey,
            model = model,
            systemPrompt = "Scegli UNA sola emoji che rappresenti al meglio una sezione di un'app. " +
                "Stile: emoji classica e colorata di un oggetto, cibo, luogo o attività concreta, " +
                "come 🛒 🏷️ 🥦 ✈️ 💪 📚. Niente bandiere, niente lettere o numeri, niente simboli astratti. " +
                "Rispondi SOLO con l'emoji, senza testo, spazi o punteggiatura.",
            userText = "Nome sezione: $title\nIstruzioni della sezione: $prompt",
            image = null,
        ).mapCatching { raw ->
            val bi = android.icu.text.BreakIterator.getCharacterInstance()
            val t = raw.trim()
            bi.setText(t)
            val first = t.substring(0, bi.next().coerceAtLeast(0))
            // Deve essere davvero un'emoji, non una lettera o una cifra.
            require(first.isNotEmpty() && first.codePointAt(0) > 0x2000) { "Emoji non valida" }
            first
        }

    /**
     * Assegna un reparto della spesa a ogni prodotto scritto a mano. Restituisce nome -> reparto
     * (solo per i prodotti riconosciuti; "Altro" non compare).
     */
    suspend fun classifyDepts(apiKey: String, model: String, names: List<String>, fallback: Boolean): Result<Map<String, String>> {
        val others = if (fallback) FALLBACK_MODELS.filter { it != model } else emptyList()
        val system = "Sei un assistente per la lista della spesa di un supermercato italiano. " +
            "Per ogni prodotto dell'elenco scegli il reparto tra questi: " +
            Depts.ORDER.joinToString(", ") + ". " +
            "Esempi: tagliata, petto di pollo, salmone, prosciutto -> Carne e pesce; sgrassatore, detersivo, candeggina, ammorbidente, " +
            "carta igienica, spugne, sacchetti, shampoo -> Casa e igiene. " +
            "Usa Altro SOLO se il prodotto non è né un alimento né un prodotto per la casa o l'igiene. " +
            "Rispondi con UNA riga per prodotto, nel formato esatto: nome del prodotto uguale all'elenco | reparto. " +
            "Nessun altro testo, niente numerazione."
        return generate(apiKey, model, system, listOf(ChatTurn(true, names.joinToString("\n"))), others).mapCatching { raw ->
            val byLower = names.associateBy { it.trim().lowercase() }
            raw.lines().mapNotNull { line ->
                val parts = line.split('|', limit = 2)
                if (parts.size < 2) return@mapNotNull null
                val name = byLower[parts[0].trim().trim('-', '*', ' ').lowercase()] ?: return@mapNotNull null
                val dept = Depts.normalize(parts[1].trim())
                if (dept.isEmpty()) null else name to dept
            }.toMap()
        }
    }

    /** Propone fino a 5 emoji diverse tra cui scegliere l'icona della sezione. */
    suspend fun suggestEmojis(apiKey: String, model: String, title: String, prompt: String): Result<List<String>> =
        ask(
            apiKey = apiKey,
            model = model,
            systemPrompt = "Proponi 5 emoji DIVERSE tra loro che rappresentino bene una sezione di un'app. " +
                "Stile: emoji classiche e colorate di oggetti, cibi, luoghi o attività concrete, " +
                "come 🛒 🏷️ 🥦 ✈️ 💪 📚. Niente bandiere, lettere, numeri o simboli astratti. " +
                "Rispondi SOLO con le 5 emoji separate da uno spazio, senza testo.",
            userText = "Nome sezione: $title\nIstruzioni della sezione: $prompt",
            image = null,
        ).mapCatching { raw ->
            val bi = android.icu.text.BreakIterator.getCharacterInstance()
            bi.setText(raw)
            val found = mutableListOf<String>()
            var start = bi.first()
            var end = bi.next()
            while (end != android.icu.text.BreakIterator.DONE) {
                val g = raw.substring(start, end).trim()
                // Solo vere emoji: niente lettere, cifre o bandiere (indicatori regionali).
                if (g.isNotEmpty() && g.codePointAt(0) > 0x2000 && g.codePointAt(0) !in 0x1F1E6..0x1F1FF) found += g
                start = end
                end = bi.next()
            }
            found.distinct().take(5).also { require(it.isNotEmpty()) { "Nessuna icona proposta. Riprova." } }
        }

    /** Trasforma le info scritte dall'utente in un prompt di sistema pronto all'uso. */
    suspend fun generatePrompt(apiKey: String, model: String, title: String, info: String): Result<String> =
        ask(
            apiKey = apiKey,
            model = model,
            systemPrompt = "Sei un esperto di prompt engineering. Scrivi un prompt di sistema in italiano per un " +
                "assistente AI, partendo dalle info dell'utente. L'utente userà la sezione mandando una foto " +
                "e/o del testo. Il prompt deve definire: il ruolo dell'assistente, cosa fare con foto e testo, " +
                "e il formato della risposta (breve, pratica, con elenchi puntati, niente tabelle). " +
                "Massimo 120 parole. Rispondi SOLO con il prompt, senza introduzioni, titoli, virgolette o spiegazioni.",
            userText = "Nome sezione: $title\nInfo dell'utente: $info",
            image = null,
        ).map { it.trim().trim('"') }

    private fun extractText(json: String): String {
        val root = JSONObject(json)
        val candidates = root.optJSONArray("candidates")
        if (candidates == null || candidates.length() == 0) {
            val reason = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            throw RuntimeException(
                if (reason.isNotBlank()) "Richiesta bloccata dal filtro di sicurezza ($reason)."
                else "Nessuna risposta dal modello. Riprova.",
            )
        }
        val parts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) {
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        }
        return sb.toString().ifBlank { throw RuntimeException("Risposta vuota. Riprova.") }
    }

    private fun friendlyError(code: Int, body: String): String {
        val apiMsg = runCatching { JSONObject(body).getJSONObject("error").getString("message") }.getOrNull()
        return when (code) {
            400 -> "Richiesta non valida o chiave non corretta. ${apiMsg.orEmpty()}".trim()
            401, 403 -> "Chiave API non valida o non autorizzata. Controllala nelle Impostazioni."
            404 -> "Modello non trovato. Cambia il nome del modello nelle Impostazioni."
            429 -> "Hai finito le richieste gratuite per ora. Riprova tra un minuto, o domani se è il limite giornaliero."
            in 500..599 -> "Il server Google non risponde. Riprova tra poco."
            else -> "Errore $code. ${apiMsg.orEmpty()}".trim()
        }
    }

    private fun Bitmap.toBase64(): String {
        val out = ByteArrayOutputStream()
        compress(Bitmap.CompressFormat.JPEG, 85, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
}
