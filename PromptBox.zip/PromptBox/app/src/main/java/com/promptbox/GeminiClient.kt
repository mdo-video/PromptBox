package com.promptbox

import android.graphics.Bitmap
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

object GeminiClient {

    suspend fun ask(
        apiKey: String,
        model: String,
        systemPrompt: String,
        userText: String,
        image: Bitmap?,
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            require(apiKey.isNotBlank()) { "Manca la chiave API. Inseriscila nelle Impostazioni." }

            val parts = JSONArray()
            if (userText.isNotBlank()) parts.put(JSONObject().put("text", userText.trim()))
            if (image != null) {
                parts.put(
                    JSONObject().put(
                        "inline_data",
                        JSONObject().put("mime_type", "image/jpeg").put("data", image.toBase64()),
                    ),
                )
            }
            if (parts.length() == 0) parts.put(JSONObject().put("text", "Analizza."))

            val body = JSONObject()
                .put(
                    "systemInstruction",
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))),
                )
                .put(
                    "contents",
                    JSONArray().put(JSONObject().put("role", "user").put("parts", parts)),
                )

            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20_000
                readTimeout = 90_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("x-goog-api-key", apiKey.trim())
            }
            try {
                conn.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = conn.responseCode
                val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code !in 200..299) throw RuntimeException(friendlyError(code, text))
                extractText(text)
            } finally {
                conn.disconnect()
            }
        }
    }

    /**
     * Fa scegliere all'AI una sola emoji per la sezione, nello stesso stile di quelle fisse
     * (🛒 🏷️ 🥦 ✨). Se qualcosa va storto restituisce un errore e l'app usa 📌.
     */
    suspend fun pickEmoji(apiKey: String, model: String, title: String, prompt: String): Result<String> =
        ask(
            apiKey = apiKey,
            model = model,
            systemPrompt = "Scegli UNA sola emoji che rappresenti al meglio una sezione di un'app. " +
                "Stile: emoji classica e colorata di un oggetto, cibo, luogo o attività concreta, " +
                "come 🛒 🏷️ 🥦 ✈️ 💪 📚. Niente bandiere, niente lettere o numeri, niente simboli astratti. " +
                "Rispondi SOLO con l'emoji, senza testo, spazi o punteggiatura.",
            userText = "Nome sezione: $title\nIstruzioni della sezione: $prompt",
            image = null,
        ).mapCatching { raw ->
            val bi = android.icu.text.BreakIterator.getCharacterInstance()
            val t = raw.trim()
            bi.setText(t)
            val first = t.substring(0, bi.next().coerceAtLeast(0))
            // Deve essere davvero un'emoji, non una lettera o una cifra.
            require(first.isNotEmpty() && first.codePointAt(0) > 0x2000) { "Emoji non valida" }
            first
        }

    private fun extractText(json: String): String {
        val root = JSONObject(json)
        val candidates = root.optJSONArray("candidates")
        if (candidates == null || candidates.length() == 0) {
            val reason = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            throw RuntimeException(
                if (reason.isNotBlank()) "Richiesta bloccata dal filtro di sicurezza ($reason)."
                else "Nessuna risposta dal modello. Riprova.",
            )
        }
        val parts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) {
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        }
        return sb.toString().ifBlank { throw RuntimeException("Risposta vuota. Riprova.") }
    }

    private fun friendlyError(code: Int, body: String): String {
        val apiMsg = runCatching { JSONObject(body).getJSONObject("error").getString("message") }.getOrNull()
        return when (code) {
            400 -> "Richiesta non valida o chiave non corretta. ${apiMsg.orEmpty()}".trim()
            401, 403 -> "Chiave API non valida o non autorizzata. Controllala nelle Impostazioni."
            404 -> "Modello non trovato. Cambia il nome del modello nelle Impostazioni."
            429 -> "Hai finito le richieste gratuite per ora. Riprova tra un minuto, o domani se è il limite giornaliero."
            in 500..599 -> "Il server Google non risponde. Riprova tra poco."
            else -> "Errore $code. ${apiMsg.orEmpty()}".trim()
        }
    }

    private fun Bitmap.toBase64(): String {
        val out = ByteArrayOutputStream()
        compress(Bitmap.CompressFormat.JPEG, 85, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
}
