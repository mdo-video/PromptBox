package com.promptbox

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Tema sempre scuro: icone chiare nelle barre di sistema.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        val store = Store(applicationContext)
        setContent {
            var dynamic by remember { mutableStateOf(store.dynamic) }
            PrismaTheme(dynamic) {
                Surface(color = MaterialTheme.colorScheme.background) {
                    App(store, dynamic) {
                        dynamic = it
                        store.dynamic = it
                    }
                }
            }
        }
    }
}

@Composable
fun App(store: Store, dynamic: Boolean, onDynamic: (Boolean) -> Unit) {
    var screen by rememberSaveable { mutableStateOf("home") } // home | settings | section:<id>
    var sections by remember { mutableStateOf(store.loadSections()) }
    val hasKey = remember(screen) { store.apiKey.isNotBlank() }
    var pinned by remember { mutableStateOf(store.pinned) }
    val scope = rememberCoroutineScope()
    // Le sezioni pinnate vanno in cima; l'ordine tra pari resta quello originale.
    val all = sections
        .map { it.copy(pinned = it.id in pinned) }
        .sortedByDescending { it.pinned }

    // Controllo silenzioso all'avvio: se c'è una versione più nuova compare una scheda in Home.
    var update by remember { mutableStateOf<Updater.Info?>(null) }
    LaunchedEffect(Unit) {
        Updater.latest().onSuccess { if (it.versionCode > BuildConfig.VERSION_CODE) update = it }
    }

    BackHandler(enabled = screen != "home") { screen = "home" }

    val current = if (screen.startsWith("section:")) all.find { it.id == screen.removePrefix("section:") } else null

    when {
        screen == "settings" -> SettingsScreen(store, dynamic, onDynamic) { screen = "home" }
        current != null -> SectionScreen(store, current, all.indexOf(current)) { screen = "home" }
        else -> HomeScreen(
            sections = all,
            hasKey = hasKey,
            update = update,
            onOpen = { screen = "section:${it.id}" },
            onSettings = { screen = "settings" },
            onAdd = { title, prompt, emoji ->
                val s = Section(
                    id = "c${System.currentTimeMillis()}",
                    title = title.trim().uppercase(),
                    emoji = emoji.ifBlank { "📌" },
                    hint = "Foto e/o testo",
                    systemPrompt = prompt.trim() + " Rispondi sempre in italiano.",
                )
                sections = sections + s
                store.saveSections(sections)
            },
            onEdit = { s, title, prompt, emoji ->
                val updated = s.copy(
                    title = title.trim().uppercase(),
                    systemPrompt = prompt.trim(),
                    emoji = emoji.ifBlank { s.emoji },
                    pinned = false,
                )
                sections = sections.map { if (it.id == s.id) updated else it }
                store.saveSections(sections)
            },
            onSuggestEmojis = { title, prompt ->
                GeminiClient.suggestEmojis(store.apiKey, store.model, title, prompt)
            },
            onGeneratePrompt = { title, info ->
                GeminiClient.generatePrompt(store.apiKey, store.model, title, info)
            },
            onTogglePin = { s ->
                pinned = if (s.id in pinned) pinned - s.id else pinned + s.id
                store.pinned = pinned
            },
            onDelete = { s ->
                sections = sections.filter { it.id != s.id }
                store.saveSections(sections)
                store.saveChat(s.id, emptyList())
                pinned = pinned - s.id
                store.pinned = pinned
            },
        )
    }
}
