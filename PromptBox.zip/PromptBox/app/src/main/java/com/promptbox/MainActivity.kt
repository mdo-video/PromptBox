package com.promptbox

import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val store = Store(applicationContext)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF7FD8A5),
                    onPrimary = Color(0xFF00391E),
                    background = Color(0xFF111318),
                    surface = Color(0xFF111318),
                    surfaceVariant = Color(0xFF1E2128),
                    onSurface = Color(0xFFE3E2E6),
                ),
            ) {
                App(store)
            }
        }
    }
}

// ───────────────────────── Navigazione ─────────────────────────

@Composable
fun App(store: Store) {
    var screen by rememberSaveable { mutableStateOf("home") } // home | settings | section:<id>
    var custom by remember { mutableStateOf(store.customSections()) }
    val hasKey = remember(screen) { store.apiKey.isNotBlank() }
    val all = DefaultSections.all + custom

    // Controllo silenzioso all'avvio: se c'è una versione più nuova compare una scheda in Home.
    var update by remember { mutableStateOf<Updater.Info?>(null) }
    LaunchedEffect(Unit) {
        Updater.latest().onSuccess { if (it.versionCode > BuildConfig.VERSION_CODE) update = it }
    }

    BackHandler(enabled = screen != "home") { screen = "home" }

    val current = if (screen.startsWith("section:")) all.find { it.id == screen.removePrefix("section:") } else null

    when {
        screen == "settings" -> SettingsScreen(store) { screen = "home" }
        current != null -> SectionScreen(store, current) { screen = "home" }
        else -> HomeScreen(
            sections = all,
            hasKey = hasKey,
            update = update,
            onOpen = { screen = "section:${it.id}" },
            onSettings = { screen = "settings" },
            onAdd = { title, prompt ->
                val s = Section(
                    id = "c${System.currentTimeMillis()}",
                    title = title.trim().uppercase(),
                    emoji = "📌",
                    hint = "Foto e/o testo",
                    systemPrompt = prompt.trim() + " Rispondi sempre in italiano.",
                    custom = true,
                )
                custom = custom + s
                store.saveCustomSections(custom)
            },
            onDelete = { s ->
                custom = custom.filter { it.id != s.id }
                store.saveCustomSections(custom)
            },
        )
    }
}

// ───────────────────────── Home ─────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    sections: List<Section>,
    hasKey: Boolean,
    update: Updater.Info?,
    onOpen: (Section) -> Unit,
    onSettings: () -> Unit,
    onAdd: (String, String) -> Unit,
    onDelete: (Section) -> Unit,
) {
    var showAdd by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("PromptBox", fontWeight = FontWeight.SemiBold) },
                actions = {
                    IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, "Impostazioni") }
                },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAdd = true },
                icon = { Icon(Icons.Filled.Add, null) },
                text = { Text("Nuova sezione") },
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (update != null) {
                item { UpdateCard(update) }
            }
            if (!hasKey) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onSettings() },
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF3A2E12)),
                    ) {
                        Text(
                            "Per iniziare inserisci la chiave API nelle Impostazioni. Tocca qui.",
                            modifier = Modifier.padding(16.dp),
                        )
                    }
                }
            }
            items(sections, key = { it.id }) { s ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onOpen(s) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(20.dp),
                ) {
                    Row(
                        modifier = Modifier.padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(s.emoji, fontSize = 32.sp)
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text(s.title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text(s.hint, fontSize = 13.sp, color = Color(0xFFB0B3BA))
                        }
                        if (s.custom) {
                            IconButton(onClick = { onDelete(s) }) { Icon(Icons.Filled.Delete, "Elimina") }
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        var title by remember { mutableStateOf("") }
        var prompt by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Nuova sezione") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(title, { title = it }, label = { Text("Nome (es. VIAGGI)") }, singleLine = true)
                    OutlinedTextField(
                        prompt, { prompt = it },
                        label = { Text("Istruzioni per l'AI") },
                        placeholder = { Text("Es. Sei una guida turistica. Dalla foto dimmi cosa vedere vicino.") },
                        minLines = 4,
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = title.isNotBlank() && prompt.isNotBlank(),
                    onClick = { onAdd(title, prompt); showAdd = false },
                ) { Text("Crea") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Annulla") } },
        )
    }
}

// ───────────────────────── Sezione ─────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SectionScreen(store: Store, section: Section, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    var text by rememberSaveable { mutableStateOf("") }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var loading by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var pendingUri by remember { mutableStateOf<Uri?>(null) }

    fun loadImage(uri: Uri) {
        scope.launch {
            val bmp = withContext(Dispatchers.IO) { runCatching { ImageUtils.load(context, uri) }.getOrNull() }
            if (bmp != null) bitmap = bmp else error = "Non riesco a leggere l'immagine."
        }
    }

    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) loadImage(uri)
    }
    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) pendingUri?.let { loadImage(it) }
    }

    fun launchCamera() {
        val dir = File(context.cacheDir, "photos").apply { mkdirs() }
        val file = File.createTempFile("foto", ".jpg", dir)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        pendingUri = uri
        takePhoto.launch(uri)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("${section.emoji}  ${section.title}", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(section.hint, color = Color(0xFFB0B3BA), fontSize = 14.sp)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { launchCamera() }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.CameraAlt, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Scatta")
                }
                OutlinedButton(
                    onClick = {
                        pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.weight(1f),
                ) {
                    Icon(Icons.Filled.Image, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Galleria")
                }
            }

            bitmap?.let { bmp ->
                Box {
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = "Foto",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxWidth().height(200.dp).clip(RoundedCornerShape(16.dp)),
                    )
                    IconButton(
                        onClick = { bitmap = null },
                        modifier = Modifier.align(Alignment.TopEnd),
                    ) { Icon(Icons.Filled.Close, "Rimuovi foto", tint = Color.White) }
                }
            }

            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Scrivi qui (facoltativo se hai una foto)") },
                minLines = 3,
            )

            Button(
                onClick = {
                    loading = true
                    error = null
                    result = null
                    scope.launch {
                        GeminiClient.ask(store.apiKey, store.model, section.systemPrompt, text, bitmap)
                            .onSuccess { result = it }
                            .onFailure { error = it.message ?: "Errore sconosciuto" }
                        loading = false
                    }
                },
                enabled = !loading && (text.isNotBlank() || bitmap != null),
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) {
                if (loading) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                } else {
                    Icon(Icons.Filled.Send, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Chiedi all'AI")
                }
            }

            error?.let {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF4A1F1F))) {
                    Text(it, modifier = Modifier.padding(14.dp))
                }
            }

            result?.let { raw ->
                val clean = cleanMarkdown(raw)
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                ) {
                    Column(Modifier.padding(16.dp)) {
                        SelectionContainer { Text(clean, lineHeight = 22.sp) }
                        Spacer(Modifier.height(8.dp))
                        TextButton(onClick = { clipboard.setText(AnnotatedString(clean)) }) {
                            Icon(Icons.Filled.ContentCopy, null, Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Copia")
                        }
                    }
                }
            }
        }
    }
}

/** Toglie i simboli Markdown più comuni per mostrare testo pulito. */
private fun cleanMarkdown(s: String): String =
    s.replace("**", "")
        .replace(Regex("(?m)^#+\\s*"), "")
        .replace(Regex("(?m)^(\\s*)[*-]\\s+"), "$1• ")
        .trim()

// ───────────────────────── Impostazioni ─────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(store: Store, onBack: () -> Unit) {
    val uriHandler = LocalUriHandler.current
    var key by remember { mutableStateOf(store.apiKey) }
    var model by remember { mutableStateOf(store.model) }
    var saved by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Impostazioni", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            OutlinedTextField(
                value = key,
                onValueChange = { key = it; saved = false },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Chiave API Gemini") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
            )
            OutlinedTextField(
                value = model,
                onValueChange = { model = it; saved = false },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Modello") },
                supportingText = { Text("Predefinito: ${Store.DEFAULT_MODEL}. Cambialo solo se Google lo sostituisce.") },
                singleLine = true,
            )
            Button(
                onClick = {
                    store.apiKey = key
                    store.model = model
                    saved = true
                },
                modifier = Modifier.fillMaxWidth().height(50.dp),
            ) { Text(if (saved) "Salvato ✓" else "Salva") }

            TextButton(onClick = { uriHandler.openUri("https://aistudio.google.com/apikey") }) {
                Text("Crea una chiave gratuita su Google AI Studio")
            }

            UpdateSection()

            Text(
                "La chiave resta cifrata su questo dispositivo e non viene mai inclusa nell'app. " +
                    "Nel piano gratuito Google può usare i testi e le foto inviati per migliorare i suoi prodotti: " +
                    "non inviare dati sensibili. Se finisci le richieste gratuite l'app ti avvisa e riprovi più tardi.",
                fontSize = 13.sp,
                color = Color(0xFFB0B3BA),
            )
        }
    }
}
