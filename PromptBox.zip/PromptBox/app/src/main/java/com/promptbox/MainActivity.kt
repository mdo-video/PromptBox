package com.promptbox

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : ComponentActivity() {
    /** Contenuto ricevuto dal menu Condividi, in attesa che si scelga la sezione. */
    private var shared by mutableStateOf<Shared?>(null)

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        parseShared(intent)?.let { shared = it }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Se l'app viene riaperta dalle recenti, l'intent di condivisione vecchio non va riproposto.
        val fromHistory = intent.flags and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY != 0
        if (savedInstanceState == null && !fromHistory) shared = parseShared(intent)
        // Tema sempre scuro: icone chiare nelle barre di sistema.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        val store = Store(applicationContext)
        setContent {
            var dynamic by remember { mutableStateOf(store.dynamic) }
            PrismaTheme(dynamic) {
                Surface(color = MaterialTheme.colorScheme.background) {
                    App(store, dynamic, shared, { shared = null }) {
                        dynamic = it
                        store.dynamic = it
                    }
                }
            }
        }
    }
}

@Composable
fun App(
    store: Store,
    dynamic: Boolean,
    shared: Shared?,
    onSharedHandled: () -> Unit,
    onDynamic: (Boolean) -> Unit,
) {
    val context = LocalContext.current
    var screen by rememberSaveable { mutableStateOf("home") } // home | settings | changelog | shopping | section:<id>
    var incoming by remember { mutableStateOf<Shared?>(null) }
    var seenChangelog by remember { mutableIntStateOf(store.seenChangelog) }
    fun openChangelog() {
        seenChangelog = Changelog.latestId
        store.seenChangelog = Changelog.latestId
        screen = "changelog"
    }
    var sections by remember { mutableStateOf(store.loadSections()) }
    val hasKey = remember(screen) { store.apiKey.isNotBlank() }
    var pinned by remember { mutableStateOf(store.pinned) }
    val scope = rememberCoroutineScope()
    // Le sezioni pinnate vanno in cima; l'ordine tra pari resta quello originale.
    val all = sections
        .map { it.copy(pinned = it.id in pinned) }
        .sortedByDescending { it.pinned }

    // --- Sincronizzazione con l'account Google (cartella nascosta di Drive) ---
    var syncOn by remember { mutableStateOf(store.syncOn) }
    var syncEmail by remember { mutableStateOf(store.syncEmail) }
    var syncBusy by remember { mutableStateOf(false) }
    var syncMessage by remember { mutableStateOf<String?>(null) }
    var lastSync by remember { mutableLongStateOf(store.lastSync) }
    val resync = remember { AtomicBoolean(false) }

    suspend fun doSync(token: String) {
        val snapshot = sections
        DriveSync.sync(token, snapshot, store.deletedSections())
            .onSuccess { r ->
                // Se nel frattempo hai modificato qualcosa, il risultato non si applica: ci pensa la prossima sincronizzazione.
                if (r.changedLocal && sections === snapshot) {
                    sections = r.sections
                    store.saveSections(r.sections)
                }
                store.setDeletedSections(r.deleted)
                store.lastSync = System.currentTimeMillis()
                lastSync = store.lastSync
                syncMessage = null
            }
            .onFailure { syncMessage = it.message ?: "Sincronizzazione non riuscita." }
    }

    fun rememberEmail(email: String) {
        if (email.isNotBlank()) {
            syncEmail = email
            store.syncEmail = email
        }
    }

    val consentLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        when (val r = GoogleAuth.fromIntent(context, res.data)) {
            is AuthResult.Token -> {
                syncOn = true
                store.syncOn = true
                rememberEmail(r.email)
                scope.launch {
                    syncBusy = true
                    doSync(r.token)
                    syncBusy = false
                }
            }
            is AuthResult.Failure -> syncMessage = r.message
            is AuthResult.NeedsConsent -> syncMessage = "Accesso non completato."
        }
    }

    fun startSync(interactive: Boolean) {
        if (syncBusy) {
            resync.set(true)
            return
        }
        scope.launch {
            syncBusy = true
            do {
                resync.set(false)
                when (val r = GoogleAuth.authorize(context)) {
                    is AuthResult.Token -> {
                        if (interactive) {
                            syncOn = true
                            store.syncOn = true
                        }
                        rememberEmail(r.email)
                        doSync(r.token)
                    }
                    is AuthResult.NeedsConsent ->
                        if (interactive) {
                            consentLauncher.launch(IntentSenderRequest.Builder(r.pendingIntent.intentSender).build())
                        } else {
                            syncMessage = "Riaccedi a Google dalle Impostazioni per riprendere la sincronizzazione."
                        }
                    is AuthResult.Failure -> syncMessage = r.message
                }
            } while (resync.get())
            syncBusy = false
        }
    }

    LaunchedEffect(Unit) { if (syncOn) startSync(false) }

    // Controllo silenzioso all'avvio: se c'è una versione più nuova compare una scheda in Home.
    var update by remember { mutableStateOf<Updater.Info?>(null) }
    LaunchedEffect(Unit) {
        Updater.latest().onSuccess { if (it.versionCode > BuildConfig.VERSION_CODE) update = it }
    }

    BackHandler(enabled = screen != "home") { screen = "home" }
    BackHandler(enabled = shared != null) { onSharedHandled() }

    val current = if (screen.startsWith("section:")) all.find { it.id == screen.removePrefix("section:") } else null

    when {
        shared != null -> SharePicker(
            shared = shared,
            sections = all,
            onPick = { s ->
                incoming = shared
                onSharedHandled()
                screen = "section:${s.id}"
            },
            onCancel = onSharedHandled,
        )
        screen == "changelog" -> ChangelogScreen(onBack = { screen = "home" })
        screen == "shopping" -> ShoppingScreen(store, onBack = { screen = "home" })
        screen == "settings" -> SettingsScreen(
            store = store,
            dynamic = dynamic,
            onDynamic = onDynamic,
            sync = SyncUi(
                on = syncOn,
                email = syncEmail,
                busy = syncBusy,
                message = syncMessage,
                lastSync = lastSync,
                onSignIn = { startSync(true) },
                onSyncNow = { startSync(true) },
                onSignOut = {
                    syncOn = false
                    store.syncOn = false
                    syncEmail = ""
                    store.syncEmail = ""
                    syncMessage = null
                },
            ),
            onChangelog = { openChangelog() },
            onBack = { screen = "home" },
        )
        current != null -> SectionScreen(
            store = store,
            section = current,
            colorIndex = all.indexOf(current),
            incoming = incoming,
            onIncomingUsed = { incoming = null },
            onBack = { screen = "home" },
        )
        else -> HomeScreen(
            sections = all,
            hasKey = hasKey,
            update = update,
            onOpen = { screen = "section:${it.id}" },
            onSettings = { screen = "settings" },
            hasNews = seenChangelog < Changelog.latestId,
            onChangelog = { openChangelog() },
            onShopping = { screen = "shopping" },
            onAdd = { title, prompt, emoji ->
                val s = Section(
                    id = "c${System.currentTimeMillis()}",
                    title = title.trim().uppercase(),
                    emoji = emoji.ifBlank { "📌" },
                    hint = "Foto e/o testo",
                    systemPrompt = prompt.trim() + " Rispondi sempre in italiano.",
                    updatedAt = System.currentTimeMillis(),
                )
                sections = sections + s
                store.saveSections(sections)
                if (syncOn) startSync(false)
            },
            onEdit = { s, title, prompt, emoji ->
                val updated = s.copy(
                    title = title.trim().uppercase(),
                    systemPrompt = prompt.trim(),
                    emoji = emoji.ifBlank { s.emoji },
                    pinned = false,
                    updatedAt = System.currentTimeMillis(),
                )
                sections = sections.map { if (it.id == s.id) updated else it }
                store.saveSections(sections)
                if (syncOn) startSync(false)
            },
            onSuggestEmojis = { title, prompt ->
                GeminiClient.suggestEmojis(store.apiKey, store.model, title, prompt)
            },
            onGeneratePrompt = { title, info ->
                GeminiClient.generatePrompt(store.apiKey, store.model, title, info)
            },
            onTogglePin = { s ->
                pinned = if (s.id in pinned) pinned - s.id else pinned + s.id
                store.pinned = pinned
            },
            onDelete = { s ->
                sections = sections.filter { it.id != s.id }
                store.saveSections(sections)
                store.saveChat(s.id, emptyList())
                pinned = pinned - s.id
                store.pinned = pinned
                store.setDeletedSections(store.deletedSections() + (s.id to System.currentTimeMillis()))
                if (syncOn) startSync(false)
            },
        )
    }
}
