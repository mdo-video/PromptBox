package com.promptbox

import android.content.Intent
import android.widget.Toast
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

/** Scheda eliminata da poco: serve per "Annulla". */
private class DeletedSection(val section: Section, val chat: List<ChatTurn>, val pinned: Boolean, val index: Int)

class MainActivity : ComponentActivity() {
    /** Contenuto ricevuto dal menu Condividi, in attesa che si scelga la sezione. */
    private var shared by mutableStateOf<Shared?>(null)

    /** Azione richiesta dal widget o da una scorciatoia sull'icona (extra "action"). */
    private var launchAction by mutableStateOf<String?>(null)

    /** Cresce a ogni ritorno nell'app: serve a sincronizzare quando la riapri. */
    private var resumeTick by mutableIntStateOf(0)

    override fun onResume() {
        super.onResume()
        resumeTick++
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        parseShared(intent)?.let { shared = it }
        intent.getStringExtra("action")?.let { launchAction = it }
        intent.getStringExtra("open_section")?.let { launchAction = "section:$it" }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Se l'app viene riaperta dalle recenti, l'intent di condivisione vecchio non va riproposto.
        val fromHistory = intent.flags and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY != 0
        if (savedInstanceState == null && !fromHistory) {
            shared = parseShared(intent)
            launchAction = intent.getStringExtra("action")
                ?: intent.getStringExtra("open_section")?.let { "section:$it" }
        }
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        val store = Store(applicationContext)
        setContent {
            var dynamic by remember { mutableStateOf(store.dynamic) }
            var themeMode by remember { mutableStateOf(store.theme) }
            val dark = when (themeMode) {
                1 -> false
                2 -> true
                else -> isSystemInDarkTheme()
            }
            // Icone delle barre di sistema chiare o scure a seconda del tema.
            LaunchedEffect(dark) {
                val style = if (dark) {
                    SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
                } else {
                    SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
                }
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
            }
            PrismaTheme(dark, dynamic) {
                Surface(color = MaterialTheme.colorScheme.background) {
                    App(
                        store = store,
                        dynamic = dynamic,
                        themeMode = themeMode,
                        shared = shared,
                        launchAction = launchAction,
                        resumeTick = resumeTick,
                        onSharedHandled = { shared = null },
                        onLaunchHandled = { launchAction = null },
                        onDynamic = {
                            dynamic = it
                            store.dynamic = it
                        },
                        onTheme = {
                            themeMode = it
                            store.theme = it
                        },
                    )
                }
            }
        }
    }
}

@Composable
fun App(
    store: Store,
    dynamic: Boolean,
    themeMode: Int,
    shared: Shared?,
    launchAction: String?,
    resumeTick: Int,
    onSharedHandled: () -> Unit,
    onLaunchHandled: () -> Unit,
    onDynamic: (Boolean) -> Unit,
    onTheme: (Int) -> Unit,
) {
    val context = LocalContext.current
    var screen by rememberSaveable { mutableStateOf("home") } // home | settings | changelog | shopping | history | section:<id>
    var incoming by remember { mutableStateOf<Shared?>(null) }
    var seenChangelog by remember { mutableIntStateOf(store.seenChangelog) }
    fun openChangelog() {
        seenChangelog = Changelog.latestId
        store.seenChangelog = Changelog.latestId
        screen = "changelog"
    }
    var sections by remember { mutableStateOf(store.loadSections()) }
    var shopping by remember { mutableStateOf(store.shoppingList()) }
    var history by remember { mutableStateOf(store.shoppingHistory()) }
    // Prodotti appena arrivati da un altro dispositivo: restano evidenziati qualche secondo.
    var fresh by remember { mutableStateOf<Set<String>>(emptySet()) }
    var autoAction by remember { mutableStateOf<String?>(null) }
    val hasKey = remember(screen) { store.apiKey.isNotBlank() }
    var pinned by remember { mutableStateOf(store.pinned) }
    val scope = rememberCoroutineScope()
    // Le sezioni pinnate vanno in cima; l'ordine tra pari resta quello originale.
    // Le schede stanno raggruppate per categoria (nell'ordine in cui compaiono); in ogni gruppo le pinnate vanno in cima.
    val catOrder = sections.map { it.category }.distinct()
    val all = sections
        .map { it.copy(pinned = it.id in pinned) }
        .sortedWith(compareBy<Section> { catOrder.indexOf(it.category) }.thenByDescending { it.pinned })

    // Colore di ogni categoria: assegnato in automatico la prima volta, poi cambiabile dal menu della categoria.
    var catColors by remember { mutableStateOf(store.categoryColors()) }
    val effectiveColors = remember(catColors, catOrder) {
        val m = catColors.filterKeys { it in catOrder }.toMutableMap()
        catOrder.filter { it.isNotBlank() }.forEach { name ->
            if (name !in m) m[name] = (0 until 8).firstOrNull { i -> i !in m.values } ?: (m.size % 8)
        }
        m.toMap()
    }
    LaunchedEffect(effectiveColors) {
        if (effectiveColors != catColors) {
            catColors = effectiveColors
            store.saveCategoryColors(effectiveColors)
        }
    }

    var listView by remember { mutableStateOf(store.listView) }
    var recent by remember { mutableStateOf(store.recent) }
    // Ogni volta che si apre una scheda (da Home, da scorciatoia, da cronologia) finisce tra le recenti.
    LaunchedEffect(screen) {
        if (screen.startsWith("section:")) {
            val id = screen.removePrefix("section:")
            if (sections.any { it.id == id }) {
                val n = (listOf(id) + recent.filter { it != id }).take(3)
                if (n != recent) {
                    recent = n
                    store.recent = n
                }
            }
        }
    }

    // Ultima scheda eliminata, per poterla ripristinare con "Annulla".
    var lastDeleted by remember { mutableStateOf<DeletedSection?>(null) }

    // --- Sincronizzazione con l'account Google (cartella nascosta di Drive) ---
    var syncOn by remember { mutableStateOf(store.syncOn) }
    var syncEmail by remember { mutableStateOf(store.syncEmail) }
    var syncBusy by remember { mutableStateOf(false) }
    var syncMessage by remember { mutableStateOf<String?>(null) }
    var lastSync by remember { mutableLongStateOf(store.lastSync) }
    val resync = remember { AtomicBoolean(false) }

    suspend fun doSync(token: String) {
        val snapshot = sections
        val shopSnapshot = shopping
        val local = LocalSync(
            snapshot, store.deletedSections(), shopSnapshot, store.shoppingDeleted(),
            store.shoppingHistory(), store.profile, store.profileAt, store.syncProfile,
        )
        DriveSync.sync(token, local)
            .onSuccess { r ->
                // Lista della spesa: stessa regola delle sezioni (se nel frattempo è cambiata, ci pensa la prossima sincronizzazione).
                if (r.changedShopping && shopping === shopSnapshot) {
                    val added = r.shopping.map { it.key }.toSet() - shopSnapshot.map { it.key }.toSet()
                    if (added.isNotEmpty()) fresh = added
                    shopping = r.shopping
                    store.saveShopping(r.shopping)
                    ShoppingWidget.refresh(context)
                }
                store.setShoppingHistory(r.history)
                history = r.history
                if (r.changedProfile) store.applyRemoteProfile(r.profile, r.profileAt)
                store.setShoppingDeleted(DriveSync.mergeDeleted(store.shoppingDeleted(), r.shoppingDeleted))
                // Se nel frattempo hai modificato qualcosa, il risultato non si applica: ci pensa la prossima sincronizzazione.
                if (r.changedLocal && sections === snapshot) {
                    sections = r.sections
                    store.saveSections(r.sections)
                }
                store.setDeletedSections(r.deleted)
                store.lastSync = System.currentTimeMillis()
                lastSync = store.lastSync
                syncMessage = null
            }
            .onFailure { syncMessage = it.message ?: "Sincronizzazione non riuscita." }
    }

    fun rememberEmail(email: String) {
        if (email.isNotBlank()) {
            syncEmail = email
            store.syncEmail = email
        }
    }

    val consentLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        when (val r = GoogleAuth.fromIntent(context, res.data)) {
            is AuthResult.Token -> {
                syncOn = true
                store.syncOn = true
                rememberEmail(r.email)
                scope.launch {
                    syncBusy = true
                    doSync(r.token)
                    syncBusy = false
                }
            }
            is AuthResult.Failure -> syncMessage = r.message
            is AuthResult.NeedsConsent -> syncMessage = "Accesso non completato."
        }
    }

    fun startSync(interactive: Boolean) {
        if (syncBusy) {
            resync.set(true)
            return
        }
        scope.launch {
            syncBusy = true
            do {
                resync.set(false)
                when (val r = GoogleAuth.authorize(context)) {
                    is AuthResult.Token -> {
                        if (interactive) {
                            syncOn = true
                            store.syncOn = true
                        }
                        rememberEmail(r.email)
                        doSync(r.token)
                    }
                    is AuthResult.NeedsConsent ->
                        if (interactive) {
                            consentLauncher.launch(IntentSenderRequest.Builder(r.pendingIntent.intentSender).build())
                        } else {
                            syncMessage = "Riaccedi a Google dalle Impostazioni per riprendere la sincronizzazione."
                        }
                    is AuthResult.Failure -> syncMessage = r.message
                }
            } while (resync.get())
            syncBusy = false
        }
    }

    LaunchedEffect(Unit) { if (syncOn) startSync(false) }

    // Modifica alla lista della spesa: si salva, si segnano gli eliminati e si sincronizza subito.
    fun changeShopping(newList: List<ShopItem>, removed: List<String>) {
        val now = System.currentTimeMillis()
        shopping = newList
        store.saveShopping(newList)
        if (removed.isNotEmpty()) {
            store.setShoppingDeleted(store.shoppingDeleted() + removed.associateWith { now })
        }
        ShoppingWidget.refresh(context)
        if (syncOn) startSync(false)
    }

    // Un prodotto spuntato conta per i suggerimenti "ricomprare".
    fun bought(key: String) {
        val updated = history + (key to ((history[key] ?: 0) + 1))
        history = updated
        store.setShoppingHistory(updated)
    }

    // Riapre una chat archiviata; quella in corso nella stessa sezione finisce a sua volta in Cronologia.
    fun restoreChat(a: Store.Archived) {
        store.archiveChat(a.sectionId, store.loadChat(a.sectionId))
        store.deleteArchived(a.id)
        store.saveChat(a.sectionId, a.turns)
        screen = "section:${a.sectionId}"
    }

    fun importCard(card: CardData) {
        val now = System.currentTimeMillis()
        val s = Section(
            id = "c$now",
            title = card.title.trim().uppercase(),
            emoji = card.emoji.ifBlank { "📌" },
            hint = "Foto e/o testo",
            systemPrompt = card.prompt.trim(),
            category = card.category.trim(),
            updatedAt = now,
        )
        sections = sections + s
        store.saveSections(sections)
        Toast.makeText(context, "Scheda \"${s.title}\" importata", Toast.LENGTH_SHORT).show()
        if (syncOn) startSync(false)
    }

    // Scheda ricevuta da un altro telefono (messaggio con codice PRISMA1): si importa senza scegliere la sezione.
    LaunchedEffect(shared) {
        val card = shared?.text?.let { CardShare.decode(it) }
        if (card != null) {
            importCard(card)
            onSharedHandled()
        }
    }

    // Widget e scorciatoie sull'icona.
    LaunchedEffect(launchAction) {
        when (launchAction) {
            "shopping" -> screen = "shopping"
            "spesa_photo", "spesa_scan" -> {
                if (sections.any { it.id == "spesa" }) {
                    autoAction = launchAction
                    screen = "section:spesa"
                }
            }
            else -> {
                // Icona di una scheda fissata sulla Home di Android.
                val target = launchAction
                if (target != null && target.startsWith("section:") && sections.any { "section:${it.id}" == target }) {
                    screen = target
                }
            }
        }
        if (launchAction != null) onLaunchHandled()
    }
    LaunchedEffect(Unit) { ShoppingWidget.refresh(context) }

    // Ogni volta che si torna nell'app (il primo ritorno è l'avvio, già coperto sopra) si sincronizza.
    LaunchedEffect(resumeTick) { if (resumeTick > 1 && syncOn) startSync(false) }

    // Con la lista aperta si sincronizza subito e poi ogni 20 secondi: i prodotti nuovi arrivano da soli.
    LaunchedEffect(screen, syncOn) {
        if (screen == "shopping" && syncOn) {
            while (true) {
                startSync(false)
                delay(20_000)
            }
        }
    }

    // Controllo silenzioso all'avvio: se c'è una versione più nuova compare una scheda in Home.
    var update by remember { mutableStateOf<Updater.Info?>(null) }
    LaunchedEffect(Unit) {
        Updater.latest().onSuccess { if (it.versionCode > BuildConfig.VERSION_CODE) update = it }
    }

    BackHandler(enabled = screen != "home") { screen = "home" }
    BackHandler(enabled = shared != null) { onSharedHandled() }

    val current = if (screen.startsWith("section:")) all.find { it.id == screen.removePrefix("section:") } else null

    when {
        shared != null && CardShare.decode(shared.text) == null -> SharePicker(
            shared = shared,
            sections = all,
            onPick = { s ->
                incoming = shared
                onSharedHandled()
                screen = "section:${s.id}"
            },
            onCancel = onSharedHandled,
        )
        screen == "changelog" -> ChangelogScreen(onBack = { screen = "home" })
        screen == "history" -> HistoryScreen(
            store = store,
            sections = all,
            onOpenCurrent = { screen = "section:${it.id}" },
            onRestore = { restoreChat(it) },
            onBack = { screen = "home" },
        )
        screen == "shopping" -> ShoppingScreen(
            list = shopping,
            history = history,
            fresh = fresh,
            syncing = syncBusy,
            syncEnabled = syncOn,
            syncMessage = syncMessage,
            canCook = all.any { it.id == "frigo" },
            onRefresh = { startSync(false) },
            onChange = { l, removed -> changeShopping(l, removed) },
            onBought = { bought(it) },
            onCook = { text ->
                incoming = Shared(text, null)
                screen = "section:frigo"
            },
            onFreshSeen = { fresh = emptySet() },
            onBack = { screen = "home" },
        )
        screen == "settings" -> SettingsScreen(
            store = store,
            dynamic = dynamic,
            onDynamic = onDynamic,
            sync = SyncUi(
                on = syncOn,
                email = syncEmail,
                busy = syncBusy,
                message = syncMessage,
                lastSync = lastSync,
                onSignIn = { startSync(true) },
                onSyncNow = { startSync(true) },
                onSignOut = {
                    syncOn = false
                    store.syncOn = false
                    syncEmail = ""
                    store.syncEmail = ""
                    syncMessage = null
                },
            ),
            themeMode = themeMode,
            onTheme = onTheme,
            onBackupDone = {
                sections = store.loadSections()
                shopping = store.shoppingList()
                history = store.shoppingHistory()
                pinned = store.pinned
                ShoppingWidget.refresh(context)
                if (syncOn) startSync(false)
            },
            onChangelog = { openChangelog() },
            onBack = { screen = "home" },
        )
        current != null -> SectionScreen(
            store = store,
            section = current,
            colorIndex = all.indexOf(current),
            incoming = incoming,
            onIncomingUsed = { incoming = null },
            onAddToShopping = { names ->
                val (updated, added) = withNewItems(shopping, names)
                if (added > 0) changeShopping(updated, emptyList())
                added
            },
            autoAction = autoAction,
            onAutoActionUsed = { autoAction = null },
            onBack = { screen = "home" },
        )
        else -> HomeScreen(
            sections = all,
            hasKey = hasKey,
            update = update,
            onOpen = { screen = "section:${it.id}" },
            onSettings = { screen = "settings" },
            hasNews = seenChangelog < Changelog.latestId,
            onChangelog = { openChangelog() },
            onShopping = { screen = "shopping" },
            onHistory = { screen = "history" },
            syncProblem = syncOn && syncMessage != null,
            onRetrySync = { startSync(false) },
            onAdd = { title, prompt, emoji, category ->
                val s = Section(
                    id = "c${System.currentTimeMillis()}",
                    title = title.trim().uppercase(),
                    emoji = emoji.ifBlank { "📌" },
                    hint = "Foto e/o testo",
                    systemPrompt = prompt.trim() + " Rispondi sempre in italiano.",
                    category = category.trim(),
                    updatedAt = System.currentTimeMillis(),
                )
                sections = sections + s
                store.saveSections(sections)
                if (syncOn) startSync(false)
            },
            onEdit = { s, title, prompt, emoji, category ->
                val updated = s.copy(
                    title = title.trim().uppercase(),
                    systemPrompt = prompt.trim(),
                    emoji = emoji.ifBlank { s.emoji },
                    pinned = false,
                    category = category.trim(),
                    updatedAt = System.currentTimeMillis(),
                )
                // Se cambia categoria la scheda va in fondo al suo nuovo gruppo.
                sections = if (updated.category != s.category) {
                    sections.filter { it.id != s.id } + updated
                } else {
                    sections.map { if (it.id == s.id) updated else it }
                }
                store.saveSections(sections)
                if (syncOn) startSync(false)
            },
            onSuggestEmojis = { title, prompt ->
                GeminiClient.suggestEmojis(store.apiKey, store.model, title, prompt)
            },
            onGeneratePrompt = { title, info ->
                GeminiClient.generatePrompt(store.apiKey, store.model, title, info)
            },
            listView = listView,
            onToggleView = { listView = !listView; store.listView = listView },
            recent = recent,
            categoryColors = effectiveColors,
            onCategoryColor = { name ->
                val m = effectiveColors + (name to (((effectiveColors[name] ?: 0) + 1) % 8))
                catColors = m
                store.saveCategoryColors(m)
            },
            onImportCard = { importCard(it) },
            onUndoDelete = {
                lastDeleted?.let { d ->
                    val restored = d.section.copy(updatedAt = System.currentTimeMillis())
                    val list = sections.toMutableList()
                    list.add(d.index.coerceIn(0, list.size), restored)
                    sections = list
                    store.saveSections(sections)
                    store.saveChat(restored.id, d.chat)
                    if (d.pinned) {
                        pinned = pinned + restored.id
                        store.pinned = pinned
                    }
                    store.setDeletedSections(store.deletedSections() - restored.id)
                    lastDeleted = null
                    if (syncOn) startSync(false)
                }
            },
            onRenameCategory = { old, new ->
                val now = System.currentTimeMillis()
                catColors[old]?.let { c ->
                    val m = catColors - old + (if (new.isBlank()) emptyMap() else mapOf(new.trim() to c))
                    catColors = m
                    store.saveCategoryColors(m)
                }
                sections = sections.map { if (it.category == old) it.copy(category = new.trim(), updatedAt = now) else it }
                store.saveSections(sections)
                if (syncOn) startSync(false)
            },
            onMoveCategory = { name, dir ->
                val order = all.map { it.category }.distinct().toMutableList()
                val i = order.indexOf(name)
                val j = i + dir
                if (i >= 0 && j in order.indices) {
                    val tmp = order[i]; order[i] = order[j]; order[j] = tmp
                    val byId = sections.associateBy { it.id }
                    sections = order.flatMap { c -> all.filter { it.category == c }.map { it.id } }.mapNotNull { byId[it] }
                    store.saveSections(sections)
                    if (syncOn) startSync(false)
                }
            },
            onReorder = { ids ->
                val byId = sections.associateBy { it.id }
                sections = ids.mapNotNull { byId[it] } + sections.filter { it.id !in ids }
                store.saveSections(sections)
                if (syncOn) startSync(false)
            },
            onTogglePin = { s ->
                pinned = if (s.id in pinned) pinned - s.id else pinned + s.id
                store.pinned = pinned
            },
            onDelete = { s ->
                lastDeleted = DeletedSection(
                    section = sections.firstOrNull { it.id == s.id } ?: s.copy(pinned = false),
                    chat = store.loadChat(s.id),
                    pinned = s.id in pinned,
                    index = sections.indexOfFirst { it.id == s.id },
                )
                sections = sections.filter { it.id != s.id }
                store.saveSections(sections)
                store.saveChat(s.id, emptyList())
                pinned = pinned - s.id
                store.pinned = pinned
                store.setDeletedSections(store.deletedSections() + (s.id to System.currentTimeMillis()))
                if (syncOn) startSync(false)
            },
        )
    }
}
