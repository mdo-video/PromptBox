package com.promptbox

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Brush
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material3.AssistChip
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.material.icons.filled.AddToHomeScreen
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.FilterChip
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.zIndex
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.material3.FilledTonalButton
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NewReleases
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material3.Button
import androidx.compose.material3.LocalContentColor
import kotlinx.coroutines.delay

/** Parti di supporto della Home (finestra sezione, intestazioni, schede). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun SectionDialog(
    heading: String,
    confirmLabel: String,
    initialTitle: String,
    initialPrompt: String,
    initialEmoji: String,
    initialCategory: String,
    categories: List<String>,
    onGeneratePrompt: suspend (String, String) -> Result<String>,
    onSuggestEmojis: suspend (String, String) -> Result<List<String>>,
    onConfirm: (String, String, String, String) -> Unit,
    onDismiss: () -> Unit,
) {
    var title by remember { mutableStateOf(initialTitle) }
    var info by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(initialCategory) }
    var prompt by remember { mutableStateOf(initialPrompt) }
    var generating by remember { mutableStateOf(false) }
    var emoji by remember { mutableStateOf(initialEmoji) }
    var options by remember { mutableStateOf<List<String>>(emptyList()) }
    var suggesting by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    // In creazione si parte da un solo campo ("Cosa vuoi che faccia?"); nome, icona e prompt compaiono dopo.
    var showDetails by remember { mutableStateOf(initialPrompt.isNotBlank()) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(heading) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (!showDetails) {
                    OutlinedTextField(
                        info, { info = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Cosa vuoi che faccia?") },
                        placeholder = { Text("Es. dalla foto di un monumento mi dici storia e curiosità") },
                        minLines = 3,
                    )
                    Button(
                        enabled = info.isNotBlank() && !generating,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            generating = true
                            error = null
                            scope.launch {
                                val name = title.ifBlank { info.trim().split(' ').take(2).joinToString(" ").take(20).uppercase() }
                                onGeneratePrompt(name, info.trim())
                                    .onSuccess {
                                        prompt = it
                                        title = name
                                        showDetails = true
                                        onSuggestEmojis(name, it).onSuccess { list ->
                                            options = list
                                            list.firstOrNull()?.let { first -> if (emoji == "📌") emoji = first }
                                        }
                                    }
                                    .onFailure { error = it.message ?: "Errore" }
                                generating = false
                            }
                        },
                    ) {
                        if (generating) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Filled.AutoAwesome, null, Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(if (generating) "Creo il prompt..." else "Crea con AI")
                    }
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                    TextButton(onClick = { showDetails = true }) { Text("Scrivo io il prompt") }
                    return@Column
                }
                OutlinedTextField(title, { title = it }, label = { Text("Nome (es. VIAGGI)") }, singleLine = true)
                OutlinedTextField(
                    category, { category = it },
                    label = { Text("Categoria (facoltativa)") },
                    placeholder = { Text("Es. Cucina") },
                    singleLine = true,
                )
                if (categories.isNotEmpty()) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        categories.forEach { c ->
                            val on = category.trim() == c
                            FilterChip(selected = on, onClick = { category = if (on) "" else c }, label = { Text(c) })
                        }
                    }
                }

                // Icona: l'app ne propone fino a 5 e tu scegli quella che ti piace.
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        modifier = Modifier.size(56.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center,
                    ) { Text(emoji, fontSize = 28.sp) }
                    FilledTonalButton(
                        enabled = title.isNotBlank() && !suggesting,
                        onClick = {
                            suggesting = true
                            error = null
                            scope.launch {
                                onSuggestEmojis(title.trim(), prompt.ifBlank { info }.trim())
                                    .onSuccess { options = it }
                                    .onFailure { error = it.message ?: "Errore" }
                                suggesting = false
                            }
                        },
                    ) {
                        if (suggesting) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Filled.AutoAwesome, null, Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(if (suggesting) "Cerco..." else "Proponi icone")
                    }
                }
                if (options.isNotEmpty()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        repeat(5) { i ->
                            val e = options.getOrNull(i)
                            if (e == null) {
                                Spacer(Modifier.weight(1f))
                            } else {
                                val selected = e == emoji
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(1f)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surfaceContainerHighest)
                                        .border(
                                            if (selected) 2.dp else 0.dp,
                                            if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                            CircleShape,
                                        )
                                        .clickable { emoji = e },
                                    contentAlignment = Alignment.Center,
                                ) { Text(e, fontSize = 22.sp) }
                            }
                        }
                    }
                }
                OutlinedTextField(
                    info, { info = it },
                    label = { Text("Cosa vuoi che faccia?") },
                    placeholder = { Text("Es. dalla foto di un monumento mi dici storia e curiosità") },
                    minLines = 3,
                )
                FilledTonalButton(
                    enabled = info.isNotBlank() && !generating,
                    onClick = {
                        generating = true
                        error = null
                        scope.launch {
                            onGeneratePrompt(title.trim(), info.trim())
                                .onSuccess { prompt = it }
                                .onFailure { error = it.message ?: "Errore" }
                            generating = false
                        }
                    },
                ) {
                    if (generating) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Filled.AutoAwesome, null, Modifier.size(18.dp))
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(if (generating) "Creo il prompt..." else "Crea prompt con AI")
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                OutlinedTextField(
                    prompt, { prompt = it },
                    label = { Text("Prompt (modificabile)") },
                    minLines = 4,
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = showDetails && title.isNotBlank() && prompt.isNotBlank() && !generating,
                onClick = { onConfirm(title, prompt, emoji, category) },
            ) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annulla") } },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun ChooserCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, primary: Boolean = false, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (primary) cs.primaryContainer else cs.surfaceContainerHigh,
            contentColor = if (primary) cs.onPrimaryContainer else cs.onSurface,
        ),
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).clip(CircleShape).background(LocalContentColor.current.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center,
            ) { Icon(icon, null) }
            Spacer(Modifier.width(16.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = LocalContentColor.current.copy(alpha = 0.75f))
            }
        }
    }
}

internal val CATEGORY_HUES = floatArrayOf(150f, 210f, 265f, 330f, 20f, 45f, 180f, 100f)

/** Colori di sfondo e testo di una scheda in una categoria colorata. */
internal fun categoryPalette(index: Int, dark: Boolean): Pair<Color, Color> {
    val h = CATEGORY_HUES[((index % 8) + 8) % 8]
    return if (dark) Color.hsl(h, 0.38f, 0.24f) to Color.hsl(h, 0.55f, 0.9f)
    else Color.hsl(h, 0.55f, 0.86f) to Color.hsl(h, 0.6f, 0.18f)
}

internal fun categoryDot(index: Int): Color = Color.hsl(CATEGORY_HUES[((index % 8) + 8) % 8], 0.6f, 0.55f)

@Composable
internal fun CategoryHeader(
    name: String,
    count: Int,
    collapsed: Boolean,
    editable: Boolean,
    onToggle: () -> Unit,
    onRename: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onRemove: () -> Unit,
    colorIndex: Int,
    onColor: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onToggle)
            .padding(start = 4.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            if (collapsed) Icons.Filled.KeyboardArrowDown else Icons.Filled.KeyboardArrowUp,
            if (collapsed) "Apri categoria" else "Chiudi categoria",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.width(4.dp))
        if (editable) {
            Box(Modifier.size(12.dp).clip(CircleShape).background(categoryDot(colorIndex)))
            Spacer(Modifier.width(8.dp))
        }
        Text(name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(8.dp))
        Text("$count", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.weight(1f))
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Opzioni categoria") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                if (editable) {
                    DropdownMenuItem(text = { Text("Rinomina") }, onClick = { menu = false; onRename() })
                    DropdownMenuItem(text = { Text("Cambia colore") }, onClick = { menu = false; onColor() })
                }
                DropdownMenuItem(text = { Text("Sposta su") }, onClick = { menu = false; onMoveUp() })
                DropdownMenuItem(text = { Text("Sposta giù") }, onClick = { menu = false; onMoveDown() })
                if (editable) {
                    DropdownMenuItem(text = { Text("Togli categoria") }, onClick = { menu = false; onRemove() })
                }
            }
        }
    }
}

/** Testata compatta: logo, titolo, novità, vista griglia/lista e ricerca sempre visibile. */
@Composable
internal fun HomeHeader(
    hasNews: Boolean,
    syncProblem: Boolean,
    onChangelog: () -> Unit,
    onRetrySync: () -> Unit,
    listView: Boolean,
    onToggleView: () -> Unit,
    query: String,
    onQuery: (String) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.statusBarsPadding().padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF14201B)),
                contentAlignment = Alignment.Center,
            ) {
                Image(
                    painter = painterResource(R.drawable.ic_launcher_foreground),
                    contentDescription = "Logo Prisma",
                    modifier = Modifier.requiredSize(64.dp),
                )
            }
            Spacer(Modifier.width(12.dp))
            Text("Prisma", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
            if (syncProblem) {
                IconButton(onClick = onRetrySync) {
                    Icon(Icons.Filled.CloudOff, "Sincronizzazione non riuscita: tocca per riprovare", tint = cs.error)
                }
            }
            IconButton(onClick = onChangelog) {
                BadgedBox(badge = { if (hasNews) Badge() }) { Icon(Icons.Filled.AutoAwesome, "Novità") }
            }
            IconButton(onClick = onToggleView) {
                Icon(
                    if (listView) Icons.Filled.GridView else Icons.Filled.ViewAgenda,
                    if (listView) "Vista a griglia" else "Vista a lista",
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        TextField(
            value = query,
            onValueChange = onQuery,
            placeholder = { Text("Cerca schede") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { onQuery("") }) { Icon(Icons.Filled.Close, "Cancella ricerca") }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = cs.surfaceContainerHigh,
                unfocusedContainerColor = cs.surfaceContainerHigh,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
            ),
            modifier = Modifier.fillMaxWidth().padding(end = 8.dp),
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun SectionCard(
    index: Int,
    s: Section,
    onOpen: (Section) -> Unit,
    onTogglePin: (Section) -> Unit,
    onEditRequest: () -> Unit,
    onDeleteRequest: () -> Unit,
    modifier: Modifier = Modifier,
    colorIndex: Int? = null,
    compact: Boolean = false,
    dragging: Boolean = false,
    translation: () -> Offset = { Offset.Zero },
    onDragStart: () -> Unit = {},
    onDrag: (Offset) -> Unit = {},
    onDragEnd: () -> Unit = {},
) {
    val cs = MaterialTheme.colorScheme
    val haptic = LocalHapticFeedback.current
    val cardContext = LocalContext.current
    val scope = rememberCoroutineScope()
    val currentOpen by rememberUpdatedState(onOpen)
    val currentStart by rememberUpdatedState(onDragStart)
    val currentDrag by rememberUpdatedState(onDrag)
    val currentEnd by rememberUpdatedState(onDragEnd)
    var moved by remember { mutableStateOf(0f) }
    var suppressClick by remember { mutableStateOf(false) }
    var visible by rememberSaveable(s.id) { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    LaunchedEffect(s.id) {
        if (!visible) delay(index * 70L)
        visible = true
    }
    val (bg, fg) = if (colorIndex != null) categoryPalette(colorIndex, cs.background.luminance() < 0.5f) else when (index % 3) {
        0 -> cs.primaryContainer to cs.onPrimaryContainer
        1 -> cs.secondaryContainer to cs.onSecondaryContainer
        else -> cs.tertiaryContainer to cs.onTertiaryContainer
    }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn() + scaleIn(initialScale = 0.9f),
        modifier = modifier,
    ) {
        Box(
            Modifier.graphicsLayer {
                val t = translation()
                translationX = t.x
                translationY = t.y
                val sc = if (dragging) 1.06f else 1f
                scaleX = sc
                scaleY = sc
                alpha = if (dragging) 0.92f else 1f
            },
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (compact) 76.dp else 172.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .clickable {
                        if (suppressClick) suppressClick = false else currentOpen(s)
                    }
                    // Tieni premuto e trascina per spostare; se rilasci senza muoverti esce il menu.
                    .pointerInput(s.id) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = {
                                moved = 0f
                                suppressClick = true
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                currentStart()
                            },
                            onDrag = { change, delta ->
                                change.consume()
                                moved += kotlin.math.abs(delta.x) + kotlin.math.abs(delta.y)
                                currentDrag(delta)
                            },
                            onDragEnd = {
                                currentEnd()
                                if (moved < 24f) menu = true
                                scope.launch { delay(150); suppressClick = false }
                            },
                            onDragCancel = {
                                currentEnd()
                                scope.launch { delay(150); suppressClick = false }
                            },
                        )
                    },
                colors = CardDefaults.cardColors(containerColor = bg, contentColor = fg),
                shape = RoundedCornerShape(28.dp),
            ) {
                if (compact) {
                    Row(
                        Modifier.fillMaxSize().padding(start = 16.dp, end = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            modifier = Modifier.size(44.dp).clip(CircleShape).background(fg.copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center,
                        ) { Text(s.emoji, fontSize = 22.sp) }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                s.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                s.hint,
                                style = MaterialTheme.typography.bodySmall,
                                color = fg.copy(alpha = 0.75f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        IconButton(onClick = { onTogglePin(s) }, modifier = Modifier.size(40.dp)) {
                            Icon(
                                if (s.pinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                                if (s.pinned) "Rimuovi pin" else "Fissa in alto",
                                Modifier.size(20.dp),
                            )
                        }
                    }
                } else BoxWithConstraints(Modifier.fillMaxSize().padding(16.dp)) {
                    val innerWidth = maxWidth
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(fg.copy(alpha = 0.12f))
                            .align(Alignment.TopStart),
                        contentAlignment = Alignment.Center,
                    ) { Text(s.emoji, fontSize = 24.sp) }

                    IconButton(
                        onClick = { onTogglePin(s) },
                        modifier = Modifier.align(Alignment.TopEnd).size(32.dp),
                    ) {
                        Icon(
                            if (s.pinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                            if (s.pinned) "Rimuovi pin" else "Fissa in alto",
                            Modifier.size(18.dp),
                        )
                    }

                    Column(Modifier.align(Alignment.BottomStart)) {
                        // Il titolo si rimpicciolisce finché la parola più lunga sta intera nella card.
                        val longest = s.title.split(' ', '\n').maxOfOrNull { it.length }?.coerceAtLeast(1) ?: 1
                        val titleSp = (innerWidth.value / (longest * 0.72f)).coerceIn(14f, 22f)
                        Text(
                            s.title,
                            style = MaterialTheme.typography.titleLarge,
                            fontSize = titleSp.sp,
                            lineHeight = (titleSp * 1.15f).sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Modifica") },
                    leadingIcon = { Icon(Icons.Filled.Edit, null) },
                    onClick = { menu = false; onEditRequest() },
                )
                DropdownMenuItem(
                    text = { Text("Condividi") },
                    leadingIcon = { Icon(Icons.Filled.Share, null) },
                    onClick = { menu = false; CardShare.share(cardContext, s) },
                )
                DropdownMenuItem(
                    text = { Text("Aggiungi alla Home") },
                    leadingIcon = { Icon(Icons.Filled.AddToHomeScreen, null) },
                    onClick = {
                        menu = false
                        if (!SectionShortcut.pin(cardContext, s)) {
                            Toast.makeText(cardContext, "Il tuo launcher non supporta le scorciatoie", Toast.LENGTH_SHORT).show()
                        }
                    },
                )
                DropdownMenuItem(
                    text = { Text("Elimina") },
                    leadingIcon = { Icon(Icons.Filled.Delete, null) },
                    onClick = { menu = false; onDeleteRequest() },
                )
            }
        }
    }
}
