package com.promptbox

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Brush
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material3.AssistChip
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.material.icons.filled.AddToHomeScreen
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.FilterChip
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.zIndex
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.material3.FilledTonalButton
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NewReleases
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    sections: List<Section>,
    hasKey: Boolean,
    update: Updater.Info?,
    onOpen: (Section) -> Unit,
    onSettings: () -> Unit,
    hasNews: Boolean = false,
    onChangelog: () -> Unit = {},
    onShopping: () -> Unit = {},
    onHistory: () -> Unit = {},
    syncProblem: Boolean = false,
    onRetrySync: () -> Unit = {},
    onAdd: (String, String, String, String) -> Unit,
    onEdit: (Section, String, String, String, String) -> Unit,
    onRenameCategory: (String, String) -> Unit = { _, _ -> },
    listView: Boolean = false,
    onToggleView: () -> Unit = {},
    recent: List<String> = emptyList(),
    categoryColors: Map<String, Int> = emptyMap(),
    onCategoryColor: (String, Int) -> Unit = { _, _ -> },
    onUndoDelete: () -> Unit = {},
    onImportCard: (CardData) -> Unit = {},
    onMoveCategory: (String, Int) -> Unit = { _, _ -> },
    onDelete: (Section) -> Unit,
    onTogglePin: (Section) -> Unit,
    onReorder: (List<String>) -> Unit = {},
    onGeneratePrompt: suspend (String, String) -> Result<String>,
    onSuggestEmojis: suspend (String, String) -> Result<List<String>>,
) {
    var showChooser by remember { mutableStateOf(false) }
    var showLibrary by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Section?>(null) }
    var searching by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    val searchActive = query.isNotBlank()
    val searchFocus = remember { FocusRequester() }
    LaunchedEffect(searching) { if (searching) searchFocus.requestFocus() }
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    var renamingCat by remember { mutableStateOf<String?>(null) }
    var coloringCat by remember { mutableStateOf<String?>(null) }
    var removingCat by remember { mutableStateOf<String?>(null) }
    // Categorie chiuse (nomi uniti da un separatore, così si salvano anche con la rotazione dello schermo).
    var collapsedRaw by rememberSaveable { mutableStateOf("") }
    val collapsed = remember(collapsedRaw) { collapsedRaw.split('\u0001').filter { it.isNotEmpty() }.toSet() }
    val categoryNames = remember(sections) { sections.map { it.category }.filter { it.isNotBlank() }.distinct() }
    val cs = MaterialTheme.colorScheme

    // --- Riordino: tieni premuta una scheda e trascinala dove vuoi ---
    val gridState = rememberLazyGridState()
    val dragScope = rememberCoroutineScope()
    var localOrder by remember { mutableStateOf<List<String>?>(null) }
    var draggedId by remember { mutableStateOf<String?>(null) }
    var dragTotal by remember { mutableStateOf(Offset.Zero) }
    var dragStart by remember { mutableStateOf(IntOffset.Zero) }
    val displayed = remember(sections, localOrder) {
        localOrder?.let { order ->
            val byId = sections.associateBy { it.id }
            order.mapNotNull { byId[it] }
        } ?: sections
    }
    val translationFor: (String) -> Offset = { id ->
        if (id != draggedId) {
            Offset.Zero
        } else {
            val info = gridState.layoutInfo.visibleItemsInfo.firstOrNull { it.key == id }
            if (info == null) dragTotal
            else Offset(dragTotal.x - (info.offset.x - dragStart.x), dragTotal.y - (info.offset.y - dragStart.y))
        }
    }
    val startDrag: (String) -> Unit = startDrag@{ id ->
        // Durante la ricerca l'ordine non si può cambiare.
        if (searchActive) return@startDrag
        val info = gridState.layoutInfo.visibleItemsInfo.firstOrNull { it.key == id }
        dragStart = info?.offset ?: IntOffset.Zero
        dragTotal = Offset.Zero
        localOrder = sections.map { it.id }
        draggedId = id
    }
    val moveDrag: (Offset) -> Unit = moveDrag@{ delta ->
        val id = draggedId ?: return@moveDrag
        dragTotal += delta
        val items = gridState.layoutInfo.visibleItemsInfo
        val size = items.firstOrNull { it.key == id }?.size ?: return@moveDrag
        val center = Offset(
            dragStart.x + size.width / 2f + dragTotal.x,
            dragStart.y + size.height / 2f + dragTotal.y,
        )
        // Se la scheda passa sopra un'altra (dello stesso gruppo pinnate / non pinnate) si scambiano.
        val pinnedById = sections.associate { it.id to (it.pinned to it.category) }
        val target = items.firstOrNull {
            val k = it.key as? String
            k != null && k != id && pinnedById[k] == pinnedById[id] &&
                center.x >= it.offset.x && center.x < it.offset.x + it.size.width &&
                center.y >= it.offset.y && center.y < it.offset.y + it.size.height
        }?.key as? String
        if (target != null) {
            val cur = localOrder ?: return@moveDrag
            val from = cur.indexOf(id)
            val to = cur.indexOf(target)
            if (from >= 0 && to >= 0 && from != to) {
                localOrder = cur.toMutableList().apply { removeAt(from); add(to, id) }
            }
        }
        // Vicino al bordo la lista scorre da sola.
        val viewH = gridState.layoutInfo.viewportSize.height
        val dy = when {
            center.y < 140f -> -28f
            center.y > viewH - 180f -> 28f
            else -> 0f
        }
        if (dy != 0f) dragScope.launch { gridState.scrollBy(dy) }
    }
    val finishDrag: () -> Unit = {
        localOrder?.let { onReorder(it) }
        localOrder = null
        draggedId = null
        dragTotal = Offset.Zero
    }

    val doDelete: (Section) -> Unit = { sec ->
        onDelete(sec)
        dragScope.launch {
            snackbarHostState.currentSnackbarData?.dismiss()
            val r = snackbarHostState.showSnackbar(
                message = "Scheda ${sec.title} eliminata",
                actionLabel = "Annulla",
                duration = SnackbarDuration.Long,
            )
            if (r == SnackbarResult.ActionPerformed) onUndoDelete()
        }
    }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = {
                    if (searching) {
                        OutlinedTextField(
                            value = query,
                            onValueChange = { query = it },
                            placeholder = { Text("Cerca schede") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().focusRequester(searchFocus),
                        )
                    }
                },
                actions = {
                    IconButton(onClick = {
                        searching = !searching
                        if (!searching) query = ""
                    }) {
                        Icon(
                            if (searching) Icons.Filled.Close else Icons.Filled.Search,
                            if (searching) "Chiudi ricerca" else "Cerca schede",
                        )
                    }
                    if (!searching) {
                    if (syncProblem) {
                        IconButton(onClick = onRetrySync) {
                            Icon(Icons.Filled.CloudOff, "Sincronizzazione non riuscita: tocca per riprovare", tint = cs.error)
                        }
                    }
                    IconButton(onClick = onHistory) { Icon(Icons.Filled.History, "Cronologia e ricerca") }
                    IconButton(onClick = onShopping) { Icon(Icons.Filled.ShoppingCart, "Lista della spesa") }
                    IconButton(onClick = onChangelog) {
                        BadgedBox(badge = { if (hasNews) Badge() }) {
                            Icon(Icons.Filled.NewReleases, "Novità")
                        }
                    }
                    IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, "Impostazioni") }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showChooser = true },
                icon = { Icon(Icons.Filled.Add, null) },
                text = { Text("Nuova sezione") },
                containerColor = cs.primaryContainer,
                contentColor = cs.onPrimaryContainer,
            )
        },
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(if (listView) 1 else 2),
            state = gridState,
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 0.dp, 16.dp, 110.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (!searching) item(span = { GridItemSpan(maxLineSpan) }) { Hero() }
            if (!searching) item(key = "recent_row", span = { GridItemSpan(maxLineSpan) }) {
                val recentSections = recent.mapNotNull { id -> sections.firstOrNull { it.id == id } }.take(3)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Row(
                        Modifier
                            .weight(1f)
                            .horizontalScroll(rememberScrollState())
                            // Sfumatura a destra: si capisce che le recenti continuano, invece di essere tagliate di netto.
                            .drawWithContent {
                                drawContent()
                                drawRect(
                                    Brush.horizontalGradient(
                                        listOf(Color.Transparent, cs.background),
                                        startX = size.width - 28.dp.toPx(),
                                        endX = size.width,
                                    ),
                                )
                            },
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        recentSections.forEach { r ->
                            val shape = RoundedCornerShape(50)
                            Text(
                                "${r.emoji} ${r.title.lowercase().replaceFirstChar { it.uppercase() }}",
                                style = MaterialTheme.typography.labelLarge,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier
                                    .clip(shape)
                                    .border(1.dp, cs.outlineVariant, shape)
                                    .clickable { onOpen(r) }
                                    .padding(horizontal = 12.dp, vertical = 7.dp)
                                    .widthIn(max = 150.dp),
                            )
                        }
                        // Spazio finale: l'ultima recente non finisce sotto la sfumatura.
                        Spacer(Modifier.width(24.dp))
                    }
                    IconButton(onClick = onToggleView, modifier = Modifier.size(40.dp)) {
                        Icon(
                            if (listView) Icons.Filled.GridView else Icons.Filled.ViewAgenda,
                            if (listView) "Vista a griglia" else "Vista a lista",
                            Modifier.size(22.dp),
                            tint = cs.onSurfaceVariant,
                        )
                    }
                }
            }

            if (update != null) {
                item(span = { GridItemSpan(maxLineSpan) }) { UpdateCard(update) }
            }
            if (!hasKey) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Card(
                        onClick = onSettings,
                        colors = CardDefaults.cardColors(
                            containerColor = cs.errorContainer,
                            contentColor = cs.onErrorContainer,
                        ),
                        shape = RoundedCornerShape(24.dp),
                    ) {
                        Text(
                            "Per iniziare inserisci la chiave API nelle Impostazioni. Tocca qui.",
                            modifier = Modifier.padding(18.dp),
                        )
                    }
                }
            }

            val q = query.trim()
            val shown = if (q.isEmpty()) displayed else displayed.filter {
                it.title.contains(q, true) || it.category.contains(q, true) || it.systemPrompt.contains(q, true)
            }
            // Durante la ricerca: elenco semplice, senza titoli di categoria.
            val hasCategories = !searchActive && displayed.any { it.category.isNotBlank() }
            val groups = if (hasCategories) displayed.groupBy { it.category } else mapOf("" to shown)
            if (searchActive && shown.isEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Text(
                        "Nessuna scheda trovata",
                        modifier = Modifier.padding(24.dp),
                        color = cs.onSurfaceVariant,
                    )
                }
            }
            var baseIndex = 0
            for ((cat, list) in groups) {
                val start = baseIndex
                baseIndex += list.size
                val isClosed = hasCategories && cat in collapsed
                if (hasCategories) {
                    item(key = "cat:$cat", span = { GridItemSpan(maxLineSpan) }) {
                        CategoryHeader(
                            name = cat.ifBlank { "Altre" },
                            count = list.size,
                            collapsed = isClosed,
                            editable = cat.isNotBlank(),
                            onToggle = {
                                collapsedRaw = (if (isClosed) collapsed - cat else collapsed + cat).joinToString("\u0001")
                            },
                            onRename = { renamingCat = cat },
                            onMoveUp = { onMoveCategory(cat, -1) },
                            onMoveDown = { onMoveCategory(cat, 1) },
                            onRemove = { removingCat = cat },
                            colorIndex = categoryColors[cat] ?: 0,
                            onColor = { coloringCat = cat },
                        )
                    }
                }
                if (!isClosed) {
                    itemsIndexed(list, key = { _, s -> s.id }) { i, s ->
                        val isDragged = draggedId == s.id
                        SectionCard(
                            start + i, s, onOpen, onTogglePin, { editing = s }, { doDelete(s) },
                            compact = listView,
                            colorIndex = if (hasCategories && cat.isNotBlank()) (categoryColors[cat] ?: 0) else null,
                            modifier = if (isDragged) Modifier.zIndex(1f) else Modifier.animateItem(),
                            dragging = isDragged,
                            translation = { translationFor(s.id) },
                            onDragStart = { startDrag(s.id) },
                            onDrag = moveDrag,
                            onDragEnd = finishDrag,
                        )
                    }
                }
            }
        }
    }

    if (showChooser) {
        AlertDialog(
            onDismissRequest = { showChooser = false },
            title = { Text("Nuova sezione") },
            text = {
                Column {
                    Text("Parti da zero, scegli una sezione già pronta dalla libreria o incolla una scheda ricevuta.")
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { showChooser = false; showAdd = true }) { Text("Da zero") }
                    TextButton(onClick = { showChooser = false; showLibrary = true }) { Text("Dalla libreria") }
                    TextButton(onClick = {
                        showChooser = false
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }
                            ?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
                        val card = CardShare.decode(text)
                        if (card != null) {
                            onImportCard(card)
                        } else {
                            Toast.makeText(context, "Negli appunti non c'è una scheda Prisma", Toast.LENGTH_SHORT).show()
                        }
                    }) { Text("Incolla scheda copiata") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showChooser = false }) { Text("Annulla") } },
        )
    }
    if (showLibrary) {
        LibraryDialog(
            onPick = { t -> onAdd(t.title, t.prompt, t.emoji, ""); showLibrary = false },
            onDismiss = { showLibrary = false },
        )
    }
    if (showAdd) {
        SectionDialog(
            heading = "Nuova sezione",
            confirmLabel = "Crea",
            initialTitle = "",
            initialPrompt = "",
            initialEmoji = "📌",
            initialCategory = "",
            categories = categoryNames,
            onGeneratePrompt = onGeneratePrompt,
            onSuggestEmojis = onSuggestEmojis,
            onConfirm = { t, p, e, c -> onAdd(t, p, e, c); showAdd = false },
            onDismiss = { showAdd = false },
        )
    }
    editing?.let { sec ->
        SectionDialog(
            heading = "Modifica sezione",
            confirmLabel = "Salva",
            initialTitle = sec.title,
            initialPrompt = sec.systemPrompt,
            initialEmoji = sec.emoji,
            initialCategory = sec.category,
            categories = categoryNames,
            onGeneratePrompt = onGeneratePrompt,
            onSuggestEmojis = onSuggestEmojis,
            onConfirm = { t, p, e, c -> onEdit(sec, t, p, e, c); editing = null },
            onDismiss = { editing = null },
        )
    }
    coloringCat?.let { name ->
        val current = categoryColors[name] ?: 0
        AlertDialog(
            onDismissRequest = { coloringCat = null },
            title = { Text("Colore di $name") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    for (row in 0 until 2) {
                        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            for (col in 0 until 4) {
                                val i = row * 4 + col
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(categoryDot(i))
                                        .clickable { onCategoryColor(name, i); coloringCat = null },
                                    contentAlignment = Alignment.Center,
                                ) {
                                    if (i == current) {
                                        Icon(Icons.Filled.Check, "Colore attuale", tint = Color.White)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { coloringCat = null }) { Text("Annulla") } },
        )
    }
    renamingCat?.let { old ->
        var text by remember(old) { mutableStateOf(old) }
        AlertDialog(
            onDismissRequest = { renamingCat = null },
            title = { Text("Rinomina categoria") },
            text = { OutlinedTextField(text, { text = it }, singleLine = true, label = { Text("Nome categoria") }) },
            confirmButton = {
                TextButton(
                    enabled = text.isNotBlank(),
                    onClick = { onRenameCategory(old, text); renamingCat = null },
                ) { Text("Salva") }
            },
            dismissButton = { TextButton(onClick = { renamingCat = null }) { Text("Annulla") } },
        )
    }
    removingCat?.let { name ->
        AlertDialog(
            onDismissRequest = { removingCat = null },
            title = { Text("Togliere la categoria $name?") },
            text = { Text("Le schede restano: finiscono solo fuori da ogni categoria.") },
            confirmButton = { TextButton(onClick = { onRenameCategory(name, ""); removingCat = null }) { Text("Togli") } },
            dismissButton = { TextButton(onClick = { removingCat = null }) { Text("Annulla") } },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SectionDialog(
    heading: String,
    confirmLabel: String,
    initialTitle: String,
    initialPrompt: String,
    initialEmoji: String,
    initialCategory: String,
    categories: List<String>,
    onGeneratePrompt: suspend (String, String) -> Result<String>,
    onSuggestEmojis: suspend (String, String) -> Result<List<String>>,
    onConfirm: (String, String, String, String) -> Unit,
    onDismiss: () -> Unit,
) {
    var title by remember { mutableStateOf(initialTitle) }
    var info by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(initialCategory) }
    var prompt by remember { mutableStateOf(initialPrompt) }
    var generating by remember { mutableStateOf(false) }
    var emoji by remember { mutableStateOf(initialEmoji) }
    var options by remember { mutableStateOf<List<String>>(emptyList()) }
    var suggesting by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(heading) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedTextField(title, { title = it }, label = { Text("Nome (es. VIAGGI)") }, singleLine = true)
                OutlinedTextField(
                    category, { category = it },
                    label = { Text("Categoria (facoltativa)") },
                    placeholder = { Text("Es. Cucina") },
                    singleLine = true,
                )
                if (categories.isNotEmpty()) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        categories.forEach { c ->
                            val on = category.trim() == c
                            FilterChip(selected = on, onClick = { category = if (on) "" else c }, label = { Text(c) })
                        }
                    }
                }

                // Icona: l'app ne propone fino a 5 e tu scegli quella che ti piace.
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        modifier = Modifier.size(56.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center,
                    ) { Text(emoji, fontSize = 28.sp) }
                    FilledTonalButton(
                        enabled = title.isNotBlank() && !suggesting,
                        onClick = {
                            suggesting = true
                            error = null
                            scope.launch {
                                onSuggestEmojis(title.trim(), prompt.ifBlank { info }.trim())
                                    .onSuccess { options = it }
                                    .onFailure { error = it.message ?: "Errore" }
                                suggesting = false
                            }
                        },
                    ) {
                        if (suggesting) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Filled.AutoAwesome, null, Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(if (suggesting) "Cerco..." else "Proponi icone")
                    }
                }
                if (options.isNotEmpty()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        repeat(5) { i ->
                            val e = options.getOrNull(i)
                            if (e == null) {
                                Spacer(Modifier.weight(1f))
                            } else {
                                val selected = e == emoji
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(1f)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surfaceContainerHighest)
                                        .border(
                                            if (selected) 2.dp else 0.dp,
                                            if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                            CircleShape,
                                        )
                                        .clickable { emoji = e },
                                    contentAlignment = Alignment.Center,
                                ) { Text(e, fontSize = 22.sp) }
                            }
                        }
                    }
                }
                OutlinedTextField(
                    info, { info = it },
                    label = { Text("Cosa vuoi che faccia?") },
                    placeholder = { Text("Es. dalla foto di un monumento mi dici storia e curiosità") },
                    minLines = 3,
                )
                FilledTonalButton(
                    enabled = info.isNotBlank() && !generating,
                    onClick = {
                        generating = true
                        error = null
                        scope.launch {
                            onGeneratePrompt(title.trim(), info.trim())
                                .onSuccess { prompt = it }
                                .onFailure { error = it.message ?: "Errore" }
                            generating = false
                        }
                    },
                ) {
                    if (generating) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Filled.AutoAwesome, null, Modifier.size(18.dp))
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(if (generating) "Creo il prompt..." else "Crea prompt con AI")
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                OutlinedTextField(
                    prompt, { prompt = it },
                    label = { Text("Prompt (modificabile)") },
                    minLines = 4,
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = title.isNotBlank() && prompt.isNotBlank() && !generating,
                onClick = { onConfirm(title, prompt, emoji, category) },
            ) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annulla") } },
    )
}

private val CATEGORY_HUES = floatArrayOf(150f, 210f, 265f, 330f, 20f, 45f, 180f, 100f)

/** Colori di sfondo e testo di una scheda in una categoria colorata. */
private fun categoryPalette(index: Int, dark: Boolean): Pair<Color, Color> {
    val h = CATEGORY_HUES[((index % 8) + 8) % 8]
    return if (dark) Color.hsl(h, 0.38f, 0.24f) to Color.hsl(h, 0.55f, 0.9f)
    else Color.hsl(h, 0.55f, 0.86f) to Color.hsl(h, 0.6f, 0.18f)
}

private fun categoryDot(index: Int): Color = Color.hsl(CATEGORY_HUES[((index % 8) + 8) % 8], 0.6f, 0.55f)

@Composable
private fun CategoryHeader(
    name: String,
    count: Int,
    collapsed: Boolean,
    editable: Boolean,
    onToggle: () -> Unit,
    onRename: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onRemove: () -> Unit,
    colorIndex: Int,
    onColor: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onToggle)
            .padding(start = 4.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            if (collapsed) Icons.Filled.KeyboardArrowDown else Icons.Filled.KeyboardArrowUp,
            if (collapsed) "Apri categoria" else "Chiudi categoria",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.width(4.dp))
        if (editable) {
            Box(Modifier.size(12.dp).clip(CircleShape).background(categoryDot(colorIndex)))
            Spacer(Modifier.width(8.dp))
        }
        Text(name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(8.dp))
        Text("$count", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.weight(1f))
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Opzioni categoria") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                if (editable) {
                    DropdownMenuItem(text = { Text("Rinomina") }, onClick = { menu = false; onRename() })
                    DropdownMenuItem(text = { Text("Cambia colore") }, onClick = { menu = false; onColor() })
                }
                DropdownMenuItem(text = { Text("Sposta su") }, onClick = { menu = false; onMoveUp() })
                DropdownMenuItem(text = { Text("Sposta giù") }, onClick = { menu = false; onMoveDown() })
                if (editable) {
                    DropdownMenuItem(text = { Text("Togli categoria") }, onClick = { menu = false; onRemove() })
                }
            }
        }
    }
}

@Composable
private fun Hero() {
    Row(
        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier.size(68.dp).clip(RoundedCornerShape(22.dp)).background(Color(0xFF14201B)),
            contentAlignment = Alignment.Center,
        ) {
            Image(
                painter = painterResource(R.drawable.ic_launcher_foreground),
                contentDescription = "Logo Prisma",
                modifier = Modifier.requiredSize(98.dp),
            )
        }
        Spacer(Modifier.width(16.dp))
        Column {
            Text("Prisma", style = MaterialTheme.typography.displaySmall)
            Text(
                "Un prompt per ogni cosa",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SectionCard(
    index: Int,
    s: Section,
    onOpen: (Section) -> Unit,
    onTogglePin: (Section) -> Unit,
    onEditRequest: () -> Unit,
    onDeleteRequest: () -> Unit,
    modifier: Modifier = Modifier,
    colorIndex: Int? = null,
    compact: Boolean = false,
    dragging: Boolean = false,
    translation: () -> Offset = { Offset.Zero },
    onDragStart: () -> Unit = {},
    onDrag: (Offset) -> Unit = {},
    onDragEnd: () -> Unit = {},
) {
    val cs = MaterialTheme.colorScheme
    val haptic = LocalHapticFeedback.current
    val cardContext = LocalContext.current
    val scope = rememberCoroutineScope()
    val currentOpen by rememberUpdatedState(onOpen)
    val currentStart by rememberUpdatedState(onDragStart)
    val currentDrag by rememberUpdatedState(onDrag)
    val currentEnd by rememberUpdatedState(onDragEnd)
    var moved by remember { mutableStateOf(0f) }
    var suppressClick by remember { mutableStateOf(false) }
    var visible by rememberSaveable(s.id) { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    LaunchedEffect(s.id) {
        if (!visible) delay(index * 70L)
        visible = true
    }
    val (bg, fg) = if (colorIndex != null) categoryPalette(colorIndex, cs.background.luminance() < 0.5f) else when (index % 3) {
        0 -> cs.primaryContainer to cs.onPrimaryContainer
        1 -> cs.secondaryContainer to cs.onSecondaryContainer
        else -> cs.tertiaryContainer to cs.onTertiaryContainer
    }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn() + scaleIn(initialScale = 0.9f),
        modifier = modifier,
    ) {
        Box(
            Modifier.graphicsLayer {
                val t = translation()
                translationX = t.x
                translationY = t.y
                val sc = if (dragging) 1.06f else 1f
                scaleX = sc
                scaleY = sc
                alpha = if (dragging) 0.92f else 1f
            },
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (compact) 76.dp else 172.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .clickable {
                        if (suppressClick) suppressClick = false else currentOpen(s)
                    }
                    // Tieni premuto e trascina per spostare; se rilasci senza muoverti esce il menu.
                    .pointerInput(s.id) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = {
                                moved = 0f
                                suppressClick = true
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                currentStart()
                            },
                            onDrag = { change, delta ->
                                change.consume()
                                moved += kotlin.math.abs(delta.x) + kotlin.math.abs(delta.y)
                                currentDrag(delta)
                            },
                            onDragEnd = {
                                currentEnd()
                                if (moved < 24f) menu = true
                                scope.launch { delay(150); suppressClick = false }
                            },
                            onDragCancel = {
                                currentEnd()
                                scope.launch { delay(150); suppressClick = false }
                            },
                        )
                    },
                colors = CardDefaults.cardColors(containerColor = bg, contentColor = fg),
                shape = RoundedCornerShape(28.dp),
            ) {
                if (compact) {
                    Row(
                        Modifier.fillMaxSize().padding(start = 16.dp, end = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            modifier = Modifier.size(44.dp).clip(CircleShape).background(fg.copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center,
                        ) { Text(s.emoji, fontSize = 22.sp) }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                s.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                s.hint,
                                style = MaterialTheme.typography.bodySmall,
                                color = fg.copy(alpha = 0.75f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        IconButton(onClick = { onTogglePin(s) }, modifier = Modifier.size(40.dp)) {
                            Icon(
                                if (s.pinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                                if (s.pinned) "Rimuovi pin" else "Fissa in alto",
                                Modifier.size(20.dp),
                            )
                        }
                    }
                } else BoxWithConstraints(Modifier.fillMaxSize().padding(16.dp)) {
                    val innerWidth = maxWidth
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(fg.copy(alpha = 0.12f))
                            .align(Alignment.TopStart),
                        contentAlignment = Alignment.Center,
                    ) { Text(s.emoji, fontSize = 24.sp) }

                    IconButton(
                        onClick = { onTogglePin(s) },
                        modifier = Modifier.align(Alignment.TopEnd).size(32.dp),
                    ) {
                        Icon(
                            if (s.pinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                            if (s.pinned) "Rimuovi pin" else "Fissa in alto",
                            Modifier.size(18.dp),
                        )
                    }

                    Column(Modifier.align(Alignment.BottomStart)) {
                        // Il titolo si rimpicciolisce finché la parola più lunga sta intera nella card.
                        val longest = s.title.split(' ', '\n').maxOfOrNull { it.length }?.coerceAtLeast(1) ?: 1
                        val titleSp = (innerWidth.value / (longest * 0.72f)).coerceIn(14f, 22f)
                        Text(
                            s.title,
                            style = MaterialTheme.typography.titleLarge,
                            fontSize = titleSp.sp,
                            lineHeight = (titleSp * 1.15f).sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            s.hint,
                            style = MaterialTheme.typography.bodySmall,
                            color = fg.copy(alpha = 0.75f),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Modifica") },
                    leadingIcon = { Icon(Icons.Filled.Edit, null) },
                    onClick = { menu = false; onEditRequest() },
                )
                DropdownMenuItem(
                    text = { Text("Condividi") },
                    leadingIcon = { Icon(Icons.Filled.Share, null) },
                    onClick = { menu = false; CardShare.share(cardContext, s) },
                )
                DropdownMenuItem(
                    text = { Text("Aggiungi alla Home") },
                    leadingIcon = { Icon(Icons.Filled.AddToHomeScreen, null) },
                    onClick = {
                        menu = false
                        if (!SectionShortcut.pin(cardContext, s)) {
                            Toast.makeText(cardContext, "Il tuo launcher non supporta le scorciatoie", Toast.LENGTH_SHORT).show()
                        }
                    },
                )
                DropdownMenuItem(
                    text = { Text("Elimina") },
                    leadingIcon = { Icon(Icons.Filled.Delete, null) },
                    onClick = { menu = false; onDeleteRequest() },
                )
            }
        }
    }
}
