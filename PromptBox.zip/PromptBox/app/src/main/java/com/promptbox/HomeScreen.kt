package com.promptbox

import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Brush
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material3.AssistChip
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material.icons.filled.Receipt
import android.widget.Toast
import androidx.compose.material.icons.filled.AddToHomeScreen
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.FilterChip
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.zIndex
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.material3.FilledTonalButton
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NewReleases
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material3.Button
import androidx.compose.material3.LocalContentColor
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    sections: List<Section>,
    store: Store,
    onReceipt: (Receipt) -> Unit,
    onToStock: (List<PantryItem>) -> Unit,
    hasKey: Boolean,
    update: Updater.Info?,
    onOpen: (Section) -> Unit,
    onSettings: () -> Unit,
    hasNews: Boolean = false,
    onChangelog: () -> Unit = {},
    onShopping: () -> Unit = {},
    onHistory: () -> Unit = {},
    syncProblem: Boolean = false,
    onRetrySync: () -> Unit = {},
    onAdd: (String, String, String, String) -> Unit,
    onEdit: (Section, String, String, String, String) -> Unit,
    onRenameCategory: (String, String) -> Unit = { _, _ -> },
    listView: Boolean = false,
    onToggleView: () -> Unit = {},
    recent: List<String> = emptyList(),
    categoryColors: Map<String, Int> = emptyMap(),
    collapsedCategories: Set<String> = emptySet(),
    onCollapsedChange: (Set<String>) -> Unit = {},
    onCategoryColor: (String, Int) -> Unit = { _, _ -> },
    onUndoDelete: () -> Unit = {},
    onImportCard: (CardData) -> Unit = {},
    onMoveCategory: (String, Int) -> Unit = { _, _ -> },
    onDelete: (Section) -> Unit,
    onTogglePin: (Section) -> Unit,
    onReorder: (List<String>) -> Unit = {},
    onGeneratePrompt: suspend (String, String) -> Result<String>,
    onSuggestEmojis: suspend (String, String) -> Result<List<String>>,
) {
    var showChooser by remember { mutableStateOf(false) }
    var showReceipt by remember { mutableStateOf(false) }
    var updateHidden by rememberSaveable { mutableStateOf(false) }
    var showLibrary by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Section?>(null) }
    var query by rememberSaveable { mutableStateOf("") }
    val searchActive = query.isNotBlank()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    var renamingCat by remember { mutableStateOf<String?>(null) }
    var coloringCat by remember { mutableStateOf<String?>(null) }
    var removingCat by remember { mutableStateOf<String?>(null) }
    // Categorie chiuse (nomi uniti da un separatore, così si salvano anche con la rotazione dello schermo).
    // Si ricordano anche chiudendo l'app o cambiando schermata (salvate in Store dal chiamante).
    var collapsed by remember { mutableStateOf(collapsedCategories) }
    val categoryNames = remember(sections) { sections.map { it.category }.filter { it.isNotBlank() }.distinct() }
    val cs = MaterialTheme.colorScheme

    // --- Riordino: tieni premuta una scheda e trascinala dove vuoi ---
    val gridState = rememberLazyGridState()
    val dragScope = rememberCoroutineScope()
    var localOrder by remember { mutableStateOf<List<String>?>(null) }
    var draggedId by remember { mutableStateOf<String?>(null) }
    var dragTotal by remember { mutableStateOf(Offset.Zero) }
    var dragStart by remember { mutableStateOf(IntOffset.Zero) }
    val displayed = remember(sections, localOrder) {
        localOrder?.let { order ->
            val byId = sections.associateBy { it.id }
            order.mapNotNull { byId[it] }
        } ?: sections
    }
    val translationFor: (String) -> Offset = { id ->
        if (id != draggedId) {
            Offset.Zero
        } else {
            val info = gridState.layoutInfo.visibleItemsInfo.firstOrNull { it.key == id }
            if (info == null) dragTotal
            else Offset(dragTotal.x - (info.offset.x - dragStart.x), dragTotal.y - (info.offset.y - dragStart.y))
        }
    }
    val startDrag: (String) -> Unit = startDrag@{ id ->
        // Durante la ricerca l'ordine non si può cambiare.
        if (searchActive) return@startDrag
        val info = gridState.layoutInfo.visibleItemsInfo.firstOrNull { it.key == id }
        dragStart = info?.offset ?: IntOffset.Zero
        dragTotal = Offset.Zero
        localOrder = sections.map { it.id }
        draggedId = id
    }
    val moveDrag: (Offset) -> Unit = moveDrag@{ delta ->
        val id = draggedId ?: return@moveDrag
        dragTotal += delta
        val items = gridState.layoutInfo.visibleItemsInfo
        val size = items.firstOrNull { it.key == id }?.size ?: return@moveDrag
        val center = Offset(
            dragStart.x + size.width / 2f + dragTotal.x,
            dragStart.y + size.height / 2f + dragTotal.y,
        )
        // Se la scheda passa sopra un'altra (dello stesso gruppo pinnate / non pinnate) si scambiano.
        val pinnedById = sections.associate { it.id to (it.pinned to it.category) }
        val target = items.firstOrNull {
            val k = it.key as? String
            k != null && k != id && pinnedById[k] == pinnedById[id] &&
                center.x >= it.offset.x && center.x < it.offset.x + it.size.width &&
                center.y >= it.offset.y && center.y < it.offset.y + it.size.height
        }?.key as? String
        if (target != null) {
            val cur = localOrder ?: return@moveDrag
            val from = cur.indexOf(id)
            val to = cur.indexOf(target)
            if (from >= 0 && to >= 0 && from != to) {
                localOrder = cur.toMutableList().apply { removeAt(from); add(to, id) }
            }
        }
        // Vicino al bordo la lista scorre da sola.
        val viewH = gridState.layoutInfo.viewportSize.height
        val dy = when {
            center.y < 140f -> -28f
            center.y > viewH - 180f -> 28f
            else -> 0f
        }
        if (dy != 0f) dragScope.launch { gridState.scrollBy(dy) }
    }
    val finishDrag: () -> Unit = {
        localOrder?.let { onReorder(it) }
        localOrder = null
        draggedId = null
        dragTotal = Offset.Zero
    }

    val doDelete: (Section) -> Unit = { sec ->
        onDelete(sec)
        dragScope.launch {
            snackbarHostState.currentSnackbarData?.dismiss()
            val r = snackbarHostState.showSnackbar(
                message = "Scheda ${sec.title} eliminata",
                actionLabel = "Annulla",
                duration = SnackbarDuration.Long,
            )
            if (r == SnackbarResult.ActionPerformed) onUndoDelete()
        }
    }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            HomeHeader(
                hasNews = hasNews,
                syncProblem = syncProblem,
                onChangelog = onChangelog,
                onRetrySync = onRetrySync,
                listView = listView,
                onToggleView = onToggleView,
                query = query,
                onQuery = { query = it },
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showChooser = true },
                containerColor = cs.primary,
                contentColor = cs.onPrimary,
                shape = RoundedCornerShape(20.dp),
            ) { Icon(Icons.Filled.Add, "Nuova sezione") }
        },
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(
                if (androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp >= WIDE_MIN_DP) {
                    if (listView) 2 else 3
                } else {
                    if (listView) 1 else 2
                },
            ),
            state = gridState,
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 0.dp, 16.dp, 110.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (!searchActive) item(key = "recent_row", span = { GridItemSpan(maxLineSpan) }) {
                val recentSections = recent.mapNotNull { id -> sections.firstOrNull { it.id == id } }.take(3)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Row(
                        Modifier
                            .weight(1f)
                            .horizontalScroll(rememberScrollState())
                            // Sfumatura a destra: si capisce che le recenti continuano, invece di essere tagliate di netto.
                            .drawWithContent {
                                drawContent()
                                drawRect(
                                    Brush.horizontalGradient(
                                        listOf(Color.Transparent, cs.background),
                                        startX = size.width - 28.dp.toPx(),
                                        endX = size.width,
                                    ),
                                )
                            },
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        recentSections.forEach { r ->
                            val shape = RoundedCornerShape(50)
                            Text(
                                "${r.emoji} ${r.title.lowercase().replaceFirstChar { it.uppercase() }}",
                                style = MaterialTheme.typography.labelLarge,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier
                                    .clip(shape)
                                    .border(1.dp, cs.outlineVariant, shape)
                                    .clickable { onOpen(r) }
                                    .padding(horizontal = 12.dp, vertical = 7.dp)
                                    .widthIn(max = 150.dp),
                            )
                        }
                        // Spazio finale: l'ultima recente non finisce sotto la sfumatura.
                        Spacer(Modifier.width(24.dp))
                    }
                }
            }

            if (update != null && !updateHidden) {
                item(span = { GridItemSpan(maxLineSpan) }) { UpdateCard(update, onDismiss = { updateHidden = true }) }
            }
            if (!hasKey) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Card(
                        onClick = onSettings,
                        colors = CardDefaults.cardColors(
                            containerColor = cs.surfaceContainerHigh,
                            contentColor = cs.onSurface,
                        ),
                        shape = RoundedCornerShape(20.dp),
                    ) {
                        androidx.compose.foundation.layout.Row(
                            Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            androidx.compose.foundation.layout.Box(
                                Modifier.size(40.dp).clip(androidx.compose.foundation.shape.CircleShape)
                                    .background(cs.error.copy(alpha = 0.14f)),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = cs.error)
                            }
                            androidx.compose.foundation.layout.Spacer(Modifier.width(12.dp))
                            androidx.compose.foundation.layout.Column(Modifier.weight(1f)) {
                                Text("Manca la chiave API", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "Inseriscila nelle Impostazioni per iniziare.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = cs.onSurfaceVariant,
                                )
                            }
                            Icon(
                                androidx.compose.material.icons.Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                contentDescription = null,
                                tint = cs.onSurfaceVariant,
                            )
                        }
                    }
                }
            }

            val q = query.trim()
            val shown = if (q.isEmpty()) displayed else displayed.filter {
                it.title.contains(q, true) || it.category.contains(q, true) || it.systemPrompt.contains(q, true)
            }
            // Durante la ricerca: elenco semplice, senza titoli di categoria.
            val hasCategories = !searchActive && displayed.any { it.category.isNotBlank() }
            val groups = if (hasCategories) displayed.groupBy { it.category } else mapOf("" to shown)
            if (searchActive && shown.isEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Text(
                        "Nessuna scheda trovata",
                        modifier = Modifier.padding(24.dp),
                        color = cs.onSurfaceVariant,
                    )
                }
            }
            var baseIndex = 0
            for ((cat, list) in groups) {
                val start = baseIndex
                baseIndex += list.size
                val isClosed = hasCategories && cat in collapsed
                if (hasCategories) {
                    item(key = "cat:$cat", span = { GridItemSpan(maxLineSpan) }) {
                        CategoryHeader(
                            name = cat.ifBlank { "Altre" },
                            count = list.size,
                            collapsed = isClosed,
                            editable = cat.isNotBlank(),
                            onToggle = {
                                collapsed = if (isClosed) collapsed - cat else collapsed + cat
                                onCollapsedChange(collapsed)
                            },
                            onRename = { renamingCat = cat },
                            onMoveUp = { onMoveCategory(cat, -1) },
                            onMoveDown = { onMoveCategory(cat, 1) },
                            onRemove = { removingCat = cat },
                            colorIndex = categoryColors[cat] ?: 0,
                            onColor = { coloringCat = cat },
                        )
                    }
                }
                if (!isClosed) {
                    itemsIndexed(list, key = { _, s -> s.id }) { i, s ->
                        val isDragged = draggedId == s.id
                        SectionCard(
                            start + i, s, onOpen, onTogglePin, { editing = s }, { doDelete(s) },
                            compact = listView,
                            colorIndex = if (hasCategories && cat.isNotBlank()) (categoryColors[cat] ?: 0) else null,
                            modifier = if (isDragged) Modifier.zIndex(1f) else Modifier.animateItem(),
                            dragging = isDragged,
                            translation = { translationFor(s.id) },
                            onDragStart = { startDrag(s.id) },
                            onDrag = moveDrag,
                            onDragEnd = finishDrag,
                        )
                    }
                }
            }
        }
    }

    if (showChooser) {
        ModalBottomSheet(
            onDismissRequest = { showChooser = false },
            containerColor = cs.surfaceContainerHigh,
        ) {
            Column(Modifier.navigationBarsPadding().padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
                Text("Aggiungi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 14.dp))
                // L'unico tasto pieno: lo scontrino, come in Frigo e Dispensa.
                Card(
                    onClick = { showChooser = false; showReceipt = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = cs.primary, contentColor = cs.onPrimary),
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(48.dp).clip(CircleShape).background(cs.onPrimary.copy(alpha = 0.14f)),
                            contentAlignment = Alignment.Center,
                        ) { Icon(Icons.Filled.Receipt, null) }
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text("Scansiona scontrino", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("Fotografalo: l'AI riempie frigo e dispensa", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                Text(
                    "NUOVA SEZIONE",
                    style = MaterialTheme.typography.labelMedium,
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(start = 4.dp, top = 18.dp, bottom = 4.dp),
                )
                ChooserRow(
                    icon = Icons.Filled.AutoAwesome,
                    title = "Crea con AI",
                    subtitle = "Scrivi cosa vuoi, l'AI prepara il prompt",
                    divider = false,
                    onClick = { showChooser = false; showAdd = true },
                )
                ChooserRow(
                    icon = Icons.Filled.GridView,
                    title = "Dalla libreria",
                    subtitle = "Sezioni già pronte, con anteprima",
                    onClick = { showChooser = false; showLibrary = true },
                )
                ChooserRow(
                    icon = Icons.Filled.ContentPaste,
                    title = "Incolla scheda copiata",
                    subtitle = "Ricevuta da un altro telefono",
                    onClick = {
                        showChooser = false
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }
                            ?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
                        val card = CardShare.decode(text)
                        if (card != null) {
                            onImportCard(card)
                        } else {
                            Toast.makeText(context, "Negli appunti non c'è una scheda Prisma", Toast.LENGTH_SHORT).show()
                        }
                    },
                )
            }
        }
    }
    if (showReceipt) {
        ReceiptToPantryFlow(
            store = store,
            onReceipt = onReceipt,
            onToStock = {
                onToStock(it)
                dragScope.launch {
                    snackbarHostState.currentSnackbarData?.dismiss()
                    snackbarHostState.showSnackbar(
                        if (it.size == 1) "1 prodotto aggiunto a frigo e dispensa" else it.size.toString() + " prodotti aggiunti a frigo e dispensa",
                    )
                }
            },
            onDismiss = { showReceipt = false },
        )
    }
    if (showLibrary) {
        LibraryDialog(
            onPick = { t -> onAdd(t.title, t.prompt, t.emoji, ""); showLibrary = false },
            onDismiss = { showLibrary = false },
        )
    }
    if (showAdd) {
        SectionDialog(
            heading = "Nuova sezione",
            confirmLabel = "Crea",
            initialTitle = "",
            initialPrompt = "",
            initialEmoji = "📌",
            initialCategory = "",
            categories = categoryNames,
            onGeneratePrompt = onGeneratePrompt,
            onSuggestEmojis = onSuggestEmojis,
            onConfirm = { t, p, e, c -> onAdd(t, p, e, c); showAdd = false },
            onDismiss = { showAdd = false },
        )
    }
    editing?.let { sec ->
        SectionDialog(
            heading = "Modifica sezione",
            confirmLabel = "Salva",
            initialTitle = sec.title,
            initialPrompt = sec.systemPrompt,
            initialEmoji = sec.emoji,
            initialCategory = sec.category,
            categories = categoryNames,
            onGeneratePrompt = onGeneratePrompt,
            onSuggestEmojis = onSuggestEmojis,
            onConfirm = { t, p, e, c -> onEdit(sec, t, p, e, c); editing = null },
            onDismiss = { editing = null },
        )
    }
    coloringCat?.let { name ->
        val current = categoryColors[name] ?: 0
        AlertDialog(
            onDismissRequest = { coloringCat = null },
            title = { Text("Colore di $name") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    for (row in 0 until 2) {
                        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            for (col in 0 until 4) {
                                val i = row * 4 + col
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(categoryDot(i))
                                        .clickable { onCategoryColor(name, i); coloringCat = null },
                                    contentAlignment = Alignment.Center,
                                ) {
                                    if (i == current) {
                                        Icon(Icons.Filled.Check, "Colore attuale", tint = Color.White)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { coloringCat = null }) { Text("Annulla") } },
        )
    }
    renamingCat?.let { old ->
        var text by remember(old) { mutableStateOf(old) }
        AlertDialog(
            onDismissRequest = { renamingCat = null },
            title = { Text("Rinomina categoria") },
            text = { OutlinedTextField(text, { text = it }, singleLine = true, label = { Text("Nome categoria") }) },
            confirmButton = {
                TextButton(
                    enabled = text.isNotBlank(),
                    onClick = { onRenameCategory(old, text); renamingCat = null },
                ) { Text("Salva") }
            },
            dismissButton = { TextButton(onClick = { renamingCat = null }) { Text("Annulla") } },
        )
    }
    removingCat?.let { name ->
        AlertDialog(
            onDismissRequest = { removingCat = null },
            title = { Text("Togliere la categoria $name?") },
            text = { Text("Le schede restano: finiscono solo fuori da ogni categoria.") },
            confirmButton = { TextButton(onClick = { onRenameCategory(name, ""); removingCat = null }) { Text("Togli") } },
            dismissButton = { TextButton(onClick = { removingCat = null }) { Text("Annulla") } },
        )
    }
}
