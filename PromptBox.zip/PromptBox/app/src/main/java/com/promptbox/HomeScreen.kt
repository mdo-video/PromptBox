package com.promptbox

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.material3.FilledTonalButton
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    sections: List<Section>,
    hasKey: Boolean,
    update: Updater.Info?,
    onOpen: (Section) -> Unit,
    onSettings: () -> Unit,
    onAdd: (String, String, String) -> Unit,
    onEdit: (Section, String, String, String) -> Unit,
    onDelete: (Section) -> Unit,
    onTogglePin: (Section) -> Unit,
    onGeneratePrompt: suspend (String, String) -> Result<String>,
    onSuggestEmojis: suspend (String, String) -> Result<List<String>>,
) {
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Section?>(null) }
    var deleting by remember { mutableStateOf<Section?>(null) }
    val cs = MaterialTheme.colorScheme

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = {},
                actions = {
                    IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, "Impostazioni") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAdd = true },
                icon = { Icon(Icons.Filled.Add, null) },
                text = { Text("Nuova sezione") },
                containerColor = cs.primaryContainer,
                contentColor = cs.onPrimaryContainer,
            )
        },
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 0.dp, 16.dp, 110.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) { Hero() }

            if (update != null) {
                item(span = { GridItemSpan(maxLineSpan) }) { UpdateCard(update) }
            }
            if (!hasKey) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Card(
                        onClick = onSettings,
                        colors = CardDefaults.cardColors(
                            containerColor = cs.errorContainer,
                            contentColor = cs.onErrorContainer,
                        ),
                        shape = RoundedCornerShape(24.dp),
                    ) {
                        Text(
                            "Per iniziare inserisci la chiave API nelle Impostazioni. Tocca qui.",
                            modifier = Modifier.padding(18.dp),
                        )
                    }
                }
            }

            itemsIndexed(sections, key = { _, s -> s.id }) { index, s ->
                SectionCard(index, s, onOpen, onTogglePin, { editing = s }, { deleting = s })
            }
        }
    }

    if (showAdd) {
        SectionDialog(
            heading = "Nuova sezione",
            confirmLabel = "Crea",
            initialTitle = "",
            initialPrompt = "",
            initialEmoji = "📌",
            onGeneratePrompt = onGeneratePrompt,
            onSuggestEmojis = onSuggestEmojis,
            onConfirm = { t, p, e -> onAdd(t, p, e); showAdd = false },
            onDismiss = { showAdd = false },
        )
    }
    editing?.let { sec ->
        SectionDialog(
            heading = "Modifica sezione",
            confirmLabel = "Salva",
            initialTitle = sec.title,
            initialPrompt = sec.systemPrompt,
            initialEmoji = sec.emoji,
            onGeneratePrompt = onGeneratePrompt,
            onSuggestEmojis = onSuggestEmojis,
            onConfirm = { t, p, e -> onEdit(sec, t, p, e); editing = null },
            onDismiss = { editing = null },
        )
    }
    deleting?.let { sec ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Eliminare ${sec.title}?") },
            text = { Text("La sezione e il suo prompt verranno cancellati.") },
            confirmButton = { TextButton(onClick = { onDelete(sec); deleting = null }) { Text("Elimina") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Annulla") } },
        )
    }
}

@Composable
private fun SectionDialog(
    heading: String,
    confirmLabel: String,
    initialTitle: String,
    initialPrompt: String,
    initialEmoji: String,
    onGeneratePrompt: suspend (String, String) -> Result<String>,
    onSuggestEmojis: suspend (String, String) -> Result<List<String>>,
    onConfirm: (String, String, String) -> Unit,
    onDismiss: () -> Unit,
) {
    var title by remember { mutableStateOf(initialTitle) }
    var info by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf(initialPrompt) }
    var generating by remember { mutableStateOf(false) }
    var emoji by remember { mutableStateOf(initialEmoji) }
    var options by remember { mutableStateOf<List<String>>(emptyList()) }
    var suggesting by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(heading) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedTextField(title, { title = it }, label = { Text("Nome (es. VIAGGI)") }, singleLine = true)

                // Icona: l'app ne propone fino a 5 e tu scegli quella che ti piace.
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        modifier = Modifier.size(56.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center,
                    ) { Text(emoji, fontSize = 28.sp) }
                    FilledTonalButton(
                        enabled = title.isNotBlank() && !suggesting,
                        onClick = {
                            suggesting = true
                            error = null
                            scope.launch {
                                onSuggestEmojis(title.trim(), prompt.ifBlank { info }.trim())
                                    .onSuccess { options = it }
                                    .onFailure { error = it.message ?: "Errore" }
                                suggesting = false
                            }
                        },
                    ) {
                        if (suggesting) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Filled.AutoAwesome, null, Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(if (suggesting) "Cerco..." else "Proponi icone")
                    }
                }
                if (options.isNotEmpty()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        repeat(5) { i ->
                            val e = options.getOrNull(i)
                            if (e == null) {
                                Spacer(Modifier.weight(1f))
                            } else {
                                val selected = e == emoji
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(1f)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surfaceContainerHighest)
                                        .border(
                                            if (selected) 2.dp else 0.dp,
                                            if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                            CircleShape,
                                        )
                                        .clickable { emoji = e },
                                    contentAlignment = Alignment.Center,
                                ) { Text(e, fontSize = 22.sp) }
                            }
                        }
                    }
                }
                OutlinedTextField(
                    info, { info = it },
                    label = { Text("Cosa vuoi che faccia?") },
                    placeholder = { Text("Es. dalla foto di un monumento mi dici storia e curiosità") },
                    minLines = 3,
                )
                FilledTonalButton(
                    enabled = info.isNotBlank() && !generating,
                    onClick = {
                        generating = true
                        error = null
                        scope.launch {
                            onGeneratePrompt(title.trim(), info.trim())
                                .onSuccess { prompt = it }
                                .onFailure { error = it.message ?: "Errore" }
                            generating = false
                        }
                    },
                ) {
                    if (generating) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Filled.AutoAwesome, null, Modifier.size(18.dp))
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(if (generating) "Creo il prompt..." else "Crea prompt con AI")
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                OutlinedTextField(
                    prompt, { prompt = it },
                    label = { Text("Prompt (modificabile)") },
                    minLines = 4,
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = title.isNotBlank() && prompt.isNotBlank() && !generating,
                onClick = { onConfirm(title, prompt, emoji) },
            ) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annulla") } },
    )
}

@Composable
private fun Hero() {
    Row(
        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier.size(68.dp).clip(RoundedCornerShape(22.dp)).background(Color(0xFF14201B)),
            contentAlignment = Alignment.Center,
        ) {
            Image(
                painter = painterResource(R.drawable.ic_launcher_foreground),
                contentDescription = "Logo Prisma",
                modifier = Modifier.requiredSize(98.dp),
            )
        }
        Spacer(Modifier.width(16.dp))
        Column {
            Text("Prisma", style = MaterialTheme.typography.displaySmall)
            Text(
                "Un prompt per ogni cosa",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SectionCard(
    index: Int,
    s: Section,
    onOpen: (Section) -> Unit,
    onTogglePin: (Section) -> Unit,
    onEditRequest: () -> Unit,
    onDeleteRequest: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var visible by rememberSaveable(s.id) { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    LaunchedEffect(s.id) {
        if (!visible) delay(index * 70L)
        visible = true
    }
    val (bg, fg) = when (index % 3) {
        0 -> cs.primaryContainer to cs.onPrimaryContainer
        1 -> cs.secondaryContainer to cs.onSecondaryContainer
        else -> cs.tertiaryContainer to cs.onTertiaryContainer
    }

    AnimatedVisibility(visible = visible, enter = fadeIn() + scaleIn(initialScale = 0.9f)) {
        Box {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(172.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .combinedClickable(onClick = { onOpen(s) }, onLongClick = { menu = true }),
                colors = CardDefaults.cardColors(containerColor = bg, contentColor = fg),
                shape = RoundedCornerShape(28.dp),
            ) {
                BoxWithConstraints(Modifier.fillMaxSize().padding(16.dp)) {
                    val innerWidth = maxWidth
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(fg.copy(alpha = 0.12f))
                            .align(Alignment.TopStart),
                        contentAlignment = Alignment.Center,
                    ) { Text(s.emoji, fontSize = 24.sp) }

                    IconButton(
                        onClick = { onTogglePin(s) },
                        modifier = Modifier.align(Alignment.TopEnd).size(32.dp),
                    ) {
                        Icon(
                            if (s.pinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                            if (s.pinned) "Rimuovi pin" else "Fissa in alto",
                            Modifier.size(18.dp),
                        )
                    }

                    Column(Modifier.align(Alignment.BottomStart)) {
                        // Il titolo si rimpicciolisce finché la parola più lunga sta intera nella card.
                        val longest = s.title.split(' ', '\n').maxOfOrNull { it.length }?.coerceAtLeast(1) ?: 1
                        val titleSp = (innerWidth.value / (longest * 0.72f)).coerceIn(14f, 22f)
                        Text(
                            s.title,
                            style = MaterialTheme.typography.titleLarge,
                            fontSize = titleSp.sp,
                            lineHeight = (titleSp * 1.15f).sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            s.hint,
                            style = MaterialTheme.typography.bodySmall,
                            color = fg.copy(alpha = 0.75f),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Modifica") },
                    leadingIcon = { Icon(Icons.Filled.Edit, null) },
                    onClick = { menu = false; onEditRequest() },
                )
                DropdownMenuItem(
                    text = { Text("Elimina") },
                    leadingIcon = { Icon(Icons.Filled.Delete, null) },
                    onClick = { menu = false; onDeleteRequest() },
                )
            }
        }
    }
}
