package com.promptbox

import androidx.compose.animation.AnimatedVisibility
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    sections: List<Section>,
    hasKey: Boolean,
    update: Updater.Info?,
    onOpen: (Section) -> Unit,
    onSettings: () -> Unit,
    onAdd: (String, String) -> Unit,
    onDelete: (Section) -> Unit,
    onTogglePin: (Section) -> Unit,
    onGeneratePrompt: suspend (String, String) -> Result<String>,
) {
    var showAdd by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = {},
                actions = {
                    IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, "Impostazioni") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAdd = true },
                icon = { Icon(Icons.Filled.Add, null) },
                text = { Text("Nuova sezione") },
                containerColor = cs.primaryContainer,
                contentColor = cs.onPrimaryContainer,
            )
        },
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 0.dp, 16.dp, 110.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) { Hero() }

            if (update != null) {
                item(span = { GridItemSpan(maxLineSpan) }) { UpdateCard(update) }
            }
            if (!hasKey) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Card(
                        onClick = onSettings,
                        colors = CardDefaults.cardColors(
                            containerColor = cs.errorContainer,
                            contentColor = cs.onErrorContainer,
                        ),
                        shape = RoundedCornerShape(24.dp),
                    ) {
                        Text(
                            "Per iniziare inserisci la chiave API nelle Impostazioni. Tocca qui.",
                            modifier = Modifier.padding(18.dp),
                        )
                    }
                }
            }

            itemsIndexed(sections, key = { _, s -> s.id }) { index, s ->
                SectionCard(index, s, onOpen, onDelete, onTogglePin)
            }
        }
    }

    if (showAdd) {
        var title by remember { mutableStateOf("") }
        var info by remember { mutableStateOf("") }
        var prompt by remember { mutableStateOf("") }
        var generating by remember { mutableStateOf(false) }
        var error by remember { mutableStateOf<String?>(null) }
        val scope = rememberCoroutineScope()
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Nuova sezione") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    OutlinedTextField(title, { title = it }, label = { Text("Nome (es. VIAGGI)") }, singleLine = true)
                    OutlinedTextField(
                        info, { info = it },
                        label = { Text("Cosa vuoi che faccia?") },
                        placeholder = { Text("Es. dalla foto di un monumento mi dici storia e curiosità") },
                        minLines = 3,
                    )
                    FilledTonalButton(
                        enabled = info.isNotBlank() && !generating,
                        onClick = {
                            generating = true
                            error = null
                            scope.launch {
                                onGeneratePrompt(title.trim(), info.trim())
                                    .onSuccess { prompt = it }
                                    .onFailure { error = it.message ?: "Errore" }
                                generating = false
                            }
                        },
                    ) {
                        if (generating) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Filled.AutoAwesome, null, Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(if (generating) "Creo il prompt..." else "Crea prompt con AI")
                    }
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                    OutlinedTextField(
                        prompt, { prompt = it },
                        label = { Text("Prompt (modificabile)") },
                        minLines = 4,
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = title.isNotBlank() && prompt.isNotBlank() && !generating,
                    onClick = { onAdd(title, prompt); showAdd = false },
                ) { Text("Crea") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Annulla") } },
        )
    }
}

@Composable
private fun Hero() {
    Row(
        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier.size(68.dp).clip(RoundedCornerShape(22.dp)).background(Color(0xFF14201B)),
            contentAlignment = Alignment.Center,
        ) {
            Image(
                painter = painterResource(R.drawable.ic_launcher_foreground),
                contentDescription = "Logo Prisma",
                modifier = Modifier.requiredSize(98.dp),
            )
        }
        Spacer(Modifier.width(16.dp))
        Column {
            Text("Prisma", style = MaterialTheme.typography.displaySmall)
            Text(
                "Un prompt per ogni cosa",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun SectionCard(
    index: Int,
    s: Section,
    onOpen: (Section) -> Unit,
    onDelete: (Section) -> Unit,
    onTogglePin: (Section) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var visible by rememberSaveable(s.id) { mutableStateOf(false) }
    LaunchedEffect(s.id) {
        if (!visible) delay(index * 70L)
        visible = true
    }
    val (bg, fg) = when (index % 3) {
        0 -> cs.primaryContainer to cs.onPrimaryContainer
        1 -> cs.secondaryContainer to cs.onSecondaryContainer
        else -> cs.tertiaryContainer to cs.onTertiaryContainer
    }

    AnimatedVisibility(visible = visible, enter = fadeIn() + scaleIn(initialScale = 0.9f)) {
        Card(
            onClick = { onOpen(s) },
            modifier = Modifier.fillMaxWidth().height(160.dp),
            colors = CardDefaults.cardColors(containerColor = bg, contentColor = fg),
            shape = RoundedCornerShape(28.dp),
        ) {
            Box(Modifier.fillMaxSize().padding(16.dp)) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(fg.copy(alpha = 0.12f))
                        .align(Alignment.TopStart),
                    contentAlignment = Alignment.Center,
                ) { Text(s.emoji, fontSize = 24.sp) }

                Row(Modifier.align(Alignment.TopEnd)) {
                    IconButton(
                        onClick = { onTogglePin(s) },
                        modifier = Modifier.size(32.dp),
                    ) {
                        Icon(
                            if (s.pinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                            if (s.pinned) "Rimuovi pin" else "Fissa in alto",
                            Modifier.size(18.dp),
                        )
                    }
                    if (s.custom) {
                        IconButton(
                            onClick = { onDelete(s) },
                            modifier = Modifier.size(32.dp),
                        ) { Icon(Icons.Filled.Delete, "Elimina", Modifier.size(18.dp)) }
                    }
                }

                Column(Modifier.align(Alignment.BottomStart)) {
                    Text(s.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(
                        s.hint,
                        style = MaterialTheme.typography.bodySmall,
                        color = fg.copy(alpha = 0.75f),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}
