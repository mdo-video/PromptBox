package com.promptbox

import org.json.JSONArray
import org.json.JSONObject

/** Una scheda creata dall'utente (es. "Cantina"): funziona come Frigo e Dispensa, con ripiani, scadenze e avvisi. */
data class CustomTab(val id: String, val name: String, val options: PlaceConditions = PlaceConditions())

/**
 * Come sono disposte le schede in alto nell'area Casa: l'ordine scelto, le schede nascoste, i nomi cambiati e le schede create
 * dall'utente. I posti di base (Frigo, Dispensa, Congelati, Pulizie) e quelli creati dall'utente si possono modificare ed
 * eliminare (con i prodotti che contengono); i posti di base eliminati si ripristinano, vuoti, dal tasto +. Le altre schede
 * di base (Spesa, Riepilogo, Scontrini) si nascondono soltanto.
 *
 * L'oggetto non cambia mai: ogni modifica ne restituisce uno nuovo. Una scheda personalizzata usa il proprio [CustomTab.id]
 * sia come id della schermata sia come `place` dei suoi prodotti ([PantryItem.place]).
 */
class KitchenTabsConfig(
    /** L'ordine scelto (id). Gli id sconosciuti si ignorano e le schede che mancano vanno in coda: così le novità non si perdono. */
    val order: List<String> = emptyList(),
    val hidden: Set<String> = emptySet(),
    /** Nomi cambiati per le schede di base (le personalizzate tengono il nome in [custom]). */
    val names: Map<String, String> = emptyMap(),
    val custom: List<CustomTab> = emptyList(),
    /** Le opzioni (temperatura, sbrinamento...) scelte per i posti di base. */
    val baseOptions: Map<String, PlaceConditions> = emptyMap(),
    /** I posti di base eliminati (si ripristinano dal tasto +). */
    val removed: Set<String> = emptySet(),
) {
    private fun copy(
        order: List<String> = this.order,
        hidden: Set<String> = this.hidden,
        names: Map<String, String> = this.names,
        custom: List<CustomTab> = this.custom,
        baseOptions: Map<String, PlaceConditions> = this.baseOptions,
        removed: Set<String> = this.removed,
    ) = KitchenTabsConfig(order, hidden, names, custom, baseOptions, removed)

    fun isCustom(id: String): Boolean = custom.any { it.id == id }

    /** Le opzioni (temperatura, umidità, spazio, sbrinamento...) di un posto; vuote se non ne ha. */
    fun conditions(id: String): PlaceConditions = custom.firstOrNull { it.id == id }?.options ?: baseOptions[id] ?: PlaceConditions()

    /** È un posto dove si tengono le cose (non Spesa, Riepilogo, Scontrini)? */
    fun isPlace(id: String): Boolean = id in PLACE_TABS || isCustom(id)

    /** Che tipo di posto è: quello scelto, altrimenti quello del nome (per i posti di base, quello di fabbrica). */
    fun kindOf(id: String): PlaceKind? {
        conditions(id).placeKind()?.let { return it }
        if (!isCustom(id)) {
            when (id) {
                "frigo" -> return PlaceKind.FRIDGE
                "congelatore" -> return PlaceKind.FREEZER
                "dispensa" -> return PlaceKind.PANTRY
                "casa" -> return PlaceKind.CLEANING
            }
        }
        return PlaceKind.guess(label(id))
    }

    /** Il posto è un congelatore (quello di base o una scheda tipo "Congelatore 2")? */
    fun isFreezer(id: String): Boolean = kindOf(id) == PlaceKind.FREEZER

    /** Il frigo dove vanno i prodotti scongelati: quello di base, altrimenti la prima scheda-frigo. null = non c'è nessun frigo. */
    fun fridgePlace(): String? = if ("frigo" in all()) "frigo" else custom.firstOrNull { kindOf(it.id) == PlaceKind.FRIDGE }?.id

    /**
     * La scheda "Cosa ci cucino?" si mostra in questo posto? Vale la scelta fatta; per le schede create prima che esistesse
     * (nessuna scelta) si decide dal nome, così un "Garage" già creato non propone ricette.
     */
    fun cooks(id: String): Boolean = conditions(id).cook ?: kindOf(id)?.let { PlaceConditions.forKind(it).cook } ?: true

    /** Cambia le opzioni o le letture di un posto (di base o creato dall'utente). Le altre schede non hanno opzioni. */
    fun withConditions(id: String, options: PlaceConditions): KitchenTabsConfig = when {
        isCustom(id) -> copy(custom = custom.map { if (it.id == id) it.copy(options = options) else it })
        id in PLACE_TABS -> copy(baseOptions = if (options.isEmpty()) baseOptions - id else baseOptions + (id to options))
        else -> this
    }

    fun isKnown(id: String): Boolean = id in KITCHEN_AREA || isCustom(id)

    /** I posti di base eliminati, nell'ordine di fabbrica: si possono ripristinare. */
    fun removedTabs(): List<String> = KITCHEN_TABS.map { it.first }.filter { it in removed }

    /** Il posto si può eliminare? Quelli creati dall'utente sì; di base solo Frigo, Dispensa, Congelati e Pulizie. Almeno una scheda resta. */
    fun canDelete(id: String): Boolean = (isCustom(id) || (id in PLACE_TABS && id in all())) && (id in hidden || visible().size > 1)

    /** Rimette un posto di base eliminato (vuoto, con il suo nome di fabbrica). */
    fun restore(id: String): KitchenTabsConfig = if (id in removed) copy(removed = removed - id) else this

    /** Tutte le schede, nascoste comprese, nell'ordine scelto. */
    fun all(): List<String> {
        val known = KITCHEN_TABS.map { it.first }.filter { it !in removed } + custom.map { it.id }
        val placed = order.filter { it in known }.distinct()
        return placed + known.filter { it !in placed }
    }

    fun visible(): List<String> = all().filter { it !in hidden }

    fun hiddenTabs(): List<String> = all().filter { it in hidden }

    /** Le schede da mostrare nella riga: quelle visibili, più quella aperta adesso anche se nascosta (ci si può arrivare da un avviso). */
    fun shown(current: String): List<String> = all().filter { it !in hidden || it == current }

    fun label(id: String): String =
        custom.firstOrNull { it.id == id }?.name
            ?: names[id]?.takeIf { it.isNotBlank() }
            ?: KITCHEN_TABS.firstOrNull { it.first == id }?.second
            ?: id

    /** Il nome scelto dall'utente per un posto, o null se ha ancora quello di fabbrica. */
    fun renamed(id: String): String? =
        custom.firstOrNull { it.id == id }?.name ?: names[id]?.takeIf { it.isNotBlank() }

    /** La scheda da aprire partendo da [wanted] (l'ultima aperta): se non c'è più o è nascosta, la prima visibile. */
    fun startTab(wanted: String): String = if (wanted in visible()) wanted else visible().firstOrNull() ?: "shopping"

    // ── Modifiche ───────────────────────────────────────────────────────────────────────────────────────────────

    /** Il nome va bene? "" = sì. [id] = la scheda che si sta rinominando (null = una nuova). Per le schede di base il nome vuoto vale "come prima". */
    fun nameError(name: String, id: String?): String {
        val n = name.trim()
        if (n.isEmpty()) return if (id != null && !isCustom(id)) "" else "Scrivi un nome"
        if (n.length > MAX_NAME) return "Al massimo $MAX_NAME lettere"
        val clash = all().any { it != id && label(it).equals(n, ignoreCase = true) }
        return if (clash) "C'è già una scheda con questo nome" else ""
    }

    fun rename(id: String, name: String): KitchenTabsConfig {
        if (id !in all() || nameError(name, id).isNotEmpty()) return this
        val n = name.trim()
        if (isCustom(id)) return copy(custom = custom.map { if (it.id == id) it.copy(name = n) else it })
        val original = KITCHEN_TABS.first { it.first == id }.second
        return if (n.isEmpty() || n == original) copy(names = names - id) else copy(names = names + (id to n))
    }

    fun canMove(id: String, delta: Int): Boolean {
        val v = visible()
        val i = v.indexOf(id)
        return i >= 0 && (i + delta) in v.indices
    }

    /** Sposta di un posto tra le schede visibili (le nascoste restano dove sono). */
    fun move(id: String, delta: Int): KitchenTabsConfig {
        if (!canMove(id, delta)) return this
        val v = visible()
        val other = v[v.indexOf(id) + delta]
        val full = all().toMutableList()
        val a = full.indexOf(id)
        val b = full.indexOf(other)
        full[a] = other
        full[b] = id
        return copy(order = full)
    }

    /** Almeno una scheda deve restare visibile. */
    fun canHide(id: String): Boolean = id in visible() && visible().size > 1

    fun hide(id: String): KitchenTabsConfig = if (canHide(id)) copy(hidden = hidden + id) else this

    fun show(id: String): KitchenTabsConfig = if (id in hidden) copy(hidden = hidden - id) else this

    /** Aggiunge una scheda personalizzata in fondo. Nome non valido: null. */
    fun add(name: String, now: Long = System.currentTimeMillis(), options: PlaceConditions = PlaceConditions()): Pair<KitchenTabsConfig, CustomTab>? {
        if (nameError(name, null).isNotEmpty()) return null
        var id = "u_" + java.lang.Long.toString(now, 36)
        var n = 1
        while (isKnown(id)) id = "u_" + java.lang.Long.toString(now, 36) + (n++)
        val tab = CustomTab(id, name.trim(), options)
        return copy(custom = custom + tab, order = all() + id) to tab
    }

    /** Elimina un posto (creato dall'utente, o di base come Frigo e Dispensa); Spesa, Riepilogo e Scontrini si nascondono soltanto. I suoi prodotti li toglie chi chiama. */
    fun delete(id: String): KitchenTabsConfig = when {
        isCustom(id) -> copy(custom = custom.filter { it.id != id }, order = order - id, hidden = hidden - id)
        canDelete(id) -> copy(removed = removed + id, order = order - id, hidden = hidden - id, names = names - id, baseOptions = baseOptions - id)
        else -> this
    }

    // ── Salvataggio ─────────────────────────────────────────────────────────────────────────────────────────────

    /** Testo da salvare; vuoto se è tutto com'era di fabbrica. */
    fun toJson(): String {
        if (order.isEmpty() && hidden.isEmpty() && names.isEmpty() && custom.isEmpty() && baseOptions.isEmpty() && removed.isEmpty()) return ""
        val o = JSONObject()
        if (order.isNotEmpty()) o.put("o", JSONArray(order))
        if (hidden.isNotEmpty()) o.put("h", JSONArray(hidden.toList()))
        if (names.isNotEmpty()) {
            val n = JSONObject()
            names.forEach { (k, v) -> n.put(k, v) }
            o.put("n", n)
        }
        if (custom.isNotEmpty()) {
            val arr = JSONArray()
            custom.forEach { t ->
                val c = JSONObject().put("i", t.id).put("n", t.name)
                if (!t.options.isEmpty()) c.put("o", t.options.toJson())
                arr.put(c)
            }
            o.put("c", arr)
        }
        if (baseOptions.isNotEmpty()) {
            val b = JSONObject()
            baseOptions.forEach { (k, v) -> if (!v.isEmpty()) b.put(k, v.toJson()) }
            o.put("b", b)
        }
        if (removed.isNotEmpty()) o.put("r", JSONArray(removed.toList()))
        return o.toString()
    }

    companion object {
        const val MAX_NAME = 20

        /** I posti di base: si modificano e si eliminano come quelli creati dall'utente. */
        val PLACE_TABS: Set<String> = setOf("frigo", "dispensa", "congelatore", "casa")

        /** Legge le impostazioni salvate; se il testo è rovinato o vuoto restano quelle di fabbrica. */
        fun parse(json: String): KitchenTabsConfig {
            if (json.isBlank()) return KitchenTabsConfig()
            return try {
                val o = JSONObject(json)
                fun strings(key: String): List<String> =
                    o.optJSONArray(key)?.let { a -> (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() } } ?: emptyList()
                val custom = o.optJSONArray("c")?.let { a ->
                    (0 until a.length()).mapNotNull { i ->
                        val t = a.optJSONObject(i) ?: return@mapNotNull null
                        val id = t.optString("i").trim()
                        val name = t.optString("n").trim().take(MAX_NAME)
                        if (id.isEmpty() || name.isEmpty() || id in KITCHEN_AREA) null else CustomTab(id, name, PlaceConditions.parse(t.optJSONObject("o")))
                    }.distinctBy { it.id }
                } ?: emptyList()
                val names = o.optJSONObject("n")?.let { n ->
                    n.keys().asSequence()
                        .filter { it in KITCHEN_AREA }
                        .associateWith { n.optString(it).trim().take(MAX_NAME) }
                        .filterValues { it.isNotEmpty() }
                } ?: emptyMap()
                val base = o.optJSONObject("b")?.let { b ->
                    b.keys().asSequence().filter { it in PLACE_TABS }.associateWith { PlaceConditions.parse(b.optJSONObject(it)) }.filterValues { !it.isEmpty() }
                } ?: emptyMap()
                val removed = strings("r").filter { it in PLACE_TABS }.toSet()
                KitchenTabsConfig(strings("o"), strings("h").toSet(), names, custom, base, removed)
            } catch (e: Exception) {
                KitchenTabsConfig()
            }
        }
    }
}

/**
 * Le schede di Casa come le ha disposte l'utente. Le imposta [Store] (come [Pantry.config]); le funzioni di [Pantry]
 * (ripiani, scadenze) e le schermate leggono da qui il nome e il tipo di un posto.
 */
object KitchenTabs {
    @Volatile
    var config: KitchenTabsConfig = KitchenTabsConfig()

    /** Il posto è una scheda creata dall'utente? */
    fun isCustom(place: String): Boolean = config.isCustom(place)

    fun label(place: String): String = config.label(place)

    /** Il nome scelto dall'utente per un posto, o null se ha ancora quello di fabbrica. */
    fun renamed(place: String): String? = config.renamed(place)
}
