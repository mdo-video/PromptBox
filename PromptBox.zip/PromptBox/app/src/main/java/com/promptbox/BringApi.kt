package com.promptbox

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

/**
 * Invia prodotti alla lista di Bring! (la lista predefinita dell'account).
 * Bring non ha un'API pubblica: si usano gli stessi indirizzi delle librerie della community
 * (stessi della app Bring e dell'integrazione di Home Assistant), quindi potrebbe smettere di funzionare se Bring li cambia.
 * Serve email e password di Bring: chi entra con Google o Apple può crearla da Profilo > Altre impostazioni > Cambia password.
 */
object BringApi {
    class AuthFailed : Exception("Email o password di Bring non corrette")

    private const val BASE = "https://api.getbring.com/rest/v2/"
    private const val KEY = "cof4Nc6D8saplXjE3h3HXqHH8m7VU2i1Gs0g85Sp"

    private class Resp(val code: Int, val body: String)

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun request(
        method: String,
        path: String,
        uuid: String?,
        token: String?,
        body: String?,
        contentType: String?,
    ): Resp {
        val c = URL(BASE + path).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 20_000
            c.readTimeout = 30_000
            c.setRequestProperty("X-BRING-API-KEY", KEY)
            c.setRequestProperty("X-BRING-CLIENT", "webApp")
            c.setRequestProperty("X-BRING-CLIENT-SOURCE", "webApp")
            c.setRequestProperty("X-BRING-COUNTRY", "IT")
            if (uuid != null) c.setRequestProperty("X-BRING-USER-UUID", uuid)
            if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", contentType ?: "application/json; charset=UTF-8")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            return Resp(code, text)
        } finally {
            c.disconnect()
        }
    }

    /** Aggiunge i prodotti alla lista predefinita di Bring. Restituisce quanti ne ha inviati. */
    suspend fun addItems(email: String, password: String, names: List<String>): Result<Int> =
        withContext(Dispatchers.IO) {
            runCatching {
                val clean = names.map { it.trim() }.filter { it.isNotEmpty() }
                if (clean.isEmpty()) return@runCatching 0

                val login = request(
                    "POST", "bringauth", null, null,
                    "email=${enc(email.trim())}&password=${enc(password)}",
                    "application/x-www-form-urlencoded; charset=UTF-8",
                )
                if (login.code in 400..403) throw AuthFailed()
                if (login.code !in 200..299) throw IOException("Bring ha risposto ${login.code}")
                val auth = JSONObject(login.body)
                val uuid = auth.getString("uuid")
                val token = auth.getString("access_token")

                var listUuid = auth.optString("bringListUUID")
                if (listUuid.isBlank()) {
                    val lists = request("GET", "bringusers/$uuid/lists", uuid, token, null, null)
                    if (lists.code in 200..299) {
                        val arr = JSONObject(lists.body).optJSONArray("lists")
                        if (arr != null && arr.length() > 0) listUuid = arr.getJSONObject(0).optString("listUuid")
                    }
                }
                if (listUuid.isBlank()) throw IOException("Non trovo nessuna lista in Bring")

                // Come fa la app: un solo invio con tutte le modifiche.
                val changes = JSONArray()
                clean.forEach {
                    changes.put(
                        JSONObject().put("itemId", it).put("spec", "")
                            .put("uuid", UUID.randomUUID().toString()).put("operation", "TO_PURCHASE"),
                    )
                }
                val batch = request(
                    "PUT", "bringlists/$listUuid/items", uuid, token,
                    JSONObject().put("changes", changes).put("sender", "").toString(),
                    "application/json; charset=UTF-8",
                )
                if (batch.code !in 200..299) {
                    // Se l'invio unico non va, si prova il metodo più vecchio: un prodotto alla volta.
                    clean.forEach { name ->
                        val r = request(
                            "PUT", "bringlists/$listUuid", uuid, token,
                            "purchase=${enc(name)}&recently=&specification=&remove=&sender=null",
                            "application/x-www-form-urlencoded; charset=UTF-8",
                        )
                        if (r.code !in 200..299) throw IOException("Bring ha risposto ${r.code}")
                    }
                }
                clean.size
            }
        }
}
