package com.promptbox

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

/**
 * La chiave API è salvata cifrata sul dispositivo (EncryptedSharedPreferences).
 * Non è mai scritta nel codice né nell'APK.
 */
class Store(context: Context) {

    private val secure: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "promptbox_secure",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )
    private val plain: SharedPreferences =
        context.getSharedPreferences("promptbox_plain", Context.MODE_PRIVATE)

    var apiKey: String
        get() = secure.getString("api_key", "") ?: ""
        set(value) = secure.edit().putString("api_key", value.trim()).apply()

    /** "Su di me": obiettivi, allergie, preferenze. Cifrato, resta sul telefono (non si sincronizza). */
    var profile: String
        get() = secure.getString("profile", "") ?: ""
        set(value) = secure.edit().putString("profile", value.trim()).apply()

    /** Ultima voce del changelog vista: serve al pallino "novità" in Home. */
    var seenChangelog: Int
        get() = plain.getInt("seen_changelog", 0)
        set(value) = plain.edit().putInt("seen_changelog", value).apply()

    var model: String
        get() = plain.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(value) = plain.edit().putString("model", value.trim().ifBlank { DEFAULT_MODEL }).apply()

    /** Conversazione attiva per una sezione: se spenta, ogni messaggio è una richiesta nuova, senza memoria dei precedenti. */
    fun chatEnabled(sectionId: String): Boolean = plain.getBoolean("chat_enabled_$sectionId", true)

    fun setChatEnabled(sectionId: String, value: Boolean) =
        plain.edit().putBoolean("chat_enabled_$sectionId", value).apply()

    /** Colori dinamici (Material You), solo Android 12 o più recente. */
    var dynamic: Boolean
        get() = plain.getBoolean("dynamic", false)
        set(value) = plain.edit().putBoolean("dynamic", value).apply()

    /** Id delle sezioni pinnate (valido per sezioni fisse e personalizzate). */
    var pinned: Set<String>
        get() = plain.getStringSet("pinned", emptySet())?.toSet() ?: emptySet()
        set(value) = plain.edit().putStringSet("pinned", value).apply()

    fun customSections(): List<Section> {
        val raw = plain.getString("custom_sections", "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Section(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    emoji = o.optString("emoji", "📌").ifBlank { "📌" },
                    hint = "Foto e/o testo",
                    systemPrompt = o.getString("prompt"),
                    custom = true,
                )
            }
        }.getOrDefault(emptyList())
    }

    /**
     * Tutte le sezioni (anche quelle di partenza) vivono qui, così sono tutte modificabili ed eliminabili.
     * Alla prima apertura le sezioni fisse del codice e quelle create in precedenza vengono copiate qui.
     */
    fun loadSections(): List<Section> {
        val raw = plain.getString("sections_v2", null)
        if (raw == null) {
            val seeded = DefaultSections.all + customSections()
            saveSections(seeded)
            return seeded
        }
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Section(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    emoji = o.optString("emoji", "📌").ifBlank { "📌" },
                    hint = o.optString("hint", "Foto e/o testo"),
                    systemPrompt = o.getString("prompt"),
                    updatedAt = o.optLong("u", 0L),
                )
            }
        }.getOrDefault(emptyList())
    }

    fun saveSections(list: List<Section>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("title", it.title).put("emoji", it.emoji)
                    .put("hint", it.hint).put("prompt", it.systemPrompt).put("u", it.updatedAt),
            )
        }
        plain.edit().putString("sections_v2", arr.toString()).apply()
    }

    fun saveCustomSections(list: List<Section>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("title", it.title).put("prompt", it.systemPrompt).put("emoji", it.emoji))
        }
        plain.edit().putString("custom_sections", arr.toString()).apply()
    }

    /** Sincronizzazione con l'account Google. */
    var syncOn: Boolean
        get() = plain.getBoolean("sync_on", false)
        set(value) = plain.edit().putBoolean("sync_on", value).apply()

    var syncEmail: String
        get() = plain.getString("sync_email", "") ?: ""
        set(value) = plain.edit().putString("sync_email", value).apply()

    var lastSync: Long
        get() = plain.getLong("last_sync", 0L)
        set(value) = plain.edit().putLong("last_sync", value).apply()

    /** Sezioni eliminate (id -> quando): servono perché l'eliminazione si propaghi agli altri telefoni. */
    fun deletedSections(): Map<String, Long> {
        val raw = plain.getString("deleted_sections", null) ?: return emptyMap()
        return runCatching {
            val o = JSONObject(raw)
            o.keys().asSequence().associateWith { o.getLong(it) }
        }.getOrDefault(emptyMap())
    }

    fun setDeletedSections(map: Map<String, Long>) {
        val o = JSONObject()
        map.forEach { (k, v) -> o.put(k, v) }
        plain.edit().putString("deleted_sections", o.toString()).apply()
    }

    /** Conversazione di una sezione (solo testo: le foto non vengono salvate). */
    fun loadChat(sectionId: String): List<ChatTurn> {
        val raw = plain.getString("chat_$sectionId", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ChatTurn(
                    fromUser = o.getBoolean("u"),
                    text = o.optString("t"),
                    image = null,
                    hadImage = o.optBoolean("i", false),
                )
            }
        }.getOrDefault(emptyList())
    }

    fun saveChat(sectionId: String, turns: List<ChatTurn>) {
        if (turns.isEmpty()) {
            plain.edit().remove("chat_$sectionId").apply()
            return
        }
        val arr = JSONArray()
        turns.takeLast(MAX_TURNS).forEach {
            arr.put(JSONObject().put("u", it.fromUser).put("t", it.text).put("i", it.hadImage))
        }
        plain.edit().putString("chat_$sectionId", arr.toString()).apply()
    }

    companion object {
        // Modello del free tier. Si può cambiare dalle Impostazioni se Google lo sostituisce.
        const val DEFAULT_MODEL = "gemini-3.1-flash-lite"
        private const val MAX_TURNS = 40
    }
}
