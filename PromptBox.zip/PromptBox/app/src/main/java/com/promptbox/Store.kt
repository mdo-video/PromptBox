package com.promptbox

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

/**
 * La chiave API è salvata cifrata sul dispositivo (EncryptedSharedPreferences).
 * Non è mai scritta nel codice né nell'APK.
 */
class Store(context: Context) {

    private val secure: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "promptbox_secure",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )
    private val plain: SharedPreferences =
        context.getSharedPreferences("promptbox_plain", Context.MODE_PRIVATE)

    var apiKey: String
        get() = secure.getString("api_key", "") ?: ""
        set(value) = secure.edit().putString("api_key", value.trim()).apply()

    var model: String
        get() = plain.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(value) = plain.edit().putString("model", value.trim().ifBlank { DEFAULT_MODEL }).apply()

    /** Colori dinamici (Material You), solo Android 12 o più recente. */
    var dynamic: Boolean
        get() = plain.getBoolean("dynamic", false)
        set(value) = plain.edit().putBoolean("dynamic", value).apply()

    fun customSections(): List<Section> {
        val raw = plain.getString("custom_sections", "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Section(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    emoji = "📌",
                    hint = "Foto e/o testo",
                    systemPrompt = o.getString("prompt"),
                    custom = true,
                )
            }
        }.getOrDefault(emptyList())
    }

    fun saveCustomSections(list: List<Section>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("title", it.title).put("prompt", it.systemPrompt))
        }
        plain.edit().putString("custom_sections", arr.toString()).apply()
    }

    companion object {
        // Modello del free tier. Si può cambiare dalle Impostazioni se Google lo sostituisce.
        const val DEFAULT_MODEL = "gemini-3.1-flash-lite"
    }
}
