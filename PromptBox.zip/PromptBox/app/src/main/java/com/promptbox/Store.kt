package com.promptbox

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import java.io.File
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

/**
 * La chiave API è salvata cifrata sul dispositivo (EncryptedSharedPreferences).
 * Non è mai scritta nel codice né nell'APK.
 */
class Store(context: Context) {

    private val appContext: Context = context.applicationContext

    // Pigro: l'archivio cifrato è lento da aprire e serve solo per la chiave API, non per gli allarmi e le notifiche.
    private val secure: SharedPreferences by lazy {
        EncryptedSharedPreferences.create(
            context,
            "promptbox_secure",
            MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }
    private val plain: SharedPreferences =
        context.getSharedPreferences("promptbox_plain", Context.MODE_PRIVATE)

    init {
        migrateChatsToSecure()
    }

    /** Le conversazioni (bollette, documenti, domande personali) ora stanno nella memoria cifrata, come la chiave API. */
    private fun isChatKey(k: String) = k == "chat_archive" || (k.startsWith("chat_") && !k.startsWith("chat_enabled_"))

    /** Una volta sola: sposta le chat già salvate in chiaro nella memoria cifrata. */
    private fun migrateChatsToSecure() {
        if (plain.getBoolean("chats_enc_v1", false)) return
        val old = plain.all.filter { (k, v) -> isChatKey(k) && v is String }
        if (old.isNotEmpty()) {
            val se = secure.edit()
            old.forEach { (k, v) -> se.putString(k, v as String) }
            // Si toglie il testo in chiaro solo se la copia cifrata è stata scritta davvero.
            if (!se.commit()) return
            val pe = plain.edit()
            old.keys.forEach { pe.remove(it) }
            pe.putBoolean("chats_enc_v1", true).apply()
        } else {
            plain.edit().putBoolean("chats_enc_v1", true).apply()
        }
    }

    /** Quando le impostazioni condivise tra dispositivi sono state cambiate l'ultima volta (serve alla sincronizzazione). */
    val settingsAt: Long get() = plain.getLong("settings_at", 0L)

    /** Registra la data delle impostazioni senza cambiarle (primo invio a Drive). */
    fun markSettings(at: Long) {
        plain.edit().putLong("settings_at", at).apply()
    }

    private fun touch() {
        plain.edit().putLong("settings_at", System.currentTimeMillis()).apply()
    }

    // --- PIN per mostrare/copiare la chiave API (si specchia tra i dispositivi insieme alle impostazioni) ---
    private var pinHash: String
        get() = secure.getString("pin_hash", "") ?: ""
        set(value) = secure.edit().putString("pin_hash", value).apply()

    private var pinSalt: String
        get() = secure.getString("pin_salt", "") ?: ""
        set(value) = secure.edit().putString("pin_salt", value).apply()

    val hasPin: Boolean get() = pinHash.isNotEmpty() && pinSalt.isNotEmpty()

    private fun hashPin(pin: String, salt: ByteArray): String {
        val spec = javax.crypto.spec.PBEKeySpec(pin.toCharArray(), salt, 60_000, 256)
        val h = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return android.util.Base64.encodeToString(h, android.util.Base64.NO_WRAP)
    }

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { java.security.SecureRandom().nextBytes(it) }
        pinSalt = android.util.Base64.encodeToString(salt, android.util.Base64.NO_WRAP)
        pinHash = hashPin(pin, salt)
        plain.edit().putInt("pin_fails", 0).putLong("pin_lock_until", 0L).apply()
        touch()
    }

    /** Secondi da aspettare prima di riprovare (dopo 5 PIN sbagliati di fila), 0 se si può provare. */
    fun pinLockSeconds(): Int {
        val left = plain.getLong("pin_lock_until", 0L) - System.currentTimeMillis()
        return if (left > 0) (left / 1000 + 1).toInt() else 0
    }

    fun checkPin(pin: String): Boolean {
        if (!hasPin || pinLockSeconds() > 0) return false
        val salt = android.util.Base64.decode(pinSalt, android.util.Base64.NO_WRAP)
        val ok = hashPin(pin, salt) == pinHash
        val e = plain.edit()
        if (ok) {
            e.putInt("pin_fails", 0).putLong("pin_lock_until", 0L)
        } else {
            val fails = plain.getInt("pin_fails", 0) + 1
            if (fails >= 5) e.putInt("pin_fails", 0).putLong("pin_lock_until", System.currentTimeMillis() + 60_000L)
            else e.putInt("pin_fails", fails)
        }
        e.apply()
        return ok
    }

    var apiKey: String
        get() = secure.getString("api_key", "") ?: ""
        set(value) {
            // Cambiare la chiave conta come modifica delle impostazioni: così viaggia sugli altri dispositivi.
            if (value.trim() != apiKey) { secure.edit().putString("api_key", value.trim()).apply(); touch() }
        }

    /** Accesso a Bring! (cifrato sul telefono) per mandare la lista della spesa. */
    var bringEmail: String
        get() = secure.getString("bring_email", "") ?: ""
        set(value) { if (value.trim() != bringEmail) { secure.edit().putString("bring_email", value.trim()).apply(); touch() } }

    /** Lista Bring scelta per ogni reparto: JSON {"Carne e pesce":"<codice lista>", ...}. "-" = non mandare. */
    var bringDeptLists: Map<String, String>
        get() = runCatching {
            val o = org.json.JSONObject(secure.getString("bring_dept_lists", "{}") ?: "{}")
            o.keys().asSequence().associateWith { o.getString(it) }
        }.getOrDefault(emptyMap())
        set(value) { if (value != bringDeptLists) { secure.edit().putString("bring_dept_lists", org.json.JSONObject(value).toString()).apply(); touch() } }

    /** Nomi delle liste Bring viste l'ultima volta ({codice lista: nome}): servono a mostrare "Carne e pesce → Macelleria" senza rete. */
    var bringListNames: Map<String, String>
        get() = runCatching {
            val o = org.json.JSONObject(secure.getString("bring_list_names", "{}") ?: "{}")
            o.keys().asSequence().associateWith { o.getString(it) }
        }.getOrDefault(emptyMap())
        set(value) { if (value != bringListNames) { secure.edit().putString("bring_list_names", org.json.JSONObject(value).toString()).apply(); touch() } }

    var bringPassword: String
        get() = secure.getString("bring_password", "") ?: ""
        set(value) { if (value != bringPassword) { secure.edit().putString("bring_password", value).apply(); touch() } }

    /** "Su di me": obiettivi, allergie, preferenze. Cifrato sul telefono; si sincronizza solo se lo attivi. */
    var profile: String
        get() = secure.getString("profile", "") ?: ""
        set(value) {
            val v = value.trim()
            if (v != profile) {
                secure.edit().putString("profile", v).apply()
                plain.edit().putLong("profile_at", System.currentTimeMillis()).apply()
            }
        }

    /** Quando "Su di me" è stato modificato l'ultima volta (serve alla sincronizzazione). */
    val profileAt: Long get() = plain.getLong("profile_at", 0L)

    /** Applica "Su di me" arrivato da un altro dispositivo, senza segnarlo come modifica locale. */
    fun applyRemoteProfile(text: String, at: Long) {
        secure.edit().putString("profile", text.trim()).apply()
        plain.edit().putLong("profile_at", at).apply()
    }

    /** Sincronizza anche "Su di me" (spento di default). */
    var syncProfile: Boolean
        get() = plain.getBoolean("sync_profile", false)
        set(value) = plain.edit().putBoolean("sync_profile", value).apply()

    /** Tema: 0 automatico (segue il telefono), 1 chiaro, 2 scuro. */
    var theme: Int
        get() = plain.getInt("theme", 0)
        set(value) { if (value.coerceIn(0, 2) != theme) { plain.edit().putInt("theme", value.coerceIn(0, 2)).apply(); touch() } }

    /** Ultima voce del changelog vista: serve al pallino "novità" in Home. */
    var seenChangelog: Int
        get() = plain.getInt("seen_changelog", 0)
        set(value) = plain.edit().putInt("seen_changelog", value).apply()

    /** Lunghezza delle risposte: 0 breve, 1 normale, 2 dettagliata. */
    var length: Int
        get() = plain.getInt("answer_length", 1)
        set(value) { if (value.coerceIn(0, 2) != length) { plain.edit().putInt("answer_length", value.coerceIn(0, 2)).apply(); touch() } }

    /** Se il modello scelto non risponde o ha finito le richieste, prova un altro modello gratuito. */
    var fallback: Boolean
        get() = plain.getBoolean("model_fallback", true)
        set(value) { if (value != fallback) { plain.edit().putBoolean("model_fallback", value).apply(); touch() } }

    private fun today(): String =
        java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())

    /** Richieste all'AI fatte oggi (conta le risposte arrivate nelle sezioni). */
    fun requestsToday(): Int =
        if (plain.getString("req_day", "") == today()) plain.getInt("req_count", 0) else 0

    fun countRequest() {
        plain.edit().putString("req_day", today()).putInt("req_count", requestsToday() + 1).apply()
    }

    // --- Blocchi sincronizzati per intero: frigo/dispensa, scontrini, routine (con avviso di scadenza), campi guidati ---
    // Ognuno ha la sua data di ultima modifica ("blk_<nome>_at"): in Sync.kt vince il blocco modificato più di recente.

    /** Contenuto di un blocco come testo JSON (lo stesso che si salva su Drive e nel backup). */
    fun blockData(name: String): String = when (name) {
        "pantry" -> plain.getString("pantry", "[]") ?: "[]"
        "receipts" -> plain.getString("receipts", "[]") ?: "[]"
        "waste" -> plain.getString("waste", "[]") ?: "[]"
        "memory" -> plain.getString("memory", "[]") ?: "[]"
        "routines" -> JSONObject()
            .put("r", plain.getString("routines", "[]") ?: "[]")
            .put("x", plain.getBoolean("expiry_notify", false))
            .put("ft", plain.getInt("freezer_temp", Freezer.DEFAULT_TEMP))
            .put("pc", plain.getString("pantry_config", "") ?: "")
            .put("kt", plain.getString("kitchen_tabs", "") ?: "")
            .toString()
        "guided" -> JSONObject().also { o ->
            plain.all.forEach { (k, v) -> if ((k.startsWith("gf_") || k.startsWith("gv_")) && v is String) o.put(k, v) }
        }.toString()
        "chats" -> chatsBlockJson()
        "docs" -> docsBlockJson()
        else -> ""
    }

    /** Chat di ogni sezione e archivio chat (stanno nella memoria cifrata; su Drive vanno solo nella cartella privata dell'app). */
    private fun chatsBlockJson(): String {
        val cur = JSONObject()
        secure.all.forEach { (k, v) ->
            if (k.startsWith("chat_") && k != "chat_archive" && v is String) cur.put(k.removePrefix("chat_"), v)
        }
        return JSONObject().put("cur", cur).put("arch", secure.getString("chat_archive", "[]") ?: "[]").toString()
    }

    /** Archivio documenti per sezione (con i PDF fino a 1 MB), interruttori "archivio" e "chat" di ogni sezione. */
    private fun docsBlockJson(): String {
        val items = JSONObject()
        val on = JSONObject()
        val chat = JSONObject()
        plain.all.forEach { (k, v) ->
            when {
                k.startsWith("docarchive_on_") && v is Boolean -> on.put(k.removePrefix("docarchive_on_"), v)
                k.startsWith("docarchive_") && v is String -> items.put(k.removePrefix("docarchive_"), withPdfs(v))
                k.startsWith("chat_enabled_") && v is Boolean -> chat.put(k.removePrefix("chat_enabled_"), v)
                else -> Unit
            }
        }
        return JSONObject().put("items", items).put("on", on).put("chat", chat).toString()
    }

    /** Aggiunge a ogni scheda archiviata il suo PDF (base64) se il file c'è e non supera 1 MB. */
    private fun withPdfs(raw: String): String = runCatching {
        val arr = JSONArray(raw)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val name = o.optString("file")
            if (name.isBlank()) continue
            val f = File(docDir(), name)
            if (f.exists() && f.length() <= MAX_SYNC_PDF) o.put("pdf", Base64.encodeToString(f.readBytes(), Base64.NO_WRAP))
        }
        arr.toString()
    }.getOrDefault(raw)

    private fun safePdfName(n: String) = n.matches(Regex("[A-Za-z0-9_-]+\\.pdf"))

    fun blockAt(name: String): Long = plain.getLong("blk_${name}_at", 0L)

    /** Segna il blocco come modificato adesso. */
    private fun touchBlock(name: String) {
        plain.edit().putLong("blk_${name}_at", System.currentTimeMillis()).apply()
    }

    /** Registra la data di un blocco senza cambiarne il contenuto (primo invio a Drive). */
    fun markBlock(name: String, at: Long) {
        plain.edit().putLong("blk_${name}_at", at).apply()
    }

    /** Applica un blocco arrivato da un altro dispositivo o da un backup, senza segnarlo come modifica locale. */
    fun applyBlock(name: String, json: String, at: Long) {
        val e = plain.edit()
        runCatching {
            when (name) {
                "pantry" -> { JSONArray(json); e.putString("pantry", json) }
                "receipts" -> { JSONArray(json); e.putString("receipts", json) }
                "waste" -> { JSONArray(json); e.putString("waste", json) }
                "memory" -> { JSONArray(json); e.putString("memory", json) }
                "routines" -> {
                    val o = JSONObject(json)
                    val r = o.optString("r", "[]")
                    JSONArray(r)
                    e.putString("routines", r).putBoolean("expiry_notify", o.optBoolean("x", false))
                        .putInt("freezer_temp", Freezer.clampTemp(o.optInt("ft", Freezer.DEFAULT_TEMP)))
                    // Da una versione più vecchia "pc" manca: le impostazioni dei posti restano quelle che ci sono.
                    if (o.has("pc")) {
                        val pc = o.optString("pc", "")
                        e.putString("pantry_config", pc)
                        Pantry.config = PantryConfig.parse(pc)
                    } else {
                        Unit
                    }
                    // Come sopra: da una versione più vecchia "kt" manca e le schede restano come sono.
                    if (o.has("kt")) {
                        val kt = o.optString("kt", "")
                        e.putString("kitchen_tabs", kt)
                        KitchenTabs.config = KitchenTabsConfig.parse(kt)
                    }
                }
                "guided" -> {
                    val o = JSONObject(json)
                    plain.all.keys.filter { it.startsWith("gf_") || it.startsWith("gv_") }.forEach { e.remove(it) }
                    o.keys().forEach { k -> if (k.startsWith("gf_") || k.startsWith("gv_")) e.putString(k, o.getString(k)) }
                }
                "chats" -> {
                    val o = JSONObject(json)
                    val arch = o.optString("arch", "[]")
                    JSONArray(arch)
                    val cur = o.optJSONObject("cur") ?: JSONObject()
                    cur.keys().forEach { k -> JSONArray(cur.getString(k)) }
                    val se = secure.edit()
                    secure.all.keys.filter { it.startsWith("chat_") && it != "chat_archive" }.forEach { se.remove(it) }
                    cur.keys().forEach { k -> se.putString("chat_$k", cur.getString(k)) }
                    se.putString("chat_archive", arch)
                    se.apply()
                }
                "docs" -> {
                    val o = JSONObject(json)
                    val items = o.optJSONObject("items") ?: JSONObject()
                    val on = o.optJSONObject("on") ?: JSONObject()
                    val chat = o.optJSONObject("chat") ?: JSONObject()
                    val cleaned = LinkedHashMap<String, String>()
                    val keep = HashSet<String>()
                    items.keys().forEach { k ->
                        val arr = JSONArray(items.getString(k))
                        for (i in 0 until arr.length()) {
                            val obj = arr.getJSONObject(i)
                            val file = obj.optString("file")
                            val pdf = obj.optString("pdf")
                            if (file.isNotBlank() && safePdfName(file)) {
                                keep += file
                                val f = File(docDir(), file)
                                if (pdf.isNotBlank() && !f.exists()) f.writeBytes(Base64.decode(pdf, Base64.NO_WRAP))
                            }
                            obj.remove("pdf")
                        }
                        cleaned[k] = arr.toString()
                    }
                    plain.all.keys.filter { it.startsWith("docarchive_") || it.startsWith("chat_enabled_") }.forEach { e.remove(it) }
                    cleaned.forEach { (k, v) -> e.putString("docarchive_$k", v) }
                    on.keys().forEach { k -> e.putBoolean("docarchive_on_$k", on.getBoolean(k)) }
                    chat.keys().forEach { k -> e.putBoolean("chat_enabled_$k", chat.getBoolean(k)) }
                    // I PDF di schede che non esistono più non servono più.
                    docDir().listFiles()?.forEach { f -> if (f.name !in keep) f.delete() }
                }
                else -> return
            }
        }.onFailure { return }
        e.putLong("blk_${name}_at", at).apply()
    }

    /** Campi guidati di una sezione e ultime scelte fatte (si sincronizzano tra i dispositivi). */
    fun guidedFields(sectionId: String): List<GuidedField> = GuidedFields.fromJson(plain.getString("gf_$sectionId", null))

    fun saveGuidedFields(sectionId: String, list: List<GuidedField>) {
        plain.edit().putString("gf_$sectionId", GuidedFields.toJson(list)).apply()
        touchBlock("guided")
    }

    fun guidedValues(sectionId: String): Map<String, String> = GuidedFields.valuesFromJson(plain.getString("gv_$sectionId", null))

    fun saveGuidedValues(sectionId: String, map: Map<String, String>) {
        plain.edit().putString("gv_$sectionId", GuidedFields.valuesToJson(map)).apply()
        touchBlock("guided")
    }

    /** Scontrini letti dall'AI. */
    fun receipts(): List<Receipt> = ReceiptTools.listFromJson(plain.getString("receipts", null))

    fun saveReceipts(list: List<Receipt>) {
        plain.edit().putString("receipts", ReceiptTools.listToJson(list)).apply()
        touchBlock("receipts")
    }

    /** Esegue un salvataggio fuori dal thread principale, uno alla volta e nell'ordine in cui sono stati chiesti. */
    fun inBackground(block: () -> Unit) {
        storeWriter.execute { runCatching(block) }
    }

    /** Routine programmate e avviso di scadenza. */
    fun routines(): List<Routine> = Reminders.listFromJson(plain.getString("routines", null))

    fun saveRoutines(list: List<Routine>) {
        plain.edit().putString("routines", Reminders.listToJson(list)).apply()
        touchBlock("routines")
    }

    /** Già chiesto se attivare l'avviso di scadenza (si sincronizza con le impostazioni: non lo richiede su ogni dispositivo). */
    var expiryAsked: Boolean
        get() = plain.getBoolean("expiry_asked", false)
        set(value) {
            if (value != expiryAsked) { plain.edit().putBoolean("expiry_asked", value).apply(); touch() }
        }

    var expiryNotify: Boolean
        get() = plain.getBoolean("expiry_notify", false)
        set(value) {
            plain.edit().putBoolean("expiry_notify", value).apply()
            touchBlock("routines")
        }

    /** Impostazioni dei posti: ripiani scelti, scadenze accese o spente, ripiano automatico, avvisi. Si sincronizzano con le routine. */
    var pantryConfig: PantryConfig
        get() = PantryConfig.parse(plain.getString("pantry_config", "") ?: "")
        set(value) {
            plain.edit().putString("pantry_config", value.toJson()).apply()
            Pantry.config = value
            touchBlock("routines")
        }

    /** Le schede in alto in Casa: ordine, nascoste, nomi e schede create dall'utente. Si sincronizzano con le routine. */
    var kitchenTabs: KitchenTabsConfig
        get() = KitchenTabsConfig.parse(plain.getString("kitchen_tabs", "") ?: "")
        set(value) {
            plain.edit().putString("kitchen_tabs", value.toJson()).apply()
            KitchenTabs.config = value
            touchBlock("routines")
        }

    init {
        // Le funzioni di Pantry (ripiani, scadenze) leggono le impostazioni da qui: vanno caricate subito, anche per gli avvisi in background.
        Pantry.config = pantryConfig
        KitchenTabs.config = kitchenTabs
    }

    /** Temperatura del congelatore in °C (di solito -18): la durata degli alimenti congelati si calcola su questa. Si sincronizza con le routine. */
    var freezerTemp: Int
        get() = plain.getInt("freezer_temp", Freezer.DEFAULT_TEMP)
        set(value) {
            plain.edit().putInt("freezer_temp", Freezer.clampTemp(value)).apply()
            touchBlock("routines")
        }

    /** Prodotti buttati perché scaduti (per contare quanto si spreca). */
    fun wasteEntries(): List<WasteEntry> = Learning.wasteFromJson(plain.getString("waste", null))

    fun saveWaste(list: List<WasteEntry>) {
        plain.edit().putString("waste", Learning.wasteToJson(list)).apply()
        touchBlock("waste")
    }

    /** Cosa l'app ha imparato dalle correzioni sui nomi degli scontrini. */
    fun productMemory(): List<ProductMemo> = Learning.memosFromJson(plain.getString("memory", null))

    fun saveProductMemory(list: List<ProductMemo>) {
        plain.edit().putString("memory", Learning.memosToJson(list)).apply()
        touchBlock("memory")
    }

    /** Frigo e dispensa. */
    fun pantryItems(): List<PantryItem> {
        val raw = plain.getString("pantry", "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                PantryItem(
                    id = o.getString("i"),
                    name = o.getString("n"),
                    place = o.optString("p", "frigo"),
                    shelf = o.optString("s", ""),
                    qty = o.optString("q", ""),
                    expiry = if (o.has("e")) o.getLong("e") else null,
                    addedAt = o.optLong("a", 0L),
                    estimated = o.optBoolean("g", false),
                    price = if (o.has("pr")) o.getDouble("pr") else null,
                    frozenAt = if (o.has("fz")) o.getLong("fz") else null,
                    lifeDays = if (o.has("ld")) o.getInt("ld") else null,
                )
            }
        }.getOrDefault(emptyList())
    }

    fun savePantry(list: List<PantryItem>) {
        val arr = JSONArray()
        list.forEach {
            val o = JSONObject().put("i", it.id).put("n", it.name).put("p", it.place).put("s", it.shelf).put("q", it.qty).put("a", it.addedAt)
            it.expiry?.let { e -> o.put("e", e) }
            if (it.estimated) o.put("g", true)
            it.price?.let { p -> o.put("pr", p) }
            it.frozenAt?.let { f -> o.put("fz", f) }
            it.lifeDays?.let { d -> o.put("ld", d) }
            arr.put(o)
        }
        plain.edit().putString("pantry", arr.toString()).apply()
        touchBlock("pantry")
    }

    /** Lista della spesa. */
    fun shoppingList(): List<ShopItem> {
        val raw = plain.getString("shopping", "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ShopItem(o.getString("t"), o.optBoolean("d", false), o.optLong("u", 0L), o.optString("p", ""))
            }
        }.getOrDefault(emptyList())
    }

    fun saveShopping(list: List<ShopItem>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("t", it.text).put("d", it.done).put("u", it.updatedAt).put("p", it.dept)) }
        plain.edit().putString("shopping", arr.toString()).apply()
    }

    /** Prodotti eliminati dalla lista (chiave -> quando): servono perché l'eliminazione arrivi agli altri dispositivi. */
    fun shoppingDeleted(): Map<String, Long> {
        val raw = plain.getString("shopping_deleted", null) ?: return emptyMap()
        return runCatching {
            val o = JSONObject(raw)
            o.keys().asSequence().associateWith { o.getLong(it) }
        }.getOrDefault(emptyMap())
    }

    fun setShoppingDeleted(map: Map<String, Long>) {
        val o = JSONObject()
        map.forEach { (k, v) -> o.put(k, v) }
        plain.edit().putString("shopping_deleted", o.toString()).apply()
    }

    /** Quante volte hai preso un prodotto (chiave minuscola -> conteggio): serve ai suggerimenti "ricomprare". */
    fun shoppingHistory(): Map<String, Int> {
        val raw = plain.getString("shopping_history", null) ?: return emptyMap()
        return runCatching {
            val o = JSONObject(raw)
            o.keys().asSequence().associateWith { o.getInt(it) }
        }.getOrDefault(emptyMap())
    }

    fun setShoppingHistory(map: Map<String, Int>) {
        val o = JSONObject()
        map.entries.sortedByDescending { it.value }.take(200).forEach { (k, v) -> o.put(k, v) }
        plain.edit().putString("shopping_history", o.toString()).apply()
    }

    var model: String
        get() = plain.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(value) {
            val v = value.trim().ifBlank { DEFAULT_MODEL }
            if (v != model) { plain.edit().putString("model", v).apply(); touch() }
        }

    /** Conversazione attiva per una sezione: se spenta, ogni messaggio è una richiesta nuova, senza memoria dei precedenti. */
    fun chatEnabled(sectionId: String): Boolean = plain.getBoolean("chat_enabled_$sectionId", true)

    // Archivio schede di una sezione (si sincronizza: blocco "docs").
    fun archiveOn(sectionId: String): Boolean = plain.getBoolean("docarchive_on_$sectionId", false)

    fun setArchiveOn(sectionId: String, value: Boolean) {
        plain.edit().putBoolean("docarchive_on_$sectionId", value).apply()
        touchBlock("docs")
    }

    fun docItems(sectionId: String): List<DocItem> {
        val raw = plain.getString("docarchive_$sectionId", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                DocItem(o.getLong("id"), o.getString("name"), o.getString("json"), o.optString("file").ifBlank { null })
            }
        }.getOrDefault(emptyList())
    }

    private fun saveDocItems(sectionId: String, items: List<DocItem>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("json", it.json).put("file", it.file ?: ""))
        }
        plain.edit().putString("docarchive_$sectionId", arr.toString()).apply()
        touchBlock("docs")
    }

    private fun docDir() = File(appContext.filesDir, "docarchive").apply { mkdirs() }

    /** Cartella dei PDF dell'archivio documenti (serve alla sincronizzazione dei PDF grandi). */
    fun docArchiveDir(): File = docDir()

    /** Il PDF salvato di una scheda (null se è stata archiviata solo con i dati). */
    fun docFile(item: DocItem): File? = item.file?.let { File(docDir(), it) }

    /** Aggiunge una scheda (con il PDF originale, se c'è); se ce n'è già una con lo stesso nome la sostituisce. */
    fun addDocItem(sectionId: String, name: String, json: String, pdf: ByteArray? = null) {
        val old = docItems(sectionId)
        old.filter { it.name == name }.forEach { docFile(it)?.delete() }
        val id = System.currentTimeMillis()
        val fileName = pdf?.let {
            val n = sectionId.replace(Regex("[^A-Za-z0-9_-]"), "_") + "_" + id + ".pdf"
            File(docDir(), n).writeBytes(it)
            n
        }
        saveDocItems(sectionId, old.filter { it.name != name } + DocItem(id, name, json, fileName))
    }

    fun removeDocItem(sectionId: String, id: Long) {
        val items = docItems(sectionId)
        items.firstOrNull { it.id == id }?.let { docFile(it)?.delete() }
        saveDocItems(sectionId, items.filter { it.id != id })
    }

    fun setChatEnabled(sectionId: String, value: Boolean) {
        plain.edit().putBoolean("chat_enabled_$sectionId", value).apply()
        touchBlock("docs")
    }

    /** Colori dinamici (Material You), solo Android 12 o più recente. */
    var dynamic: Boolean
        get() = plain.getBoolean("dynamic", false)
        set(value) { if (value != dynamic) { plain.edit().putBoolean("dynamic", value).apply(); touch() } }

    /** Palette colore (0 Menta, 1 Oceano, 2 Lavanda, 3 Tramonto, 4 Ciliegia, 5 Grafite). Vale quando i colori dinamici sono spenti. */
    var palette: Int
        get() = plain.getInt("palette", 0).coerceIn(0, Palettes.names.lastIndex)
        set(value) {
            val v = value.coerceIn(0, Palettes.names.lastIndex)
            if (v != palette) { plain.edit().putInt("palette", v).apply(); touch() }
        }

    /** Nero AMOLED: sfondo nero puro nel tema scuro. */
    var amoled: Boolean
        get() = plain.getBoolean("amoled", false)
        set(value) { if (value != amoled) { plain.edit().putBoolean("amoled", value).apply(); touch() } }

    /** Id delle sezioni pinnate (valido per sezioni fisse e personalizzate). */
    var pinned: Set<String>
        get() = plain.getStringSet("pinned", emptySet())?.toSet() ?: emptySet()
        set(value) { if (value != pinned) { plain.edit().putStringSet("pinned", value).apply(); touch() } }

    /** Vista della Home: false = griglia, true = lista compatta. */
    var listView: Boolean
        get() = plain.getBoolean("home_list", false)
        set(value) { if (value != listView) { plain.edit().putBoolean("home_list", value).apply(); touch() } }

    /** Categorie chiuse in Home (si sincronizzano con le impostazioni). */
    var collapsedCategories: Set<String>
        get() = plain.getStringSet("collapsed_cats", emptySet())?.toSet() ?: emptySet()
        set(value) { if (value != collapsedCategories) { plain.edit().putStringSet("collapsed_cats", value).apply(); touch() } }

    /** Ultime schede aperte (la più recente per prima). */
    var recent: List<String>
        get() = (plain.getString("recent", "") ?: "").split(',').filter { it.isNotBlank() }
        set(value) = plain.edit().putString("recent", value.joinToString(",")).apply()

    fun customSections(): List<Section> {
        val raw = plain.getString("custom_sections", "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Section(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    emoji = o.optString("emoji", "📌").ifBlank { "📌" },
                    hint = "Foto e/o testo",
                    systemPrompt = o.getString("prompt"),
                    custom = true,
                )
            }
        }.getOrDefault(emptyList())
    }

    /**
     * Tutte le sezioni (anche quelle di partenza) vivono qui, così sono tutte modificabili ed eliminabili.
     * Alla prima apertura le sezioni fisse del codice e quelle create in precedenza vengono copiate qui.
     */
    fun loadSections(): List<Section> {
        val raw = plain.getString("sections_v2", null)
        if (raw == null) {
            val seeded = DefaultSections.all + customSections()
            saveSections(seeded)
            plain.edit().putBoolean("defaults_v3", true).apply()
            return seeded
        }
        val loaded = runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Section(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    emoji = o.optString("emoji", "📌").ifBlank { "📌" },
                    hint = o.optString("hint", "Foto e/o testo"),
                    systemPrompt = o.getString("prompt"),
                    updatedAt = o.optLong("u", 0L),
                    category = o.optString("cat", ""),
                )
            }
        }.getOrDefault(emptyList())
        return addNewDefaults(loaded)
    }

    /**
     * Chi aveva già l'app riceve una volta sola le sezioni di partenza nuove (DOCUMENTI, VIAGGIO, VIDEO).
     * Non si aggiungono se le hai già eliminate (anche da un altro dispositivo).
     */
    private fun addNewDefaults(current: List<Section>): List<Section> {
        if (plain.getBoolean("defaults_v3", false)) return current
        val have = current.map { it.id }.toSet()
        val gone = deletedSections().keys
        val now = System.currentTimeMillis()
        val fresh = DefaultSections.extra
            .filter { it.id !in have && it.id !in gone }
            .map { it.copy(updatedAt = now) }
        val result = current + fresh
        if (fresh.isNotEmpty()) saveSections(result)
        plain.edit().putBoolean("defaults_v3", true).apply()
        return result
    }

    fun saveSections(list: List<Section>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("title", it.title).put("emoji", it.emoji)
                    .put("hint", it.hint).put("prompt", it.systemPrompt).put("u", it.updatedAt)
                    .put("cat", it.category),
            )
        }
        plain.edit().putString("sections_v2", arr.toString()).apply()
    }

    /** Colore di ogni categoria (indice nella tavolozza di Home), solo su questo dispositivo. */
    fun categoryColors(): Map<String, Int> {
        val raw = plain.getString("cat_colors", null) ?: return emptyMap()
        return runCatching {
            val o = JSONObject(raw)
            o.keys().asSequence().associateWith { o.getInt(it) }
        }.getOrDefault(emptyMap())
    }

    /** [touch] = false per i salvataggi automatici (colori assegnati da soli), che non devono contare come una modifica tua. */
    fun saveCategoryColors(map: Map<String, Int>, touch: Boolean = true) {
        val o = JSONObject()
        map.forEach { (k, v) -> o.put(k, v) }
        plain.edit().putString("cat_colors", o.toString()).apply()
        if (touch) touch()
    }

    /**
     * Impostazioni che si specchiano tra i dispositivi: modello, lunghezza, tema, colori delle categorie,
     * sezioni pinnate, account Bring (con le liste scelte per reparto) e chiave API (solo nella cartella privata su Drive, mai nel file di backup). Non le chat.
     */
    fun settingsJson(includeSecrets: Boolean = true): JSONObject = JSONObject()
        .put("model", model).put("length", length).put("fallback", fallback)
        .put("theme", theme).put("dynamic", dynamic).put("palette", palette).put("amoled", amoled)
        .put("listView", listView).put("collapsedCats", JSONArray(collapsedCategories.toList())).put("expiryAsked", expiryAsked)
        .put("pinned", JSONArray(pinned.toList()))
        .put("catColors", JSONObject(categoryColors()))
        .put("bringEmail", bringEmail)
        .put("bringDeptLists", JSONObject(bringDeptLists)).put("bringListNames", JSONObject(bringListNames))
        .put("pinHash", pinHash).put("pinSalt", pinSalt)
        .also {
            // La password di Bring viaggia solo verso la cartella privata dell'app su Drive, mai nel file di backup che salvi tu.
            // Chiave API e password Bring viaggiano solo verso la cartella privata dell'app su Drive.
            if (includeSecrets) {
                it.put("bringPassword", bringPassword)
                if (apiKey.isNotBlank()) it.put("apiKey", apiKey)
            }
        }

    /** Applica le impostazioni arrivate da un altro dispositivo o da un backup, senza segnarle come modifica locale. */
    fun applySettings(o: JSONObject, at: Long) {
        fun strMap(name: String): Map<String, String> =
            o.optJSONObject(name)?.let { j -> j.keys().asSequence().associateWith { j.getString(it) } } ?: emptyMap()
        val e = plain.edit()
        if (o.has("model")) e.putString("model", o.getString("model").ifBlank { DEFAULT_MODEL })
        if (o.has("length")) e.putInt("answer_length", o.getInt("length").coerceIn(0, 2))
        if (o.has("fallback")) e.putBoolean("model_fallback", o.getBoolean("fallback"))
        if (o.has("theme")) e.putInt("theme", o.getInt("theme").coerceIn(0, 2))
        if (o.has("dynamic")) e.putBoolean("dynamic", o.getBoolean("dynamic"))
        if (o.has("palette")) e.putInt("palette", o.getInt("palette").coerceIn(0, Palettes.names.lastIndex))
        if (o.has("amoled")) e.putBoolean("amoled", o.getBoolean("amoled"))
        if (o.has("listView")) e.putBoolean("home_list", o.getBoolean("listView"))
        if (o.has("expiryAsked")) e.putBoolean("expiry_asked", o.getBoolean("expiryAsked"))
        o.optJSONArray("collapsedCats")?.let { a -> e.putStringSet("collapsed_cats", (0 until a.length()).map { a.getString(it) }.toSet()) }
        o.optJSONArray("pinned")?.let { a -> e.putStringSet("pinned", (0 until a.length()).map { a.getString(it) }.toSet()) }
        o.optJSONObject("catColors")?.let { j ->
            e.putString("cat_colors", JSONObject().also { n -> j.keys().forEach { k -> n.put(k, j.getInt(k)) } }.toString())
        }
        e.putLong("settings_at", at).apply()
        val se = secure.edit()
        if (o.optString("pinHash").isNotEmpty() && o.optString("pinSalt").isNotEmpty()) {
            se.putString("pin_hash", o.getString("pinHash")).putString("pin_salt", o.getString("pinSalt"))
        }
        if (o.has("bringEmail")) se.putString("bring_email", o.getString("bringEmail"))
        if (o.has("bringPassword")) se.putString("bring_password", o.getString("bringPassword"))
        // Una chiave vuota non cancella mai quella che c'è già.
        if (o.optString("apiKey").isNotBlank()) se.putString("api_key", o.getString("apiKey").trim())
        if (o.has("bringDeptLists")) se.putString("bring_dept_lists", JSONObject(strMap("bringDeptLists")).toString())
        if (o.has("bringListNames")) se.putString("bring_list_names", JSONObject(strMap("bringListNames")).toString())
        se.apply()
    }

    fun saveCustomSections(list: List<Section>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("title", it.title).put("prompt", it.systemPrompt).put("emoji", it.emoji))
        }
        plain.edit().putString("custom_sections", arr.toString()).apply()
    }

    /** Sincronizzazione con l'account Google. */
    var syncOn: Boolean
        get() = plain.getBoolean("sync_on", false)
        set(value) = plain.edit().putBoolean("sync_on", value).apply()

    var syncEmail: String
        get() = plain.getString("sync_email", "") ?: ""
        set(value) = plain.edit().putString("sync_email", value).apply()

    /**
     * Ultimo stato delle chat su cui i dispositivi erano d'accordo (cifrato come le chat). Serve a capire se una chat
     * manca perché è stata cancellata o perché è nuova. Si azzera quando la sincronizzazione si spegne.
     */
    var chatsBase: String?
        get() = secure.getString("sync_base_chats", null)
        set(value) { if (value == null) secure.edit().remove("sync_base_chats").apply() else secure.edit().putString("sync_base_chats", value).apply() }

    /** Riga di dettaglio mostrata nelle Impostazioni sotto "Ultima sincronizzazione" e dimensione dell'ultimo file scritto su Drive. */
    var syncDetail: String
        get() = plain.getString("sync_detail", "") ?: ""
        set(value) = plain.edit().putString("sync_detail", value).apply()
    var syncBytes: Long
        get() = plain.getLong("sync_bytes", 0L)
        set(value) = plain.edit().putLong("sync_bytes", value).apply()

    var lastSync: Long
        get() = plain.getLong("last_sync", 0L)
        set(value) = plain.edit().putLong("last_sync", value).apply()

    /** Sezioni eliminate (id -> quando): servono perché l'eliminazione si propaghi agli altri telefoni. */
    fun deletedSections(): Map<String, Long> {
        val raw = plain.getString("deleted_sections", null) ?: return emptyMap()
        return runCatching {
            val o = JSONObject(raw)
            o.keys().asSequence().associateWith { o.getLong(it) }
        }.getOrDefault(emptyMap())
    }

    fun setDeletedSections(map: Map<String, Long>) {
        val o = JSONObject()
        map.forEach { (k, v) -> o.put(k, v) }
        plain.edit().putString("deleted_sections", o.toString()).apply()
    }

    /** Conversazione di una sezione (solo testo: le foto non vengono salvate). */
    fun loadChat(sectionId: String): List<ChatTurn> {
        val raw = secure.getString("chat_$sectionId", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ChatTurn(
                    fromUser = o.getBoolean("u"),
                    text = o.optString("t"),
                    image = null,
                    hadImage = o.optBoolean("i", false),
                    docName = o.optString("d").ifBlank { null },
                )
            }
        }.getOrDefault(emptyList())
    }

    fun saveChat(sectionId: String, turns: List<ChatTurn>) {
        if (turns.isEmpty()) {
            secure.edit().remove("chat_$sectionId").apply()
            touchBlock("chats")
            return
        }
        // Ogni messaggio ha la sua ora ("ts"): serve a unire le chat di due dispositivi. Quelle già salvate si riusano.
        val known = HashMap<String, ArrayDeque<Long>>()
        runCatching {
            val prev = JSONArray(secure.getString("chat_$sectionId", null) ?: "[]")
            for (i in 0 until prev.length()) {
                val o = prev.getJSONObject(i)
                known.getOrPut("${o.getBoolean("u")}|${o.optString("t")}") { ArrayDeque() }.addLast(o.optLong("ts", 0L))
            }
        }
        val stamp = System.currentTimeMillis()
        val arr = JSONArray()
        turns.takeLast(MAX_TURNS).forEachIndexed { idx, it ->
            val ts = known["${it.fromUser}|${it.text}"]?.removeFirstOrNull() ?: (stamp + idx)
            arr.put(JSONObject().put("u", it.fromUser).put("t", it.text).put("i", it.hadImage).put("d", it.docName ?: "").put("ts", ts))
        }
        secure.edit().putString("chat_$sectionId", arr.toString()).apply()
        touchBlock("chats")
    }

    /** Chat archiviata quando si preme "Nuova chat": si può cercare e riaprire. */
    class Archived(val id: Long, val sectionId: String, val at: Long, val title: String, val turns: List<ChatTurn>)

    fun archive(): List<Archived> {
        val raw = secure.getString("chat_archive", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val ts = o.getJSONArray("turns")
                Archived(
                    id = o.getLong("id"),
                    sectionId = o.getString("s"),
                    at = o.getLong("a"),
                    title = o.optString("t"),
                    turns = (0 until ts.length()).map { j ->
                        val t = ts.getJSONObject(j)
                        ChatTurn(t.getBoolean("u"), t.optString("t"), null, t.optBoolean("i", false))
                    },
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun saveArchive(list: List<Archived>) {
        val arr = JSONArray()
        list.take(MAX_ARCHIVE).forEach { a ->
            val ts = JSONArray()
            a.turns.forEach { ts.put(JSONObject().put("u", it.fromUser).put("t", it.text).put("i", it.hadImage)) }
            arr.put(JSONObject().put("id", a.id).put("s", a.sectionId).put("a", a.at).put("t", a.title).put("turns", ts))
        }
        secure.edit().putString("chat_archive", arr.toString()).apply()
        touchBlock("chats")
    }

    /** Mette da parte una chat (almeno una domanda e una risposta). */
    fun archiveChat(sectionId: String, turns: List<ChatTurn>) {
        if (turns.size < 2) return
        val first = turns.firstOrNull { it.fromUser }
        val title = first?.text?.trim()?.replace('\n', ' ')?.take(70).orEmpty().ifBlank { "Foto" }
        val now = System.currentTimeMillis()
        saveArchive(listOf(Archived(now, sectionId, now, title, turns.takeLast(MAX_TURNS))) + archive())
    }

    fun deleteArchived(id: Long) = saveArchive(archive().filter { it.id != id })

    /** Rimette in archivio una chat eliminata da poco ("Annulla"), al suo posto per data. */
    fun restoreArchived(a: Archived) =
        saveArchive((listOf(a) + archive().filter { it.id != a.id }).sortedByDescending { it.at })

    companion object {
        private const val MAX_ARCHIVE = 60
        /** Oltre questa dimensione il PDF resta solo sul dispositivo dove è stato salvato (la scheda con i dati viaggia lo stesso). */
        const val MAX_SYNC_PDF = 1_000_000L
        // Modello del free tier. Si può cambiare dalle Impostazioni se Google lo sostituisce.
        const val DEFAULT_MODEL = "gemini-3.1-flash-lite"
        private const val MAX_TURNS = 40
    }
}

/** Un solo thread per i salvataggi, così non si accavallano. */
private val storeWriter = java.util.concurrent.Executors.newSingleThreadExecutor { r ->
    Thread(r, "prisma-store").apply { isDaemon = true }
}
