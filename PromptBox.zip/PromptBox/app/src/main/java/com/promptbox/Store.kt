package com.promptbox

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

/**
 * La chiave API è salvata cifrata sul dispositivo (EncryptedSharedPreferences).
 * Non è mai scritta nel codice né nell'APK.
 */
class Store(context: Context) {

    private val secure: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "promptbox_secure",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )
    private val plain: SharedPreferences =
        context.getSharedPreferences("promptbox_plain", Context.MODE_PRIVATE)

    var apiKey: String
        get() = secure.getString("api_key", "") ?: ""
        set(value) = secure.edit().putString("api_key", value.trim()).apply()

    /** Accesso a Bring! (cifrato sul telefono) per mandare la lista della spesa. */
    var bringEmail: String
        get() = secure.getString("bring_email", "") ?: ""
        set(value) = secure.edit().putString("bring_email", value.trim()).apply()

    /** Codice della lista Bring dove mandare il cibo / i prodotti per la casa ("" = predefinita, "-" = non mandare). */
    var bringFoodList: String
        get() = secure.getString("bring_food_list", "") ?: ""
        set(value) = secure.edit().putString("bring_food_list", value).apply()

    var bringHomeList: String
        get() = secure.getString("bring_home_list", "") ?: ""
        set(value) = secure.edit().putString("bring_home_list", value).apply()

    var bringPassword: String
        get() = secure.getString("bring_password", "") ?: ""
        set(value) = secure.edit().putString("bring_password", value).apply()

    /** "Su di me": obiettivi, allergie, preferenze. Cifrato sul telefono; si sincronizza solo se lo attivi. */
    var profile: String
        get() = secure.getString("profile", "") ?: ""
        set(value) {
            val v = value.trim()
            if (v != profile) {
                secure.edit().putString("profile", v).apply()
                plain.edit().putLong("profile_at", System.currentTimeMillis()).apply()
            }
        }

    /** Quando "Su di me" è stato modificato l'ultima volta (serve alla sincronizzazione). */
    val profileAt: Long get() = plain.getLong("profile_at", 0L)

    /** Applica "Su di me" arrivato da un altro dispositivo, senza segnarlo come modifica locale. */
    fun applyRemoteProfile(text: String, at: Long) {
        secure.edit().putString("profile", text.trim()).apply()
        plain.edit().putLong("profile_at", at).apply()
    }

    /** Sincronizza anche "Su di me" (spento di default). */
    var syncProfile: Boolean
        get() = plain.getBoolean("sync_profile", false)
        set(value) = plain.edit().putBoolean("sync_profile", value).apply()

    /** Tema: 0 automatico (segue il telefono), 1 chiaro, 2 scuro. */
    var theme: Int
        get() = plain.getInt("theme", 0)
        set(value) = plain.edit().putInt("theme", value.coerceIn(0, 2)).apply()

    /** Ultima voce del changelog vista: serve al pallino "novità" in Home. */
    var seenChangelog: Int
        get() = plain.getInt("seen_changelog", 0)
        set(value) = plain.edit().putInt("seen_changelog", value).apply()

    /** Lunghezza delle risposte: 0 breve, 1 normale, 2 dettagliata. */
    var length: Int
        get() = plain.getInt("answer_length", 1)
        set(value) = plain.edit().putInt("answer_length", value.coerceIn(0, 2)).apply()

    /** Se il modello scelto non risponde o ha finito le richieste, prova un altro modello gratuito. */
    var fallback: Boolean
        get() = plain.getBoolean("model_fallback", true)
        set(value) = plain.edit().putBoolean("model_fallback", value).apply()

    private fun today(): String =
        java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())

    /** Richieste all'AI fatte oggi (conta le risposte arrivate nelle sezioni). */
    fun requestsToday(): Int =
        if (plain.getString("req_day", "") == today()) plain.getInt("req_count", 0) else 0

    fun countRequest() {
        plain.edit().putString("req_day", today()).putInt("req_count", requestsToday() + 1).apply()
    }

    /** Lista della spesa. */
    fun shoppingList(): List<ShopItem> {
        val raw = plain.getString("shopping", "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ShopItem(o.getString("t"), o.optBoolean("d", false), o.optLong("u", 0L), o.optString("p", ""))
            }
        }.getOrDefault(emptyList())
    }

    fun saveShopping(list: List<ShopItem>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("t", it.text).put("d", it.done).put("u", it.updatedAt).put("p", it.dept)) }
        plain.edit().putString("shopping", arr.toString()).apply()
    }

    /** Prodotti eliminati dalla lista (chiave -> quando): servono perché l'eliminazione arrivi agli altri dispositivi. */
    fun shoppingDeleted(): Map<String, Long> {
        val raw = plain.getString("shopping_deleted", null) ?: return emptyMap()
        return runCatching {
            val o = JSONObject(raw)
            o.keys().asSequence().associateWith { o.getLong(it) }
        }.getOrDefault(emptyMap())
    }

    fun setShoppingDeleted(map: Map<String, Long>) {
        val o = JSONObject()
        map.forEach { (k, v) -> o.put(k, v) }
        plain.edit().putString("shopping_deleted", o.toString()).apply()
    }

    /** Quante volte hai preso un prodotto (chiave minuscola -> conteggio): serve ai suggerimenti "ricomprare". */
    fun shoppingHistory(): Map<String, Int> {
        val raw = plain.getString("shopping_history", null) ?: return emptyMap()
        return runCatching {
            val o = JSONObject(raw)
            o.keys().asSequence().associateWith { o.getInt(it) }
        }.getOrDefault(emptyMap())
    }

    fun setShoppingHistory(map: Map<String, Int>) {
        val o = JSONObject()
        map.entries.sortedByDescending { it.value }.take(200).forEach { (k, v) -> o.put(k, v) }
        plain.edit().putString("shopping_history", o.toString()).apply()
    }

    var model: String
        get() = plain.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(value) = plain.edit().putString("model", value.trim().ifBlank { DEFAULT_MODEL }).apply()

    /** Conversazione attiva per una sezione: se spenta, ogni messaggio è una richiesta nuova, senza memoria dei precedenti. */
    fun chatEnabled(sectionId: String): Boolean = plain.getBoolean("chat_enabled_$sectionId", true)

    fun setChatEnabled(sectionId: String, value: Boolean) =
        plain.edit().putBoolean("chat_enabled_$sectionId", value).apply()

    /** Colori dinamici (Material You), solo Android 12 o più recente. */
    var dynamic: Boolean
        get() = plain.getBoolean("dynamic", false)
        set(value) = plain.edit().putBoolean("dynamic", value).apply()

    /** Id delle sezioni pinnate (valido per sezioni fisse e personalizzate). */
    var pinned: Set<String>
        get() = plain.getStringSet("pinned", emptySet())?.toSet() ?: emptySet()
        set(value) = plain.edit().putStringSet("pinned", value).apply()

    /** Vista della Home: false = griglia, true = lista compatta. */
    var listView: Boolean
        get() = plain.getBoolean("home_list", false)
        set(value) = plain.edit().putBoolean("home_list", value).apply()

    /** Ultime schede aperte (la più recente per prima). */
    var recent: List<String>
        get() = (plain.getString("recent", "") ?: "").split(',').filter { it.isNotBlank() }
        set(value) = plain.edit().putString("recent", value.joinToString(",")).apply()

    fun customSections(): List<Section> {
        val raw = plain.getString("custom_sections", "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Section(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    emoji = o.optString("emoji", "📌").ifBlank { "📌" },
                    hint = "Foto e/o testo",
                    systemPrompt = o.getString("prompt"),
                    custom = true,
                )
            }
        }.getOrDefault(emptyList())
    }

    /**
     * Tutte le sezioni (anche quelle di partenza) vivono qui, così sono tutte modificabili ed eliminabili.
     * Alla prima apertura le sezioni fisse del codice e quelle create in precedenza vengono copiate qui.
     */
    fun loadSections(): List<Section> {
        val raw = plain.getString("sections_v2", null)
        if (raw == null) {
            val seeded = DefaultSections.all + customSections()
            saveSections(seeded)
            plain.edit().putBoolean("defaults_v3", true).apply()
            return seeded
        }
        val loaded = runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Section(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    emoji = o.optString("emoji", "📌").ifBlank { "📌" },
                    hint = o.optString("hint", "Foto e/o testo"),
                    systemPrompt = o.getString("prompt"),
                    updatedAt = o.optLong("u", 0L),
                    category = o.optString("cat", ""),
                )
            }
        }.getOrDefault(emptyList())
        return addNewDefaults(loaded)
    }

    /**
     * Chi aveva già l'app riceve una volta sola le sezioni di partenza nuove (DOCUMENTI, VIAGGIO, VIDEO).
     * Non si aggiungono se le hai già eliminate (anche da un altro dispositivo).
     */
    private fun addNewDefaults(current: List<Section>): List<Section> {
        if (plain.getBoolean("defaults_v3", false)) return current
        val have = current.map { it.id }.toSet()
        val gone = deletedSections().keys
        val now = System.currentTimeMillis()
        val fresh = DefaultSections.extra
            .filter { it.id !in have && it.id !in gone }
            .map { it.copy(updatedAt = now) }
        val result = current + fresh
        if (fresh.isNotEmpty()) saveSections(result)
        plain.edit().putBoolean("defaults_v3", true).apply()
        return result
    }

    fun saveSections(list: List<Section>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("title", it.title).put("emoji", it.emoji)
                    .put("hint", it.hint).put("prompt", it.systemPrompt).put("u", it.updatedAt)
                    .put("cat", it.category),
            )
        }
        plain.edit().putString("sections_v2", arr.toString()).apply()
    }

    /** Colore di ogni categoria (indice nella tavolozza di Home), solo su questo dispositivo. */
    fun categoryColors(): Map<String, Int> {
        val raw = plain.getString("cat_colors", null) ?: return emptyMap()
        return runCatching {
            val o = JSONObject(raw)
            o.keys().asSequence().associateWith { o.getInt(it) }
        }.getOrDefault(emptyMap())
    }

    fun saveCategoryColors(map: Map<String, Int>) {
        val o = JSONObject()
        map.forEach { (k, v) -> o.put(k, v) }
        plain.edit().putString("cat_colors", o.toString()).apply()
    }

    fun saveCustomSections(list: List<Section>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("title", it.title).put("prompt", it.systemPrompt).put("emoji", it.emoji))
        }
        plain.edit().putString("custom_sections", arr.toString()).apply()
    }

    /** Sincronizzazione con l'account Google. */
    var syncOn: Boolean
        get() = plain.getBoolean("sync_on", false)
        set(value) = plain.edit().putBoolean("sync_on", value).apply()

    var syncEmail: String
        get() = plain.getString("sync_email", "") ?: ""
        set(value) = plain.edit().putString("sync_email", value).apply()

    var lastSync: Long
        get() = plain.getLong("last_sync", 0L)
        set(value) = plain.edit().putLong("last_sync", value).apply()

    /** Sezioni eliminate (id -> quando): servono perché l'eliminazione si propaghi agli altri telefoni. */
    fun deletedSections(): Map<String, Long> {
        val raw = plain.getString("deleted_sections", null) ?: return emptyMap()
        return runCatching {
            val o = JSONObject(raw)
            o.keys().asSequence().associateWith { o.getLong(it) }
        }.getOrDefault(emptyMap())
    }

    fun setDeletedSections(map: Map<String, Long>) {
        val o = JSONObject()
        map.forEach { (k, v) -> o.put(k, v) }
        plain.edit().putString("deleted_sections", o.toString()).apply()
    }

    /** Conversazione di una sezione (solo testo: le foto non vengono salvate). */
    fun loadChat(sectionId: String): List<ChatTurn> {
        val raw = plain.getString("chat_$sectionId", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ChatTurn(
                    fromUser = o.getBoolean("u"),
                    text = o.optString("t"),
                    image = null,
                    hadImage = o.optBoolean("i", false),
                )
            }
        }.getOrDefault(emptyList())
    }

    fun saveChat(sectionId: String, turns: List<ChatTurn>) {
        if (turns.isEmpty()) {
            plain.edit().remove("chat_$sectionId").apply()
            return
        }
        val arr = JSONArray()
        turns.takeLast(MAX_TURNS).forEach {
            arr.put(JSONObject().put("u", it.fromUser).put("t", it.text).put("i", it.hadImage))
        }
        plain.edit().putString("chat_$sectionId", arr.toString()).apply()
    }

    /** Chat archiviata quando si preme "Nuova chat": si può cercare e riaprire. */
    class Archived(val id: Long, val sectionId: String, val at: Long, val title: String, val turns: List<ChatTurn>)

    fun archive(): List<Archived> {
        val raw = plain.getString("chat_archive", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val ts = o.getJSONArray("turns")
                Archived(
                    id = o.getLong("id"),
                    sectionId = o.getString("s"),
                    at = o.getLong("a"),
                    title = o.optString("t"),
                    turns = (0 until ts.length()).map { j ->
                        val t = ts.getJSONObject(j)
                        ChatTurn(t.getBoolean("u"), t.optString("t"), null, t.optBoolean("i", false))
                    },
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun saveArchive(list: List<Archived>) {
        val arr = JSONArray()
        list.take(MAX_ARCHIVE).forEach { a ->
            val ts = JSONArray()
            a.turns.forEach { ts.put(JSONObject().put("u", it.fromUser).put("t", it.text).put("i", it.hadImage)) }
            arr.put(JSONObject().put("id", a.id).put("s", a.sectionId).put("a", a.at).put("t", a.title).put("turns", ts))
        }
        plain.edit().putString("chat_archive", arr.toString()).apply()
    }

    /** Mette da parte una chat (almeno una domanda e una risposta). */
    fun archiveChat(sectionId: String, turns: List<ChatTurn>) {
        if (turns.size < 2) return
        val first = turns.firstOrNull { it.fromUser }
        val title = first?.text?.trim()?.replace('\n', ' ')?.take(70).orEmpty().ifBlank { "Foto" }
        val now = System.currentTimeMillis()
        saveArchive(listOf(Archived(now, sectionId, now, title, turns.takeLast(MAX_TURNS))) + archive())
    }

    fun deleteArchived(id: Long) = saveArchive(archive().filter { it.id != id })

    companion object {
        private const val MAX_ARCHIVE = 60
        // Modello del free tier. Si può cambiare dalle Impostazioni se Google lo sostituisce.
        const val DEFAULT_MODEL = "gemini-3.1-flash-lite"
        private const val MAX_TURNS = 40
    }
}
