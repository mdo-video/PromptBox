package com.promptbox

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.Dialog
import androidx.compose.material3.Surface
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.text.font.FontFamily
import org.json.JSONObject
import android.os.ParcelFileDescriptor
import android.graphics.pdf.PdfRenderer
import android.content.Context
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items as lazyRowItems
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.OutlinedButton
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.Switch
import androidx.compose.material3.AlertDialog
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material3.AssistChip
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import android.widget.Toast
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.InputChip
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TextField
import androidx.compose.foundation.border
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Brush
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SectionScreen(
    store: Store,
    section: Section,
    colorIndex: Int,
    incoming: Shared?,
    onIncomingUsed: () -> Unit,
    onAddToShopping: (List<ListSuggestion>) -> Int,
    onCook: ((String) -> Unit)? = null,
    autoAction: String?,
    onAutoActionUsed: () -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val cs = MaterialTheme.colorScheme
    val accent = accentFor(colorIndex)

    // La conversazione si ricarica da quella salvata, così si può riprendere quando si vuole.
    val turns = remember(section.id) { mutableStateListOf<ChatTurn>().apply { addAll(store.loadChat(section.id)) } }
    var text by rememberSaveable { mutableStateOf("") }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var doc by remember { mutableStateOf<ChatDoc?>(null) }
    var archiveOn by remember(section.id) { mutableStateOf(store.archiveOn(section.id)) }
    var archive by remember(section.id) { mutableStateOf(store.docItems(section.id)) }
    var showArchive by remember { mutableStateOf(false) }
    var viewing by remember { mutableStateOf<DocItem?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var pendingUri by remember { mutableStateOf<Uri?>(null) }
    var generation by remember { mutableIntStateOf(0) }
    var chatOn by remember(section.id) { mutableStateOf(store.chatEnabled(section.id)) }
    val listState = rememberLazyListState()

    val needsRetry = !loading && turns.lastOrNull()?.fromUser == true
    val extraItem = loading || needsRetry
    val itemCount = turns.size + if (extraItem) 1 else 0

    // Dopo l'invio si va in fondo; quando arriva la risposta si resta all'inizio di quella risposta.
    LaunchedEffect(turns.size, loading, needsRetry) {
        if (itemCount > 0) {
            val last = turns.lastOrNull()
            val target = if (!loading && last != null && !last.fromUser) turns.lastIndex else itemCount - 1
            listState.animateScrollToItem(target)
        }
    }

    fun loadImage(uri: Uri) {
        scope.launch {
            val bmp = withContext(Dispatchers.IO) { runCatching { ImageUtils.load(context, uri) }.getOrNull() }
            if (bmp != null) bitmap = bmp else error = "Non riesco a leggere l'immagine."
        }
    }

    fun loadDoc(uri: Uri) {
        error = null
        scope.launch {
            val res = withContext(Dispatchers.IO) { DocUtils.load(context, uri) }
            res.onSuccess { doc = it }.onFailure { error = it.message ?: "Non riesco a leggere il file." }
        }
    }

    fun appendText(extra: String) {
        text = if (text.isBlank()) extra else text.trimEnd() + "\n" + extra
    }

    // Contenuto arrivato dal menu Condividi: testo nel campo, foto allegata.
    LaunchedEffect(incoming) {
        if (incoming != null) {
            if (incoming.text.isNotBlank()) appendText(incoming.text)
            incoming.imageUri?.let { loadImage(it) }
            onIncomingUsed()
        }
    }

    var scanning by remember { mutableStateOf(false) }
    var listItems by remember { mutableStateOf<List<ListSuggestion>?>(null) }
    fun scanBarcode() {
        error = null
        scanning = true
        scope.launch {
            val code = BarcodeTools.scan(context).getOrElse {
                error = it.message
                null
            }
            if (code != null) {
                val info = BarcodeTools.lookup(code)
                val line = info.getOrNull()
                if (line != null) appendText(line) else error = info.exceptionOrNull()?.message
            }
            scanning = false
        }
    }

    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) loadImage(uri)
    }
    val pickDoc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) loadDoc(uri)
    }
    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) pendingUri?.let { loadImage(it) }
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val spoken = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) text = if (text.isBlank()) spoken else text.trimEnd() + " " + spoken
    }

    fun startMic() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "it-IT")
        }
        runCatching { speech.launch(intent) }
            .onFailure { error = "Il riconoscimento vocale non è disponibile su questo telefono." }
    }

    fun launchCamera() {
        val dir = File(context.cacheDir, "photos").apply { mkdirs() }
        val file = File.createTempFile("foto", ".jpg", dir)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        pendingUri = uri
        takePhoto.launch(uri)
    }

    // Scorciatoia dall'icona dell'app: apre subito la fotocamera o lo scanner.
    LaunchedEffect(autoAction) {
        if (autoAction != null) {
            when (autoAction) {
                "spesa_photo" -> launchCamera()
                "spesa_scan" -> scanBarcode()
            }
            onAutoActionUsed()
        }
    }

    fun request() {
        loading = true
        error = null
        val gen = generation
        val snapshot = turns.toList().dropWhile { !it.fromUser }
        scope.launch {
            GeminiClient.chat(
                store.apiKey, store.model, section.systemPrompt + DocArchive.context(archive), snapshot,
                store.profile, store.length, store.fallback,
            )
                .onSuccess {
                    store.countRequest()
                    if (gen == generation) {
                        turns.add(ChatTurn(fromUser = false, text = it))
                        store.saveChat(section.id, turns.toList())
                    }
                }
                .onFailure { if (gen == generation) error = it.message ?: "Errore sconosciuto" }
            if (gen == generation) loading = false
        }
    }

    // Con l'archivio attivo il file non va in chat: se ne salvano i DATI SCHEDA e poi si risponde dall'archivio.
    fun archiveDoc(d: ChatDoc) {
        val question = text.trim()
        turns.add(ChatTurn(fromUser = true, text = question, docName = d.name))
        store.saveChat(section.id, turns.toList())
        text = ""
        doc = null
        loading = true
        error = null
        val gen = generation
        scope.launch {
            val res = DocArchive.extract(d, store.apiKey, store.model, store.fallback)
            if (gen != generation) return@launch
            res.onSuccess { (name, json) ->
                store.addDocItem(section.id, name, json, if (d.mime == "application/pdf") d.bytes else null)
                archive = store.docItems(section.id)
                if (question.isBlank()) {
                    turns.add(ChatTurn(fromUser = false, text = "✅ Archiviata: **$name**\nPer rivederla (con le immagini) tocca l'icona cartella in alto."))
                    store.saveChat(section.id, turns.toList())
                    loading = false
                } else {
                    request()
                }
            }.onFailure {
                // Niente è stato salvato: si toglie il messaggio e si rimette il file, così si può riprovare.
                turns.removeAt(turns.lastIndex)
                store.saveChat(section.id, turns.toList())
                text = question
                doc = d
                error = it.message ?: "Non sono riuscito ad archiviare il file."
                loading = false
            }
        }
    }

    fun send() {
        // Con la conversazione spenta ogni messaggio riparte da zero.
        if (!chatOn) turns.clear()
        val attached = doc
        if (archiveOn && attached != null) {
            archiveDoc(attached)
            return
        }
        turns.add(ChatTurn(fromUser = true, text = text.trim(), image = bitmap, doc = doc))
        store.saveChat(section.id, turns.toList())
        text = ""
        bitmap = null
        doc = null
        request()
    }

    fun newChat() {
        generation++
        // La chat precedente non si perde: finisce nella Cronologia.
        store.archiveChat(section.id, turns.toList())
        turns.clear()
        store.saveChat(section.id, emptyList())
        text = ""
        bitmap = null
        doc = null
        error = null
        loading = false
    }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(34.dp).clip(CircleShape).background(accent.container),
                            contentAlignment = Alignment.Center,
                        ) { Text(section.emoji, fontSize = 17.sp) }
                        Spacer(Modifier.width(10.dp))
                        // Il titolo sta su una riga e si rimpicciolisce finché entra intero (prima andava a capo e veniva tagliato).
                        var titleSp by remember(section.title) { mutableStateOf(17f) }
                        Text(
                            section.title,
                            fontWeight = FontWeight.Medium,
                            fontSize = titleSp.sp,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis,
                            onTextLayout = { r -> if (r.hasVisualOverflow && titleSp > 12f) titleSp -= 1f },
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") }
                },
                actions = {
                    if (archiveOn || archive.isNotEmpty()) {
                        IconButton(onClick = { showArchive = true }) {
                            Icon(Icons.Filled.Folder, "Archivio schede", tint = cs.onSurfaceVariant)
                        }
                    }
                    if (turns.isNotEmpty()) {
                        IconButton(onClick = { newChat() }) {
                            Icon(Icons.Filled.AddComment, "Nuova chat", tint = cs.onSurfaceVariant)
                        }
                    }
                    // Interruttore chat: una sola pillola al posto di scritta + switch (verde = chat attiva).
                    Row(
                        Modifier
                            .padding(start = 2.dp, end = 12.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (chatOn) accent.container else cs.surfaceContainerHigh)
                            .clickable { chatOn = !chatOn; store.setChatEnabled(section.id, chatOn) }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            if (chatOn) Icons.Filled.ChatBubble else Icons.Outlined.ChatBubbleOutline,
                            null,
                            Modifier.size(18.dp),
                            tint = if (chatOn) accent.onContainer else cs.onSurfaceVariant,
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "Chat",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = if (chatOn) accent.onContainer else cs.onSurfaceVariant,
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .consumeWindowInsets(padding)
                .imePadding()
                .fillMaxSize(),
        ) {
            if (turns.isEmpty()) {
                Column(
                    modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.Bottom,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(56.dp).clip(CircleShape).background(accent.container),
                            contentAlignment = Alignment.Center,
                        ) { Text(section.emoji, fontSize = 28.sp) }
                        Spacer(Modifier.width(14.dp))
                        Text(
                            section.hint,
                            style = MaterialTheme.typography.titleMedium,
                            color = cs.onSurfaceVariant,
                            modifier = Modifier.weight(1f),
                        )
                    }
                    val suggestions = quickChips(section.id)
                    if (suggestions.isNotEmpty()) {
                        Spacer(Modifier.height(16.dp))
                        suggestions.chunked(2).forEach { rowChips ->
                            Row(
                                Modifier.fillMaxWidth().padding(bottom = 10.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                rowChips.forEach { c ->
                                    Card(
                                        onClick = { appendText(c.text) },
                                        modifier = Modifier.weight(1f).height(72.dp),
                                        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh),
                                        shape = RoundedCornerShape(22.dp),
                                    ) {
                                        Box(Modifier.fillMaxSize().padding(14.dp), contentAlignment = Alignment.CenterStart) {
                                            Text(
                                                c.label,
                                                style = MaterialTheme.typography.titleSmall,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis,
                                            )
                                        }
                                    }
                                }
                                if (rowChips.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                    error?.let {
                        Spacer(Modifier.height(8.dp))
                        ErrorCard(it)
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        // Sfumatura in fondo: il testo non viene più tagliato di netto sopra la barra di scrittura.
                        .drawWithContent {
                            drawContent()
                            drawRect(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, cs.background),
                                    startY = size.height - 36.dp.toPx(),
                                    endY = size.height,
                                ),
                            )
                        },
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    items(count = turns.size, key = { it }) { i ->
                        val turn = turns[i]
                        if (turn.fromUser) {
                            UserBubble(turn, accent)
                        } else {
                            // La riga [[LISTA: ...]] decisa dall'AI non si mostra: serve solo per il tasto "Alla lista".
                            val (shownText, listNames) = splitShoppingMarker(turn.text)
                            AiResponse(raw = shownText, accent = accent)
                        }
                    }
                    if (loading) {
                        item(key = "loading") {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh),
                                shape = RoundedCornerShape(24.dp),
                            ) {
                                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.5.dp, color = accent.strong)
                                    Spacer(Modifier.width(12.dp))
                                    Text("Sto pensando...", color = cs.onSurfaceVariant)
                                }
                            }
                        }
                    } else if (needsRetry) {
                        item(key = "retry") {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                ErrorCard(error ?: "La risposta non è arrivata.")
                                FilledTonalButton(
                                    onClick = { request() },
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = accent.container,
                                        contentColor = accent.onContainer,
                                    ),
                                ) { Text("Riprova") }
                            }
                        }
                    }
                }
            }

            if (turns.isNotEmpty() && !needsRetry) {
                error?.let { Box(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) { ErrorCard(it) } }
            }

            if (scanning) {
                Text(
                    "Cerco il prodotto...",
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.onSurfaceVariant,
                )
            }

            val lastAi = turns.lastOrNull()?.takeIf { !it.fromUser }
            if (lastAi != null && !loading) {
                val (shownLast, lastNames) = splitShoppingMarker(lastAi.text)
                ResponseActions(
                    accent = accent,
                    onToList = if (lastNames.isEmpty()) null else ({ listItems = lastNames }),
                    onCook = if (onCook != null && lastNames.isNotEmpty() && section.id == "spesa") ({
                        onCook("Ho questi ingredienti: " + lastNames.filter { it.dept != "Casa e igiene" }.joinToString(", ") { it.name } + ". Cosa posso cucinare?")
                    }) else null,
                    onCopy = { clipboard.setText(AnnotatedString(plainText(shownLast))) },
                    onShare = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, plainText(shownLast))
                        }
                        context.startActivity(Intent.createChooser(send, null))
                    },
                )
            }

            Composer(
                text = text,
                onText = { text = it },
                bitmap = bitmap,
                onRemovePhoto = { bitmap = null },
                docName = doc?.name,
                onRemoveDoc = { doc = null },
                onPickDoc = { pickDoc.launch(DocUtils.PICKER_TYPES) },
                archiveCount = archive.size,
                onArchive = { showArchive = true },
                onScan = { scanBarcode() },
                chips = if (turns.isEmpty()) emptyList() else quickChips(section.id),
                onChip = { appendText(it) },
                onCamera = { launchCamera() },
                onGallery = {
                    pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                onMic = { startMic() },
                onSend = { send() },
                canSend = !loading && (text.isNotBlank() || bitmap != null || doc != null),
                accent = accent,
                followUp = turns.isNotEmpty() && chatOn,
            )
        }
    }

    if (showArchive) {
        ArchiveDialog(
            on = archiveOn,
            onToggle = { archiveOn = it; store.setArchiveOn(section.id, it) },
            items = archive,
            onOpen = { viewing = it },
            onDelete = { item ->
                store.removeDocItem(section.id, item.id)
                archive = store.docItems(section.id)
            },
            onDismiss = { showArchive = false },
        )
    }

    viewing?.let { item ->
        val f = store.docFile(item)
        if (f != null && f.exists()) {
            PdfViewerDialog(
                file = f,
                title = item.name,
                onOpenExternal = { openPdfExternal(context, f) },
                onDismiss = { viewing = null },
            )
        } else {
            JsonDialog(item = item, onDismiss = { viewing = null })
        }
    }

    listItems?.let { found ->
        AddToShoppingDialog(
            items = found,
            onAdd = { chosen ->
                val n = onAddToShopping(chosen)
                listItems = null
                Toast.makeText(
                    context,
                    if (n > 0) "Aggiunti alla lista: $n" else "Erano già nella lista.",
                    Toast.LENGTH_SHORT,
                ).show()
            },
            onDismiss = { listItems = null },
        )
    }
}

@Composable
private fun ArchiveDialog(
    on: Boolean,
    onToggle: (Boolean) -> Unit,
    items: List<DocItem>,
    onOpen: (DocItem) -> Unit,
    onDelete: (DocItem) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Chiudi") } },
        title = { Text("Archivio schede") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Archivia i file che allego", Modifier.weight(1f))
                    Switch(checked = on, onCheckedChange = onToggle)
                }
                Text(
                    if (on) "Un PDF con i DATI SCHEDA in fondo viene salvato qui e l'AI risponde da queste schede."
                    else "Spento: i file allegati vengono solo letti dall'AI, senza salvarli.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (items.isEmpty()) {
                    Text("Nessuna scheda salvata.")
                } else {
                    Text("Tocca una scheda per aprirla.", style = MaterialTheme.typography.labelMedium)
                    LazyColumn(Modifier.heightIn(max = 280.dp)) {
                        lazyRowItems(items) { item ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    (if (item.file != null) "📄 " else "") + item.name,
                                    Modifier.weight(1f).clickable { onOpen(item) }.padding(vertical = 12.dp),
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                IconButton(onClick = { onDelete(item) }) { Icon(Icons.Filled.Delete, "Elimina") }
                            }
                        }
                    }
                }
            }
        },
    )
}

private fun openPdfExternal(context: Context, file: File) {
    runCatching {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(i)
    }.onFailure { Toast.makeText(context, "Nessuna app per aprire i PDF.", Toast.LENGTH_SHORT).show() }
}

/** Schermo intero con le pagine del PDF salvato, immagini comprese (PdfRenderer di Android). */
@Composable
private fun PdfViewerDialog(file: File, title: String, onOpenExternal: () -> Unit, onDismiss: () -> Unit) {
    val pages = remember(file) { mutableStateListOf<Bitmap>() }
    var failed by remember(file) { mutableStateOf(false) }
    LaunchedEffect(file) {
        withContext(Dispatchers.IO) {
            var fd: ParcelFileDescriptor? = null
            var renderer: PdfRenderer? = null
            try {
                fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                renderer = PdfRenderer(fd)
                for (i in 0 until renderer.pageCount) {
                    val page = renderer.openPage(i)
                    try {
                        val w = 1100
                        val h = (w.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(android.graphics.Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        pages.add(bmp)
                    } finally {
                        page.close()
                    }
                }
            } catch (e: Exception) {
                failed = true
            } finally {
                runCatching { renderer?.close() }
                runCatching { fd?.close() }
            }
        }
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, "Chiudi") }
                    Text(
                        title,
                        Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.titleMedium,
                    )
                    TextButton(onClick = onOpenExternal) { Text("Apri con…") }
                }
                if (failed && pages.isEmpty()) {
                    Text("Non riesco ad aprire il PDF.", Modifier.padding(16.dp))
                }
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    lazyRowItems(pages) { bmp ->
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = null,
                            contentScale = ContentScale.FillWidth,
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)),
                        )
                    }
                }
            }
        }
    }
}

/** Per le schede archiviate solo con i dati (senza PDF): mostra il JSON. */
@Composable
private fun JsonDialog(item: DocItem, onDismiss: () -> Unit) {
    val pretty = remember(item.id) { runCatching { JSONObject(item.json).toString(2) }.getOrDefault(item.json) }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Chiudi") } },
        title = { Text(item.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "Solo dati: di questa scheda non c'è un PDF salvato. Riallegalo con l'archivio acceso per salvarlo.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                SelectionContainer { Text(pretty, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall) }
            }
        },
    )
}

@Composable
private fun UserBubble(turn: ChatTurn, accent: Accent) {
    val cs = MaterialTheme.colorScheme
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
        Column(
            modifier = Modifier
                .widthIn(max = 320.dp)
                .clip(RoundedCornerShape(24.dp, 24.dp, 6.dp, 24.dp))
                .background(accent.container)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (turn.image != null) {
                Image(
                    bitmap = turn.image.asImageBitmap(),
                    contentDescription = "Foto",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(16.dp)),
                )
            } else if (turn.hadImage) {
                Text("📷 Foto", color = accent.onContainer.copy(alpha = 0.8f), style = MaterialTheme.typography.labelLarge)
            }
            if (turn.docName != null) {
                Text("📄 ${turn.docName}", color = accent.onContainer.copy(alpha = 0.8f), style = MaterialTheme.typography.labelLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            if (turn.text.isNotBlank()) {
                SelectionContainer {
                    Text(turn.text, color = accent.onContainer, style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}

/** Divide la risposta in un'introduzione e una parte per ogni titoletto (una proposta per scheda). */
private fun splitProposals(raw: String): Pair<String, List<String>> {
    val head = Regex("^#{1,6}\\s+.*")
    val intro = StringBuilder()
    val parts = mutableListOf<StringBuilder>()
    for (line in raw.replace("\r", "").lines()) {
        if (head.matches(line.trimEnd())) parts += StringBuilder()
        if (parts.isEmpty()) intro.append(line).append('\n') else parts.last().append(line).append('\n')
    }
    return intro.toString().trim() to parts.map { it.toString().trim() }.filter { it.isNotEmpty() }
}

@Composable
private fun AiResponse(raw: String, accent: Accent) {
    val cs = MaterialTheme.colorScheme
    val (intro, parts) = remember(raw) { splitProposals(raw) }
    if (parts.size < 2) {
        Card(
            colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh),
            shape = RoundedCornerShape(6.dp, 28.dp, 28.dp, 28.dp),
        ) {
            Column(Modifier.padding(20.dp)) {
                SelectionContainer { MarkdownText(raw, accent = accent.strong) }
            }
        }
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (intro.isNotBlank()) {
            SelectionContainer {
                MarkdownText(intro, Modifier.padding(horizontal = 4.dp), accent = accent.strong)
            }
        }
        // Fino a 5 proposte in colonna; oltre, un carosello orizzontale.
        if (parts.size > 5) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                lazyRowItems(parts) { p -> ProposalCard(p, accent, Modifier.width(300.dp)) }
            }
        } else {
            parts.forEach { ProposalCard(it, accent, Modifier.fillMaxWidth()) }
        }
    }
}

@Composable
private fun ProposalCard(text: String, accent: Accent, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
        shape = RoundedCornerShape(24.dp),
    ) {
        Column(Modifier.padding(16.dp)) {
            SelectionContainer { MarkdownText(text, accent = accent.strong) }
        }
    }
}

/** Barra azioni fissa in fondo alla risposta: Alla lista, Cosa ci cucino?, Copia, Condividi. */
@Composable
private fun ResponseActions(
    accent: Accent,
    onToList: (() -> Unit)?,
    onCook: (() -> Unit)?,
    onCopy: () -> Unit,
    onShare: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val tonal = ButtonDefaults.filledTonalButtonColors(containerColor = accent.container, contentColor = accent.onContainer)
        if (onToList != null) {
            FilledTonalButton(onClick = onToList, colors = tonal) {
                Icon(Icons.Filled.AddShoppingCart, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Alla lista")
            }
        }
        if (onCook != null) {
            FilledTonalButton(onClick = onCook, colors = tonal) {
                Icon(Icons.Filled.Restaurant, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Cosa ci cucino?")
            }
        }
        OutlinedButton(onClick = onCopy) {
            Icon(Icons.Filled.ContentCopy, null, Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Copia")
        }
        OutlinedButton(onClick = onShare) {
            Icon(Icons.Filled.Share, null, Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Condividi")
        }
    }
}

@Composable
private fun ErrorCard(message: String) {
    val cs = MaterialTheme.colorScheme
    Card(
        colors = CardDefaults.cardColors(containerColor = cs.errorContainer, contentColor = cs.onErrorContainer),
        shape = RoundedCornerShape(24.dp),
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ErrorOutline, null)
            Spacer(Modifier.width(12.dp))
            Text(message)
        }
    }
}

/** Colori della sezione: gli stessi della sua scheda nella Home. */
private class Accent(val container: Color, val onContainer: Color, val strong: Color, val onStrong: Color)

@Composable
private fun accentFor(index: Int): Accent {
    val cs = MaterialTheme.colorScheme
    return when (index.coerceAtLeast(0) % 3) {
        0 -> Accent(cs.primaryContainer, cs.onPrimaryContainer, cs.primary, cs.onPrimary)
        1 -> Accent(cs.secondaryContainer, cs.onSecondaryContainer, cs.secondary, cs.onSecondary)
        else -> Accent(cs.tertiaryContainer, cs.onTertiaryContainer, cs.tertiary, cs.onTertiary)
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun Composer(
    text: String,
    onText: (String) -> Unit,
    bitmap: Bitmap?,
    onRemovePhoto: () -> Unit,
    docName: String?,
    onRemoveDoc: () -> Unit,
    onPickDoc: () -> Unit,
    archiveCount: Int,
    onArchive: () -> Unit,
    onScan: () -> Unit,
    chips: List<QuickChip>,
    onChip: (String) -> Unit,
    onCamera: () -> Unit,
    onGallery: () -> Unit,
    onMic: () -> Unit,
    onSend: () -> Unit,
    canSend: Boolean,
    followUp: Boolean,
    accent: Accent,
) {
    val cs = MaterialTheme.colorScheme
    var menu by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .background(cs.surfaceContainerHigh, RoundedCornerShape(34.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp),
    ) {
        bitmap?.let { bmp ->
            Box(Modifier.padding(start = 8.dp, top = 6.dp, bottom = 4.dp).clip(RoundedCornerShape(18.dp))) {
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = "Foto",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(88.dp),
                )
                FilledIconButton(
                    onClick = onRemovePhoto,
                    modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).size(26.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = Color.Black.copy(alpha = 0.55f),
                        contentColor = Color.White,
                    ),
                ) { Icon(Icons.Filled.Close, "Rimuovi foto", Modifier.size(14.dp)) }
            }
        }
        docName?.let { n ->
            InputChip(
                selected = true,
                onClick = onRemoveDoc,
                label = { Text(n, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 220.dp)) },
                leadingIcon = { Icon(Icons.Filled.AttachFile, null, Modifier.size(18.dp)) },
                trailingIcon = { Icon(Icons.Filled.Close, "Rimuovi file", Modifier.size(18.dp)) },
                modifier = Modifier.padding(start = 8.dp, top = 6.dp, bottom = 2.dp),
            )
        }
        if (chips.isNotEmpty()) {
            FlowRow(
                modifier = Modifier.fillMaxWidth().padding(start = 6.dp, top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                maxLines = 2,
            ) {
                chips.forEach { c ->
                    AssistChip(onClick = { onChip(c.text) }, label = { Text(c.label) })
                }
            }
        }
        Row(verticalAlignment = Alignment.Bottom) {
            // "+" apre la scelta tra fotocamera e galleria.
            Box(Modifier.padding(bottom = 4.dp)) {
                IconButton(onClick = { menu = true }) {
                    Icon(Icons.Filled.Add, "Aggiungi", tint = cs.onSurface)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Scatta una foto") },
                        leadingIcon = { Icon(Icons.Filled.CameraAlt, null, tint = accent.strong) },
                        onClick = { menu = false; onCamera() },
                    )
                    DropdownMenuItem(
                        text = { Text("Dalla galleria") },
                        leadingIcon = { Icon(Icons.Filled.PhotoLibrary, null, tint = accent.strong) },
                        onClick = { menu = false; onGallery() },
                    )
                    DropdownMenuItem(
                        text = { Text("Da file (PDF, testo)") },
                        leadingIcon = { Icon(Icons.Filled.AttachFile, null, tint = accent.strong) },
                        onClick = { menu = false; onPickDoc() },
                    )
                    DropdownMenuItem(
                        text = { Text(if (archiveCount > 0) "Archivio schede ($archiveCount)" else "Archivio schede") },
                        leadingIcon = { Icon(Icons.Filled.Folder, null, tint = accent.strong) },
                        onClick = { menu = false; onArchive() },
                    )
                    DropdownMenuItem(
                        text = { Text("Scansiona codice a barre") },
                        leadingIcon = { Icon(Icons.Filled.QrCodeScanner, null, tint = accent.strong) },
                        onClick = { menu = false; onScan() },
                    )
                }
            }
            TextField(
                value = text,
                onValueChange = onText,
                modifier = Modifier.weight(1f),
                placeholder = { Text(if (followUp) "Chiedi di più..." else "Scrivi qui...") },
                maxLines = 5,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    disabledContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent,
                    cursorColor = accent.strong,
                ),
            )
            Box(Modifier.padding(bottom = 4.dp)) {
                IconButton(onClick = onMic) { Icon(Icons.Filled.Mic, "Detta a voce", tint = cs.onSurface) }
            }
            FilledIconButton(
                onClick = onSend,
                enabled = canSend,
                modifier = Modifier.padding(start = 2.dp, bottom = 4.dp, end = 2.dp).size(48.dp),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = accent.strong,
                    contentColor = accent.onStrong,
                    disabledContainerColor = accent.container,
                    disabledContentColor = accent.onContainer.copy(alpha = 0.6f),
                ),
            ) { Icon(Icons.AutoMirrored.Filled.Send, "Invia") }
        }
    }
}
