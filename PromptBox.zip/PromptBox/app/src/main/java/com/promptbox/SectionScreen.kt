package com.promptbox

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.Dialog
import androidx.compose.material3.Surface
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.text.font.FontFamily
import org.json.JSONObject
import android.os.ParcelFileDescriptor
import android.graphics.pdf.PdfRenderer
import android.content.Context
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items as lazyRowItems
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.OutlinedButton
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.Switch
import androidx.compose.material3.AlertDialog
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material3.AssistChip
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import android.widget.Toast
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Stop
import androidx.compose.runtime.DisposableEffect
import java.util.Locale
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.TextToSpeech
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Event
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.InputChip
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TextField
import androidx.compose.foundation.border
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Brush
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SectionScreen(
    store: Store,
    section: Section,
    colorIndex: Int,
    incoming: Shared?,
    onIncomingUsed: () -> Unit,
    onAddToShopping: (List<ListSuggestion>) -> Int,
    onCook: ((String) -> Unit)? = null,
    sendTargets: List<Section> = emptyList(),
    onSendTo: ((Section, String) -> Unit)? = null,
    autoAction: String?,
    onAutoActionUsed: () -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val cs = MaterialTheme.colorScheme
    val accent = accentFor(colorIndex)

    // La conversazione si ricarica da quella salvata, così si può riprendere quando si vuole.
    val turns = remember(section.id) { mutableStateListOf<ChatTurn>().apply { addAll(store.loadChat(section.id)) } }
    var text by rememberSaveable { mutableStateOf("") }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var doc by remember { mutableStateOf<ChatDoc?>(null) }
    var archiveOn by remember(section.id) { mutableStateOf(store.archiveOn(section.id)) }
    var archive by remember(section.id) { mutableStateOf(store.docItems(section.id)) }
    var showArchive by remember { mutableStateOf(false) }
    // Campi guidati: modulo a scelta rapida sopra la casella di testo (solo su questo telefono).
    var gFields by remember(section.id) { mutableStateOf(store.guidedFields(section.id)) }
    var gValues by remember(section.id) { mutableStateOf(store.guidedValues(section.id)) }
    var showFields by remember { mutableStateOf(false) }
    var viewing by remember { mutableStateOf<DocItem?>(null) }
    var loading by remember { mutableStateOf(false) }
    // Il tasto "Annulla" c'è solo mentre aspetto la risposta dell'AI (non durante l'archiviazione di un file).
    var canStop by remember { mutableStateOf(false) }
    var streamText by remember { mutableStateOf("") } // la risposta che arriva a pezzi
    var error by remember { mutableStateOf<String?>(null) }
    // Risposta in modifica (tocco prolungato) e aggiornamento delle righe nascoste dopo la modifica.
    var editIndex by remember { mutableStateOf<Int?>(null) }
    // "Manda a…" (scelta della sezione) e scelta del timer quando nella risposta ce ne sono più d'uno.
    var showSend by remember { mutableStateOf(false) }
    var showTimers by remember { mutableStateOf(false) }
    var refreshingList by remember { mutableStateOf(false) }
    var pendingUri by remember { mutableStateOf<Uri?>(null) }
    var generation by remember { mutableIntStateOf(0) }
    // La richiesta all'AI in corso: "Annulla" la ferma davvero (chiude la connessione), non si limita a ignorare la risposta.
    var requestJob by remember { mutableStateOf<Job?>(null) }
    var chatOn by remember(section.id) { mutableStateOf(store.chatEnabled(section.id)) }
    val listState = rememberLazyListState()

    val needsRetry = !loading && turns.lastOrNull()?.fromUser == true
    val extraItem = loading || needsRetry
    val itemCount = turns.size + if (extraItem) 1 else 0

    // Dopo l'invio si va in fondo; quando arriva la risposta si resta all'inizio di quella risposta.
    LaunchedEffect(turns.size, loading, needsRetry) {
        if (itemCount > 0) {
            val last = turns.lastOrNull()
            val target = if (!loading && last != null && !last.fromUser) turns.lastIndex else itemCount - 1
            listState.animateScrollToItem(target)
        }
    }

    fun loadImage(uri: Uri) {
        scope.launch {
            val bmp = withContext(Dispatchers.IO) { runCatching { ImageUtils.load(context, uri) }.getOrNull() }
            if (bmp != null) bitmap = bmp else error = "Non riesco a leggere l'immagine."
        }
    }

    fun loadDoc(uri: Uri) {
        error = null
        scope.launch {
            val res = withContext(Dispatchers.IO) { DocUtils.load(context, uri) }
            res.onSuccess { doc = it }.onFailure { error = it.message ?: "Non riesco a leggere il file." }
        }
    }

    fun appendText(extra: String) {
        text = if (text.isBlank()) extra else text.trimEnd() + "\n" + extra
    }

    // Routine: la richiesta arriva già pronta e parte da sola (vedi l'effetto dopo send()).
    var autoSendPending by remember { mutableStateOf(false) }

    // Contenuto arrivato dal menu Condividi o da una routine: testo nel campo, foto o PDF allegati.
    LaunchedEffect(incoming) {
        if (incoming != null) {
            if (incoming.text.isNotBlank()) appendText(incoming.text)
            if (incoming.autoSend && incoming.text.isNotBlank()) autoSendPending = true
            incoming.imageUri?.let { loadImage(it) }
            incoming.docUri?.let { loadDoc(it) }
            onIncomingUsed()
        }
    }

    var scanning by remember { mutableStateOf(false) }
    var listItems by remember { mutableStateOf<List<ListSuggestion>?>(null) }
    fun scanBarcode() {
        error = null
        scanning = true
        scope.launch {
            val code = BarcodeTools.scan(context).getOrElse {
                error = it.message
                null
            }
            if (code != null) {
                val info = BarcodeTools.lookup(code)
                val line = info.getOrNull()
                if (line != null) appendText(line) else error = info.exceptionOrNull()?.message
            }
            scanning = false
        }
    }

    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) loadImage(uri)
    }
    val pickDoc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) loadDoc(uri)
    }
    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) pendingUri?.let { loadImage(it) }
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val spoken = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) text = if (text.isBlank()) spoken else text.trimEnd() + " " + spoken
    }

    fun startMic() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "it-IT")
        }
        runCatching { speech.launch(intent) }
            .onFailure { error = "Il riconoscimento vocale non è disponibile su questo telefono." }
    }

    fun launchCamera() {
        val dir = File(context.cacheDir, "photos").apply { mkdirs() }
        val file = File.createTempFile("foto", ".jpg", dir)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        pendingUri = uri
        takePhoto.launch(uri)
    }

    // Scorciatoia dall'icona dell'app: apre subito la fotocamera o lo scanner.
    LaunchedEffect(autoAction) {
        if (autoAction != null) {
            when (autoAction) {
                "spesa_photo" -> launchCamera()
                "spesa_scan" -> scanBarcode()
            }
            onAutoActionUsed()
        }
    }

    /** Salva la risposta modificata a mano e rifà lista della spesa / calendario dal testo nuovo. */
    fun applyEdit(idx: Int, newText: String, oldRaw: String) {
        val t = newText.trim()
        val turn = turns.getOrNull(idx) ?: return
        if (t.isBlank() || t == splitShoppingMarker(oldRaw).first.trim()) return
        val hadList = splitShoppingMarker(oldRaw).second.isNotEmpty()
        val hadCal = CalendarTools.parse(oldRaw).isNotEmpty()
        turns[idx] = turn.copy(text = t)
        store.saveChat(section.id, turns.toList())
        if (!hadList && !hadCal) return
        refreshingList = true
        scope.launch {
            GeminiClient.refreshMarkers(store.apiKey, store.model, t, hadList, hadCal, store.fallback)
                .onSuccess { raw ->
                    val m = markerLines(raw)
                    val cur = turns.getOrNull(idx)
                    if (cur != null && !cur.fromUser && cur.text == t && m.isNotBlank()) {
                        turns[idx] = cur.copy(text = t + "\n\n" + m)
                        store.saveChat(section.id, turns.toList())
                    }
                }
                .onFailure {
                    // Meglio una lista un po' vecchia che nessuna: rimetto quella di prima.
                    val cur = turns.getOrNull(idx)
                    val old = markerLines(oldRaw)
                    if (cur != null && !cur.fromUser && cur.text == t && old.isNotBlank()) {
                        turns[idx] = cur.copy(text = t + "\n\n" + old)
                        store.saveChat(section.id, turns.toList())
                    }
                    error = "Risposta salvata, ma non sono riuscito ad aggiornare la lista: ${it.message ?: "errore"}"
                }
            refreshingList = false
        }
    }

    fun request() {
        loading = true
        canStop = true
        error = null
        streamText = ""
        val gen = generation
        val snapshot = turns.toList().dropWhile { !it.fromUser }
        requestJob?.cancel()
        requestJob = scope.launch {
            GeminiClient.chat(
                store.apiKey, store.model, section.systemPrompt + DocArchive.context(archive), snapshot,
                store.profile, store.length, store.fallback,
                onPartial = { if (gen == generation) streamText = it },
            )
                .onSuccess {
                    store.countRequest()
                    if (gen == generation) {
                        turns.add(ChatTurn(fromUser = false, text = it))
                        store.saveChat(section.id, turns.toList())
                    }
                }
                .onFailure { if (gen == generation) error = it.message ?: "Errore sconosciuto" }
            if (gen == generation) {
                streamText = ""
                loading = false
                canStop = false
            }
        }
    }

    // Annulla l'attesa: la richiesta si ferma davvero (la connessione si chiude). La domanda resta e si può rimandare con "Riprova".
    fun stopRequest() {
        generation++
        requestJob?.cancel()
        requestJob = null
        loading = false
        canStop = false
        streamText = ""
        error = "Richiesta annullata."
    }

    // Con l'archivio attivo il file non va in chat: se ne salvano i DATI SCHEDA e poi si risponde dall'archivio.
    fun archiveDoc(d: ChatDoc) {
        val question = text.trim()
        turns.add(ChatTurn(fromUser = true, text = question, docName = d.name))
        store.saveChat(section.id, turns.toList())
        text = ""
        doc = null
        loading = true
        canStop = false
        error = null
        val gen = generation
        scope.launch {
            val res = DocArchive.extract(d, store.apiKey, store.model, store.fallback)
            if (gen != generation) return@launch
            res.onSuccess { (name, json) ->
                store.addDocItem(section.id, name, json, if (d.mime == "application/pdf") d.bytes else null)
                archive = store.docItems(section.id)
                if (question.isBlank()) {
                    turns.add(ChatTurn(fromUser = false, text = "✅ Archiviata: **$name**\nPer rivederla (con le immagini) tocca l'icona cartella in alto."))
                    store.saveChat(section.id, turns.toList())
                    loading = false
                } else {
                    request()
                }
            }.onFailure {
                // Niente è stato salvato: si toglie il messaggio e si rimette il file, così si può riprovare.
                turns.removeAt(turns.lastIndex)
                store.saveChat(section.id, turns.toList())
                text = question
                doc = d
                error = it.message ?: "Non sono riuscito ad archiviare il file."
                loading = false
            }
        }
    }

    // Lettura ad alta voce della risposta (voce di sistema, in italiano).
    var speaking by remember { mutableStateOf(false) }
    val ttsHolder = remember { arrayOfNulls<TextToSpeech>(1) }
    DisposableEffect(Unit) {
        onDispose {
            ttsHolder[0]?.stop()
            ttsHolder[0]?.shutdown()
            ttsHolder[0] = null
        }
    }
    fun speak(raw: String) {
        if (speaking) {
            ttsHolder[0]?.stop()
            speaking = false
            return
        }
        // Il motore vocale accetta al massimo ~4000 caratteri per volta: spezzo il testo per righe.
        val chunks = mutableListOf<String>()
        var cur = StringBuilder()
        raw.lines().forEach { line ->
            if (cur.isNotEmpty() && cur.length + line.length > 3500) {
                chunks.add(cur.toString())
                cur = StringBuilder()
            }
            cur.append(line).append('\n')
        }
        if (cur.isNotBlank()) chunks.add(cur.toString())
        if (chunks.isEmpty()) return
        fun go(t: TextToSpeech) {
            t.setLanguage(Locale.ITALIAN)
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (utteranceId == "u" + (chunks.size - 1)) speaking = false
                }
                override fun onError(utteranceId: String?) {
                    speaking = false
                }
            })
            chunks.forEachIndexed { i, c ->
                t.speak(c, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "u$i")
            }
            speaking = true
        }
        val existing = ttsHolder[0]
        if (existing != null) {
            go(existing)
        } else {
            ttsHolder[0] = TextToSpeech(context) { status ->
                val t = ttsHolder[0]
                if (status == TextToSpeech.SUCCESS && t != null) go(t)
                else error = "La lettura ad alta voce non è disponibile su questo telefono."
            }
        }
    }

    fun send() {
        // Con la conversazione spenta ogni messaggio riparte da zero.
        if (!chatOn) turns.clear()
        val attached = doc
        if (archiveOn && attached != null) {
            archiveDoc(attached)
            return
        }
        // Le scelte del modulo guidato vanno prima del testo, solo all'inizio di una conversazione.
        val guided = if (turns.isEmpty()) GuidedFields.prefix(gFields, gValues) else ""
        val fullText = listOf(guided, text.trim()).filter { it.isNotBlank() }.joinToString("\n")
        turns.add(ChatTurn(fromUser = true, text = fullText, image = bitmap, doc = doc))
        store.saveChat(section.id, turns.toList())
        text = ""
        bitmap = null
        doc = null
        request()
    }

    // Invio automatico della routine, quando il testo è già nel campo e non c'è una risposta in corso.
    LaunchedEffect(autoSendPending, text, loading) {
        if (autoSendPending && text.isNotBlank() && !loading) {
            autoSendPending = false
            send()
        }
    }

    fun newChat() {
        generation++
        requestJob?.cancel()
        requestJob = null
        // La chat precedente non si perde: finisce nella Cronologia.
        store.archiveChat(section.id, turns.toList())
        turns.clear()
        store.saveChat(section.id, emptyList())
        text = ""
        bitmap = null
        doc = null
        error = null
        loading = false
        canStop = false
    }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(34.dp).clip(CircleShape).background(accent.container),
                            contentAlignment = Alignment.Center,
                        ) { Text(section.emoji, fontSize = 17.sp) }
                        Spacer(Modifier.width(10.dp))
                        // Il titolo sta su una riga e si rimpicciolisce finché entra intero (prima andava a capo e veniva tagliato).
                        var titleSp by remember(section.title) { mutableStateOf(17f) }
                        Text(
                            section.title,
                            fontWeight = FontWeight.Medium,
                            fontSize = titleSp.sp,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis,
                            onTextLayout = { r -> if (r.hasVisualOverflow && titleSp > 12f) titleSp -= 1f },
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") }
                },
                actions = {
                    IconButton(onClick = { showFields = true }) {
                        Icon(Icons.Filled.Tune, "Campi guidati", tint = if (gFields.isNotEmpty()) cs.primary else cs.onSurfaceVariant)
                    }
                    if (archiveOn || archive.isNotEmpty()) {
                        IconButton(onClick = { showArchive = true }) {
                            Icon(Icons.Filled.Folder, "Archivio schede", tint = cs.onSurfaceVariant)
                        }
                    }
                    if (turns.isNotEmpty()) {
                        IconButton(onClick = { newChat() }) {
                            Icon(Icons.Filled.AddComment, "Nuova chat", tint = cs.onSurfaceVariant)
                        }
                    }
                    // Interruttore chat: una sola pillola al posto di scritta + switch (verde = chat attiva).
                    Row(
                        Modifier
                            .padding(start = 2.dp, end = 12.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (chatOn) accent.container else cs.surfaceContainerHigh)
                            .clickable { chatOn = !chatOn; store.setChatEnabled(section.id, chatOn) }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            if (chatOn) Icons.Filled.ChatBubble else Icons.Outlined.ChatBubbleOutline,
                            null,
                            Modifier.size(18.dp),
                            tint = if (chatOn) accent.onContainer else cs.onSurfaceVariant,
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "Chat",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = if (chatOn) accent.onContainer else cs.onSurfaceVariant,
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .consumeWindowInsets(padding)
                .imePadding()
                .fillMaxSize(),
        ) {
            if (turns.isEmpty()) {
                Column(
                    modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.Bottom,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(56.dp).clip(CircleShape).background(accent.container),
                            contentAlignment = Alignment.Center,
                        ) { Text(section.emoji, fontSize = 28.sp) }
                        Spacer(Modifier.width(14.dp))
                        Text(
                            section.hint,
                            style = MaterialTheme.typography.titleMedium,
                            color = cs.onSurfaceVariant,
                            modifier = Modifier.weight(1f),
                        )
                    }
                    val suggestions = emptyList<QuickChip>()
                    if (suggestions.isNotEmpty()) {
                        Spacer(Modifier.height(16.dp))
                        suggestions.chunked(2).forEach { rowChips ->
                            Row(
                                Modifier.fillMaxWidth().padding(bottom = 10.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                rowChips.forEach { c ->
                                    Card(
                                        onClick = { appendText(c.text) },
                                        modifier = Modifier.weight(1f).height(72.dp),
                                        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh),
                                        shape = RoundedCornerShape(22.dp),
                                    ) {
                                        Box(Modifier.fillMaxSize().padding(14.dp), contentAlignment = Alignment.CenterStart) {
                                            Text(
                                                c.label,
                                                style = MaterialTheme.typography.titleSmall,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis,
                                            )
                                        }
                                    }
                                }
                                if (rowChips.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                    error?.let {
                        Spacer(Modifier.height(8.dp))
                        ErrorCard(it)
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        // Sfumatura in fondo: il testo non viene più tagliato di netto sopra la barra di scrittura.
                        .drawWithContent {
                            drawContent()
                            drawRect(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, cs.background),
                                    startY = size.height - 36.dp.toPx(),
                                    endY = size.height,
                                ),
                            )
                        },
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    items(count = turns.size, key = { it }) { i ->
                        val turn = turns[i]
                        if (turn.fromUser) {
                            UserBubble(turn, accent)
                        } else {
                            // La riga [[LISTA: ...]] decisa dall'AI non si mostra: serve solo per il tasto "Alla lista".
                            val (shownText, listNames) = splitShoppingMarker(turn.text)
                            AiResponse(raw = shownText, accent = accent, onLongPress = { editIndex = i })
                        }
                    }
                    if (loading && streamText.isNotBlank()) {
                        item(key = "streaming") {
                            // La risposta compare man mano; la riga [[LISTA: ...]] non si mostra.
                            Column {
                                AiResponse(raw = streamText.substringBefore("[["), accent = accent, onLongPress = {})
                                if (canStop) {
                                    TextButton(onClick = { stopRequest() }) { Text("Annulla") }
                                }
                            }
                        }
                    } else if (loading) {
                        item(key = "loading") {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh),
                                shape = RoundedCornerShape(24.dp),
                            ) {
                                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.5.dp, color = accent.strong)
                                    Spacer(Modifier.width(12.dp))
                                    Text("Sto pensando...", color = cs.onSurfaceVariant, modifier = Modifier.weight(1f))
                                    if (canStop) {
                                        TextButton(onClick = { stopRequest() }) { Text("Annulla") }
                                    }
                                }
                            }
                        }
                    } else if (needsRetry) {
                        item(key = "retry") {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                ErrorCard(error ?: "La risposta non è arrivata.")
                                FilledTonalButton(
                                    onClick = { request() },
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = accent.container,
                                        contentColor = accent.onContainer,
                                    ),
                                ) { Text("Riprova") }
                            }
                        }
                    }
                }
            }

            if (turns.isNotEmpty() && !needsRetry) {
                error?.let { Box(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) { ErrorCard(it) } }
            }

            if (refreshingList) {
                Text(
                    "Aggiorno la lista...",
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.onSurfaceVariant,
                )
            }

            if (scanning) {
                Text(
                    "Cerco il prodotto...",
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.onSurfaceVariant,
                )
            }

            val lastAi = turns.lastOrNull()?.takeIf { !it.fromUser }
            if (lastAi != null && !loading) {
                val (shownLast, lastNames) = splitShoppingMarker(lastAi.text)
                ResponseActions(
                    accent = accent,
                    onToList = if (lastNames.isEmpty()) null else ({ listItems = lastNames }),
                    onCook = if (onCook != null && lastNames.isNotEmpty() && section.id == "spesa") ({
                        onCook("Ho questi ingredienti: " + lastNames.filter { it.dept != "Casa e igiene" }.joinToString(", ") { it.name } + ". Cosa posso cucinare?")
                    }) else null,
                    calendarEvents = remember(lastAi.text) { CalendarTools.parse(lastAi.text) },
                    onCalendarOne = { ev -> CalendarTools.openOne(context, ev)?.let { msg -> error = msg } },
                    onCalendarAll = {
                        CalendarTools.open(context, CalendarTools.parse(lastAi.text))?.let { msg -> error = msg }
                    },
                    speaking = speaking,
                    onSpeak = { speak(plainText(shownLast)) },
                    onSendTo = if (onSendTo != null && sendTargets.isNotEmpty()) ({ showSend = true }) else null,
                    timers = remember(shownLast) { Timers.parse(plainText(shownLast)) },
                    onTimer = { hits ->
                        if (hits.size == 1) {
                            val err = Timers.start(context, hits[0].seconds)
                            Toast.makeText(context, err ?: ("Timer avviato: " + hits[0].label), Toast.LENGTH_SHORT).show()
                        } else {
                            showTimers = true
                        }
                    },
                    onCopy = { clipboard.setText(AnnotatedString(plainText(shownLast))) },
                    onShare = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, plainText(shownLast))
                        }
                        context.startActivity(Intent.createChooser(send, null))
                    },
                )
            }

            val guidedOn = gFields.isNotEmpty() && (turns.isEmpty() || !chatOn)
            if (guidedOn) {
                GuidedPanel(gFields, gValues) {
                    gValues = it
                    store.saveGuidedValues(section.id, it)
                }
            }

            Composer(
                text = text,
                onText = { text = it },
                bitmap = bitmap,
                onRemovePhoto = { bitmap = null },
                docName = doc?.name,
                onRemoveDoc = { doc = null },
                onPickDoc = { pickDoc.launch(DocUtils.PICKER_TYPES) },
                archiveCount = archive.size,
                onArchive = { showArchive = true },
                onScan = { scanBarcode() },
                chips = emptyList(),
                onChip = { appendText(it) },
                onCamera = { launchCamera() },
                onGallery = {
                    pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                onMic = { startMic() },
                onSend = { send() },
                canSend = !loading && (text.isNotBlank() || bitmap != null || doc != null || (guidedOn && GuidedFields.prefix(gFields, gValues).isNotBlank())),
                accent = accent,
                followUp = turns.isNotEmpty() && chatOn,
            )
        }
    }

    if (showFields) {
        GuidedFieldsDialog(
            initial = gFields,
            suggest = { GeminiClient.suggestFields(store.apiKey, store.model, section.title, section.systemPrompt) },
            onSave = { list ->
                gFields = list
                store.saveGuidedFields(section.id, list)
                // Tolgo le scelte di campi che non esistono più.
                val keep = gValues.filterKeys { k -> list.any { it.label == k } }
                gValues = keep
                store.saveGuidedValues(section.id, keep)
                showFields = false
            },
            onDismiss = { showFields = false },
        )
    }

    if (showSend && onSendTo != null) {
        val lastText = turns.lastOrNull { !it.fromUser }?.let { plainText(splitShoppingMarker(it.text).first) }.orEmpty()
        AlertDialog(
            onDismissRequest = { showSend = false },
            title = { Text("Manda a…") },
            text = {
                Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                    Text(
                        "La risposta finisce nel campo di testo della sezione che scegli: aggiungi la tua richiesta e invia.",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                    sendTargets.forEach { target ->
                        TextButton(
                            onClick = {
                                showSend = false
                                onSendTo(target, "Da " + section.title + ":\n" + lastText + "\n")
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                target.emoji + "  " + target.title,
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Start,
                            )
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showSend = false }) { Text("Annulla") } },
        )
    }

    if (showTimers) {
        val hits = turns.lastOrNull { !it.fromUser }?.let { Timers.parse(plainText(splitShoppingMarker(it.text).first)) }.orEmpty()
        AlertDialog(
            onDismissRequest = { showTimers = false },
            title = { Text("Quale timer?") },
            text = {
                Column {
                    hits.forEach { hit ->
                        TextButton(
                            onClick = {
                                showTimers = false
                                val err = Timers.start(context, hit.seconds)
                                Toast.makeText(context, err ?: ("Timer avviato: " + hit.label), Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text("⏱  " + hit.label, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showTimers = false }) { Text("Annulla") } },
        )
    }

    editIndex?.let { idx ->
        val turn = turns.getOrNull(idx)
        if (turn == null || turn.fromUser) {
            editIndex = null
        } else {
            var draft by remember(idx) { mutableStateOf(splitShoppingMarker(turn.text).first) }
            AlertDialog(
                onDismissRequest = { editIndex = null },
                title = { Text("Modifica la risposta") },
                text = {
                    OutlinedTextField(
                        value = draft,
                        onValueChange = { draft = it },
                        modifier = Modifier.fillMaxWidth().heightIn(max = 380.dp),
                        minLines = 8,
                    )
                },
                confirmButton = {
                    TextButton(onClick = { applyEdit(idx, draft, turn.text); editIndex = null }) { Text("Salva") }
                },
                dismissButton = { TextButton(onClick = { editIndex = null }) { Text("Annulla") } },
            )
        }
    }

    if (showArchive) {
        ArchiveDialog(
            on = archiveOn,
            onToggle = { archiveOn = it; store.setArchiveOn(section.id, it) },
            items = archive,
            onOpen = { viewing = it },
            onDelete = { item ->
                store.removeDocItem(section.id, item.id)
                archive = store.docItems(section.id)
            },
            onDismiss = { showArchive = false },
        )
    }

    viewing?.let { item ->
        val f = store.docFile(item)
        if (f != null && f.exists()) {
            PdfViewerDialog(
                file = f,
                title = item.name,
                onOpenExternal = { openPdfExternal(context, f) },
                onDismiss = { viewing = null },
            )
        } else {
            JsonDialog(item = item, onDismiss = { viewing = null })
        }
    }

    listItems?.let { found ->
        AddToShoppingDialog(
            items = found,
            onAdd = { chosen ->
                val n = onAddToShopping(chosen)
                listItems = null
                Toast.makeText(
                    context,
                    if (n > 0) "Aggiunti alla lista: $n" else "Erano già nella lista.",
                    Toast.LENGTH_SHORT,
                ).show()
            },
            onDismiss = { listItems = null },
        )
    }
}
