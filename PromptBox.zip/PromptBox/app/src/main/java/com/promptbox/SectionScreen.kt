package com.promptbox

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material3.AssistChip
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import android.widget.Toast
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TextField
import androidx.compose.foundation.border
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SectionScreen(
    store: Store,
    section: Section,
    colorIndex: Int,
    incoming: Shared?,
    onIncomingUsed: () -> Unit,
    onAddToShopping: (List<ListSuggestion>) -> Int,
    autoAction: String?,
    onAutoActionUsed: () -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val cs = MaterialTheme.colorScheme
    val accent = accentFor(colorIndex)

    // La conversazione si ricarica da quella salvata, così si può riprendere quando si vuole.
    val turns = remember(section.id) { mutableStateListOf<ChatTurn>().apply { addAll(store.loadChat(section.id)) } }
    var text by rememberSaveable { mutableStateOf("") }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var pendingUri by remember { mutableStateOf<Uri?>(null) }
    var generation by remember { mutableIntStateOf(0) }
    var chatOn by remember(section.id) { mutableStateOf(store.chatEnabled(section.id)) }
    val listState = rememberLazyListState()

    val needsRetry = !loading && turns.lastOrNull()?.fromUser == true
    val extraItem = loading || needsRetry
    val itemCount = turns.size + if (extraItem) 1 else 0

    // Dopo l'invio si va in fondo; quando arriva la risposta si resta all'inizio di quella risposta.
    LaunchedEffect(turns.size, loading, needsRetry) {
        if (itemCount > 0) {
            val last = turns.lastOrNull()
            val target = if (!loading && last != null && !last.fromUser) turns.lastIndex else itemCount - 1
            listState.animateScrollToItem(target)
        }
    }

    fun loadImage(uri: Uri) {
        scope.launch {
            val bmp = withContext(Dispatchers.IO) { runCatching { ImageUtils.load(context, uri) }.getOrNull() }
            if (bmp != null) bitmap = bmp else error = "Non riesco a leggere l'immagine."
        }
    }

    fun appendText(extra: String) {
        text = if (text.isBlank()) extra else text.trimEnd() + "\n" + extra
    }

    // Contenuto arrivato dal menu Condividi: testo nel campo, foto allegata.
    LaunchedEffect(incoming) {
        if (incoming != null) {
            if (incoming.text.isNotBlank()) appendText(incoming.text)
            incoming.imageUri?.let { loadImage(it) }
            onIncomingUsed()
        }
    }

    var scanning by remember { mutableStateOf(false) }
    var listItems by remember { mutableStateOf<List<ListSuggestion>?>(null) }
    fun scanBarcode() {
        error = null
        scanning = true
        scope.launch {
            val code = BarcodeTools.scan(context).getOrElse {
                error = it.message
                null
            }
            if (code != null) {
                val info = BarcodeTools.lookup(code)
                val line = info.getOrNull()
                if (line != null) appendText(line) else error = info.exceptionOrNull()?.message
            }
            scanning = false
        }
    }

    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) loadImage(uri)
    }
    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) pendingUri?.let { loadImage(it) }
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val spoken = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) text = if (text.isBlank()) spoken else text.trimEnd() + " " + spoken
    }

    fun startMic() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "it-IT")
        }
        runCatching { speech.launch(intent) }
            .onFailure { error = "Il riconoscimento vocale non è disponibile su questo telefono." }
    }

    fun launchCamera() {
        val dir = File(context.cacheDir, "photos").apply { mkdirs() }
        val file = File.createTempFile("foto", ".jpg", dir)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        pendingUri = uri
        takePhoto.launch(uri)
    }

    // Scorciatoia dall'icona dell'app: apre subito la fotocamera o lo scanner.
    LaunchedEffect(autoAction) {
        if (autoAction != null) {
            when (autoAction) {
                "spesa_photo" -> launchCamera()
                "spesa_scan" -> scanBarcode()
            }
            onAutoActionUsed()
        }
    }

    fun request() {
        loading = true
        error = null
        val gen = generation
        val snapshot = turns.toList().dropWhile { !it.fromUser }
        scope.launch {
            GeminiClient.chat(
                store.apiKey, store.model, section.systemPrompt, snapshot,
                store.profile, store.length, store.fallback,
            )
                .onSuccess {
                    store.countRequest()
                    if (gen == generation) {
                        turns.add(ChatTurn(fromUser = false, text = it))
                        store.saveChat(section.id, turns.toList())
                    }
                }
                .onFailure { if (gen == generation) error = it.message ?: "Errore sconosciuto" }
            if (gen == generation) loading = false
        }
    }

    fun send() {
        // Con la conversazione spenta ogni messaggio riparte da zero.
        if (!chatOn) turns.clear()
        turns.add(ChatTurn(fromUser = true, text = text.trim(), image = bitmap))
        store.saveChat(section.id, turns.toList())
        text = ""
        bitmap = null
        request()
    }

    fun newChat() {
        generation++
        // La chat precedente non si perde: finisce nella Cronologia.
        store.archiveChat(section.id, turns.toList())
        turns.clear()
        store.saveChat(section.id, emptyList())
        text = ""
        bitmap = null
        error = null
        loading = false
    }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(36.dp).clip(CircleShape).background(accent.container),
                            contentAlignment = Alignment.Center,
                        ) { Text(section.emoji, fontSize = 18.sp) }
                        Spacer(Modifier.width(10.dp))
                        Text(section.title, fontWeight = FontWeight.Bold)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") }
                },
                actions = {
                    if (turns.isNotEmpty()) {
                        TextButton(onClick = { newChat() }, colors = ButtonDefaults.textButtonColors(contentColor = accent.strong)) {
                            Text("Nuova chat")
                        }
                    }
                    Text("Chat", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
                    Switch(
                        checked = chatOn,
                        onCheckedChange = { chatOn = it; store.setChatEnabled(section.id, it) },
                        colors = SwitchDefaults.colors(
                            checkedTrackColor = accent.strong,
                            checkedThumbColor = accent.onStrong,
                            checkedBorderColor = accent.strong,
                        ),
                        modifier = Modifier.padding(horizontal = 8.dp),
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .consumeWindowInsets(padding)
                .imePadding()
                .fillMaxSize(),
        ) {
            if (turns.isEmpty()) {
                Column(
                    modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Box(
                        modifier = Modifier.size(96.dp).clip(CircleShape).background(accent.container),
                        contentAlignment = Alignment.Center,
                    ) { Text(section.emoji, fontSize = 44.sp) }
                    Spacer(Modifier.height(20.dp))
                    Text(
                        section.hint,
                        style = MaterialTheme.typography.titleMedium,
                        color = cs.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                    )
                    error?.let {
                        Spacer(Modifier.height(16.dp))
                        ErrorCard(it)
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    items(count = turns.size, key = { it }) { i ->
                        val turn = turns[i]
                        if (turn.fromUser) {
                            UserBubble(turn, accent)
                        } else {
                            // La riga [[LISTA: ...]] decisa dall'AI non si mostra: serve solo per il tasto "Alla lista".
                            val (shownText, listNames) = splitShoppingMarker(turn.text)
                            AiCard(
                                raw = shownText,
                                accent = accent,
                                onCopy = { clipboard.setText(AnnotatedString(plainText(shownText))) },
                                onToList = if (listNames.isEmpty()) null else ({ listItems = listNames }),
                                onShare = {
                                    val send = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, plainText(shownText))
                                    }
                                    context.startActivity(Intent.createChooser(send, null))
                                },
                            )
                        }
                    }
                    if (loading) {
                        item(key = "loading") {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh),
                                shape = RoundedCornerShape(24.dp),
                            ) {
                                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.5.dp, color = accent.strong)
                                    Spacer(Modifier.width(12.dp))
                                    Text("Sto pensando...", color = cs.onSurfaceVariant)
                                }
                            }
                        }
                    } else if (needsRetry) {
                        item(key = "retry") {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                ErrorCard(error ?: "La risposta non è arrivata.")
                                FilledTonalButton(
                                    onClick = { request() },
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = accent.container,
                                        contentColor = accent.onContainer,
                                    ),
                                ) { Text("Riprova") }
                            }
                        }
                    }
                }
            }

            if (turns.isNotEmpty() && !needsRetry) {
                error?.let { Box(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) { ErrorCard(it) } }
            }

            if (scanning) {
                Text(
                    "Cerco il prodotto...",
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.onSurfaceVariant,
                )
            }

            Composer(
                text = text,
                onText = { text = it },
                bitmap = bitmap,
                onRemovePhoto = { bitmap = null },
                onScan = { scanBarcode() },
                chips = quickChips(section.id),
                onChip = { appendText(it) },
                onCamera = { launchCamera() },
                onGallery = {
                    pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                onMic = { startMic() },
                onSend = { send() },
                canSend = !loading && (text.isNotBlank() || bitmap != null),
                accent = accent,
                followUp = turns.isNotEmpty() && chatOn,
            )
        }
    }

    listItems?.let { found ->
        AddToShoppingDialog(
            items = found,
            onAdd = { chosen ->
                val n = onAddToShopping(chosen)
                listItems = null
                Toast.makeText(
                    context,
                    if (n > 0) "Aggiunti alla lista: $n" else "Erano già nella lista.",
                    Toast.LENGTH_SHORT,
                ).show()
            },
            onDismiss = { listItems = null },
        )
    }
}

@Composable
private fun UserBubble(turn: ChatTurn, accent: Accent) {
    val cs = MaterialTheme.colorScheme
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
        Column(
            modifier = Modifier
                .widthIn(max = 320.dp)
                .clip(RoundedCornerShape(24.dp, 24.dp, 6.dp, 24.dp))
                .background(accent.container)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (turn.image != null) {
                Image(
                    bitmap = turn.image.asImageBitmap(),
                    contentDescription = "Foto",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(16.dp)),
                )
            } else if (turn.hadImage) {
                Text("📷 Foto", color = accent.onContainer.copy(alpha = 0.8f), style = MaterialTheme.typography.labelLarge)
            }
            if (turn.text.isNotBlank()) {
                SelectionContainer {
                    Text(turn.text, color = accent.onContainer, style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}

@Composable
private fun AiCard(raw: String, accent: Accent, onCopy: () -> Unit, onToList: (() -> Unit)?, onShare: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh),
        shape = RoundedCornerShape(6.dp, 28.dp, 28.dp, 28.dp),
    ) {
        Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 8.dp)) {
            SelectionContainer { MarkdownText(raw, accent = accent.strong) }
            Spacer(Modifier.height(4.dp))
            Row {
                TextButton(onClick = onCopy, colors = ButtonDefaults.textButtonColors(contentColor = accent.strong)) {
                    Icon(Icons.Filled.ContentCopy, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Copia")
                }
                TextButton(onClick = onShare, colors = ButtonDefaults.textButtonColors(contentColor = accent.strong)) {
                    Icon(Icons.Filled.Share, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Condividi")
                }
                if (onToList != null) {
                    TextButton(onClick = onToList, colors = ButtonDefaults.textButtonColors(contentColor = accent.strong)) {
                        Icon(Icons.Filled.AddShoppingCart, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Alla lista")
                    }
                }
            }
        }
    }
}

@Composable
private fun ErrorCard(message: String) {
    val cs = MaterialTheme.colorScheme
    Card(
        colors = CardDefaults.cardColors(containerColor = cs.errorContainer, contentColor = cs.onErrorContainer),
        shape = RoundedCornerShape(24.dp),
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ErrorOutline, null)
            Spacer(Modifier.width(12.dp))
            Text(message)
        }
    }
}

/** Colori della sezione: gli stessi della sua scheda nella Home. */
private class Accent(val container: Color, val onContainer: Color, val strong: Color, val onStrong: Color)

@Composable
private fun accentFor(index: Int): Accent {
    val cs = MaterialTheme.colorScheme
    return when (index.coerceAtLeast(0) % 3) {
        0 -> Accent(cs.primaryContainer, cs.onPrimaryContainer, cs.primary, cs.onPrimary)
        1 -> Accent(cs.secondaryContainer, cs.onSecondaryContainer, cs.secondary, cs.onSecondary)
        else -> Accent(cs.tertiaryContainer, cs.onTertiaryContainer, cs.tertiary, cs.onTertiary)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun Composer(
    text: String,
    onText: (String) -> Unit,
    bitmap: Bitmap?,
    onRemovePhoto: () -> Unit,
    onScan: () -> Unit,
    chips: List<QuickChip>,
    onChip: (String) -> Unit,
    onCamera: () -> Unit,
    onGallery: () -> Unit,
    onMic: () -> Unit,
    onSend: () -> Unit,
    canSend: Boolean,
    followUp: Boolean,
    accent: Accent,
) {
    val cs = MaterialTheme.colorScheme
    var menu by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .background(cs.surfaceContainerHigh, RoundedCornerShape(34.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp),
    ) {
        bitmap?.let { bmp ->
            Box(Modifier.padding(start = 8.dp, top = 6.dp, bottom = 4.dp).clip(RoundedCornerShape(18.dp))) {
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = "Foto",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(88.dp),
                )
                FilledIconButton(
                    onClick = onRemovePhoto,
                    modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).size(26.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = Color.Black.copy(alpha = 0.55f),
                        contentColor = Color.White,
                    ),
                ) { Icon(Icons.Filled.Close, "Rimuovi foto", Modifier.size(14.dp)) }
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(start = 6.dp, top = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            chips.forEach { c ->
                AssistChip(onClick = { onChip(c.text) }, label = { Text(c.label) })
            }
        }
        Row(verticalAlignment = Alignment.Bottom) {
            // "+" apre la scelta tra fotocamera e galleria.
            Box(Modifier.padding(bottom = 4.dp)) {
                IconButton(onClick = { menu = true }) {
                    Icon(Icons.Filled.Add, "Aggiungi foto", tint = cs.onSurface)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Scatta una foto") },
                        leadingIcon = { Icon(Icons.Filled.CameraAlt, null, tint = accent.strong) },
                        onClick = { menu = false; onCamera() },
                    )
                    DropdownMenuItem(
                        text = { Text("Dalla galleria") },
                        leadingIcon = { Icon(Icons.Filled.PhotoLibrary, null, tint = accent.strong) },
                        onClick = { menu = false; onGallery() },
                    )
                    DropdownMenuItem(
                        text = { Text("Scansiona codice a barre") },
                        leadingIcon = { Icon(Icons.Filled.QrCodeScanner, null, tint = accent.strong) },
                        onClick = { menu = false; onScan() },
                    )
                }
            }
            TextField(
                value = text,
                onValueChange = onText,
                modifier = Modifier.weight(1f),
                placeholder = { Text(if (followUp) "Chiedi di più..." else "Scrivi qui...") },
                maxLines = 5,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    disabledContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent,
                    cursorColor = accent.strong,
                ),
            )
            Box(Modifier.padding(bottom = 4.dp)) {
                IconButton(onClick = onMic) { Icon(Icons.Filled.Mic, "Detta a voce", tint = cs.onSurface) }
            }
            FilledIconButton(
                onClick = onSend,
                enabled = canSend,
                modifier = Modifier.padding(start = 2.dp, bottom = 4.dp, end = 2.dp).size(48.dp),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = accent.strong,
                    contentColor = accent.onStrong,
                    disabledContainerColor = accent.container,
                    disabledContentColor = accent.onContainer.copy(alpha = 0.6f),
                ),
            ) { Icon(Icons.AutoMirrored.Filled.Send, "Invia") }
        }
    }
}
