package com.promptbox

import android.graphics.Bitmap
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale

data class ReceiptItem(val name: String, val price: Double, val dept: String)

/** Uno scontrino letto dall'AI. [at] è la data dello scontrino (ms). */
data class Receipt(val id: String, val at: Long, val shop: String, val total: Double, val items: List<ReceiptItem>)

object ReceiptTools {
    /** Modelli per gli scontrini: i più precisi per primi (hanno la quota gratuita); in fondo quello scelto nelle Impostazioni. */
    private const val PRIMARY_MODEL = "gemini-3.7-flash"
    private const val SECOND_MODEL = "gemini-3.5-flash"

    private val SYSTEM =
        "Nell'immagine c'è uno scontrino italiano. Leggilo con attenzione, riga per riga dall'alto in basso, e rispondi SOLO con un oggetto JSON: " +
            "{\"negozio\":\"nome del negozio\",\"data\":\"AAAA-MM-GG\",\"totale\":12.34," +
            "\"articoli\":[{\"nome\":\"Latte intero\",\"prezzo\":1.29,\"reparto\":\"Latticini e uova\"}]}. " +
            "Regole: un elemento per ogni riga di prodotto, senza saltarne e senza inventarne; " +
            "nomi leggibili e corti in italiano (espandi le abbreviazioni dello scontrino); " +
            "prezzo = importo pagato per quella riga, numero con il punto decimale (le virgole dello scontrino sono decimali: 1,29 diventa 1.29); " +
            "se la riga ha una quantità (2 x 1,29) o un peso (0,350 kg x 8,90) il prezzo è il totale della riga; " +
            "uno sconto va sottratto dal prodotto a cui si riferisce, non creare righe di sconto; " +
            "ignora le righe che non sono prodotti: subtotale, IVA, resto, contanti, carta, pagamento, punti fedeltà, numero dello scontrino; " +
            "totale = importo totale pagato; " +
            "reparto = uno tra: " + Depts.ORDER.joinToString(", ") + ". " +
            "Se la data non si legge scrivi \"\". Se manca il totale scrivi 0. " +
            "Prima di rispondere controlla che la somma dei prezzi sia uguale al totale: se non lo è, rileggi le righe. " +
            "Se l'immagine non è uno scontrino rispondi {\"errore\":\"non è uno scontrino\"}."

    /** Una lettura: lo scontrino, il totale scritto sullo scontrino (0 se non c'è) e la risposta grezza dell'AI. */
    class Parsed(val receipt: Receipt, val stated: Double, val raw: String)

    /** Lettura finita: [warning] c'è solo se i conti non tornano, [calls] sono le richieste fatte all'AI. */
    class Checked(val receipt: Receipt, val warning: String?, val calls: Int)

    private fun itemsSum(p: Parsed) = p.receipt.items.sumOf { it.price }

    /** Quanto la somma delle righe si discosta dal totale scritto sullo scontrino (0 se il totale non c'è). */
    internal fun gap(p: Parsed): Double = if (p.stated > 0.0) Math.abs(itemsSum(p) - p.stated) else 0.0

    /** Differenza accettata: 2% del totale, e comunque almeno 10 centesimi. */
    internal fun tolerance(p: Parsed): Double = maxOf(0.10, 0.02 * p.stated)

    private suspend fun readOnce(apiKey: String, models: List<String>, bitmap: Bitmap, text: String): Result<Parsed> =
        GeminiClient.askJson(apiKey, models, SYSTEM, text, bitmap).mapCatching { parseRaw(it) }

    /**
     * Legge lo scontrino. Se la lettura fallisce riprova una volta con gli stessi modelli; se la somma delle righe non
     * torna col totale chiede all'AI di rileggere guardando di nuovo la foto e tiene la lettura più vicina al totale.
     */
    suspend fun readChecked(apiKey: String, model: String, bitmap: Bitmap): Result<Checked> {
        val models = listOf(PRIMARY_MODEL, SECOND_MODEL, model).distinct()
        var calls = 1
        var first = readOnce(apiKey, models, bitmap, "Leggi lo scontrino.")
        val failure = first.exceptionOrNull()
        if (failure != null && !failure.message.orEmpty().contains("non sembra uno scontrino")) {
            calls++
            first = readOnce(apiKey, models, bitmap, "Leggi lo scontrino. Rispondi con un JSON completo e valido.")
        }
        val p = first.getOrElse { return Result.failure(it) }
        if (gap(p) <= tolerance(p)) return Result.success(Checked(p.receipt, null, calls))

        calls++
        val verify = "Questa è una prima lettura dello scontrino, che può avere righe mancanti o prezzi sbagliati:\n${p.raw}\n" +
            "La somma dei prezzi è ${euro(itemsSum(p))} ma il totale dello scontrino è ${euro(p.stated)}. " +
            "Riguarda l'immagine riga per riga, correggi e aggiungi ciò che manca e rispondi con l'oggetto JSON completo e corretto."
        val second = readOnce(apiKey, models, bitmap, verify).getOrNull()
        val best = if (second != null && gap(second) < gap(p)) second else p
        val warning = if (gap(best) > tolerance(best)) {
            "Attenzione: la somma dei prodotti (${euro(itemsSum(best))}) non coincide con il totale (${euro(best.stated)}). " +
                "Può mancare una riga o esserci uno sconto sul totale: controlla prima di confermare."
        } else null
        return Result.success(Checked(best.receipt, warning, calls))
    }

    fun parse(raw: String): Receipt = parseRaw(raw).receipt

    fun parseRaw(raw: String): Parsed {
        val clean = raw.replace("```json", "").replace("```", "").trim()
        val a = clean.indexOf('{')
        val b = clean.lastIndexOf('}')
        require(a >= 0 && b > a) { "Non riesco a leggere lo scontrino. Riprova a leggere la stessa foto, o rifalla più nitida." }
        val o = JSONObject(clean.substring(a, b + 1))
        require(!o.has("errore")) { "Questa non sembra uno scontrino." }
        val arr = o.optJSONArray("articoli") ?: JSONArray()
        val items = (0 until arr.length()).mapNotNull { i ->
            val x = arr.optJSONObject(i) ?: return@mapNotNull null
            val name = x.optString("nome").trim()
            if (name.isEmpty()) return@mapNotNull null
            val dept = x.optString("reparto").trim().let { if (it in Depts.ORDER) it else "Altro" }
            ReceiptItem(name, x.optDouble("prezzo", 0.0), dept)
        }
        require(items.isNotEmpty()) { "Nessun articolo trovato nello scontrino." }
        val stated = o.optDouble("totale", 0.0).takeIf { it > 0.0 } ?: 0.0
        val total = if (stated > 0.0) stated else items.sumOf { it.price }
        val now = System.currentTimeMillis()
        val at = runCatching {
            LocalDate.parse(o.optString("data")).atTime(12, 0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        }.getOrDefault(now)
        return Parsed(Receipt("r$now", at, o.optString("negozio").trim(), total, items), stated, clean.substring(a, b + 1))
    }

    fun euro(v: Double): String = String.format(Locale.ITALY, "%.2f €", v)

    fun dateText(at: Long): String {
        val d = java.time.Instant.ofEpochMilli(at).atZone(ZoneId.systemDefault()).toLocalDate()
        return String.format("%02d/%02d/%d", d.dayOfMonth, d.monthValue, d.year)
    }

    fun listToJson(list: List<Receipt>): String {
        val arr = JSONArray()
        list.forEach { r ->
            val items = JSONArray()
            r.items.forEach { items.put(JSONObject().put("n", it.name).put("p", it.price).put("d", it.dept)) }
            arr.put(JSONObject().put("i", r.id).put("a", r.at).put("s", r.shop).put("t", r.total).put("l", items))
        }
        return arr.toString()
    }

    fun listFromJson(raw: String?): List<Receipt> = runCatching {
        val arr = JSONArray(raw ?: "[]")
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val l = o.getJSONArray("l")
            Receipt(
                id = o.getString("i"),
                at = o.getLong("a"),
                shop = o.optString("s", ""),
                total = o.optDouble("t", 0.0),
                items = (0 until l.length()).map { j ->
                    val x = l.getJSONObject(j)
                    ReceiptItem(x.getString("n"), x.optDouble("p", 0.0), x.optString("d", "Altro"))
                },
            )
        }
    }.getOrDefault(emptyList())
}
