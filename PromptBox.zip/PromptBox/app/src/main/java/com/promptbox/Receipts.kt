package com.promptbox

import android.graphics.Bitmap
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale

data class ReceiptItem(val name: String, val price: Double, val dept: String, val qty: String = "")

/** Uno scontrino letto dall'AI. [at] è la data dello scontrino (ms). */
data class Receipt(val id: String, val at: Long, val shop: String, val total: Double, val items: List<ReceiptItem>)

object ReceiptTools {
    /** Modelli per gli scontrini: i più precisi per primi (hanno la quota gratuita); in fondo quello scelto nelle Impostazioni. */
    private const val PRIMARY_MODEL = "gemini-3.7-flash"
    private const val SECOND_MODEL = "gemini-3.5-flash"

    private val SYSTEM =
        "Nell'immagine c'è uno scontrino italiano. Leggilo con attenzione, riga per riga dall'alto in basso, e rispondi SOLO con un oggetto JSON: " +
            "{\"negozio\":\"nome del negozio\",\"data\":\"AAAA-MM-GG\",\"totale\":12.34," +
            "\"articoli\":[{\"nome\":\"Latte intero\",\"quantita\":\"2\",\"prezzo\":1.29,\"reparto\":\"Latticini e uova\"}]}. " +
            "Regole: un elemento per ogni riga di prodotto, senza saltarne e senza inventarne; " +
            "nomi leggibili e corti in italiano (espandi le abbreviazioni dello scontrino); " +
            "prezzo = importo pagato per quella riga, numero con il punto decimale (le virgole dello scontrino sono decimali: 1,29 diventa 1.29); " +
            "quantita = quanti pezzi si sono comprati, solo il numero (la riga \"2 x 1,29\" ha quantita \"2\"); per un prodotto a peso scrivi il peso (\"350 g\"); se la riga non la indica scrivi \"\"; "+
            "se la riga ha una quantità (2 x 1,29) o un peso (0,350 kg x 8,90) il prezzo è il totale della riga; " +
            "uno sconto va sottratto dal prodotto a cui si riferisce, non creare righe di sconto; " +
            "ignora le righe che non sono prodotti: subtotale, IVA, resto, contanti, carta, pagamento, punti fedeltà, numero dello scontrino; " +
            "totale = importo totale pagato; " +
            "reparto = uno tra: " + Depts.ORDER.joinToString(", ") + ". " +
            "Il negozio può non essere un supermercato (casalinghi, discount): scegli \"Casa e igiene\" per tutto ciò che non si mangia né si beve e serve in casa " +
            "(detersivi, anticalcare, dentifricio, deodorante, spazzolini, carta, sacchetti, utensili e articoli da cucina come portaposate, mandolina, cuffie copripiatti); " +
            "i reparti di cibo (Dispensa, Bevande, Pane e cereali...) SOLO per ciò che si mangia o si beve; \"Altro\" per il resto (elettronica, abbigliamento, giocattoli, cancelleria). " +
            "Abbreviazioni frequenti: S/CALCARE = anticalcare, DENT = dentifricio, DEO = deodorante, C/ = con, PZ = pezzi. " +
            "Se il nome della riga è generico (\"ARTICOLO E.\") scrivilo com'è, senza inventare cosa sia. " +
            "Se la data non si legge scrivi \"\". Se manca il totale scrivi 0. " +
            "Prima di rispondere controlla che la somma dei prezzi sia uguale al totale: se non lo è, rileggi le righe. " +
            "Se l'immagine non è uno scontrino rispondi {\"errore\":\"non è uno scontrino\"}."

    /** Una lettura: lo scontrino, il totale scritto sullo scontrino (0 se non c'è) e la risposta grezza dell'AI. */
    class Parsed(val receipt: Receipt, val stated: Double, val raw: String)

    /** Lettura finita: [warning] c'è solo se i conti non tornano, [calls] sono le richieste fatte all'AI. */
    class Checked(val receipt: Receipt, val warning: String?, val calls: Int)

    private fun itemsSum(p: Parsed) = p.receipt.items.sumOf { it.price }

    /** Quanto la somma delle righe si discosta dal totale scritto sullo scontrino (0 se il totale non c'è). */
    internal fun gap(p: Parsed): Double = if (p.stated > 0.0) Math.abs(itemsSum(p) - p.stated) else 0.0

    /** Differenza accettata: 2% del totale, e comunque almeno 10 centesimi. */
    internal fun tolerance(p: Parsed): Double = maxOf(0.10, 0.02 * p.stated)

    /** Dopo quanti ms senza risposta parte in parallelo una seconda richiesta, con un altro modello. */
    private const val HEDGE_MS = 7_000L

    /**
     * Una richiesta; se il primo modello è lento ne parte una seconda in parallelo con un altro modello e vale la prima
     * risposta riuscita (l'altra si annulla). Le richieste in più si usano solo quando serve, per non finire la quota gratuita.
     */
    private suspend fun askFastest(apiKey: String, models: List<String>, bitmap: Bitmap, text: String): Result<String> = coroutineScope {
        val started = AtomicBoolean(false)
        val done = Channel<Pair<Boolean, Result<String>>>(Channel.UNLIMITED)
        val a = launch { done.send(false to GeminiClient.askJson(apiKey, models, SYSTEM, text, bitmap)) }
        val b = launch {
            delay(HEDGE_MS)
            started.set(true)
            done.send(true to GeminiClient.askJson(apiKey, models.drop(1).ifEmpty { models }, SYSTEM, text, bitmap))
        }
        val first = done.receive()
        val result = when {
            first.second.isSuccess -> first.second
            // La prima è fallita (i modelli di riserva li ha già provati lei) e la seconda non è ancora partita: inutile aspettarla.
            !first.first && !started.get() -> first.second
            // Una è fallita e l'altra è in corso: vale quella, se riesce.
            else -> done.receive().second.takeIf { it.isSuccess } ?: first.second
        }
        a.cancel()
        b.cancel()
        result
    }

    private suspend fun readOnce(apiKey: String, models: List<String>, bitmap: Bitmap, text: String): Result<Parsed> =
        askFastest(apiKey, models, bitmap, text).mapCatching { parseRaw(it) }

    /**
     * Legge lo scontrino. Se la lettura fallisce riprova una volta con gli stessi modelli; se la somma delle righe non
     * torna col totale chiede all'AI di rileggere guardando di nuovo la foto e tiene la lettura più vicina al totale.
     */
    suspend fun readChecked(apiKey: String, model: String, bitmap: Bitmap, onStage: (String) -> Unit = {}): Result<Checked> {
        val models = listOf(PRIMARY_MODEL, SECOND_MODEL, model).distinct()
        var calls = 1
        var first = readOnce(apiKey, models, bitmap, "Leggi lo scontrino.")
        val failure = first.exceptionOrNull()
        if (failure != null && !failure.message.orEmpty().contains("non sembra uno scontrino")) {
            onStage("Riprovo a leggere…")
            calls++
            first = readOnce(apiKey, models, bitmap, "Leggi lo scontrino. Rispondi con un JSON completo e valido.")
        }
        val p = first.getOrElse { return Result.failure(it) }
        if (gap(p) <= tolerance(p)) return Result.success(Checked(p.receipt, null, calls))

        calls++
        onStage("Controllo i conti…")
        val verify = "Questa è una prima lettura dello scontrino, che può avere righe mancanti o prezzi sbagliati:\n${p.raw}\n" +
            "La somma dei prezzi è ${euro(itemsSum(p))} ma il totale dello scontrino è ${euro(p.stated)}. " +
            "Riguarda l'immagine riga per riga, correggi e aggiungi ciò che manca e rispondi con l'oggetto JSON completo e corretto."
        val second = readOnce(apiKey, models, bitmap, verify).getOrNull()
        val best = if (second != null && gap(second) < gap(p)) second else p
        val warning = if (gap(best) > tolerance(best)) {
            "Attenzione: la somma dei prodotti (${euro(itemsSum(best))}) non coincide con il totale (${euro(best.stated)}). " +
                "Può mancare una riga o esserci uno sconto sul totale: controlla prima di confermare."
        } else null
        return Result.success(Checked(best.receipt, warning, calls))
    }

    fun parse(raw: String): Receipt = parseRaw(raw).receipt

    /** La quantità letta dall'AI come testo: "2" e 2 diventano "2", "1" (un solo pezzo) e il vuoto restano vuoti. */
    internal fun cleanQty(v: Any?): String {
        val t = when (v) {
            null, JSONObject.NULL -> ""
            is Number -> if (v.toDouble() % 1.0 == 0.0) v.toLong().toString() else v.toString()
            else -> v.toString().trim()
        }
        return if (t == "1" || t == "0") "" else t.take(20)
    }

    fun parseRaw(raw: String): Parsed {
        val clean = raw.replace("```json", "").replace("```", "").trim()
        val a = clean.indexOf('{')
        val b = clean.lastIndexOf('}')
        require(a >= 0 && b > a) { "Non riesco a leggere lo scontrino. Riprova a leggere la stessa foto, o rifalla più nitida." }
        val o = JSONObject(clean.substring(a, b + 1))
        require(!o.has("errore")) { "Questa non sembra uno scontrino." }
        val arr = o.optJSONArray("articoli") ?: JSONArray()
        val items = (0 until arr.length()).mapNotNull { i ->
            val x = arr.optJSONObject(i) ?: return@mapNotNull null
            val name = x.optString("nome").trim()
            if (name.isEmpty()) return@mapNotNull null
            val dept0 = x.optString("reparto").trim().let { if (it in Depts.ORDER) it else "Altro" }
            // Rete di sicurezza: se l'AI mette un detersivo o un utensile in un reparto di cibo, lo riporta in Casa e igiene.
            val dept = if (dept0 != "Casa e igiene" && Stock.looksHome(name)) "Casa e igiene" else dept0
            ReceiptItem(name, x.optDouble("prezzo", 0.0), dept, cleanQty(x.opt("quantita")))
        }
        require(items.isNotEmpty()) { "Nessun articolo trovato nello scontrino." }
        val stated = o.optDouble("totale", 0.0).takeIf { it > 0.0 } ?: 0.0
        val total = if (stated > 0.0) stated else items.sumOf { it.price }
        val now = System.currentTimeMillis()
        val at = runCatching {
            LocalDate.parse(o.optString("data")).atTime(12, 0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        }.getOrDefault(now)
        return Parsed(Receipt("r$now", at, o.optString("negozio").trim(), total, items), stated, clean.substring(a, b + 1))
    }

    fun euro(v: Double): String = String.format(Locale.ITALY, "%.2f €", v)

    fun dateText(at: Long): String {
        val d = java.time.Instant.ofEpochMilli(at).atZone(ZoneId.systemDefault()).toLocalDate()
        return String.format("%02d/%02d/%d", d.dayOfMonth, d.monthValue, d.year)
    }

    fun listToJson(list: List<Receipt>): String {
        val arr = JSONArray()
        list.forEach { r ->
            val items = JSONArray()
            r.items.forEach { items.put(JSONObject().put("n", it.name).put("p", it.price).put("d", it.dept).put("q", it.qty)) }
            arr.put(JSONObject().put("i", r.id).put("a", r.at).put("s", r.shop).put("t", r.total).put("l", items))
        }
        return arr.toString()
    }

    fun listFromJson(raw: String?): List<Receipt> = runCatching {
        val arr = JSONArray(raw ?: "[]")
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val l = o.getJSONArray("l")
            Receipt(
                id = o.getString("i"),
                at = o.getLong("a"),
                shop = o.optString("s", ""),
                total = o.optDouble("t", 0.0),
                items = (0 until l.length()).map { j ->
                    val x = l.getJSONObject(j)
                    ReceiptItem(x.getString("n"), x.optDouble("p", 0.0), x.optString("d", "Altro"), x.optString("q", ""))
                },
            )
        }
    }.getOrDefault(emptyList())
}
