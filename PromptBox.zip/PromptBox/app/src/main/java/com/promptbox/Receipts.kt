package com.promptbox

import android.graphics.Bitmap
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale

data class ReceiptItem(val name: String, val price: Double, val dept: String)

/** Uno scontrino letto dall'AI. [at] è la data dello scontrino (ms). */
data class Receipt(val id: String, val at: Long, val shop: String, val total: Double, val items: List<ReceiptItem>)

object ReceiptTools {
    private val SYSTEM =
        "Nell'immagine c'è uno scontrino di un negozio. Leggilo e rispondi SOLO con un oggetto JSON, senza backtick e senza altro testo: " +
            "{\"negozio\":\"nome del negozio\",\"data\":\"AAAA-MM-GG\",\"totale\":12.34," +
            "\"articoli\":[{\"nome\":\"Latte intero\",\"prezzo\":1.29,\"reparto\":\"Latticini e uova\"}]}. " +
            "Regole: un elemento per ogni riga di prodotto; nomi leggibili e corti in italiano (espandi le abbreviazioni dello scontrino); " +
            "prezzo = importo pagato per quella riga, numero con il punto decimale, dopo eventuali sconti; " +
            "reparto = uno tra: " + Depts.ORDER.joinToString(", ") + ". " +
            "Se la data non si legge scrivi \"\". Se manca il totale scrivi 0. " +
            "Se l'immagine non è uno scontrino rispondi {\"errore\":\"non è uno scontrino\"}."

    suspend fun read(apiKey: String, model: String, bitmap: Bitmap): Result<Receipt> =
        GeminiClient.ask(apiKey, model, SYSTEM, "Leggi lo scontrino.", bitmap).mapCatching { parse(it) }

    fun parse(raw: String): Receipt {
        val clean = raw.replace("```json", "").replace("```", "").trim()
        val a = clean.indexOf('{')
        val b = clean.lastIndexOf('}')
        require(a >= 0 && b > a) { "Non riesco a leggere lo scontrino. Riprova con una foto più nitida." }
        val o = JSONObject(clean.substring(a, b + 1))
        require(!o.has("errore")) { "Questa non sembra uno scontrino." }
        val arr = o.optJSONArray("articoli") ?: JSONArray()
        val items = (0 until arr.length()).mapNotNull { i ->
            val x = arr.optJSONObject(i) ?: return@mapNotNull null
            val name = x.optString("nome").trim()
            if (name.isEmpty()) return@mapNotNull null
            val dept = x.optString("reparto").trim().let { if (it in Depts.ORDER) it else "Altro" }
            ReceiptItem(name, x.optDouble("prezzo", 0.0), dept)
        }
        require(items.isNotEmpty()) { "Nessun articolo trovato nello scontrino." }
        val total = o.optDouble("totale", 0.0).takeIf { it > 0.0 } ?: items.sumOf { it.price }
        val now = System.currentTimeMillis()
        val at = runCatching {
            LocalDate.parse(o.optString("data")).atTime(12, 0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        }.getOrDefault(now)
        return Receipt("r$now", at, o.optString("negozio").trim(), total, items)
    }

    fun euro(v: Double): String = String.format(Locale.ITALY, "%.2f €", v)

    fun dateText(at: Long): String {
        val d = java.time.Instant.ofEpochMilli(at).atZone(ZoneId.systemDefault()).toLocalDate()
        return String.format("%02d/%02d/%d", d.dayOfMonth, d.monthValue, d.year)
    }

    fun listToJson(list: List<Receipt>): String {
        val arr = JSONArray()
        list.forEach { r ->
            val items = JSONArray()
            r.items.forEach { items.put(JSONObject().put("n", it.name).put("p", it.price).put("d", it.dept)) }
            arr.put(JSONObject().put("i", r.id).put("a", r.at).put("s", r.shop).put("t", r.total).put("l", items))
        }
        return arr.toString()
    }

    fun listFromJson(raw: String?): List<Receipt> = runCatching {
        val arr = JSONArray(raw ?: "[]")
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val l = o.getJSONArray("l")
            Receipt(
                id = o.getString("i"),
                at = o.getLong("a"),
                shop = o.optString("s", ""),
                total = o.optDouble("t", 0.0),
                items = (0 until l.length()).map { j ->
                    val x = l.getJSONObject(j)
                    ReceiptItem(x.getString("n"), x.optDouble("p", 0.0), x.optString("d", "Altro"))
                },
            )
        }
    }.getOrDefault(emptyList())
}
