package com.promptbox

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Kitchen
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.sp

private data class NavItem(val screen: String, val label: String, val icon: ImageVector)

private val NAV_ITEMS = listOf(
    NavItem("home", "Home", Icons.Filled.Home),
    NavItem("shopping", "Spesa", Icons.Filled.ShoppingCart),
    NavItem("frigo", "Frigo", Icons.Filled.Kitchen),
    NavItem("dispensa", "Dispensa", Icons.Filled.Inventory2),
    NavItem("settings", "Impostazioni", Icons.Filled.Settings),
)

/** Schermate che mostrano la barra di navigazione in basso. */
val NAV_SCREENS: Set<String> = NAV_ITEMS.map { it.screen }.toSet()

@Composable
fun PrismaNavBar(current: String, onSelect: (String) -> Unit) {
    NavigationBar {
        NAV_ITEMS.forEach { item ->
            NavigationBarItem(
                selected = current == item.screen,
                onClick = { onSelect(item.screen) },
                icon = { Icon(item.icon, null) },
                label = { Text(item.label, fontSize = 11.sp, maxLines = 1, softWrap = false) },
            )
        }
    }
}

/** Barra laterale per i tablet: stesse voci della barra in basso. */
@Composable
fun PrismaNavRail(current: String, onSelect: (String) -> Unit) {
    NavigationRail {
        NAV_ITEMS.forEach { item ->
            NavigationRailItem(
                selected = current == item.screen,
                onClick = { onSelect(item.screen) },
                icon = { Icon(item.icon, null) },
                label = { Text(item.label, fontSize = 11.sp, maxLines = 1, softWrap = false) },
            )
        }
    }
}
