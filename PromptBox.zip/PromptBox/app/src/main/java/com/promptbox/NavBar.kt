package com.promptbox

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class NavItem(val id: String, val label: String, val icon: ImageVector)

/** Tre voci: Prisma (i prompt: prima "Home", rinominata perché accanto a Casa sembrava la stessa cosa), Casa (un'area sola con schede: cucina e prodotti della casa) e Impostazioni. */
private val NAV_ITEMS = listOf(
    NavItem("home", "Prisma", Icons.Filled.AutoAwesome),
    NavItem("cucina", "Casa", Icons.Filled.Home),
    NavItem("settings", "Impostazioni", Icons.Filled.Settings),
)

/** Le schermate dei posti dove si tengono le cose: frigo, dispensa, congelatore e prodotti della casa (vivono dentro Casa). */
val KITCHEN_SCREENS: Set<String> = setOf("frigo", "dispensa", "congelatore", "casa")

/** Le schede dell'area Casa, nell'ordine in cui compaiono: [id della schermata] to [nome]. */
val KITCHEN_TABS: List<Pair<String, String>> = listOf(
    "shopping" to "Spesa",
    "cucina" to "Riepilogo",
    "frigo" to "Frigo",
    "dispensa" to "Dispensa",
    "congelatore" to "Congelati",
    "casa" to "Pulizie",
    "receipts" to "Scontrini",
)

/** Tutte le schermate dell'area Casa: mostrano la riga di schede in alto e tengono acceso "Casa" nella barra. */
val KITCHEN_AREA: Set<String> = KITCHEN_TABS.map { it.first }.toSet()

/** Schermate che mostrano la barra di navigazione in basso. */
val NAV_SCREENS: Set<String> = setOf("home", "settings") + KITCHEN_AREA

/**
 * Le costanti qui sopra sono le schede di fabbrica. Con le schede create dall'utente ([KitchenTabs]) si usano queste:
 * una scheda nascosta resta una schermata valida (ci si arriva da un avviso), solo non compare nella riga.
 */
fun isKitchenArea(screen: String): Boolean = screen in KITCHEN_AREA || KitchenTabs.isCustom(screen)

/** Le schermate che sono un posto dove si tengono le cose (frigo, dispensa, congelatore, casa o una scheda creata dall'utente). */
fun isPantryScreen(screen: String): Boolean = screen in KITCHEN_SCREENS || KitchenTabs.isCustom(screen)

/** La barra in basso si vede nelle schermate principali e in quelle dell'area Casa. */
fun showsNavBar(screen: String): Boolean = screen in NAV_SCREENS || KitchenTabs.isCustom(screen)

/** Quale voce della barra è accesa per una schermata. */
fun navCurrent(screen: String): String = when {
    isKitchenArea(screen) -> "cucina"
    screen.startsWith("section:") -> "home"
    else -> screen
}

/**
 * Cornice dell'area Casa: la riga di schede in alto (Spesa, Riepilogo, Frigo, Dispensa, Congelati, Scontrini e quelle create
 * dall'utente) sopra la schermata. Tenendo premuta una scheda si apre il menu (Rinomina, Sposta a sinistra/destra, Nascondi;
 * Elimina per le schede create dall'utente); il tasto + in fondo crea una scheda nuova o ripristina quelle nascoste.
 * La riga si prende la barra di stato; la schermata sotto la considera già occupata e non la ripete.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KitchenFrame(
    screen: String,
    tabs: KitchenTabsConfig,
    badges: Map<String, Int>,
    /** Quanti prodotti ha ogni scheda: serve ad avvisare prima di eliminare una scheda creata dall'utente. */
    counts: Map<String, Int>,
    onTab: (String) -> Unit,
    onTabsChange: (KitchenTabsConfig) -> Unit,
    /** Elimina la scheda creata dall'utente [id] con i suoi prodotti. */
    onDeleteTab: (String) -> Unit,
    /** Chiede all'AI le opzioni giuste per il nome di una scheda nuova (temperatura, umidità, spazio); null = nessun suggerimento. */
    onSuggest: suspend (String) -> PlaceConditions? = { null },
    content: @Composable () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val haptic = LocalHapticFeedback.current
    var menuFor by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf<String?>(null) }
    var deleting by remember { mutableStateOf<String?>(null) }
    var adding by remember { mutableStateOf(false) }
    var editingConditions by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(cs.background)
                .windowInsetsPadding(WindowInsets.statusBars)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            val shownTabs = tabs.shown(screen)
            shownTabs.forEachIndexed { index, id ->
                // Un filetto dove si passa dalle schede di lavoro ai luoghi (e viceversa, se l'utente le ha riordinate).
                if (index > 0 && tabGroup(shownTabs[index - 1]) != tabGroup(id)) TabGroupDivider()
                Box {
                    TabChip(
                        label = tabs.label(id),
                        icon = tabIcon(id, selected = screen == id),
                        selected = screen == id,
                        // Pallino sulle schede dove ci sono prodotti scaduti o da usare presto: è lo stesso numero del tasto Casa.
                        badge = badges[id] ?: 0,
                        onClick = { if (screen != id) onTab(id) },
                        onLongClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            menuFor = id
                        },
                    )
                    DropdownMenu(expanded = menuFor == id, onDismissRequest = { menuFor = null }) {
                        DropdownMenuItem(
                            text = { Text("Rinomina") },
                            leadingIcon = { Icon(Icons.Filled.Edit, contentDescription = null) },
                            onClick = { menuFor = null; renaming = id },
                        )
                        DropdownMenuItem(
                            text = { Text("Sposta a sinistra") },
                            leadingIcon = { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null) },
                            enabled = tabs.canMove(id, -1),
                            onClick = { menuFor = null; onTabsChange(tabs.move(id, -1)) },
                        )
                        DropdownMenuItem(
                            text = { Text("Sposta a destra") },
                            leadingIcon = { Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null) },
                            enabled = tabs.canMove(id, 1),
                            onClick = { menuFor = null; onTabsChange(tabs.move(id, 1)) },
                        )
                        DropdownMenuItem(
                            text = { Text("Nascondi") },
                            leadingIcon = { Icon(Icons.Filled.VisibilityOff, contentDescription = null) },
                            enabled = tabs.canHide(id),
                            onClick = {
                                menuFor = null
                                val next = tabs.hide(id)
                                onTabsChange(next)
                                // Se è la scheda aperta, si passa alla prima visibile.
                                if (screen == id) next.visible().firstOrNull()?.let { onTab(it) }
                            },
                        )
                        if (tabs.isCustom(id)) {
                            DropdownMenuItem(
                                text = { Text("Temperatura, umidità, spazio") },
                                leadingIcon = { Icon(Icons.Filled.Thermostat, contentDescription = null) },
                                onClick = { menuFor = null; editingConditions = id },
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("Elimina", color = cs.error) },
                                leadingIcon = { Icon(Icons.Filled.Delete, contentDescription = null, tint = cs.error) },
                                onClick = { menuFor = null; deleting = id },
                            )
                        }
                    }
                }
            }
            AddTabChip(hasHidden = tabs.hiddenTabs().isNotEmpty(), onClick = { adding = true })
        }
        Column(Modifier.weight(1f).fillMaxWidth().consumeWindowInsets(WindowInsets.statusBars)) {
            // Nelle schede create dall'utente con temperatura, umidità o spazio accesi: le letture e gli eventuali avvisi.
            val conditions = if (tabs.isCustom(screen)) tabs.conditions(screen) else PlaceConditions()
            if (conditions.features.isNotEmpty()) PlaceConditionsBar(conditions) { editingConditions = screen }
            Box(Modifier.weight(1f).fillMaxWidth()) { content() }
        }
    }

    renaming?.let { id ->
        RenameTabDialog(
            current = tabs.label(id),
            original = if (tabs.isCustom(id)) null else KITCHEN_TABS.firstOrNull { it.first == id }?.second,
            error = { tabs.nameError(it, id) },
            onSave = { name -> renaming = null; onTabsChange(tabs.rename(id, name)) },
            onDismiss = { renaming = null },
        )
    }
    deleting?.let { id ->
        DeleteTabDialog(
            name = tabs.label(id),
            count = counts[id] ?: 0,
            onConfirm = { deleting = null; onDeleteTab(id) },
            onDismiss = { deleting = null },
        )
    }
    editingConditions?.let { id ->
        PlaceConditionsSheet(
            name = tabs.label(id),
            current = tabs.conditions(id),
            onSave = { next -> editingConditions = null; onTabsChange(tabs.withConditions(id, next)) },
            onDismiss = { editingConditions = null },
        )
    }
    if (adding) {
        AddTabSheet(
            tabs = tabs,
            counts = counts,
            onSuggest = onSuggest,
            onCreate = { name, options ->
                tabs.add(name, options = options)?.let { (next, tab) ->
                    adding = false
                    onTabsChange(next)
                    onTab(tab.id)
                }
            },
            onRestore = { id -> onTabsChange(tabs.show(id)) },
            onDelete = { id -> adding = false; deleting = id },
            onDismiss = { adding = false },
        )
    }
}

/** Icona di una voce; "Casa" porta un pallino col numero dei prodotti scaduti o da usare presto. */
@Composable
private fun NavIcon(item: NavItem, kitchenBadge: Int) {
    if (item.id == "cucina" && kitchenBadge > 0) {
        BadgedBox(badge = { Badge { Text(if (kitchenBadge > 9) "9+" else kitchenBadge.toString()) } }) { Icon(item.icon, null) }
    } else {
        Icon(item.icon, null)
    }
}

@Composable
fun PrismaNavBar(current: String, kitchenBadge: Int = 0, onSelect: (String) -> Unit) {
    NavigationBar {
        NAV_ITEMS.forEach { item ->
            NavigationBarItem(
                selected = current == item.id,
                onClick = { onSelect(item.id) },
                icon = { NavIcon(item, kitchenBadge) },
                label = { Text(item.label, fontSize = 11.sp, maxLines = 1, softWrap = false) },
            )
        }
    }
}

/** Barra laterale per i tablet: stesse voci della barra in basso. */
@Composable
fun PrismaNavRail(current: String, kitchenBadge: Int = 0, onSelect: (String) -> Unit) {
    NavigationRail {
        NAV_ITEMS.forEach { item ->
            NavigationRailItem(
                selected = current == item.id,
                onClick = { onSelect(item.id) },
                icon = { NavIcon(item, kitchenBadge) },
                label = { Text(item.label, fontSize = 11.sp, maxLines = 1, softWrap = false) },
            )
        }
    }
}
