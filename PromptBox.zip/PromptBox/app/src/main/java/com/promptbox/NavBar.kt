package com.promptbox

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Kitchen
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class NavItem(val id: String, val label: String, val icon: ImageVector)

/** Tre voci: Home (i prompt), Casa (un'area sola con schede: cucina e prodotti della casa) e Impostazioni. */
private val NAV_ITEMS = listOf(
    NavItem("home", "Home", Icons.Filled.Home),
    NavItem("cucina", "Casa", Icons.Filled.Kitchen),
    NavItem("settings", "Impostazioni", Icons.Filled.Settings),
)

/** Le schermate dei posti dove si tengono le cose: frigo, dispensa, congelatore e prodotti della casa (vivono dentro Casa). */
val KITCHEN_SCREENS: Set<String> = setOf("frigo", "dispensa", "congelatore", "casa")

/** Le schede dell'area Casa, nell'ordine in cui compaiono: [id della schermata] to [nome]. */
val KITCHEN_TABS: List<Pair<String, String>> = listOf(
    "shopping" to "Spesa",
    "cucina" to "Riepilogo",
    "frigo" to "Frigo",
    "dispensa" to "Dispensa",
    "congelatore" to "Congelati",
    "casa" to "Pulizie",
    "receipts" to "Scontrini",
)

/** Tutte le schermate dell'area Casa: mostrano la riga di schede in alto e tengono acceso "Casa" nella barra. */
val KITCHEN_AREA: Set<String> = KITCHEN_TABS.map { it.first }.toSet()

/** Schermate che mostrano la barra di navigazione in basso. */
val NAV_SCREENS: Set<String> = setOf("home", "settings") + KITCHEN_AREA

/** Quale voce della barra è accesa per una schermata. */
fun navCurrent(screen: String): String = when {
    screen in KITCHEN_AREA -> "cucina"
    screen.startsWith("section:") -> "home"
    else -> screen
}

/**
 * Cornice dell'area Cucina: la riga di schede (Spesa, Riepilogo, Frigo, Dispensa, Congelati, Scontrini) sopra la schermata.
 * La riga si prende la barra di stato; la schermata sotto la considera già occupata e non la ripete.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KitchenFrame(screen: String, badges: Map<String, Int>, onTab: (String) -> Unit, content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(cs.background)
                .windowInsetsPadding(WindowInsets.statusBars)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            KITCHEN_TABS.forEach { (id, label) ->
                FilterChip(
                    selected = screen == id,
                    onClick = { if (screen != id) onTab(id) },
                    label = { Text(label, maxLines = 1, softWrap = false) },
                    // Pallino sulle schede dove ci sono prodotti scaduti o da usare presto: è lo stesso numero del tasto Cucina.
                    trailingIcon = badges[id]?.takeIf { it > 0 }?.let { n -> { Badge { Text(if (n > 9) "9+" else n.toString()) } } },
                    shape = RoundedCornerShape(12.dp),
                )
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth().consumeWindowInsets(WindowInsets.statusBars)) { content() }
    }
}

/** Icona di una voce; "Casa" porta un pallino col numero dei prodotti scaduti o da usare presto. */
@Composable
private fun NavIcon(item: NavItem, kitchenBadge: Int) {
    if (item.id == "cucina" && kitchenBadge > 0) {
        BadgedBox(badge = { Badge { Text(if (kitchenBadge > 9) "9+" else kitchenBadge.toString()) } }) { Icon(item.icon, null) }
    } else {
        Icon(item.icon, null)
    }
}

@Composable
fun PrismaNavBar(current: String, kitchenBadge: Int = 0, onSelect: (String) -> Unit) {
    NavigationBar {
        NAV_ITEMS.forEach { item ->
            NavigationBarItem(
                selected = current == item.id,
                onClick = { onSelect(item.id) },
                icon = { NavIcon(item, kitchenBadge) },
                label = { Text(item.label, fontSize = 11.sp, maxLines = 1, softWrap = false) },
            )
        }
    }
}

/** Barra laterale per i tablet: stesse voci della barra in basso. */
@Composable
fun PrismaNavRail(current: String, kitchenBadge: Int = 0, onSelect: (String) -> Unit) {
    NavigationRail {
        NAV_ITEMS.forEach { item ->
            NavigationRailItem(
                selected = current == item.id,
                onClick = { onSelect(item.id) },
                icon = { NavIcon(item, kitchenBadge) },
                label = { Text(item.label, fontSize = 11.sp, maxLines = 1, softWrap = false) },
            )
        }
    }
}
