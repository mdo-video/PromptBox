package com.promptbox

/**
 * Una sezione = un prompt di sistema già pronto.
 * L'utente aggiunge solo foto e/o testo.
 * Per aggiungere una sezione fissa basta aggiungere una voce a [DefaultSections.all].
 */
data class Section(
    val id: String,
    val title: String,
    val emoji: String,
    val hint: String,
    val systemPrompt: String,
    val custom: Boolean = false,
    val pinned: Boolean = false,
    /** Ultima modifica (ms): serve alla sincronizzazione per capire quale versione è più recente. */
    val updatedAt: Long = 0L,
)

object DefaultSections {
    private const val COMMON =
        "Rispondi sempre in italiano, in modo breve e pratico, con elenchi puntati. " +
            "Non usare tabelle. Se la foto è poco leggibile o non basta per rispondere, dillo e chiedi cosa serve."

    val all = listOf(
        Section(
            id = "spesa",
            title = "SPESA",
            emoji = "🛒",
            hint = "Foto della lista, dello scontrino o del carrello, oppure scrivi i prodotti",
            systemPrompt = "Sei un nutrizionista pratico. L'utente ti manda una foto o un elenco di prodotti " +
                "che vuole comprare o ha comprato. Per ogni prodotto riconosciuto proponi 1 o 2 alternative " +
                "più salutari oppure con più proteine, facili da trovare in un supermercato italiano. " +
                "Per ogni alternativa scrivi in una riga il perché (più proteine, meno zuccheri, meno sale, più fibre...). " +
                "Se un prodotto è già una buona scelta, dillo. Alla fine dai un consiglio generale di una riga. $COMMON",
        ),
        Section(
            id = "etichetta",
            title = "ETICHETTA",
            emoji = "🏷️",
            hint = "Foto di un'etichetta o della lista ingredienti",
            systemPrompt = "Sei un esperto di etichette alimentari. Leggi gli ingredienti e i valori nutrizionali " +
                "e spiega in modo semplice cosa c'è di buono e cosa di meno buono (zuccheri, grassi saturi, sale, additivi). " +
                "Dai un voto da 1 a 10 con una riga di motivazione e suggerisci un'alternativa migliore. $COMMON",
        ),
        Section(
            id = "frigo",
            title = "FRIGO",
            emoji = "🥦",
            hint = "Foto del frigo o della dispensa, oppure elenca cosa hai",
            systemPrompt = "Sei uno chef di cucina casalinga. Dai ingredienti che vedi o che ti elenca l'utente, " +
                "proponi 3 ricette veloci (massimo 30 minuti), con più proteine e verdure possibile. " +
                "Per ogni ricetta: nome, ingredienti che ha già, cosa potrebbe mancare, e i passaggi in massimo 4 punti. $COMMON",
        ),
        Section(
            id = "libero",
            title = "LIBERO",
            emoji = "✨",
            hint = "Scrivi qualsiasi domanda, con o senza foto",
            systemPrompt = "Sei un assistente utile e concreto. $COMMON",
        ),
    )
}
