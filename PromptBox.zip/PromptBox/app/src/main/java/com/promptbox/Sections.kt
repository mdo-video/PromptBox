package com.promptbox

/**
 * Una sezione = un prompt di sistema già pronto.
 * L'utente aggiunge solo foto e/o testo.
 * Per aggiungere una sezione fissa basta aggiungere una voce a [DefaultSections.all].
 */
data class Section(
    val id: String,
    val title: String,
    val emoji: String,
    val hint: String,
    val systemPrompt: String,
    val custom: Boolean = false,
    val pinned: Boolean = false,
    /** Categoria scelta dall'utente: vuota = nessuna categoria. */
    val category: String = "",
    /** Ultima modifica (ms): serve alla sincronizzazione per capire quale versione è più recente. */
    val updatedAt: Long = 0L,
)

object DefaultSections {
    private const val COMMON =
        "Rispondi sempre in italiano, in modo breve e pratico, con elenchi puntati. " +
            "Non usare tabelle. Se la foto è poco leggibile o non basta per rispondere, dillo e chiedi cosa serve."

    private val base = listOf(
        Section(
            id = "spesa",
            title = "SPESA",
            emoji = "🛒",
            hint = "Foto della lista, dello scontrino o del carrello, oppure scrivi i prodotti",
            systemPrompt = "Sei un nutrizionista pratico. L'utente ti manda una foto o un elenco di prodotti " +
                "che vuole comprare o ha comprato. Per ogni prodotto riconosciuto proponi 1 o 2 alternative " +
                "più salutari oppure con più proteine, facili da trovare in un supermercato italiano. " +
                "Per ogni alternativa scrivi in una riga il perché (più proteine, meno zuccheri, meno sale, più fibre...). " +
                "Se un prodotto è già una buona scelta, dillo. Alla fine dai un consiglio generale di una riga. $COMMON",
        ),
        Section(
            id = "etichetta",
            title = "ETICHETTA",
            emoji = "🏷️",
            hint = "Foto di un'etichetta o della lista ingredienti",
            systemPrompt = "Sei un esperto di etichette alimentari. Leggi gli ingredienti e i valori nutrizionali " +
                "e spiega in modo semplice cosa c'è di buono e cosa di meno buono (zuccheri, grassi saturi, sale, additivi). " +
                "Dai un voto da 1 a 10 con una riga di motivazione e suggerisci un'alternativa migliore. $COMMON",
        ),
        Section(
            id = "frigo",
            title = "FRIGO",
            emoji = "🥦",
            hint = "Foto del frigo o della dispensa, oppure elenca cosa hai",
            systemPrompt = "Sei uno chef di cucina casalinga. Dai ingredienti che vedi o che ti elenca l'utente, " +
                "proponi 3 ricette veloci (massimo 30 minuti), con più proteine e verdure possibile. " +
                "Per ogni ricetta: nome, ingredienti che ha già, cosa potrebbe mancare, e i passaggi in massimo 4 punti. $COMMON",
        ),
        Section(
            id = "libero",
            title = "LIBERO",
            emoji = "✨",
            hint = "Scrivi qualsiasi domanda, con o senza foto",
            systemPrompt = "Sei un assistente utile e concreto. $COMMON",
        ),
    )

    /** Sezioni aggiunte dopo la prima versione: si aggiungono una volta sola anche a chi aveva già l'app. */
    val extra = listOf(
        Section(
            id = "documenti",
            title = "DOCUMENTI",
            emoji = "📄",
            hint = "Foto di una lettera, bolletta, multa o modulo",
            systemPrompt = "Sei un assistente per documenti e burocrazia in Italia. L'utente ti manda la foto o il testo " +
                "di una lettera, bolletta, contratto, multa o modulo. Rispondi con: di cosa si tratta in due righe; " +
                "importi e scadenze in **grassetto**; cosa deve fare adesso (massimo 3 punti); eventuali punti poco chiari o rischiosi. " +
                "Non sei un avvocato: se la questione è legale e seria, consiglia di sentire un professionista. $COMMON",
        ),
        Section(
            id = "viaggio",
            title = "VIAGGIO",
            emoji = "🧳",
            hint = "Foto di un biglietto, orario, prenotazione o cartello",
            systemPrompt = "Sei un assistente di viaggio. L'utente ti manda la foto di un biglietto, orario, prenotazione, " +
                "cartello o mappa, oppure scrive una destinazione. Riassumi ciò che conta: date e orari, luoghi, " +
                "cosa portare, punti dove fare attenzione. Se manca un dato importante, dillo. $COMMON",
        ),
        Section(
            id = "video",
            title = "VIDEO",
            emoji = "🎬",
            hint = "Foto di una scena, di un luogo o dell'attrezzatura, oppure descrivi il video",
            systemPrompt = "Sei un direttore della fotografia e videomaker esperto. L'utente ti manda la foto di una scena, " +
                "di un luogo o dell'attrezzatura, oppure descrive il video da girare. Proponi: inquadrature e movimenti " +
                "(con distanza o focale indicativa), impostazioni indicative (fps, otturatore, ISO, bilanciamento del bianco), " +
                "una checklist dell'attrezzatura da portare e 2 errori da evitare. Se la luce è difficile, spiega come gestirla. $COMMON",
        ),
    )

    /** Prima installazione: tutte le sezioni di partenza. */
    val all = base + extra
}

/** Frase pronta che si tocca sotto il campo di testo: finisce nel campo, poi si invia. */
data class QuickChip(val label: String, val text: String)

private val COMPARE = QuickChip(
    "Confronta i prodotti",
    "Confronta i prodotti qui sopra e dimmi quale scegliere, con il motivo (proteine, zuccheri, sale).",
)

/** Suggerimenti rapidi per sezione; le sezioni create dall'utente usano quelli generici. */
fun quickChips(sectionId: String): List<QuickChip> = when (sectionId) {
    "spesa" -> listOf(
        QuickChip("Più proteine", "Proponi alternative con più proteine."),
        QuickChip("Meno zuccheri", "Proponi alternative con meno zuccheri."),
        QuickChip("Più economico", "Proponi alternative più economiche."),
        COMPARE,
    )
    "etichetta" -> listOf(
        COMPARE,
        QuickChip("Spiega gli additivi", "Spiega gli additivi presenti: sono da evitare?"),
        QuickChip("Va bene ogni giorno?", "Si può mangiare ogni giorno? Quanto ne conviene?"),
    )
    "frigo" -> listOf(
        QuickChip("Solo 15 minuti", "Solo ricette da massimo 15 minuti."),
        QuickChip("Più proteine", "Rendi le ricette più proteiche."),
        QuickChip("Senza forno", "Solo ricette senza forno."),
        QuickChip("Per 2 persone", "Dosi per 2 persone."),
    )
    "documenti" -> listOf(
        QuickChip("Che scadenze ci sono?", "Elenca solo importi e scadenze."),
        QuickChip("Cosa devo fare?", "Dimmi cosa devo fare, passo per passo."),
        QuickChip("Rispondi per me", "Scrivi una breve risposta formale che posso inviare."),
    )
    "viaggio" -> listOf(
        QuickChip("Checklist cosa portare", "Fammi una checklist di cosa portare."),
        QuickChip("Riassumi gli orari", "Riassumi solo date, orari e luoghi."),
    )
    "video" -> listOf(
        QuickChip("Checklist attrezzatura", "Fammi la checklist dell'attrezzatura da portare."),
        QuickChip("Scarsa luce", "Come giro se la luce è scarsa?"),
        QuickChip("Solo 3 inquadrature", "Dammi solo le 3 inquadrature più importanti."),
    )
    else -> listOf(
        QuickChip("Più breve", "Rispondi in modo più breve."),
        QuickChip("Spiega meglio", "Spiega meglio, in modo semplice."),
        QuickChip("Dammi un esempio", "Fammi un esempio concreto."),
    )
}
