package com.promptbox

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Una riga della cronologia: la chat in corso di una sezione oppure una chat archiviata. */
private class ChatEntry(
    val section: Section,
    val at: Long,
    val title: String,
    val turns: List<ChatTurn>,
    val archived: Store.Archived?,
)

private fun turnText(t: ChatTurn): String = splitShoppingMarker(t.text).first

/** Se la ricerca trova il testo dentro la chat, mostra un pezzetto attorno alla parola. */
private fun snippet(turns: List<ChatTurn>, q: String): String? {
    for (t in turns) {
        val text = turnText(t).replace('\n', ' ')
        val i = text.indexOf(q, ignoreCase = true)
        if (i >= 0) {
            val from = (i - 30).coerceAtLeast(0)
            val to = (i + q.length + 50).coerceAtMost(text.length)
            return (if (from > 0) "…" else "") + text.substring(from, to) + (if (to < text.length) "…" else "")
        }
    }
    return null
}

/** Cronologia: le chat in corso e quelle messe da parte con "Nuova chat", con ricerca in tutto il testo. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    store: Store,
    sections: List<Section>,
    onOpenCurrent: (Section) -> Unit,
    onRestore: (Store.Archived) -> Unit,
    onBack: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var query by remember { mutableStateOf("") }
    var archive by remember { mutableStateOf(store.archive()) }
    val current = remember {
        sections.mapNotNull { s ->
            val turns = store.loadChat(s.id)
            if (turns.isEmpty()) null
            else ChatEntry(s, System.currentTimeMillis(), turns.firstOrNull { it.fromUser }?.text?.trim().orEmpty().ifBlank { "Foto" }.take(70), turns, null)
        }
    }
    val all = current + archive.mapNotNull { a ->
        sections.firstOrNull { it.id == a.sectionId }?.let { ChatEntry(it, a.at, a.title, a.turns, a) }
    }
    val q = query.trim()
    val shown = if (q.isEmpty()) all else all.filter { e ->
        e.title.contains(q, ignoreCase = true) || e.turns.any { turnText(it).contains(q, ignoreCase = true) }
    }
    val fmt = remember { SimpleDateFormat("d MMM, HH:mm", Locale.ITALY) }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text("Cronologia", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(28.dp),
                singleLine = true,
                placeholder = { Text("Cerca in tutte le chat") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, "Cancella") }
                    }
                },
            )

            if (shown.isEmpty()) {
                Text(
                    if (all.isEmpty()) "Ancora nessuna chat. Quando premi \"Nuova chat\" la precedente finisce qui."
                    else "Nessuna chat contiene \"$q\".",
                    modifier = Modifier.padding(24.dp),
                    color = cs.onSurfaceVariant,
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 32.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(shown, key = { e -> e.archived?.id?.toString() ?: "now_${e.section.id}" }) { e ->
                        Card(
                            onClick = {
                                val a = e.archived
                                if (a == null) onOpenCurrent(e.section) else onRestore(a)
                            },
                            colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(e.section.emoji, fontSize = 24.sp)
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        e.title,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                        style = MaterialTheme.typography.titleSmall,
                                    )
                                    Text(
                                        e.section.title + " · " + (if (e.archived == null) "in corso" else fmt.format(Date(e.at))),
                                        fontSize = 12.sp,
                                        color = cs.onSurfaceVariant,
                                    )
                                    if (q.isNotEmpty()) {
                                        snippet(e.turns, q)?.let {
                                            Text(
                                                it,
                                                fontSize = 13.sp,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis,
                                                color = cs.onSurfaceVariant,
                                            )
                                        }
                                    }
                                }
                                val a = e.archived
                                if (a != null) {
                                    IconButton(onClick = {
                                        store.deleteArchived(a.id)
                                        archive = store.archive()
                                    }) { Icon(Icons.Filled.Delete, "Elimina", tint = cs.onSurfaceVariant) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
