package com.promptbox

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.draw.clip
import kotlinx.coroutines.launch
import java.util.Calendar
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Una riga della cronologia: la chat in corso di una sezione oppure una chat archiviata. */
private class ChatEntry(
    val section: Section,
    val at: Long,
    val title: String,
    val turns: List<ChatTurn>,
    val archived: Store.Archived?,
)

private fun turnText(t: ChatTurn): String = splitShoppingMarker(t.text).first

/** Se la ricerca trova il testo dentro la chat, mostra un pezzetto attorno alla parola. */
private fun snippet(turns: List<ChatTurn>, q: String): String? {
    for (t in turns) {
        val text = turnText(t).replace('\n', ' ')
        val i = text.indexOf(q, ignoreCase = true)
        if (i >= 0) {
            val from = (i - 30).coerceAtLeast(0)
            val to = (i + q.length + 50).coerceAtMost(text.length)
            return (if (from > 0) "…" else "") + text.substring(from, to) + (if (to < text.length) "…" else "")
        }
    }
    return null
}

private val GROUP_NAMES = listOf("Oggi", "Ieri", "Questa settimana", "Prima")

/** 0 = oggi, 1 = ieri, 2 = ultimi giorni della settimana, 3 = più vecchie. */
private fun dayGroup(at: Long): Int {
    val day = 86_400_000L
    val today = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    return when {
        at >= today -> 0
        at >= today - day -> 1
        at >= today - 6 * day -> 2
        else -> 3
    }
}

/** Cronologia: le chat in corso e quelle messe da parte con "Nuova chat", con ricerca, filtri per scheda e date. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    store: Store,
    sections: List<Section>,
    onOpenCurrent: (Section) -> Unit,
    onRestore: (Store.Archived) -> Unit,
    onBack: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    var query by remember { mutableStateOf("") }
    var filterId by remember { mutableStateOf<String?>(null) }
    var archive by remember { mutableStateOf(store.archive()) }
    var currentChats by remember {
        mutableStateOf(
            sections.mapNotNull { s ->
                val turns = store.loadChat(s.id)
                if (turns.isEmpty()) null
                else ChatEntry(s, System.currentTimeMillis(), turns.firstOrNull { it.fromUser }?.text?.trim().orEmpty().ifBlank { "Foto" }.take(70), turns, null)
            },
        )
    }
    val all = (currentChats + archive.mapNotNull { a ->
        sections.firstOrNull { it.id == a.sectionId }?.let { ChatEntry(it, a.at, a.title, a.turns, a) }
    }).sortedByDescending { it.at }
    val q = query.trim()
    val shown = all
        .filter { filterId == null || it.section.id == filterId }
        .filter { e -> q.isEmpty() || e.title.contains(q, ignoreCase = true) || e.turns.any { turnText(it).contains(q, ignoreCase = true) } }
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.ITALY) }
    val fmtDay = remember { SimpleDateFormat("d MMM, HH:mm", Locale.ITALY) }

    fun delete(e: ChatEntry) {
        val a = e.archived
        if (a != null) {
            store.deleteArchived(a.id)
            archive = store.archive()
        } else {
            store.saveChat(e.section.id, emptyList())
            currentChats = currentChats.filter { it.section.id != e.section.id }
        }
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            val r = snackbar.showSnackbar("Chat eliminata", actionLabel = "Annulla", duration = SnackbarDuration.Long)
            if (r == SnackbarResult.ActionPerformed) {
                if (a != null) {
                    store.restoreArchived(a)
                    archive = store.archive()
                } else {
                    store.saveChat(e.section.id, e.turns)
                    currentChats = currentChats + e
                }
            }
        }
    }

    Scaffold(
        containerColor = cs.background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Cronologia", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(28.dp),
                singleLine = true,
                placeholder = { Text("Cerca nelle chat") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, "Cancella") }
                    }
                },
            )

            // Filtri a chip: una per ogni scheda che ha chat.
            val withChats = sections.filter { s -> all.any { it.section.id == s.id } }
            if (withChats.size > 1) {
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FilterChip(selected = filterId == null, onClick = { filterId = null }, label = { Text("Tutte") })
                    withChats.forEach { s ->
                        FilterChip(
                            selected = filterId == s.id,
                            onClick = { filterId = if (filterId == s.id) null else s.id },
                            label = { Text(s.emoji + " " + s.title.lowercase().replaceFirstChar { it.uppercase() }) },
                        )
                    }
                }
            }

            if (shown.isEmpty()) {
                Text(
                    if (all.isEmpty()) "Ancora nessuna chat. Quando premi \"Nuova chat\" la precedente finisce qui."
                    else "Nessuna chat trovata.",
                    modifier = Modifier.padding(24.dp),
                    color = cs.onSurfaceVariant,
                )
            } else {
                val groups = shown.groupBy { dayGroup(it.at) }.toSortedMap()
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 32.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    groups.forEach { (g, entries) ->
                        item(key = "g_$g") {
                            Text(
                                GROUP_NAMES[g],
                                style = MaterialTheme.typography.labelLarge,
                                color = cs.primary,
                                modifier = Modifier.padding(start = 4.dp, top = 8.dp),
                            )
                        }
                        items(entries, key = { e -> e.archived?.id?.toString() ?: "now_${e.section.id}" }) { e ->
                            val idx = sections.indexOfFirst { it.id == e.section.id }.coerceAtLeast(0)
                            val (tint, onTint) = when (idx % 3) {
                                0 -> cs.primaryContainer to cs.onPrimaryContainer
                                1 -> cs.secondaryContainer to cs.onSecondaryContainer
                                else -> cs.tertiaryContainer to cs.onTertiaryContainer
                            }
                            val dismiss = rememberSwipeToDismissBoxState(
                                confirmValueChange = { v ->
                                    if (v == SwipeToDismissBoxValue.EndToStart) {
                                        delete(e)
                                        true
                                    } else false
                                },
                            )
                            SwipeToDismissBox(
                                state = dismiss,
                                enableDismissFromStartToEnd = false,
                                backgroundContent = {
                                    Box(
                                        Modifier.fillMaxSize().clip(RoundedCornerShape(20.dp)).background(cs.errorContainer).padding(end = 20.dp),
                                        contentAlignment = Alignment.CenterEnd,
                                    ) { Icon(Icons.Filled.Delete, "Elimina", tint = cs.onErrorContainer) }
                                },
                            ) {
                                Card(
                                    onClick = {
                                        val a = e.archived
                                        if (a == null) onOpenCurrent(e.section) else onRestore(a)
                                    },
                                    colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh),
                                    shape = RoundedCornerShape(20.dp),
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            Modifier.size(46.dp).clip(CircleShape).background(tint),
                                            contentAlignment = Alignment.Center,
                                        ) { Text(e.section.emoji, fontSize = 22.sp) }
                                        Spacer(Modifier.width(14.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(
                                                e.title,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis,
                                                style = MaterialTheme.typography.titleSmall,
                                            )
                                            Text(
                                                e.section.title + " · " + when {
                                                    e.archived == null -> "in corso"
                                                    g <= 1 -> fmt.format(Date(e.at))
                                                    else -> fmtDay.format(Date(e.at))
                                                },
                                                fontSize = 12.sp,
                                                color = cs.onSurfaceVariant,
                                            )
                                            if (q.isNotEmpty()) {
                                                snippet(e.turns, q)?.let {
                                                    Text(
                                                        it,
                                                        fontSize = 13.sp,
                                                        maxLines = 2,
                                                        overflow = TextOverflow.Ellipsis,
                                                        color = cs.onSurfaceVariant,
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
