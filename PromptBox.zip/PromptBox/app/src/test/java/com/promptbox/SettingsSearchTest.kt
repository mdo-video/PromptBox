package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SettingsSearchTest {
    @Test
    fun emptyQueryMatchesEverything() {
        assertTrue(settingsMatch("Cronologia", ""))
        assertTrue(settingsMatch("Cronologia", "   "))
    }

    @Test
    fun ignoresCaseAndAccents() {
        assertEquals("novita", normalizeForSearch("  Novità "))
        assertTrue(settingsMatch("Novità · Cosa c'è di nuovo", "NOVITA"))
        assertTrue(settingsMatch("Cronologia", "cronologìa"))
    }

    @Test
    fun everyWordMustMatch() {
        val text = "Sincronizzazione e backup Backup su Drive Una copia sul tuo Drive"
        assertTrue(settingsMatch(text, "backup drive"))
        assertTrue(settingsMatch(text, "drive backup"))
        assertFalse(settingsMatch(text, "backup bring"))
    }

    @Test
    fun matchesInsideWords() {
        assertTrue(settingsMatch("Aspetto Nero AMOLED oled sfondo", "amol"))
        assertFalse(settingsMatch("Aspetto Tema", "amoled"))
    }
}
