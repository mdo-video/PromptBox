package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PantryReorderTest {
    private fun item(id: String, name: String, shelf: String) =
        PantryItem(id = id, name = name, place = "c1", shelf = shelf, qty = "", expiry = null, addedAt = 0L)

    private val items = listOf(
        item("a", "Decorazioni Natale", "Generale"),
        item("b", "Albero di Natale", "Altro"),
        item("c", "Trapano", "Altro"),
    )
    private val shelves = listOf("Generale", "Altro")

    @Test fun creaIRipianiNuoviEPortaSoloGliSpostamenti() {
        val raw = "{\"ripiani\":[{\"nome\":\"decorazioni natalizie\",\"emoji\":\"🎄\",\"prodotti\":[1,2]}," +
            "{\"nome\":\"Altro\",\"emoji\":\"📦\",\"prodotti\":[3]}]}"
        val g = PantryReorder.parse(raw, items, shelves)
        // Il trapano è già in "Altro": non si sposta e non compare.
        assertEquals(1, g.size)
        assertEquals("Decorazioni natalizie", g[0].shelf)
        assertTrue(g[0].isNew)
        assertEquals(listOf("a", "b"), g[0].ids)
    }

    @Test fun unRipianoCheCeGiaNonENuovo() {
        val g = PantryReorder.parse("{\"ripiani\":[{\"nome\":\"generale\",\"prodotti\":[2,3]}]}", items, shelves)
        assertEquals("Generale", g[0].shelf)
        assertFalse(g[0].isNew)
        assertEquals(listOf("b", "c"), g[0].ids)
    }

    @Test fun ognunoInUnSoloRipianoENumeriSbagliatiSiIgnorano() {
        val raw = "{\"ripiani\":[{\"nome\":\"Natale\",\"prodotti\":[1,9,0]},{\"nome\":\"Altri\",\"prodotti\":[1,3]}]}"
        val g = PantryReorder.parse(raw, items, shelves)
        assertEquals(listOf("a"), g.first { it.shelf == "Natale" }.ids)
        assertEquals(listOf("c"), g.first { it.shelf == "Altri" }.ids)
    }

    @Test fun lApplicazioneRispettaIProdottiEsclusi() {
        val g = listOf(ReorderGroup("Natale", "🎄", true, listOf("a", "b")))
        val out = PantryReorder.apply(items, g, skipped = setOf("b"))
        assertEquals("Natale", out.first { it.id == "a" }.shelf)
        assertEquals("Altro", out.first { it.id == "b" }.shelf)
    }

    @Test fun rispostaIllegibileDaErrore() {
        assertTrue(runCatching { PantryReorder.parse("boh", items, shelves) }.isFailure)
    }
}
