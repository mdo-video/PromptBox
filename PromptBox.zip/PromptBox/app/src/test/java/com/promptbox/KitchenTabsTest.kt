package com.promptbox

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class KitchenTabsTest {
    private val base = KITCHEN_TABS.map { it.first }

    @After
    fun resetGlobal() {
        KitchenTabs.config = KitchenTabsConfig()
    }

    @Test
    fun defaultIsTheFactoryOrder() {
        val c = KitchenTabsConfig()
        assertEquals(base, c.all())
        assertEquals(base, c.visible())
        assertTrue(c.hiddenTabs().isEmpty())
        assertEquals("", c.toJson())
        assertEquals("Frigo", c.label("frigo"))
        assertNull(c.renamed("frigo"))
    }

    @Test
    fun moveSwapsWithTheVisibleNeighbour() {
        val c = KitchenTabsConfig().move("frigo", -1)
        assertEquals(listOf("shopping", "frigo", "cucina"), c.all().take(3))
        assertEquals(listOf("shopping", "cucina", "frigo"), c.move("frigo", 1).all().take(3))
    }

    @Test
    fun cannotMovePastTheEnds() {
        val c = KitchenTabsConfig()
        assertFalse(c.canMove(base.first(), -1))
        assertFalse(c.canMove(base.last(), 1))
        assertEquals(base, c.move(base.first(), -1).all())
        assertEquals(base, c.move(base.last(), 1).all())
    }

    @Test
    fun movingSkipsHiddenTabs() {
        // Con Riepilogo nascosto, Frigo a sinistra scavalca Riepilogo e passa davanti a Spesa solo con un altro passo.
        val c = KitchenTabsConfig().hide("cucina").move("frigo", -1)
        assertEquals(listOf("frigo", "shopping"), c.visible().take(2))
        assertTrue("cucina" in c.hidden)
    }

    @Test
    fun hideAndShow() {
        val c = KitchenTabsConfig().hide("casa")
        assertFalse("casa" in c.visible())
        assertEquals(listOf("casa"), c.hiddenTabs())
        // Ripristinata torna al suo posto.
        assertEquals(base, c.show("casa").visible())
    }

    @Test
    fun atLeastOneTabStaysVisible() {
        var c = KitchenTabsConfig()
        base.dropLast(1).forEach { c = c.hide(it) }
        assertEquals(1, c.visible().size)
        val last = c.visible().single()
        assertFalse(c.canHide(last))
        assertEquals(listOf(last), c.hide(last).visible())
    }

    @Test
    fun hiddenCurrentTabIsStillShown() {
        val c = KitchenTabsConfig().hide("congelatore")
        assertFalse("congelatore" in c.shown("frigo"))
        assertTrue("congelatore" in c.shown("congelatore"))
    }

    @Test
    fun renameBaseTabAndGoBack() {
        val c = KitchenTabsConfig().rename("frigo", "  Frigorifero ")
        assertEquals("Frigorifero", c.label("frigo"))
        assertEquals("Frigorifero", c.renamed("frigo"))
        // Nome vuoto o uguale all'originale: torna quello di fabbrica.
        assertNull(c.rename("frigo", "").renamed("frigo"))
        assertNull(c.rename("frigo", "Frigo").renamed("frigo"))
    }

    @Test
    fun nameValidation() {
        val c = KitchenTabsConfig()
        assertEquals("Scrivi un nome", c.nameError("  ", null))
        assertEquals("", c.nameError("", "frigo")) // base: vuoto = nome originale
        assertEquals("Al massimo ${KitchenTabsConfig.MAX_NAME} lettere", c.nameError("x".repeat(KitchenTabsConfig.MAX_NAME + 1), null))
        assertEquals("C'è già una scheda con questo nome", c.nameError("dispensa", null))
        assertEquals("", c.nameError("Dispensa", "dispensa")) // lo stesso nome della scheda che si rinomina va bene
    }

    @Test
    fun addCustomTabGoesLastAndFollowsRules() {
        val (c, tab) = KitchenTabsConfig().add("Cantina", now = 1000L)!!
        assertEquals("Cantina", tab.name)
        assertTrue(c.isCustom(tab.id))
        assertEquals(base + tab.id, c.all())
        assertEquals("Cantina", c.label(tab.id))
        assertNull(KitchenTabsConfig().add("  "))
        assertNull(c.add("cantina")) // c'è già
        // Due schede create nello stesso istante non si scambiano l'id.
        val (c2, tab2) = c.add("Garage", now = 1000L)!!
        assertTrue(tab.id != tab2.id)
        assertEquals(2, c2.custom.size)
    }

    @Test
    fun deleteCustomTabs() {
        val (c, tab) = KitchenTabsConfig().add("Cantina")!!
        val moved = c.hide(tab.id).move("frigo", -1)
        val gone = moved.delete(tab.id)
        assertFalse(gone.isCustom(tab.id))
        assertFalse(tab.id in gone.all())
        assertFalse(tab.id in gone.hidden)
    }

    @Test
    fun basePlacesCanBeDeletedAndRestored() {
        val c = KitchenTabsConfig().rename("frigo", "Frigorifero").withConditions("frigo", PlaceConditions.forKind(PlaceKind.FRIDGE))
        assertTrue(c.canDelete("frigo"))
        val gone = c.delete("frigo")
        assertFalse("frigo" in gone.all())
        assertFalse("frigo" in gone.visible())
        assertEquals(listOf("frigo"), gone.removedTabs())
        // Il nome e le opzioni di prima non restano.
        assertNull(gone.renamed("frigo"))
        assertTrue(gone.conditions("frigo").isEmpty())
        // Si rimette, vuota, col nome di fabbrica.
        val back = gone.restore("frigo")
        assertTrue("frigo" in back.visible())
        assertEquals("Frigo", back.label("frigo"))
        assertTrue(back.removedTabs().isEmpty())
        // Il giro nel salvataggio non perde niente.
        assertEquals(listOf("frigo"), KitchenTabsConfig.parse(gone.toJson()).removedTabs())
    }

    @Test
    fun workTabsAreNeverDeleted() {
        val c = KitchenTabsConfig()
        listOf("shopping", "cucina", "receipts").forEach { id ->
            assertFalse(c.canDelete(id))
            assertEquals(c.all(), c.delete(id).all())
        }
        assertTrue(c.delete("shopping").isKnown("shopping"))
    }

    @Test
    fun lastVisibleTabCannotBeDeleted() {
        var c = KitchenTabsConfig()
        c.all().filter { it != "frigo" }.forEach { c = c.hide(it) }
        assertEquals(listOf("frigo"), c.visible())
        assertFalse(c.canDelete("frigo"))
        assertEquals(c.all(), c.delete("frigo").all())
    }

    @Test
    fun basePlacesKeepTheirOwnOptions() {
        val opts = PlaceConditions.forKind(PlaceKind.FREEZER).copy(temp = -17.0)
        val c = KitchenTabsConfig().withConditions("congelatore", opts)
        assertEquals(opts, c.conditions("congelatore"))
        assertEquals(opts, KitchenTabsConfig.parse(c.toJson()).conditions("congelatore"))
        assertTrue(c.conditions("frigo").isEmpty())
        // Spesa e Riepilogo non hanno opzioni.
        assertEquals(c.toJson(), c.withConditions("shopping", opts).toJson())
    }

    @Test
    fun customTabsActLikeTheirKind() {
        val (c, fridge) = KitchenTabsConfig().add("Frigo 2", options = PlaceConditions.guess("Frigo 2"))!!
        val (c2, freezer) = c.add("Congelatore garage", options = PlaceConditions.guess("Congelatore garage"))!!
        val (c3, attic) = c2.add("Sottotetto", options = PlaceConditions.guess("Sottotetto"))!!
        assertEquals(PlaceKind.FRIDGE, c3.kindOf(fridge.id))
        assertEquals(PlaceKind.FREEZER, c3.kindOf(freezer.id))
        assertEquals(PlaceKind.STORAGE, c3.kindOf(attic.id))
        assertTrue(c3.isFreezer(freezer.id))
        assertFalse(c3.cooks(attic.id))
        assertTrue(c3.cooks(fridge.id))
        assertTrue(c3.conditions(attic.id).has(PlaceFeature.MAP))
        assertEquals("frigo", c3.fridgePlace())
        // Senza il frigo di base i prodotti scongelati vanno in "Frigo 2".
        assertEquals(fridge.id, c3.delete("frigo").fridgePlace())
        assertNull(c3.delete("frigo").delete(fridge.id).fridgePlace())
    }

    @Test
    fun jsonRoundTrip() {
        var c = KitchenTabsConfig().rename("casa", "Bagno").hide("receipts").move("dispensa", -1)
        val (withCustom, tab) = c.add("Cantina", now = 5L)!!
        c = withCustom.rename(tab.id, "Taverna")
        val back = KitchenTabsConfig.parse(c.toJson())
        assertEquals(c.all(), back.all())
        assertEquals(c.visible(), back.visible())
        assertEquals("Bagno", back.label("casa"))
        assertEquals("Taverna", back.label(tab.id))
        assertEquals(listOf("receipts"), back.hiddenTabs())
    }

    @Test
    fun parseIgnoresGarbage() {
        assertEquals(base, KitchenTabsConfig.parse("").all())
        assertEquals(base, KitchenTabsConfig.parse("non è json").all())
        // Id sconosciuti nell'ordine si ignorano; le schede che mancano vanno in coda; un id di base non può diventare "personalizzato".
        val c = KitchenTabsConfig.parse("""{"o":["boh","dispensa"],"c":[{"i":"frigo","n":"Finto"},{"i":"","n":"x"}]}""")
        assertEquals("dispensa", c.all().first())
        assertEquals(base.size, c.all().size)
        assertTrue(c.custom.isEmpty())
        assertEquals("Frigo", c.label("frigo"))
    }

    @Test
    fun startTabFallsBackToFirstVisible() {
        val c = KitchenTabsConfig().hide("shopping")
        assertEquals("cucina", c.startTab("shopping"))
        assertEquals("frigo", c.startTab("frigo"))
        assertEquals("cucina", c.startTab("u_non_esiste"))
    }

    @Test
    fun customPlaceBehavesLikeAPantry() {
        val (c, tab) = KitchenTabsConfig().add("Cantina")!!
        KitchenTabs.config = c
        assertTrue(KitchenTabs.isCustom(tab.id))
        assertTrue(isKitchenArea(tab.id))
        assertTrue(isPantryScreen(tab.id))
        assertTrue(showsNavBar(tab.id))
        assertEquals("cucina", navCurrent(tab.id))
        assertEquals(Pantry.CUSTOM, Pantry.defaultShelves(tab.id))
        assertEquals(Pantry.CUSTOM, Pantry.shelves(tab.id))
        assertEquals(14L, Pantry.soonLimit(tab.id))
        assertTrue(Pantry.tracksExpiry(tab.id, "Generale"))
        assertTrue(Pantry.cookPrompt(emptyList(), tab.id).contains("in cantina"))
    }

    @Test
    fun deletedCustomPlaceIsNoLongerAScreen() {
        assertFalse(isKitchenArea("u_xyz"))
        assertFalse(isPantryScreen("u_xyz"))
        assertFalse(showsNavBar("u_xyz"))
        assertNotNull(KitchenTabsConfig().add("Cantina"))
    }
}
