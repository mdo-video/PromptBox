package com.promptbox

import androidx.compose.ui.graphics.Color
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ThemeTest {
    @Test
    fun sixPalettesWithExpectedNames() {
        assertEquals(listOf("Menta", "Oceano", "Lavanda", "Tramonto", "Ciliegia", "Grafite"), Palettes.names)
    }

    @Test
    fun everyPaletteHasDistinctLightAndDark() {
        for (i in Palettes.names.indices) {
            val dark = Palettes.scheme(i, dark = true)
            val light = Palettes.scheme(i, dark = false)
            assertNotEquals("palette $i", dark.primary, light.primary)
            assertNotEquals("palette $i", dark.background, light.background)
        }
    }

    @Test
    fun palettesDifferFromEachOther() {
        val primaries = Palettes.names.indices.map { Palettes.scheme(it, dark = true).primary }.toSet()
        assertEquals(Palettes.names.size, primaries.size)
    }

    @Test
    fun amoledMakesDarkBackgroundBlack() {
        for (i in Palettes.names.indices) {
            val s = Palettes.scheme(i, dark = true, amoled = true)
            assertEquals(Color.Black, s.background)
            assertEquals(Color.Black, s.surface)
            // Il colore principale non cambia: Nero AMOLED tocca solo sfondo e superfici.
            assertEquals(Palettes.scheme(i, dark = true).primary, s.primary)
        }
    }

    @Test
    fun amoledDoesNothingInLightTheme() {
        for (i in Palettes.names.indices) {
            assertEquals(Palettes.scheme(i, dark = false), Palettes.scheme(i, dark = false, amoled = true))
        }
    }

    @Test
    fun outOfRangeIndexFallsBackToValidPalette() {
        assertEquals(Palettes.scheme(0, dark = true), Palettes.scheme(-3, dark = true))
        assertEquals(Palettes.scheme(5, dark = true), Palettes.scheme(99, dark = true))
    }

    @Test
    fun swatchColorsAreDifferent() {
        for (i in Palettes.names.indices) {
            val (a, b) = Palettes.swatch(i, dark = false)
            assertTrue("palette $i", a != b)
        }
    }
}
