package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PlaceConditionsTest {
    @Test
    fun guessByName() {
        val cellar = PlaceConditions.guess("Cantina")
        assertTrue(cellar.has(PlaceFeature.TEMP))
        assertTrue(cellar.has(PlaceFeature.HUMIDITY))
        assertFalse(cellar.has(PlaceFeature.SPACE))
        assertEquals(10.0, cellar.tempMin!!, 0.0)
        assertEquals(16.0, cellar.tempMax!!, 0.0)
        assertEquals(70, cellar.humidityMax)

        val garage = PlaceConditions.guess("  Garage ")
        assertTrue(garage.has(PlaceFeature.SPACE))
        assertFalse(garage.has(PlaceFeature.TEMP))

        assertTrue(PlaceConditions.guess("Xyz").isEmpty())
    }

    @Test
    fun kindFromNameUnderstandsNumbersAndPlaces() {
        assertEquals(PlaceKind.FRIDGE, PlaceKind.guess("Frigo 2"))
        assertEquals(PlaceKind.FRIDGE, PlaceKind.guess("Frigorifero cantina"))
        assertEquals(PlaceKind.FREEZER, PlaceKind.guess("Congelatore 2"))
        assertEquals(PlaceKind.FREEZER, PlaceKind.guess("Freezer garage"))
        assertEquals(PlaceKind.PANTRY, PlaceKind.guess("Dispensa 2"))
        assertEquals(PlaceKind.STORAGE, PlaceKind.guess("Sottotetto"))
        assertEquals(PlaceKind.STORAGE, PlaceKind.guess("Ripostiglio"))
        assertEquals(PlaceKind.STORAGE, PlaceKind.guess("Box"))
        assertEquals(PlaceKind.CELLAR, PlaceKind.guess("Cantina"))
        assertNull(PlaceKind.guess("Boxer"))
        assertNull(PlaceKind.guess("Xyz"))
    }

    @Test
    fun optionsFollowTheKind() {
        val fridge = PlaceConditions.guess("Frigo 2")
        assertTrue(fridge.has(PlaceFeature.TEMP))
        assertEquals(5.0, fridge.tempMax!!, 0.0)
        assertTrue(fridge.showsCook())

        val freezer = PlaceConditions.guess("Congelatore 2")
        assertTrue(freezer.has(PlaceFeature.DEFROST))
        assertEquals(-15.0, freezer.tempMax!!, 0.0)

        val attic = PlaceConditions.guess("Sottotetto")
        assertTrue(attic.has(PlaceFeature.SPACE))
        assertTrue(attic.has(PlaceFeature.MAP))
        assertFalse(attic.has(PlaceFeature.TEMP))
        assertFalse(attic.showsCook())
    }

    @Test
    fun noFoodPlacesHaveNoExpiry() {
        assertFalse(PlaceSetup.guess("Sottotetto").config.expiry)
        assertFalse(PlaceSetup.guess("Ripostiglio").config.notify)
        assertTrue(PlaceSetup.guess("Frigo 2").config.expiry)
        assertTrue(PlaceSetup.guess("Xyz").config == PlaceConfig())
    }

    @Test
    fun periodicTasksAlertWhenDue() {
        val base = PlaceConditions(setOf(PlaceFeature.DEFROST.key, PlaceFeature.CLEAN.key), defrostMonths = 6, defrostAt = 100L, cleanDays = 30, cleanAt = 100L)
        // Appena fatti: niente da dire.
        assertTrue(base.alerts(today = 101L).isEmpty())
        // Pulizia tra 5 giorni, sbrinamento ancora lontano.
        assertEquals(listOf("Pulizia tra 5 gg"), base.alerts(today = 125L))
        // Scaduti.
        assertEquals(listOf("Pulizia in ritardo di 10 gg"), base.alerts(today = 140L))
        assertEquals(listOf("Sbrinamento in ritardo di 2 gg", "Pulizia in ritardo di 152 gg"), base.alerts(today = 282L))
        // Senza la data dell'ultima volta non si può dire quando tocca.
        assertTrue(base.copy(defrostAt = null, cleanAt = null).alerts(today = 1000L).isEmpty())
        // Spento = nessun avviso.
        assertTrue(base.with(PlaceFeature.CLEAN, false).alerts(today = 140L).isEmpty())
    }

    @Test
    fun newFieldsSurviveSaving() {
        val c = PlaceConditions.forKind(PlaceKind.FREEZER).copy(defrostAt = 20000L, cleanDays = 45, cleanAt = 19990L)
        assertEquals(c, PlaceConditions.parse(c.toJson()))
    }

    @Test
    fun aiSetupReadsKindShelvesAndFlags() {
        val raw = "{\"tipo\":\"deposito\",\"temperatura\":{\"attiva\":false},\"spazio\":{\"attiva\":true},\"piantina\":{\"attiva\":true}," +
            "\"cucina\":{\"attiva\":false},\"scadenze\":{\"attiva\":false},\"avvisi\":{\"attiva\":false}," +
            "\"ripiani\":[{\"nome\":\"Valigie\",\"emoji\":\"🧳\"},{\"nome\":\"Decorazioni\",\"emoji\":\"🎄\"},{\"nome\":\"valigie\",\"emoji\":\"x\"}]}"
        val s = PlaceSetup.parse(raw, "Sottotetto")
        assertEquals(PlaceKind.STORAGE, s.options.placeKind())
        assertFalse(s.config.expiry)
        assertFalse(s.config.notify)
        assertEquals(listOf("Valigie", "Decorazioni"), s.config.shelves!!.map { it.name })
        // Un frigo tiene i suoi ripiani di sempre, anche se l'AI ne propone altri.
        val fridge = PlaceSetup.parse("{\"tipo\":\"frigo\",\"ripiani\":[{\"nome\":\"A\"},{\"nome\":\"B\"}]}", "Frigo 2")
        assertNull(fridge.config.shelves)
        // Se l'AI dimentica il tipo si usa quello del nome.
        assertEquals(PlaceKind.FREEZER, PlaceSetup.parse("{\"temperatura\":{\"attiva\":false}}", "Congelatore 2").options.placeKind())
    }

    @Test
    fun parsesAiSuggestionEvenWithFences() {
        val raw = "```json\n{\"temperatura\":{\"attiva\":true,\"min\":16,\"max\":10},\"umidita\":{\"attiva\":true,\"max\":70},\"spazio\":{\"attiva\":false}}\n```"
        val c = PlaceConditions.parseSuggestion(raw)
        assertTrue(c.has(PlaceFeature.TEMP))
        assertTrue(c.has(PlaceFeature.HUMIDITY))
        assertFalse(c.has(PlaceFeature.SPACE))
        // min e max scambiati dall'AI si rimettono in ordine
        assertEquals(10.0, c.tempMin!!, 0.0)
        assertEquals(16.0, c.tempMax!!, 0.0)
        assertEquals(70, c.humidityMax)
    }

    @Test(expected = IllegalArgumentException::class)
    fun unreadableSuggestionFails() {
        PlaceConditions.parseSuggestion("non so")
    }

    @Test
    fun alertsOnlyWhenOutOfRange() {
        val base = PlaceConditions(setOf(PlaceFeature.TEMP.key, PlaceFeature.HUMIDITY.key, PlaceFeature.SPACE.key), tempMin = 10.0, tempMax = 16.0, humidityMax = 70)
        assertTrue(base.alerts().isEmpty())
        assertTrue(base.copy(temp = 12.0, humidity = 60, spacePct = 40).alerts().isEmpty())
        assertEquals(listOf("Troppo caldo: 18 °C"), base.copy(temp = 18.0).alerts())
        assertEquals(listOf("Troppo freddo: 8,5 °C"), base.copy(temp = 8.5).alerts())
        assertEquals(listOf("Troppa umidità: 80%"), base.copy(humidity = 80).alerts())
        assertEquals(listOf("Quasi pieno: 95%"), base.copy(spacePct = 95).alerts())
        // un'opzione spenta non avvisa più, anche con la lettura ancora salvata
        assertTrue(base.with(PlaceFeature.TEMP, false).copy(temp = 30.0).alerts().isEmpty())
    }

    @Test
    fun readsNumbersTheItalianWay() {
        assertEquals(12.5, PlaceConditions.readNumber("12,5")!!, 0.0)
        assertEquals(12.0, PlaceConditions.readNumber(" 12 ")!!, 0.0)
        assertNull(PlaceConditions.readNumber("abc"))
        assertNull(PlaceConditions.readNumber(""))
    }

    @Test
    fun surviveSaveAndLoadInsideTheTabs() {
        val opts = PlaceConditions(setOf(PlaceFeature.TEMP.key), temp = 12.5, tempMin = 10.0, tempMax = 16.0)
        val (c, tab) = KitchenTabsConfig().add("Cantina", now = 1L, options = opts)!!
        val back = KitchenTabsConfig.parse(c.toJson())
        assertEquals(opts, back.conditions(tab.id))
        // le schede di base non hanno opzioni
        assertTrue(back.conditions("frigo").isEmpty())
        // cambiare le letture
        val next = back.withConditions(tab.id, opts.copy(temp = 20.0))
        assertEquals(20.0, KitchenTabsConfig.parse(next.toJson()).conditions(tab.id).temp!!, 0.0)
        // rinominare non perde le opzioni
        assertEquals(opts, next.withConditions(tab.id, opts).rename(tab.id, "Cantina nuova").conditions(tab.id))
    }
}

class PlaceCookTest {
    @Test
    fun garageDoesNotCookButUnknownAndBaseTabsDo() {
        assertFalse(PlaceConditions.guess("Garage").showsCook())
        assertTrue(PlaceConditions.guess("Cantina").showsCook())
        val (c, garage) = KitchenTabsConfig().add("Garage", now = 1L)!!
        // creata senza scelta: si decide dal nome
        assertFalse(c.cooks(garage.id))
        val (c2, other) = c.add("Zona strana", now = 2L)!!
        assertTrue(c2.cooks(other.id))
        assertTrue(c2.cooks("frigo"))
        // la scelta esplicita vince sul nome
        assertTrue(c2.withConditions(garage.id, PlaceConditions(cook = true)).cooks(garage.id))
    }

    @Test
    fun aiCanTurnCookOff() {
        val c = PlaceConditions.parseSuggestion("{\"spazio\":{\"attiva\":true},\"cucina\":{\"attiva\":false}}")
        assertEquals(false, c.cook)
        assertNull(PlaceConditions.parseSuggestion("{\"spazio\":{\"attiva\":true}}").cook)
        val back = PlaceConditions.parse(c.toJson())
        assertEquals(false, back.cook)
    }
}
