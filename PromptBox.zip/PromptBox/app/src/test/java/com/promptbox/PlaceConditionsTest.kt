package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PlaceConditionsTest {
    @Test
    fun guessByName() {
        val cellar = PlaceConditions.guess("Cantina")
        assertTrue(cellar.has(PlaceFeature.TEMP))
        assertTrue(cellar.has(PlaceFeature.HUMIDITY))
        assertFalse(cellar.has(PlaceFeature.SPACE))
        assertEquals(10.0, cellar.tempMin!!, 0.0)
        assertEquals(16.0, cellar.tempMax!!, 0.0)
        assertEquals(70, cellar.humidityMax)

        val garage = PlaceConditions.guess("  Garage ")
        assertTrue(garage.has(PlaceFeature.SPACE))
        assertFalse(garage.has(PlaceFeature.TEMP))

        assertTrue(PlaceConditions.guess("Xyz").isEmpty())
    }

    @Test
    fun parsesAiSuggestionEvenWithFences() {
        val raw = "```json\n{\"temperatura\":{\"attiva\":true,\"min\":16,\"max\":10},\"umidita\":{\"attiva\":true,\"max\":70},\"spazio\":{\"attiva\":false}}\n```"
        val c = PlaceConditions.parseSuggestion(raw)
        assertTrue(c.has(PlaceFeature.TEMP))
        assertTrue(c.has(PlaceFeature.HUMIDITY))
        assertFalse(c.has(PlaceFeature.SPACE))
        // min e max scambiati dall'AI si rimettono in ordine
        assertEquals(10.0, c.tempMin!!, 0.0)
        assertEquals(16.0, c.tempMax!!, 0.0)
        assertEquals(70, c.humidityMax)
    }

    @Test(expected = IllegalArgumentException::class)
    fun unreadableSuggestionFails() {
        PlaceConditions.parseSuggestion("non so")
    }

    @Test
    fun alertsOnlyWhenOutOfRange() {
        val base = PlaceConditions(setOf(PlaceFeature.TEMP.key, PlaceFeature.HUMIDITY.key, PlaceFeature.SPACE.key), tempMin = 10.0, tempMax = 16.0, humidityMax = 70)
        assertTrue(base.alerts().isEmpty())
        assertTrue(base.copy(temp = 12.0, humidity = 60, spacePct = 40).alerts().isEmpty())
        assertEquals(listOf("Troppo caldo: 18 °C"), base.copy(temp = 18.0).alerts())
        assertEquals(listOf("Troppo freddo: 8,5 °C"), base.copy(temp = 8.5).alerts())
        assertEquals(listOf("Troppa umidità: 80%"), base.copy(humidity = 80).alerts())
        assertEquals(listOf("Quasi pieno: 95%"), base.copy(spacePct = 95).alerts())
        // un'opzione spenta non avvisa più, anche con la lettura ancora salvata
        assertTrue(base.with(PlaceFeature.TEMP, false).copy(temp = 30.0).alerts().isEmpty())
    }

    @Test
    fun readsNumbersTheItalianWay() {
        assertEquals(12.5, PlaceConditions.readNumber("12,5")!!, 0.0)
        assertEquals(12.0, PlaceConditions.readNumber(" 12 ")!!, 0.0)
        assertNull(PlaceConditions.readNumber("abc"))
        assertNull(PlaceConditions.readNumber(""))
    }

    @Test
    fun surviveSaveAndLoadInsideTheTabs() {
        val opts = PlaceConditions(setOf(PlaceFeature.TEMP.key), temp = 12.5, tempMin = 10.0, tempMax = 16.0)
        val (c, tab) = KitchenTabsConfig().add("Cantina", now = 1L, options = opts)!!
        val back = KitchenTabsConfig.parse(c.toJson())
        assertEquals(opts, back.conditions(tab.id))
        // le schede di base non hanno opzioni
        assertTrue(back.conditions("frigo").isEmpty())
        // cambiare le letture
        val next = back.withConditions(tab.id, opts.copy(temp = 20.0))
        assertEquals(20.0, KitchenTabsConfig.parse(next.toJson()).conditions(tab.id).temp!!, 0.0)
        // rinominare non perde le opzioni
        assertEquals(opts, next.withConditions(tab.id, opts).rename(tab.id, "Cantina nuova").conditions(tab.id))
    }
}
