package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Aggiunta di un prodotto alla lista (a mano, dall'AI o da "Finito"): niente doppioni, niente silenzi. */
class ShoppingAddTest {
    private fun add(list: List<ShopItem>, name: String) = withNewItems(list, listOf(ListSuggestion(name, "")))

    @Test fun prodottoNuovoSiAggiunge() {
        val r = add(emptyList(), "Latte")
        assertEquals(1, r.count)
        assertEquals(listOf("Latte"), r.list.map { it.text })
    }

    @Test fun giaInListaNonSiDuplica() {
        val r = add(listOf(ShopItem("Latte", false, 1L)), "latte")
        assertEquals(0, r.count)
        assertEquals(1, r.list.size)
    }

    @Test fun giaPresoTornaDaComprare() {
        val r = add(listOf(ShopItem("Latte", true, 1L)), "Latte")
        assertEquals(1, r.count)
        val item = r.list.single()
        assertFalse(item.done)
        // Data nuova, altrimenti la sincronizzazione rimetterebbe "preso".
        assertTrue(item.updatedAt > 1L)
        assertEquals(emptyList<String>(), r.replacedKeys)
    }

    @Test fun leQuantitaSiSommano() {
        val r = add(listOf(ShopItem("Uova 6", false, 1L)), "Uova 12")
        assertEquals(listOf("Uova 18"), r.list.map { it.text })
        assertEquals(listOf("uova 6"), r.replacedKeys)
    }

    @Test fun nonToccaGliAltriProdotti() {
        val list = listOf(ShopItem("Pane", true, 1L), ShopItem("Latte", false, 2L))
        val r = add(list, "Burro")
        assertEquals(listOf("Burro", "Pane", "Latte"), r.list.map { it.text })
        assertTrue(r.list.first { it.text == "Pane" }.done)
    }

    @Test fun piuProdottiInUnaRiga() {
        assertEquals(listOf("latte", "uova", "pane"), splitItems("latte, uova; pane"))
        assertEquals(listOf("latte", "uova"), splitItems("latte\nuova\n"))
        assertEquals(listOf("Latte"), splitItems("  Latte  "))
        assertEquals(emptyList<String>(), splitItems(" , ; "))
    }

    @Test fun laVirgolaDecimaleNonSpezzaLaQuantita() {
        assertEquals(listOf("Pasta 0,5 kg", "latte"), splitItems("Pasta 0,5 kg, latte"))
        assertEquals(listOf("Olio 1,5 l"), splitItems("Olio 1,5 l"))
    }

    @Test fun ceCheDettiDiventaUnaLista() {
        assertEquals("latte, uova, pane", fromSpeech("latte e uova e pane"))
        assertEquals("latte, uova", fromSpeech(" latte e uova "))
        assertEquals("pane", fromSpeech("pane"))
        // Senza separatori resta una voce sola, che si corregge nel campo prima di aggiungere.
        assertEquals("latte uova", fromSpeech("latte uova"))
    }

    @Test fun piuProdottiSiAggiungonoUnoPerUno() {
        val r = withNewItems(listOf(ShopItem("Latte", false, 1L)), listOf("latte", "uova", "pane").map { ListSuggestion(it, "") })
        assertEquals(2, r.count)
        assertEquals(3, r.list.size)
    }
}
