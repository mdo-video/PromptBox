package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FreezerExtrasTest {
    @Test fun scongelareSpostaInFrigoConScadenzaNuova() {
        val frozen = PantryItem("a", "Macinato", "congelatore", "Carne", "", 500L, 0L, frozenAt = 100L, lifeDays = 90)
        val t = Pantry.thawed(frozen, today = 1000L)
        assertEquals("frigo", t.place)
        assertEquals("Carne e pesce", t.shelf)
        assertEquals(1002L, t.expiry)
        assertNull(t.frozenAt)
        assertNull(t.lifeDays)
        assertEquals(1003L, Pantry.thawed(frozen.copy(shelf = "Verdure e frutta"), today = 1000L).expiry)
        listOf("Carne", "Pesce", "Verdure e frutta", "Pronti e sughi", "Pane e dolci", "Altro").forEach {
            assertTrue(Pantry.thawedPlace(it).first in Pantry.FRIDGE)
        }
    }

    @Test fun piuProdottiInUnaRisposta() {
        val raw = "{\"prodotti\":[" +
            "{\"nome\":\"Hamburger di manzo\",\"ripiano\":\"Carne\",\"pezzi\":4,\"peso\":\"100 g\",\"data\":\"\",\"mesi\":3}," +
            "{\"nome\":\"Petto di pollo\",\"ripiano\":\"Carne\",\"pezzi\":2,\"peso\":\"\",\"data\":\"\",\"mesi\":9}," +
            "{\"errore\":\"x\"}]}"
        val list = PantryPhoto.parseAll(raw, "congelatore", 5000L)
        assertEquals(2, list.size)
        assertEquals("4 × 100 g", list[0].qty)
        assertEquals("2", list[1].qty)
        assertEquals(5000L + Freezer.lifeDays(9.0), list[1].expiry)
    }

    @Test fun unSoloOggettoRestaUnSoloProdotto() {
        val list = PantryPhoto.parseAll("{\"nome\":\"Latte\",\"ripiano\":\"Latticini\",\"pezzi\":1,\"peso\":\"1 l\",\"giorni\":5}", "frigo", 100L)
        assertEquals(1, list.size)
        assertEquals(105L, list[0].expiry)
    }

    @Test fun surgelatiDelloScontrinoVannoNelCongelatore() {
        val plan = Stock.guess(StockCandidate("Bastoncini di merluzzo", "Surgelati", 3.5))
        assertEquals("congelatore", plan.place)
        assertEquals("Pesce", plan.shelf)
        assertEquals(Freezer.lifeDays(Freezer.defaultMonths("Pesce")), plan.days)
        val item = Stock.toItems(listOf(plan), now = 1L, today = 10L).single()
        assertEquals("congelatore", item.place)
        assertEquals(10L, item.frozenAt)
        assertEquals(plan.days, item.lifeDays)
        assertEquals(Freezer.expiry(10L, plan.days, -18), item.expiry)
        assertEquals(false, item.estimated)
        val cold = Stock.toItems(listOf(plan), now = 1L, today = 10L, freezerTemp = -24).single()
        assertTrue(cold.expiry!! > item.expiry!!)
    }

    @Test fun ripianoDelCongelatoreDalNome() {
        assertEquals("Verdure e frutta", Stock.freezerShelfFor("Spinaci in foglie"))
        assertEquals("Pesce", Stock.freezerShelfFor("Frutti di mare misti"))
        assertEquals("Carne", Stock.freezerShelfFor("Hamburger di manzo"))
        assertEquals("Pronti e sughi", Stock.freezerShelfFor("Pizza margherita"))
        assertEquals("Altro", Stock.freezerShelfFor("Cubetti di ghiaccio"))
    }

    @Test fun rinnovareUnSurgelatoAggiornaAncheGliCampiDelCongelatore() {
        val old = PantryItem("a", "Piselli", "congelatore", "Verdure e frutta", "", 100L, 0L, frozenAt = 1L, lifeDays = 100)
        val add = old.copy(id = "b", expiry = 500L, frozenAt = 50L, lifeDays = 300)
        val m = Stock.merge(listOf(old), listOf(add)).single()
        assertEquals(50L, m.frozenAt)
        assertEquals(300, m.lifeDays)
        assertEquals(500L, m.expiry)
    }

    @Test fun avvisoDiScadenzaVaAncheAiCongelati() {
        val today = 1000L
        val soon = PantryItem("a", "Macinato", "congelatore", "Carne", "", today + 10, 0L, frozenAt = 1L, lifeDays = 90)
        val note = Reminders.expiryNote(listOf(soon), today)
        assertNotNull(note)
        assertEquals("congelatore", note!!.place)
        assertNull(Reminders.expiryNote(listOf(soon.copy(expiry = today + 200)), today))
        assertEquals(1, Reminders.expiryNote(listOf(soon.copy(expiry = today - 1)), today)!!.late)
    }
}
