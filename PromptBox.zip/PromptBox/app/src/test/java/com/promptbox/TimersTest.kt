package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Test

class TimersTest {
    @Test fun trovaMinutiEOre() {
        val hits = Timers.parse("Cuoci 12 min e lascia riposare 1 ora.")
        assertEquals(listOf(720, 3600), hits.map { it.seconds })
    }

    @Test fun conUnIntervalloValeIlNumeroPiuAlto() {
        assertEquals(720, Timers.parse("Forno per 10-12 minuti").single().seconds)
    }

    @Test fun nonConfondeAltriNumeri() {
        assertEquals(emptyList<TimerHit>(), Timers.parse("Servono 3 uova e 200 g di farina, 2 volte"))
    }

    @Test fun nonRipeteLoStessoTempo() {
        assertEquals(1, Timers.parse("5 min qui e ancora 5 min là").size)
    }

    @Test fun scritturaBreve() {
        assertEquals("1 min 30 s", Timers.pretty(90))
        assertEquals("1 h", Timers.pretty(3600))
    }
}
