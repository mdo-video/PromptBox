package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Test

class GuidedFieldsTest {
    private val fields = listOf(GuidedField("Persone", listOf("1", "2")), GuidedField("Evita", emptyList()))

    @Test fun componeLeRighe() {
        val values = mapOf("Persone" to "2", "Evita" to "  glutine ")
        assertEquals("Persone: 2\nEvita: glutine", GuidedFields.prefix(fields, values))
    }

    @Test fun ignoraICampiVuoti() {
        assertEquals("Persone: 1", GuidedFields.prefix(fields, mapOf("Persone" to "1", "Evita" to " ")))
    }

    @Test fun salvaERilegge() {
        assertEquals(fields, GuidedFields.fromJson(GuidedFields.toJson(fields)))
        val v = mapOf("Persone" to "2")
        assertEquals(v, GuidedFields.valuesFromJson(GuidedFields.valuesToJson(v)))
    }

    @Test fun leggeLaProstaDellAi() {
        val out = GuidedFields.parseSuggestion("```json\n[{\"label\":\"Tempo\",\"options\":[\"15 min\",\"30 min\"]},{\"label\":\"Evita\",\"options\":[]}]\n```")
        assertEquals(listOf("Tempo", "Evita"), out.map { it.label })
        assertEquals(listOf("15 min", "30 min"), out[0].options)
    }
}
