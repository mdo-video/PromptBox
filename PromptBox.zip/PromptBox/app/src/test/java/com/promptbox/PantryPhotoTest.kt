package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PantryPhotoTest {
    @Test fun codiceABarreConCifraDiControllo() {
        assertTrue(PantryPhoto.validEan("4006381333931"))
        assertFalse(PantryPhoto.validEan("4006381333932"))
        assertFalse(PantryPhoto.validEan("123"))
        assertFalse(PantryPhoto.validEan("40063813339a1"))
    }

    @Test fun quantitaDaOpenFoodFacts() {
        assertEquals("3 × 100 g", PantryPhoto.qtyFromOff("3 x 100 g"))
        assertEquals("3 × 125 g", PantryPhoto.qtyFromOff("3x125 g"))
        assertEquals("125 g", PantryPhoto.qtyFromOff("125 g"))
        assertEquals("100 g", PantryPhoto.qtyFromOff("1 x 100 g"))
        assertEquals("6", PantryPhoto.qtyFromOff("6 uova"))
        assertEquals("", PantryPhoto.qtyFromOff(""))
    }

    @Test fun leggeLaRispostaDellAi() {
        val today = Pantry.today()
        val g = PantryPhoto.parse(
            "{\"nome\":\"Mozzarella Consilia\",\"ripiano\":\"latticini\",\"pezzi\":3,\"peso\":\"100 g\",\"scadenza\":\"\",\"codice\":\"\",\"giorni\":5}",
            "frigo", today,
        )
        assertEquals("Mozzarella Consilia", g.name)
        assertEquals("Latticini", g.shelf)
        assertEquals("3 × 100 g", g.qty)
        assertEquals(today + 5, g.expiry)
        assertTrue(g.estimated)
    }

    @Test fun scadenzaVistaNellaFotoNonEStimata() {
        val g = PantryPhoto.parse(
            "```json\n{\"nome\":\"Latte\",\"ripiano\":\"Latticini\",\"pezzi\":1,\"peso\":\"1 l\",\"scadenza\":\"2027-03-12\",\"giorni\":7}\n```",
            "frigo",
        )
        assertEquals("1 l", g.qty)
        assertFalse(g.estimated)
        assertEquals(ExpiryTools.parseDate("2027-03-12"), g.expiry)
    }

    @Test fun ripianoSconosciutoERispostaSenzaProdotto() {
        val g = PantryPhoto.parse("{\"nome\":\"Pasta\",\"ripiano\":\"Boh\",\"pezzi\":1,\"peso\":\"\",\"giorni\":0}", "dispensa")
        assertNull(g.shelf)
        assertNull(g.expiry)
        assertEquals("", g.qty)
        val failed = runCatching { PantryPhoto.parse("{\"errore\":\"nessun prodotto\"}", "frigo") }
        assertTrue(failed.isFailure)
    }
}
