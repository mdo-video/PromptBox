package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Test

class StockTest {
    @Test fun propostaPerReparto() {
        assertEquals("frigo", Stock.guess(StockCandidate("Yogurt", "Latticini e uova")).place)
        assertEquals(21, Stock.guess(StockCandidate("Uova", "Latticini e uova")).days)
        assertEquals("Cassetto verdure", Stock.guess(StockCandidate("Spinaci", "Frutta e verdura")).shelf)
        assertEquals(3, Stock.guess(StockCandidate("Pane casereccio", "Pane e cereali")).days)
        assertEquals(270, Stock.guess(StockCandidate("Riso", "Pane e cereali")).days)
        assertEquals("", Stock.guess(StockCandidate("Piselli", "Surgelati")).place)
        assertEquals("", Stock.guess(StockCandidate("Detersivo", "Casa e igiene")).place)
    }

    @Test fun scalaDeiGiorni() {
        assertEquals(7, Stock.step(5, up = true))
        assertEquals(3, Stock.step(5, up = false))
        assertEquals(1, Stock.step(1, up = false))
        assertEquals(730, Stock.step(730, up = true))
        assertEquals(14, Stock.step(10, up = true))
    }

    @Test fun creaSoloIProdottiConUnPosto() {
        val plans = listOf(
            StockPlan("Latte", "frigo", "Latticini", 5),
            StockPlan("Piselli", "", "", 0),
            StockPlan("Pasta", "dispensa", "Ripiano inventato", 300),
        )
        val items = Stock.toItems(plans, now = 1000L, today = 100L)
        assertEquals(listOf("Latte", "Pasta"), items.map { it.name })
        assertEquals(105L, items[0].expiry)
        assertEquals(Pantry.PANTRY.first(), items[1].shelf) // ripiano non valido → il primo
    }

    @Test fun rinnovaInveceDiDuplicare() {
        val old = PantryItem("a", "Latte", "frigo", "Latticini", "1 L", 10L, 1L)
        val added = PantryItem("b", " latte ", "frigo", "Latticini", "", 20L, 2L)
        val other = PantryItem("c", "Burro", "frigo", "Latticini", "", 30L, 3L)
        val merged = Stock.merge(listOf(old), listOf(added, other))
        assertEquals(2, merged.size)
        assertEquals(20L, merged[0].expiry)
        assertEquals("1 L", merged[0].qty) // tiene la quantità di prima
        assertEquals("Burro", merged[1].name)
    }

    @Test fun leggeLaRispostaDellAi() {
        val cands = listOf(StockCandidate("Yogurt", "Latticini e uova"), StockCandidate("Piselli", "Surgelati"), StockCandidate("Pane", "Pane e cereali"))
        val raw = "```json\n[{\"nome\":\"yogurt\",\"luogo\":\"frigo\",\"ripiano\":\"Latticini\",\"giorni\":18}," +
            "{\"nome\":\"Piselli\",\"luogo\":\"nessuno\",\"ripiano\":\"\",\"giorni\":0}]\n```"
        val out = Stock.parseAi(raw, cands)
        assertEquals(StockPlan("Yogurt", "frigo", "Latticini", 18), out[0])
        assertEquals("", out[1].place)
        assertEquals(3, out[2].days) // non risposto dall'AI → stima per reparto
    }
}
