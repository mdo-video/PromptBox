package com.promptbox

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ExpiryToolsTest {
    private fun day(y: Int, m: Int, d: Int) = LocalDate.of(y, m, d).toEpochDay()

    @Test fun leggeLaDataIso() {
        assertEquals(day(2027, 3, 12), ExpiryTools.parseDate("2027-03-12"))
        assertEquals(day(2027, 3, 12), ExpiryTools.parseDate("```\n2027-03-12\n```"))
    }

    @Test fun leggeLaDataItaliana() {
        assertEquals(day(2026, 12, 31), ExpiryTools.parseDate("31/12/2026"))
        assertEquals(day(2026, 12, 31), ExpiryTools.parseDate("31.12.2026"))
    }

    @Test fun soloMeseEAnnoVaAFineMese() {
        assertEquals(day(2027, 2, 28), ExpiryTools.parseDate("2027-02"))
        assertEquals(day(2028, 2, 29), ExpiryTools.parseDate("02/2028"))
    }

    @Test fun nessunaDataODataNonValida() {
        assertNull(ExpiryTools.parseDate("NESSUNA"))
        assertNull(ExpiryTools.parseDate(""))
        assertNull(ExpiryTools.parseDate("2027-02-30"))
        assertNull(ExpiryTools.parseDate("non si legge"))
    }
}
