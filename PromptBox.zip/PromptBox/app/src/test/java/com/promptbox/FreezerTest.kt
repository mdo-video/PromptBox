package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FreezerTest {
    @Test fun aMenoDiciottoLaDurataNonCambia() {
        assertEquals(1.0, Freezer.factor(-18), 0.0001)
        assertEquals(100L + 270, Freezer.expiry(100L, 270, -18))
    }

    @Test fun piuCaldoAccorciaPiuFreddoAllunga() {
        assertTrue(Freezer.factor(-12) < 1.0)
        assertTrue(Freezer.factor(-24) > 1.0)
        assertTrue(Freezer.expiry(0L, 300, -12) < Freezer.expiry(0L, 300, -18))
        assertTrue(Freezer.expiry(0L, 300, -24) > Freezer.expiry(0L, 300, -18))
    }

    @Test fun laTemperaturaStaNeiLimiti() {
        assertEquals(Freezer.MAX_TEMP, Freezer.clampTemp(5))
        assertEquals(Freezer.MIN_TEMP, Freezer.clampTemp(-80))
    }

    @Test fun durataInTesto() {
        assertEquals("6 sett.", Freezer.durationText(42))
        assertEquals("1 mese", Freezer.durationText(61))
        assertEquals("9 mesi", Freezer.durationText(274))
    }

    @Test fun cambiandoTemperaturaSiRicalcolaSoloIlCongelatore() {
        val frozen = PantryItem("a", "Macinato", "congelatore", "Carne", "", 0L, 0L, frozenAt = 1000L, lifeDays = 90)
        val fridge = PantryItem("b", "Latte", "frigo", "Latticini", "", 55L, 0L)
        val out = Freezer.rescale(listOf(frozen, fridge), -24)
        assertEquals(Freezer.expiry(1000L, 90, -24), out[0].expiry)
        assertEquals(55L, out[1].expiry)
    }

    @Test fun rispostaAiPerIlCongelatore() {
        val today = Pantry.today()
        val g = PantryPhoto.parse(
            "{\"nome\":\"Macinato di manzo\",\"ripiano\":\"Carne\",\"pezzi\":1,\"peso\":\"800 g\",\"data\":\"\",\"mesi\":3}",
            "congelatore", today, -18,
        )
        assertEquals("Carne", g.shelf)
        assertEquals("800 g", g.qty)
        assertEquals(today, g.frozenAt)
        assertEquals(Freezer.lifeDays(3.0), g.lifeDays)
        assertEquals(today + Freezer.lifeDays(3.0), g.expiry)
        assertEquals(false, g.estimated)
    }

    @Test fun dataSullaBustaEInizioCongelamentoEMaiNelFuturo() {
        val today = Pantry.today()
        val past = PantryPhoto.parse(
            "{\"nome\":\"Petto di pollo\",\"ripiano\":\"Carne\",\"pezzi\":4,\"peso\":\"\",\"data\":\"" +
                java.time.LocalDate.ofEpochDay(today - 40) + "\",\"mesi\":9}",
            "congelatore", today, -18,
        )
        assertEquals(today - 40, past.frozenAt)
        assertEquals(today - 40 + Freezer.lifeDays(9.0), past.expiry)
        assertEquals("4", past.qty)
        val future = PantryPhoto.parse(
            "{\"nome\":\"Pesce\",\"ripiano\":\"Pesce\",\"pezzi\":1,\"peso\":\"\",\"data\":\"" +
                java.time.LocalDate.ofEpochDay(today + 10) + "\",\"mesi\":6}",
            "congelatore", today, -18,
        )
        assertEquals(today, future.frozenAt)
    }

    @Test fun senzaMesiDaAiSiUsaLaDurataDelRipiano() {
        val today = Pantry.today()
        val g = PantryPhoto.parse("{\"nome\":\"Spinaci\",\"ripiano\":\"Verdure e frutta\",\"pezzi\":1,\"peso\":\"\",\"data\":\"\"}", "congelatore", today)
        assertEquals(Freezer.lifeDays(Freezer.defaultMonths("Verdure e frutta")), g.lifeDays)
    }
}
