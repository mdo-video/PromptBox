package com.promptbox

import java.time.LocalDate
import java.time.LocalTime
import org.junit.Assert.assertEquals
import org.junit.Test

class CalendarFanTest {
    @Test fun leggeLuogoENoteFacoltativi() {
        val raw = "Ok! [[CALENDARIO: Allenamento # 2026-11-30 # 18:00 # 60 # 4 # Palestra Centro # Porta l'asciugamano | Corsa # 2026-12-01 # 07:30 # 45 # 1]]"
        val ev = CalendarTools.parse(raw)
        assertEquals(2, ev.size)
        assertEquals("Palestra Centro", ev[0].place)
        assertEquals("Porta l'asciugamano", ev[0].notes)
        assertEquals("", ev[1].place)
        assertEquals(1, ev[1].weeks)
    }

    @Test fun riepilogoMostraOrarioERipetizione() {
        val e = CalEvent("Allenamento", LocalDate.of(2026, 11, 30), LocalTime.of(18, 0), 60, 4, "Palestra")
        val s = CalendarTools.summary(e)
        assertEquals(true, s.contains("18:00–19:00"))
        assertEquals(true, s.contains("ogni settimana ×4"))
        assertEquals(true, s.endsWith("Palestra"))
    }

    @Test fun icsContieneLuogoENote() {
        val e = CalEvent("Cena", LocalDate.of(2026, 12, 5), LocalTime.of(20, 0), 90, 1, "Roma, centro", "Tavolo per 4")
        val ics = CalendarTools.toIcs(listOf(e))
        assertEquals(true, ics.contains("LOCATION:Roma\\, centro"))
        assertEquals(true, ics.contains("DESCRIPTION:Tavolo per 4"))
    }
}
