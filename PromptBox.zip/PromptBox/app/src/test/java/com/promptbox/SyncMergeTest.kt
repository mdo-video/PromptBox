package com.promptbox

import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Prove sulle regole di unione della sincronizzazione e sulla somma delle quantità. Si lanciano con ./gradlew testDebugUnitTest */
class SyncMergeTest {

    private fun sec(id: String, title: String, at: Long) =
        Section(id = id, title = title, emoji = "📌", hint = "", systemPrompt = "p", updatedAt = at)

    // --- sezioni ---

    @Test
    fun section_most_recent_wins() {
        val (list, _) = DriveSync.merge(listOf(sec("a", "vecchia", 1)), emptyMap(), listOf(sec("a", "nuova", 5)), emptyMap())
        assertEquals("nuova", list.single().title)
    }

    @Test
    fun section_deleted_after_edit_disappears_everywhere() {
        val (list, del) = DriveSync.merge(listOf(sec("a", "x", 1)), emptyMap(), emptyList(), mapOf("a" to 9L))
        assertTrue(list.isEmpty())
        assertEquals(9L, del["a"])
    }

    // --- lista della spesa ---

    @Test
    fun shopping_remote_newer_wins_and_delete_wins_when_newer() {
        val local = listOf(ShopItem("Latte", false, 1), ShopItem("Pane", false, 1))
        val remote = listOf(ShopItem("latte", true, 5))
        val (items, _) = DriveSync.mergeShopping(local, emptyMap(), remote, mapOf("pane" to 3L))
        assertEquals(listOf("latte"), items.map { it.text })
        assertTrue(items.single().done)
    }

    // --- blocchi (frigo, scontrini, routine, campi guidati) ---

    private fun arr(vararg ids: String) = JSONArray(ids.map { """{"i":"$it"}""" }.joinToString(",", "[", "]")).toString()

    @Test
    fun block_remote_newer_replaces_local() {
        val (out, changed) = DriveSync.mergeBlocks(
            mapOf("pantry" to SyncBlock(arr("a"), 10)),
            mapOf("pantry" to SyncBlock(arr("b"), 20)),
            now = 99,
        )
        assertEquals(arr("b"), out.getValue("pantry").json)
        assertEquals(setOf("pantry"), changed)
    }

    @Test
    fun block_local_newer_is_kept_and_not_applied() {
        val (out, changed) = DriveSync.mergeBlocks(
            mapOf("pantry" to SyncBlock(arr("a"), 30)),
            mapOf("pantry" to SyncBlock(arr("b"), 20)),
            now = 99,
        )
        assertEquals(arr("a"), out.getValue("pantry").json)
        assertTrue(changed.isEmpty())
    }

    @Test
    fun block_never_synced_data_is_united_not_replaced() {
        val (out, changed) = DriveSync.mergeBlocks(
            mapOf("pantry" to SyncBlock(arr("tablet"), 0)),
            mapOf("pantry" to SyncBlock(arr("telefono"), 20)),
            now = 99,
        )
        val ids = JSONArray(out.getValue("pantry").json).let { a -> (0 until a.length()).map { a.getJSONObject(it).getString("i") } }
        assertEquals(setOf("tablet", "telefono"), ids.toSet())
        assertEquals(99L, out.getValue("pantry").at)
        assertTrue("pantry" in changed)
    }

    @Test
    fun block_never_synced_data_gets_a_date_when_drive_has_nothing() {
        val (out, changed) = DriveSync.mergeBlocks(mapOf("receipts" to SyncBlock(arr("r1"), 0)), emptyMap(), now = 77)
        assertEquals(77L, out.getValue("receipts").at)
        assertTrue("receipts" in changed)
    }

    @Test
    fun block_empty_device_takes_what_is_on_drive() {
        val (out, _) = DriveSync.mergeBlocks(
            mapOf("pantry" to SyncBlock("[]", 0)),
            mapOf("pantry" to SyncBlock(arr("a"), 20)),
            now = 99,
        )
        assertEquals(arr("a"), out.getValue("pantry").json)
    }

    @Test
    fun empty_block_detection() {
        assertTrue(DriveSync.isEmptyBlock("pantry", "[]"))
        assertTrue(DriveSync.isEmptyBlock("guided", "{}"))
        assertTrue(DriveSync.isEmptyBlock("routines", """{"r":"[]","x":false}"""))
        assertFalse(DriveSync.isEmptyBlock("routines", """{"r":"[]","x":true}"""))
        assertFalse(DriveSync.isEmptyBlock("pantry", arr("a")))
    }

    // --- quantità nella lista della spesa ---

    private fun names(vararg n: String) = n.map { ListSuggestion(it, "") }

    @Test
    fun quantities_are_parsed() {
        val q = parseQty("Pasta 500 g")!!
        assertEquals("pasta", q.base)
        assertEquals(500.0, q.n, 0.0)
        assertEquals("g", q.unit)
        assertEquals(1.5, parseQty("Latte 1,5 l")!!.n, 0.0)
        assertEquals(null, parseQty("Pomodori pelati"))
    }

    @Test
    fun same_product_quantities_are_summed() {
        val r = withNewItems(listOf(ShopItem("Uova 6", false, 1)), names("uova 12"))
        assertEquals(listOf("Uova 18"), r.list.map { it.text })
        assertEquals(listOf("uova 6"), r.replacedKeys)
        assertEquals(1, r.count)
    }

    @Test
    fun existing_product_is_not_duplicated() {
        val r = withNewItems(listOf(ShopItem("Latte", false, 1)), names("latte", "Pane"))
        assertEquals(setOf("Latte", "Pane"), r.list.map { it.text }.toSet())
        assertEquals(1, r.count)
        assertTrue(r.replacedKeys.isEmpty())
    }

    @Test
    fun different_units_keep_the_existing_item() {
        val r = withNewItems(listOf(ShopItem("Pasta 500 g", false, 1)), names("Pasta 2 kg"))
        assertEquals(listOf("Pasta 500 g"), r.list.map { it.text })
        assertEquals(0, r.count)
    }

    // --- chat e archivio documenti ---

    @Test
    fun chats_union_keeps_longer_chat_and_merges_archive() {
        val local = """{"cur":{"a":"[1,2,3]","b":"[1]"},"arch":"[{\"id\":1,\"a\":10},{\"id\":2,\"a\":30}]"}"""
        val remote = """{"cur":{"a":"[1]","c":"[1,2]"},"arch":"[{\"id\":2,\"a\":30},{\"id\":3,\"a\":20}]"}"""
        val o = org.json.JSONObject(DriveSync.unionBlock("chats", local, remote))
        val cur = o.getJSONObject("cur")
        assertEquals(3, JSONArray(cur.getString("a")).length())
        assertEquals(setOf("a", "b", "c"), cur.keys().asSequence().toSet())
        val ids = JSONArray(o.getString("arch")).let { a -> (0 until a.length()).map { a.getJSONObject(it).getLong("id") } }
        assertEquals(listOf(2L, 3L, 1L), ids)
    }

    @Test
    fun docs_union_adds_missing_items_and_keeps_archive_on() {
        val local = """{"items":{"s":"[{\"id\":1},{\"id\":2}]"},"on":{"s":true},"chat":{"s":false}}"""
        val remote = """{"items":{"s":"[{\"id\":2},{\"id\":3}]"},"on":{"s":false},"chat":{"s":true}}"""
        val o = org.json.JSONObject(DriveSync.unionBlock("docs", local, remote))
        assertEquals(3, JSONArray(o.getJSONObject("items").getString("s")).length())
        assertTrue(o.getJSONObject("on").getBoolean("s"))
        assertTrue(o.getJSONObject("chat").getBoolean("s"))
    }

    @Test
    fun chats_and_docs_empty_blocks_are_recognised() {
        assertTrue(DriveSync.isEmptyBlock("chats", """{"cur":{},"arch":"[]"}"""))
        assertFalse(DriveSync.isEmptyBlock("chats", """{"cur":{"a":"[1]"},"arch":"[]"}"""))
        assertTrue(DriveSync.isEmptyBlock("docs", """{"items":{},"on":{},"chat":{}}"""))
        assertFalse(DriveSync.isEmptyBlock("docs", """{"items":{},"on":{"a":true},"chat":{}}"""))
    }

    // --- unione a tre vie delle chat ---

    private fun t(u: Boolean, text: String, ts: Long) = """{"u":$u,"t":"$text","i":false,"d":"","ts":$ts}"""
    private fun chats(cur: Map<String, String>, arch: String = "[]"): String {
        val c = org.json.JSONObject(); cur.forEach { (k, v) -> c.put(k, v) }
        return org.json.JSONObject().put("cur", c).put("arch", arch).toString()
    }

    @Test
    fun mergeTurns_keeps_messages_of_both_devices_in_time_order() {
        val common = t(true, "ciao", 1) + "," + t(false, "salve", 2)
        val local = "[$common," + t(true, "da A", 10) + "]"
        val remote = "[$common," + t(true, "da B", 5) + "]"
        val a = JSONArray(DriveSync.mergeTurns(local, remote))
        assertEquals(listOf("ciao", "salve", "da B", "da A"), (0 until a.length()).map { a.getJSONObject(it).getString("t") })
    }

    @Test
    fun mergeTurns_longer_wins_when_one_extends_the_other() {
        val short = "[" + t(true, "a", 1) + "]"
        val long = "[" + t(true, "a", 1) + "," + t(false, "b", 2) + "]"
        assertEquals(2, JSONArray(DriveSync.mergeTurns(short, long)).length())
        assertEquals(2, JSONArray(DriveSync.mergeTurns(long, short)).length())
    }

    @Test
    fun mergeChats_deleted_chat_stays_deleted_and_new_chat_is_kept() {
        val one = "[" + t(true, "x", 1) + "]"
        val two = "[" + t(true, "y", 2) + "]"
        val base = chats(mapOf("a" to one))
        val local = chats(mapOf("b" to two)) // a cancellata qui, b nuova qui
        val remote = chats(mapOf("a" to one)) // a invariata sull'altro dispositivo
        val cur = org.json.JSONObject(DriveSync.mergeChats(base, local, remote)).getJSONObject("cur")
        assertEquals(setOf("b"), cur.keys().asSequence().toSet())
    }

    @Test
    fun mergeChats_changed_beats_deleted() {
        val one = "[" + t(true, "x", 1) + "]"
        val more = "[" + t(true, "x", 1) + "," + t(false, "z", 3) + "]"
        val base = chats(mapOf("a" to one))
        val local = chats(emptyMap())
        val remote = chats(mapOf("a" to more))
        val cur = org.json.JSONObject(DriveSync.mergeChats(base, local, remote)).getJSONObject("cur")
        assertEquals(2, JSONArray(cur.getString("a")).length())
    }

    @Test
    fun mergeBlocks_chats_without_base_keeps_last_wins() {
        val l = mapOf("chats" to SyncBlock(chats(mapOf("a" to "[" + t(true, "x", 1) + "]")), 5))
        val r = mapOf("chats" to SyncBlock(chats(mapOf("a" to "[" + t(true, "y", 2) + "]")), 9))
        val m = DriveSync.mergeBlocks(l, r, 100)
        assertEquals(r["chats"], m.first["chats"])
    }

    @Test
    fun docFiles_lists_pdf_names_from_docs_block() {
        val json = """{"items":{"a":"[{\"id\":1,\"file\":\"a_1.pdf\"},{\"id\":2,\"file\":\"\"}]","b":"[{\"id\":3,\"file\":\"b_3.pdf\"}]"},"on":{},"chat":{}}"""
        assertEquals(setOf("a_1.pdf", "b_3.pdf"), DriveSync.docFiles(json))
        assertEquals(emptySet<String>(), DriveSync.docFiles("non json"))
    }

    @Test fun laChiaveApiNonSiPerde() {
        val conChiave = """{"theme":1,"apiKey":"abc"}"""
        val senza = """{"theme":2}"""
        // Le impostazioni scelte non hanno la chiave: si prende dall'altra parte.
        assertEquals("abc", DriveSync.secretOf(DriveSync.fillSecret(senza, conChiave, "apiKey"), "apiKey"))
        // Se ce l'hanno già non si tocca niente.
        assertEquals(conChiave, DriveSync.fillSecret(conChiave, """{"apiKey":"xyz"}""", "apiKey"))
        // Nessuna delle due: resta com'è.
        assertEquals(senza, DriveSync.fillSecret(senza, senza, "apiKey"))
    }
}
