package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlaceMapTest {
    private fun overlap(a: PlanBox, b: PlanBox) =
        a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h

    @Test
    fun newShelvesGetFreeSpotsWithoutOverlap() {
        val boxes = PlaceMap.layout(listOf("A", "B", "C", "D"), emptyList())
        assertEquals(listOf("A", "B", "C", "D"), boxes.map { it.shelf })
        for (i in boxes.indices) for (j in i + 1 until boxes.size) assertFalse("${boxes[i]} / ${boxes[j]}", overlap(boxes[i], boxes[j]))
        assertTrue(boxes.all { it.x >= 0f && it.y >= 0f && it.x + it.w <= 1.0001f && it.y + it.h <= 1.0001f })
    }

    @Test
    fun savedBoxesStayWhereTheyAre() {
        val saved = listOf(PlanBox("B", 0.5f, 0.7f, 0.3f, 0.2f))
        val boxes = PlaceMap.layout(listOf("A", "B"), saved)
        assertEquals(saved[0], boxes[1])
        assertFalse(overlap(boxes[0], boxes[1]))
    }

    @Test
    fun moveAndResizeStayInside() {
        val b = PlanBox("A", 0.5f, 0.5f, 0.4f, 0.3f)
        val m = PlaceMap.move(b, 5f, -5f)
        assertEquals(1f - 0.4f, m.x, 0.0001f)
        assertEquals(0f, m.y, 0.0001f)
        val r = PlaceMap.resize(b, 5f, 5f)
        assertEquals(1f, r.x + r.w, 0.0001f)
        assertEquals(1f, r.y + r.h, 0.0001f)
        val small = PlaceMap.resize(b, -5f, -5f)
        assertEquals(PlaceMap.MIN_W, small.w, 0.0001f)
        assertEquals(PlaceMap.MIN_H, small.h, 0.0001f)
        // un riquadro già contro il bordo non fa lanciare errori
        PlaceMap.resize(PlanBox("A", 0.95f, 0.95f, 0.2f, 0.14f), 0.3f, 0.3f)
    }

    @Test
    fun onlyShelvesWithItemsAppearAndGrowAsYouAdd() {
        val shelves = listOf(PlanShelf("Generale", "📦", 0), PlanShelf("Altro", "📦", 0))
        assertTrue(PlaceMap.zones(shelves, emptyList()).isEmpty())
        val one = PlaceMap.zones(listOf(PlanShelf("Generale", "📦", 2), PlanShelf("Altro", "📦", 0)), emptyList())
        assertEquals(listOf("Generale"), one.map { it.box.shelf })
        assertEquals(2, one[0].count)
        // un ripiano già posizionato resta anche se ora è vuoto
        val kept = PlaceMap.zones(shelves, listOf(PlanBox("Altro", 0.1f, 0.1f, 0.3f, 0.2f)))
        assertEquals(listOf("Altro"), kept.map { it.box.shelf })
    }

    @Test
    fun commitSavesEveryVisibleBoxAndKeepsHiddenOnes() {
        val current = PlaceMap.layout(listOf("A", "B"), emptyList())
        val hidden = PlanBox("Z", 0.1f, 0.1f, 0.3f, 0.2f)
        val plan = PlaceMap.commit(listOf(hidden), current, current[0].copy(x = 0.3f, y = 0.6f))
        assertEquals(setOf("A", "B", "Z"), plan.map { it.shelf }.toSet())
        assertEquals(0.3f, plan.first { it.shelf == "A" }.x, 0.0001f)
        assertEquals(current[1], plan.first { it.shelf == "B" })
    }

    @Test
    fun planSurvivesSaveAndLoad() {
        val plan = listOf(PlanBox("Scaffale", 0.1f, 0.2f, 0.4f, 0.3f))
        val opts = PlaceConditions(setOf(PlaceFeature.MAP.key), plan = plan)
        val (c, tab) = KitchenTabsConfig().add("Garage", now = 1L, options = opts)!!
        val back = KitchenTabsConfig.parse(c.toJson()).conditions(tab.id)
        assertEquals(plan, back.plan)
        assertTrue(back.has(PlaceFeature.MAP))
        assertFalse(back.hasReadings())
    }

    @Test
    fun garageGuessAndAiIncludeThePlan() {
        assertTrue(PlaceConditions.guess("Garage").has(PlaceFeature.MAP))
        assertFalse(PlaceConditions.guess("Cantina").has(PlaceFeature.MAP))
        assertTrue(PlaceConditions.parseSuggestion("{\"spazio\":{\"attiva\":true},\"piantina\":{\"attiva\":true}}").has(PlaceFeature.MAP))
    }
}
