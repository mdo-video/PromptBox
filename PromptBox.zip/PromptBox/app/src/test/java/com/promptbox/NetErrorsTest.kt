package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.net.ssl.SSLException

class NetErrorsTest {
    @Test fun senzaReteSiRiprovaEIlMessaggioDiceInternet() {
        val e = UnknownHostException("Unable to resolve host \"generativelanguage.googleapis.com\"")
        assertTrue(NetErrors.isRetryable(e))
        assertTrue(NetErrors.friendly(e).contains("internet"))
        assertFalse(NetErrors.friendly(e).contains("resolve"))
    }

    @Test fun serverIrraggiungibileSiRiprova() {
        assertTrue(NetErrors.isRetryable(ConnectException("Failed to connect")))
    }

    @Test fun timeoutDiConnessioneSiRiprovaQuelloDiLetturaNo() {
        assertTrue(NetErrors.isRetryable(SocketTimeoutException("failed to connect to host")))
        // Se l'AI ha già cominciato a rispondere non si ripete la richiesta.
        assertFalse(NetErrors.isRetryable(SocketTimeoutException("Read timed out")))
        assertTrue(NetErrors.friendly(SocketTimeoutException("Read timed out")).contains("troppo"))
    }

    @Test fun altriErroriDiRete() {
        assertFalse(NetErrors.isRetryable(SSLException("Connection closed by peer")))
        assertEquals("Connessione interrotta. Riprova.", NetErrors.friendly(IOException("Socket closed")))
        assertTrue(NetErrors.friendly(SSLException("x")).contains("sicura"))
    }

    @Test fun glAltriErroriRestanoInvariati() {
        assertEquals("Manca la chiave API.", NetErrors.friendly(IllegalArgumentException("Manca la chiave API.")))
        assertEquals("Errore sconosciuto", NetErrors.friendly(RuntimeException()))
    }

    @Test fun messaggioPerSincronizzazioneEAggiornamenti() {
        assertTrue(NetErrors.message(UnknownHostException("www.googleapis.com"), "x").contains("internet"))
        assertTrue(NetErrors.message(SocketTimeoutException("Read timed out"), "x").contains("lenta"))
        assertEquals("Accesso scaduto", NetErrors.message(RuntimeException("Accesso scaduto"), "x"))
        assertEquals("Sincronizzazione non riuscita.", NetErrors.message(RuntimeException(), "Sincronizzazione non riuscita."))
    }
}
