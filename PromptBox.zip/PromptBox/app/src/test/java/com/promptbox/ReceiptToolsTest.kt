package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ReceiptToolsTest {
    private val json = """
        {"negozio":"Conad","data":"2026-11-10","totale":5.5,
         "articoli":[
           {"nome":"Latte intero","prezzo":1.5,"reparto":"Latticini e uova"},
           {"nome":"Pane","prezzo":4.0,"reparto":"Reparto inventato"}]}
    """.trimIndent()

    @Test fun leggeLoScontrino() {
        val r = ReceiptTools.parse(json)
        assertEquals("Conad", r.shop)
        assertEquals(5.5, r.total, 0.001)
        assertEquals(2, r.items.size)
        assertEquals("Latticini e uova", r.items[0].dept)
        assertEquals("Altro", r.items[1].dept) // reparto sconosciuto
    }

    @Test fun accettaLaRispostaConIBackticks() {
        val r = ReceiptTools.parse("```json\n$json\n```")
        assertEquals(2, r.items.size)
    }

    @Test fun senzaTotaleSommaGliArticoli() {
        val r = ReceiptTools.parse("""{"negozio":"","data":"","totale":0,"articoli":[{"nome":"A","prezzo":1.25},{"nome":"B","prezzo":2.0}]}""")
        assertEquals(3.25, r.total, 0.001)
    }

    @Test fun rifiutaCiòCheNonÈUnoScontrino() {
        val err = runCatching { ReceiptTools.parse("""{"errore":"non è uno scontrino"}""") }.exceptionOrNull()
        assertTrue(err?.message.orEmpty().contains("scontrino"))
    }

    @Test fun salvaERilegge() {
        val r = ReceiptTools.parse(json)
        val back = ReceiptTools.listFromJson(ReceiptTools.listToJson(listOf(r)))
        assertEquals(r, back.single())
    }
}
