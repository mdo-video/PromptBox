package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NavTest {
    @Test fun tutteLeSchedeDellaCucinaAccendonoCucina() {
        listOf("shopping", "cucina", "frigo", "dispensa", "congelatore", "receipts").forEach { assertEquals("cucina", navCurrent(it)) }
        assertEquals("home", navCurrent("section:frigo"))
        assertEquals("home", navCurrent("home"))
        assertEquals("settings", navCurrent("settings"))
    }

    @Test fun laBarraRestaVisibileNelleSchermateDellaCucina() {
        listOf("home", "settings", "shopping", "cucina", "frigo", "dispensa", "congelatore", "receipts").forEach { assertTrue(it in NAV_SCREENS) }
        assertTrue("routines" !in NAV_SCREENS)
    }

    @Test fun leSchedeDellaCucinaSonoSeiESenzaDoppioni() {
        assertEquals(6, KITCHEN_TABS.size)
        assertEquals(KITCHEN_TABS.size, KITCHEN_TABS.map { it.first }.toSet().size)
        assertEquals("shopping", KITCHEN_TABS.first().first)
        assertTrue(KITCHEN_SCREENS.all { it in KITCHEN_AREA })
    }

    @Test fun ilRiepilogoDellaCucinaNominaTuttiEIPosti() {
        val item = PantryItem("a", "Latte", "frigo", "Latticini", "", 10L, 0L)
        val text = Pantry.cookPrompt(listOf(item), "tutto")
        assertTrue("frigo, dispensa e congelatore" in text)
    }
}
