package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NavTest {
    @Test fun tutteLeSchedeDellaCucinaAccendonoCucina() {
        listOf("shopping", "cucina", "frigo", "dispensa", "congelatore", "casa", "receipts").forEach { assertEquals("cucina", navCurrent(it)) }
        assertEquals("home", navCurrent("section:frigo"))
        assertEquals("home", navCurrent("home"))
        assertEquals("settings", navCurrent("settings"))
    }

    @Test fun laBarraRestaVisibileNelleSchermateDellaCucina() {
        listOf("home", "settings", "shopping", "cucina", "frigo", "dispensa", "congelatore", "casa", "receipts").forEach { assertTrue(it in NAV_SCREENS) }
        assertTrue("routines" !in NAV_SCREENS)
    }

    @Test fun leSchedeDellaCucinaSonoSetteESenzaDoppioni() {
        assertEquals(7, KITCHEN_TABS.size)
        assertEquals(KITCHEN_TABS.size, KITCHEN_TABS.map { it.first }.toSet().size)
        assertEquals("shopping", KITCHEN_TABS.first().first)
        assertTrue(KITCHEN_SCREENS.all { it in KITCHEN_AREA })
    }

    @Test fun ilRiepilogoDellaCucinaNominaTuttiEIPosti() {
        val item = PantryItem("a", "Latte", "frigo", "Latticini", "", 10L, 0L)
        val text = Pantry.cookPrompt(listOf(item), "tutto")
        assertTrue("frigo, dispensa e congelatore" in text)
    }

    @Test fun iProdottiDellaCasaNonSiCucinanoENonHannoScadenza() {
        val soap = PantryItem("b", "Detersivo piatti", "casa", "Pulizie", "", null, 0L)
        val milk = PantryItem("a", "Latte", "frigo", "Latticini", "", 10L, 0L)
        val text = Pantry.cookPrompt(listOf(milk, soap), "tutto")
        assertTrue("Latte" in text)
        assertTrue("Detersivo" !in text)
        assertEquals(Freshness.NONE, Pantry.freshness(soap))
        assertEquals("Casa e igiene", Pantry.deptFor(soap))
    }

    @Test fun ilReparto_CasaEIgiene_VaNellaSchedaPulizieSenzaScadenza() {
        val plan = Stock.guess(StockCandidate("Detersivo lavatrice Dixan", "Casa e igiene"))
        assertEquals("casa", plan.place)
        assertEquals("Lavanderia", plan.shelf)
        assertEquals("Bagno e igiene", Stock.homeShelfFor("Shampoo Pantene"))
        assertEquals("Carta e sacchetti", Stock.homeShelfFor("Carta igienica"))
        assertEquals("Pulizie", Stock.homeShelfFor("Sgrassatore universale"))
        val item = Stock.toItems(listOf(plan)).single()
        assertEquals(null, item.expiry)
        assertEquals("casa", item.place)
    }
}
