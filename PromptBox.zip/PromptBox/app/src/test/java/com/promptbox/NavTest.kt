package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NavTest {
    @Test fun frigoDispensaECongelatiAccendonoCucina() {
        listOf("frigo", "dispensa", "congelatore").forEach { assertEquals("cucina", navCurrent(it)) }
        assertEquals("cucina", navCurrent("cucina"))
        assertEquals("home", navCurrent("section:frigo"))
        assertEquals("settings", navCurrent("settings"))
    }

    @Test fun laBarraRestaVisibileNelleSchermateDellaCucina() {
        listOf("home", "shopping", "cucina", "settings", "frigo", "dispensa", "congelatore").forEach { assertTrue(it in NAV_SCREENS) }
    }

    @Test fun ilRiepilogoDellaCucinaNominaTuttiEIPosti() {
        val item = PantryItem("a", "Latte", "frigo", "Latticini", "", 10L, 0L)
        val text = Pantry.cookPrompt(listOf(item), "tutto")
        assertTrue("frigo, dispensa e congelatore" in text)
    }
}
