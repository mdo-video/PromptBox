package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Test

class PantryTest {
    private fun item(place: String, daysFromToday: Long?) = PantryItem(
        id = "t", name = "Prova", place = place, shelf = "", qty = "",
        expiry = daysFromToday?.let { Pantry.today() + it }, addedAt = 0L,
    )

    @Test fun etichetteDiScadenza() {
        val t = Pantry.today()
        assertEquals("Senza scadenza", Pantry.label(null))
        assertEquals("Scade oggi", Pantry.label(t))
        assertEquals("Scade domani", Pantry.label(t + 1))
        assertEquals("Scaduto ieri", Pantry.label(t - 1))
        assertEquals("Scaduto da 5 gg", Pantry.label(t - 5))
        assertEquals("Tra 9 gg", Pantry.label(t + 9))
        assertEquals("Tra 3 sett.", Pantry.label(t + 21))
        assertEquals("Tra 3 mesi", Pantry.label(t + 95))
    }

    @Test fun statoNelFrigo() {
        assertEquals(Freshness.NONE, Pantry.freshness(item("frigo", null)))
        assertEquals(Freshness.LATE, Pantry.freshness(item("frigo", -1)))
        assertEquals(Freshness.SOON, Pantry.freshness(item("frigo", 0)))
        assertEquals(Freshness.SOON, Pantry.freshness(item("frigo", 3)))
        assertEquals(Freshness.OK, Pantry.freshness(item("frigo", 4)))
    }

    @Test fun statoInDispensaHaUnaSogliaPiuLarga() {
        assertEquals(Freshness.SOON, Pantry.freshness(item("dispensa", 14)))
        assertEquals(Freshness.OK, Pantry.freshness(item("dispensa", 15)))
    }

    @Test fun ordinePerScadenzaConSenzaDataInFondo() {
        val a = item("frigo", 5).copy(name = "A")
        val b = item("frigo", 1).copy(name = "B")
        val c = item("frigo", null).copy(name = "C")
        assertEquals(listOf("B", "A", "C"), Pantry.sorted(listOf(c, a, b)).map { it.name })
    }

    @Test fun scadenzaStimataSiVedeEServeDaConfermare() {
        val sure = item("frigo", 5L)
        val guess = sure.copy(id = "g", estimated = true)
        assertEquals("Tra 5 gg", Pantry.labelOf(sure))
        assertEquals("circa tra 5 gg", Pantry.labelOf(guess))
        assertEquals(listOf("g"), Pantry.toConfirm(listOf(sure, guess)).map { it.id })
    }

    @Test fun prodottiFinitiVannoNellaListaDelRepartoGiusto() {
        fun on(name: String, shelf: String) = item("frigo", 3L).copy(name = name, shelf = shelf)
        val out = Pantry.toShopping(
            listOf(on(" Latte ", "Latticini"), on("Spinaci", "Cassetto verdure"), on("Pasta", "Pasta e cereali"), on("Maionese", "Sportello")),
        )
        assertEquals(listOf("Latte", "Spinaci", "Pasta", "Maionese"), out.map { it.name })
        assertEquals(listOf("Latticini e uova", "Frutta e verdura", "Pane e cereali", ""), out.map { it.dept })
    }

    @Test fun finitoNonDuplicaCiCheGiaInLista() {
        val list = listOf(ShopItem("Latte", false, 1L, "Latticini e uova"))
        val r = withNewItems(list, Pantry.toShopping(listOf(item("frigo", 3L).copy(name = "latte", shelf = "Latticini"))))
        assertEquals(0, r.count)
        assertEquals(1, r.list.size)
    }
}
