package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Test

class PantryTest {
    private fun item(place: String, daysFromToday: Long?) = PantryItem(
        id = "t", name = "Prova", place = place, shelf = "", qty = "",
        expiry = daysFromToday?.let { Pantry.today() + it }, addedAt = 0L,
    )

    @Test fun etichetteDiScadenza() {
        val t = Pantry.today()
        assertEquals("Senza scadenza", Pantry.label(null))
        assertEquals("Scade oggi", Pantry.label(t))
        assertEquals("Scade domani", Pantry.label(t + 1))
        assertEquals("Scaduto ieri", Pantry.label(t - 1))
        assertEquals("Scaduto da 5 gg", Pantry.label(t - 5))
        assertEquals("Tra 9 gg", Pantry.label(t + 9))
        assertEquals("Tra 3 sett.", Pantry.label(t + 21))
        assertEquals("Tra 3 mesi", Pantry.label(t + 95))
    }

    @Test fun statoNelFrigo() {
        assertEquals(Freshness.NONE, Pantry.freshness(item("frigo", null)))
        assertEquals(Freshness.LATE, Pantry.freshness(item("frigo", -1)))
        assertEquals(Freshness.SOON, Pantry.freshness(item("frigo", 0)))
        assertEquals(Freshness.SOON, Pantry.freshness(item("frigo", 3)))
        assertEquals(Freshness.OK, Pantry.freshness(item("frigo", 4)))
    }

    @Test fun statoInDispensaHaUnaSogliaPiuLarga() {
        assertEquals(Freshness.SOON, Pantry.freshness(item("dispensa", 14)))
        assertEquals(Freshness.OK, Pantry.freshness(item("dispensa", 15)))
    }

    @Test fun ordinePerScadenzaConSenzaDataInFondo() {
        val a = item("frigo", 5).copy(name = "A")
        val b = item("frigo", 1).copy(name = "B")
        val c = item("frigo", null).copy(name = "C")
        assertEquals(listOf("B", "A", "C"), Pantry.sorted(listOf(c, a, b)).map { it.name })
    }
}
