package com.promptbox

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PantryConfigTest {
    @After fun ripristina() {
        Pantry.config = PantryConfig()
    }

    @Test fun senzaModificheValgonoIPredefiniti() {
        val c = PantryConfig()
        assertEquals(Pantry.FRIDGE, c.shelfDefs("frigo").map { it.name })
        assertTrue(c.expiryOn("frigo", "Latticini"))
        assertFalse(c.expiryOn("casa", "Pulizie"))
        assertEquals("", c.toJson())
    }

    @Test fun salvaELeggeLeImpostazioni() {
        val c = PantryConfig().with(
            "dispensa",
            PlaceConfig(
                shelves = listOf(ShelfDef("Pasta", "🍝"), ShelfDef("Spezie", "🧂", expiry = false)),
                expiry = true, autoShelf = false, notify = false,
            ),
        ).with("frigo", PlaceConfig(expiry = false))
        val back = PantryConfig.parse(c.toJson())
        assertEquals(listOf("Pasta", "Spezie"), back.shelfDefs("dispensa").map { it.name })
        assertEquals("🧂", back.shelfDefs("dispensa")[1].emoji)
        assertFalse(back.of("dispensa").autoShelf)
        assertFalse(back.of("dispensa").notify)
        assertFalse(back.of("frigo").expiry)
        assertTrue(back.of("congelatore").expiry)
    }

    @Test fun testoRovinatoDaIPredefiniti() {
        assertEquals(Pantry.PANTRY, PantryConfig.parse("{non json").shelfDefs("dispensa").map { it.name })
        assertEquals(Pantry.PANTRY, PantryConfig.parse("").shelfDefs("dispensa").map { it.name })
    }

    @Test fun scadenzaSpentaPerPostoOPerRipiano() {
        val c = PantryConfig()
            .with("dispensa", PlaceConfig(shelves = listOf(ShelfDef("Pasta", "🍝"), ShelfDef("Spezie", "🧂", expiry = false))))
            .with("frigo", PlaceConfig(expiry = false))
        assertTrue(c.expiryOn("dispensa", "Pasta"))
        assertFalse(c.expiryOn("dispensa", "spezie"))
        assertFalse(c.expiryOn("frigo", "Latticini"))
        assertTrue(c.expiryOn("congelatore", "Carne"))
    }

    @Test fun senzaScadenzeNienteStatoNeAvvisi() {
        val item = PantryItem("a", "Latte", "frigo", "Latticini", "", Pantry.today() - 3, 0L)
        assertEquals(Freshness.LATE, Pantry.freshness(item))
        Pantry.config = PantryConfig().with("frigo", PlaceConfig(expiry = false))
        assertEquals(Freshness.NONE, Pantry.freshness(item))
        assertNull(Reminders.expiryNote(listOf(item)))
        assertTrue(Pantry.toConfirm(listOf(item.copy(estimated = true))).isEmpty())
    }

    @Test fun avvisiSpentiPerUnPosto() {
        val item = PantryItem("a", "Latte", "frigo", "Latticini", "", Pantry.today() + 1, 0L)
        assertTrue(Reminders.expiryNote(listOf(item)) != null)
        Pantry.config = PantryConfig().with("frigo", PlaceConfig(notify = false))
        assertNull(Reminders.expiryNote(listOf(item)))
        // La scadenza resta valida nella schermata: solo l'avviso è spento.
        assertEquals(Freshness.SOON, Pantry.freshness(item))
    }

    @Test fun ripianiPersonalizzatiEEmoji() {
        Pantry.config = PantryConfig().with("dispensa", PlaceConfig(shelves = listOf(ShelfDef("Spezie", "🌶️"), ShelfDef("Tè", "🍵"))))
        assertEquals(listOf("Spezie", "Tè"), Pantry.shelves("dispensa"))
        assertEquals("🌶️", Pantry.shelfEmoji("Spezie"))
        assertEquals("🥛", Pantry.shelfEmoji("Latticini"))
        assertEquals(Pantry.FRIDGE, Pantry.shelves("frigo"))
    }

    @Test fun scongelareUsaUnRipianoCheEsiste() {
        Pantry.config = PantryConfig().with("frigo", PlaceConfig(shelves = listOf(ShelfDef("Cassetto 1", "📦"))))
        val frozen = PantryItem("a", "Macinato", "congelatore", "Carne", "", 500L, 0L, frozenAt = 100L, lifeDays = 90)
        assertEquals("Cassetto 1", Pantry.thawed(frozen, today = 1000L).shelf)
    }

    @Test fun nomeDelRipianoValido() {
        val others = listOf("Latticini", "Pronti")
        assertEquals("Scrivi un nome", shelfNameError("  ", others))
        assertEquals("", shelfNameError("Formaggi", others))
        assertTrue(shelfNameError("latticini", others).isNotEmpty())
        assertTrue(shelfNameError("x".repeat(25), others).isNotEmpty())
    }

    @Test fun eliminandoUnRipianoIProdottiVannoInAltro() {
        assertEquals("Altro", shelfAfterDelete(listOf("Pasta", "Altro")))
        assertEquals("Pasta", shelfAfterDelete(listOf("Pasta", "Conserve")))
    }
}
