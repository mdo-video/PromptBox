package com.promptbox

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

class RemindersTest {
    private val zone = ZoneId.of("Europe/Rome")

    // Mercoledì 18 novembre 2026, ore 10:00.
    private val now = ZonedDateTime.of(2026, 11, 18, 10, 0, 0, 0, zone)

    private fun ms(y: Int, m: Int, d: Int, h: Int, min: Int) =
        ZonedDateTime.of(y, m, d, h, min, 0, 0, zone).toInstant().toEpochMilli()

    @Test fun oggiSeLOraNonÈPassata() {
        assertEquals(ms(2026, 11, 18, 18, 0), Reminders.nextRun(18, 0, emptySet(), now))
    }

    @Test fun domaniSeLOraÈPassata() {
        assertEquals(ms(2026, 11, 19, 8, 0), Reminders.nextRun(8, 0, emptySet(), now))
    }

    @Test fun rispettaIGiorniScelti() {
        // Solo lunedì (1): il prossimo è il 23 novembre.
        assertEquals(ms(2026, 11, 23, 9, 0), Reminders.nextRun(9, 0, setOf(1), now))
    }

    @Test fun salvaERilegge() {
        val r = Routine("rt1", "frigo", "🥗 Frigo", 8, 30, setOf(1, 3), "Menù di oggi", true, true)
        assertEquals(r, Reminders.listFromJson(Reminders.listToJson(listOf(r))).single())
    }

    @Test fun etichette() {
        assertEquals("Ogni giorno", Reminders.daysLabel(emptySet()))
        assertEquals("Lun Mer", Reminders.daysLabel(setOf(3, 1)))
        assertEquals("08:05", Reminders.timeLabel(8, 5))
    }
}
