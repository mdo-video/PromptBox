# Regole R8 / ProGuard di Prisma.
# Non rinomino le classi: i messaggi d'errore restano leggibili e si evitano problemi di reflection.
-dontobfuscate

# Il codice dell'app è piccolo: lo tengo tutto. Il risparmio viene dalle librerie (icone, Compose, ecc.).
-keep class com.promptbox.** { *; }

# Archivio cifrato della chiave API (Tink usa la reflection).
-keep class com.google.crypto.tink.** { *; }
-keep class androidx.security.crypto.** { *; }
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
-dontwarn org.joda.time.**
-dontwarn com.google.api.client.**
-dontwarn com.google.crypto.tink.**
