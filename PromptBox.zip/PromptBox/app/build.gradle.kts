plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Il numero dell'esecuzione della CI. In locale vale 1.
val buildNumber = (System.getenv("VERSION_CODE") ?: "1").toInt()

// Prisma 2.0: il contatore delle build riparte da zero. Il versionCode deve però continuare a crescere (Android rifiuta
// un aggiornamento con versionCode più basso, e l'aggiornamento automatico usa il tag "v<versionCode>"), quindi resta
// il numero dell'esecuzione; a ripartire è solo il numero mostrato: versionName = "2.<esecuzione - buildBase>".
// La prima compilazione dopo la 1.102 (esecuzione 103) è la 2.0, poi 2.1, 2.2… Per la 3.0 si cambia major e buildBase.
val majorVersion = 2
val buildBase = 103

android {
    namespace = "com.promptbox"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.promptbox"
        minSdk = 26
        targetSdk = 35
        versionCode = buildNumber
        versionName = "$majorVersion.${(buildNumber - buildBase).coerceAtLeast(0)}"
        buildConfigField("int", "MAJOR_VERSION", "$majorVersion")
        buildConfigField("int", "BUILD_BASE", "$buildBase")
    }

    // Firma fissa: serve perché Android accetti un aggiornamento sopra la versione già installata.
    signingConfigs {
        create("shared") {
            storeFile = file("promptbox.jks")
            storePassword = "promptbox"
            keyAlias = "promptbox"
            keyPassword = "promptbox"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("shared")
        }
        release {
            // Riduce l'APK (toglie il codice e le icone non usate). Se l'app dovesse bloccarsi all'avvio, la prima cosa da provare è rimettere false.
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("shared")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.google.android.gms:play-services-auth:21.2.0")
    implementation("com.google.android.gms:play-services-code-scanner:16.1.0")

    testImplementation("junit:junit:4.13.2")
    // org.json vero per i test sul JVM (su Android c'è già).
    testImplementation("org.json:json:20231013")
}
