# Revisione 92 — verifica
Analisi statica e modifica mirata. Gradle e SDK Android non disponibili nel runtime: compilazione, lint e test JUnit non eseguiti. Workflow prisma-check.yml predisposto per eseguirli su GitHub. Nessuna pubblicazione automatica o modifica al versionCode.

Test aggiornati: lotti distinti, importazione idempotente per ID, prezzi e scadenze indipendenti, fallback AI senza associazione posizionale, UUID.

Limiti: il controllo versione Drive non è atomico; il merge per blocchi resta invariato. Room, DataStore, WorkManager, cifratura end-to-end, diagnostica UI, assistente centrale e altre nuove funzioni della roadmap non implementati. La chiave di firma originale è mantenuta per compatibilità; non pubblicarla in un repository pubblico. Conservare una copia privata e configurare la firma tramite secret prima di una pubblicazione pubblica.

Prima di installare: backup, CI verde, prova aggiornamento su dispositivo secondario, verifica importazione e sincronizzazione. I lotti precedentemente sovrascritti non sono recuperabili automaticamente.
