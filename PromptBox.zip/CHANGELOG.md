# Revisione 92
- Importazioni con lotti distinti e UUID, senza sovrascrivere le scadenze precedenti.
- Smistamento AI con ID di prodotto e destinazioni configurate; fallback locale per risposte non riconosciute.
- Stop alla scrittura Drive se il conflitto persiste al terzo tentativo.
- Test di regressione aggiornati e workflow CI di verifica.
- Versione 2.x mantenuta per compatibilità con il sistema di aggiornamento.
